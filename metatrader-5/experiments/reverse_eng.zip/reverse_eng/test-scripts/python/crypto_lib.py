import os
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad
from base64 import b64decode


def import_key_for_aes_cbc(
    key_data_string, extractable=True, key_usages=("encrypt", "decrypt")
):
    """
    Imports a key for AES-CBC encryption/decryption using PyCryptodome.

    Args:
        key_data_string (str): The key data in base64 encoding.
        extractable (bool, optional): Whether the key is extractable. Defaults to True.
        key_usages (tuple, optional): Allowed key usages (e.g., "encrypt", "decrypt"). Defaults to ("encrypt", "decrypt").

    Returns:
        AES.new: An AES cipher object for encryption/decryption.

    Raises:
        ValueError: If the key string is invalid (not base64 encoded or wrong length).
    """

    # Ensure the key string is a string
    if not isinstance(key_data_string, str):
        raise ValueError("Key data must be a string.")

    # # Decode the base64 string
    # try:
    #     key_data = b64decode(key_data_string)
    # except (TypeError, ValueError) as e:
    #     raise ValueError(f"Invalid key data string: {e}") from e

    key_data = bytes.fromhex(key_data_string)
    # print("key_data: ", key_data)
    # Check if the key length is valid for AES (16, 24, or 32 bytes)
    if len(key_data) not in (16, 24, 32):
        raise ValueError("Invalid key length. AES key must be 16, 24, or 32 bytes.")
    # if len(key_data) != 16:
    #     raise ValueError("Invalid key length. AES key must be 16 bytes.")

    # Import the key (assuming raw format for AES-CBC)
    cipher = AES.new(key_data, AES.MODE_CBC)

    # Additional attributes for compatibility (not directly supported by PyCryptodome)
    cipher.extractable = extractable
    cipher.key_usages = key_usages

    return cipher


# # Example usage
# key_data_string = "your_base64_encoded_key_string"  # Replace with your actual key
# try:
#     key = import_key_for_aes_cbc(key_data_string)
#     print("Imported key object:", key)
# except ValueError as e:
#     print(f"Error importing key: {e}")

# # Usage example for encryption (assuming an initialization vector - IV - is available)
# plain_text = "This is a secret message"
# iv = b"0123456789012345"  # Replace with a random IV (16 bytes for AES)
# cipher_text = pad(plain_text.encode(), AES.block_size)  # Pad the message
# encrypted_data = key.encrypt(iv, cipher_text)
# print("Encrypted data (bytes):", encrypted_data)


def encrypt_aes_cbc(key, data_to_encrypt, iv=None):
    """
    Encrypts data using AES-CBC mode with the provided key.

    Args:
        key (AES.new): The AES cipher object for encryption.
        data_to_encrypt (bytes): The data to encrypt (must be padded to block size).
        iv (bytes, optional): The initialization vector (IV) for CBC mode. Defaults to None (randomly generated).

    Returns:
        bytes: The encrypted data.

    Raises:
        ValueError: If the data length is not a multiple of the block size.
    """

    # Check if the data is bytes
    if not isinstance(data_to_encrypt, bytes):
        raise ValueError("Data to encrypt must be bytes.")

    # Generate a random IV if not provided
    if iv is None:
        iv = os.urandom(AES.block_size)  # Generate random bytes for IV

    # Ensure data is padded to block size
    padded_data = pad(data_to_encrypt, AES.block_size)

    # Encrypt the data with CBC mode
    cipher_text = key.encrypt(iv, padded_data)

    return iv + cipher_text  # Return IV prepended to encrypted data


def decrypt_aes_cbc(key, encrypted_data):
    """
    Decrypts data using AES-CBC mode with the provided key.

    Args:
        key (AES.new): The AES cipher object for decryption.
        encrypted_data (bytes): The encrypted data (including IV).

    Returns:
        bytes: The decrypted data.

    Raises:
        ValueError: If the encrypted data length is not a multiple of the block size or the IV is invalid.
    """

    # Check if the encrypted data is bytes
    if not isinstance(encrypted_data, bytes):
        raise ValueError("Encrypted data must be bytes.")

    # Extract the IV (assuming it's prepended to the encrypted data)
    if len(encrypted_data) < AES.block_size:
        raise ValueError("Invalid encrypted data: missing IV")
    iv = encrypted_data[: AES.block_size]
    cipher_text = encrypted_data[AES.block_size :]

    # Decrypt the data with CBC mode
    decrypted_data = unpad(key.decrypt(iv, cipher_text), AES.block_size)

    return decrypted_data
