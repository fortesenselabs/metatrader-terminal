import asyncio
import aiohttp
import random
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from base64 import b64encode, b64decode
from crypto_lib import import_key_for_aes_cbc, encrypt_aes_cbc, decrypt_aes_cbc
from trade_server import fetch_trade_server_info

block_size = 16
algorithm_name = "AES-CBC"


def encrypt_data(data, key):
    padder = padding.PKCS7(algorithm_name).padder()
    padded_data = padder.update(data) + padder.finalize()

    iv = os.urandom(block_size)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ct = encryptor.update(padded_data) + encryptor.finalize()

    return iv, ct


def decrypt_data(encrypted_data, key):
    iv, ct = encrypted_data
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(ct) + decryptor.finalize()

    unpadder = padding.PKCS7(algorithm_name).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()

    return data


def hex_string_to_bytes(hex_string):
    return bytes.fromhex(hex_string)


def bytes_to_hex_string(byte_array):
    return byte_array.hex()


def ro(hex_string):
    """
    Converts a hexadecimal string to a byte array buffer.

    Args:
        hex_string: The input string in hexadecimal format.

    Returns:
        A byte array buffer representing the converted data.
    """
    byte_array = bytearray()
    for i in range(0, len(hex_string), 2):
        # Extract hex pair and convert to integer
        byte_value = int(hex_string[i : i + 2], 16)
        # Append byte value to the byte array
        byte_array.append(byte_value)
    return bytearray(byte_array)  # Convert to immutable bytearray


def co(e: bytes):
    try:
        # print("e: ", e)
        e = e.hex()
        print("e: ", e)
        key = import_key_for_aes_cbc(e)
        print("Imported key object:", key)
        return key
    except ValueError as e:
        print(f"Error importing key: {e}")


def uo(e, t):
    # o = { name: ql, iv: new Uint8Array(Rl) }
    return encrypt_aes_cbc(t, e)


def ho(e, t):
    # o = { name: ql, iv: new Uint8Array(Rl) }
    return decrypt_aes_cbc(t, e)


def so(text):
    """
    This function applies a transformation to a string.

    Args:
        text: The input string.

    Returns:
        The transformed string.
    """
    result = []
    for char in text:
        char_code = ord(char)
        if char_code == 28:  # ord('(')
            result.append("&")
        elif char_code == 23:  # ord('#')
            result.append("!")
        else:
            result.append(chr(char_code - 1))
    return "".join(result)


def set_string_to_buffer(buffer, string="", start_index=0):
    # Ensure the buffer is provided
    if not buffer:
        return

    # Loop through each character in the string
    for char in string:
        # Get the UTF-16 code of the current character
        char_code = ord(char)

        # Write the UTF-16 code into the buffer at the specified index
        buffer[start_index] = char_code

        # Move to the next index in the buffer
        start_index += 1


def decode_utf8_from_array_buffer(buffer, start_index=0, length=0):
    # Slice the portion of the buffer specified by startIndex and length
    sliced_buffer = buffer[start_index : start_index + length]

    # Convert the sliced buffer to a list of integers
    uint8_array = list(sliced_buffer)

    # Convert the list of integers to a string using UTF-8 decoding
    decoded_string = "".join(chr(byte) for byte in uint8_array)

    # Return the decoded string
    return decoded_string


class TradeServerInfoError(Exception):
    def __init__(self, details):
        super().__init__(f"Trade server info error - Code: {details['code']}")
        self.details = details


class CommandError(Exception):
    def __init__(self, command, code, count):
        super().__init__(
            f"Command error: command {command}, code {code}, count {count}"
        )
        self.command = command
        self.code = code
        self.count = count


class Dc:
    def __init__(self, e, t):
        self.isReady = False
        self.requests = {}
        self.listeners = {}
        self.queues = {}
        self.systemListeners = {}
        self.count = t
        self.count = t
        self.server = e["signal_server"]
        self.token = (
            e["token"]
            if isinstance(e["token"], str)
            else self._set_char_string(e["token"])
        )
        self.apiKey = e["apiKey"]
        self.key_public, self.key_private = None, None
        self.reset()

    def _set_char_string(self, token):
        t = bytearray(64)
        t[: len(token)] = bytes(token, "utf-8")
        return bytes(t)

    async def connect_to_server(self):
        self.isReady = False

        try:
            self.key_public, self.key_private = await asyncio.gather(
                co(ro(self.apiKey)),
                co(
                    ro(
                        so(
                            "13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75"
                        )
                    )
                ),
            )
        except:
            pass

        try:
            self.ws = await self._create_websocket()
            self.ws_binary = await self.ws.to_binary()
            await self._send_command(0, self.token)
        except Exception as e:
            raise TradeServerInfoError(
                {"code": 100, "command": -1, "count": self.count}
            )
        return self

    async def _fetch_key(self, key):
        if key:
            return await co(ro(key))
        return None

    async def _create_websocket(self):
        try:
            self.ws = await aiohttp.ClientSession().ws_connect(f"wss://{self.server}")
            self.ws.binary_type = aiohttp.WSMsgType.BINARY
            self.ws.on_message(self.on_message)
            self.ws.on_close(self.on_close)
            self.ws.on_error(self.on_error)
            self.ws.on_open(self.on_open)
        except Exception as e:
            raise TradeServerInfoError(
                {"code": 100, "command": -1, "count": self.count}
            )
        return self.ws

    # async def _send_command(self, e, t, o=True, n=False):
    async def send_command(self, command_id, data=None, encrypt=True, resend=False):
        # Implementation of _send_command method
        if command_id not in self.valid_commands:
            raise CommandError(
                command_id, 102, self.count
            )  # Replace count with appropriate tracking

        key = self.key_private if command_id == 0 else self.key_public
        packet = self.create_packet(command_id, data)

        # Replace uo and this.send with your actual network communication functions
        response = await self.send(packet, key, encrypt)

        if response.res_code != 0:
            raise CommandError(command_id, response.res_code, self.count)

        return response

    async def close(self, e=False):
        # Implementation of close method
        pass

    def on_message(self, e):
        # Implementation of on_message method
        pass

    def on_close(self, e):
        # Implementation of on_close method
        pass

    def on_error(self, e):
        # Implementation of on_error method
        pass

    def on_open(self):
        # Implementation of on_open method
        pass

    def on_parse(self, e):
        # Implementation of on_parse method
        pass

    def on_timeout(self, e):
        # Implementation of on_timeout method
        pass

    def on(self, e, t):
        # Implementation of on method
        pass

    def off(self, e, t):
        # Implementation of off method
        pass

    def subscribe(self, e, t):
        # Implementation of subscribe method
        pass

    def unsubscribe(self, e, t):
        # Implementation of unsubscribe method
        pass

    def system_trigger(self, e, t):
        # Implementation of system_trigger method
        pass

    def reset(self):
        # Implementation of reset method
        pass

    async def send_request(self, e):
        # Implementation of send_request method
        pass

    def check_queue(self, e):
        # Implementation of check_queue method
        pass

    def trigger(self, e, t):
        # Implementation of trigger method
        pass


async def main():
    # ... (server_info and counter definitions) ...
    counter = 1

    try:
        server_info = fetch_trade_server_info(
            "terminal/json", "Deriv-Demo", login=30565290
        )
        server_info["apiKey"] = server_info["key"]
        print(server_info)

        # Create an aiohttp client session
        async with aiohttp.ClientSession() as session:
            dc_client = Dc(server_info, counter)

            # Start the event loop and set it for aiohttp
            # loop = session.loop
            # asyncio.set_event_loop(loop)

            # Get the event loop
            loop = asyncio.get_event_loop()

            # Use the session for the websocket connection in connect_to_server
            await dc_client.connect_to_server()

            # ... (interaction logic) ...

    except TradeServerInfoError as e:
        print(f"Error connecting to server: {e}")

    # Close the event loop (optional)
    # loop.close()


if __name__ == "__main__":
    asyncio.run(main())
