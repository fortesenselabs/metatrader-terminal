import requests
from typing import Optional

BASE_URL = "https://mt5-demo-web.deriv.com"


class TradeServerInfoError(Exception):
    def __init__(self, details: dict):
        super().__init__(f"Trade server info error - Code: {details['code']}")
        self.details = details


def fetch_trade_server_info(
    url: str, trade_server: str, login: Optional[int] = None
) -> dict:
    try:
        data = {"trade_server": trade_server, "version": "5"}
        if login is not None:
            data["login"] = str(login)

        response = requests.post(f"{BASE_URL}/{url}", data=data)
        response.raise_for_status()

    except requests.exceptions.RequestException as e:
        raise TradeServerInfoError({"code": 100, "command": -1, "count": -1})

    if response.status_code != 200:
        if response.status_code == 503:
            raise TradeServerInfoError({"code": 503, "command": -1, "count": -1})
        raise TradeServerInfoError({"code": 1000, "command": -1, "count": -1})

    server_info = response.json()

    return {
        "company": server_info["company"],
        "enabled": server_info["enabled"],
        "key": server_info["key"],
        "login": server_info["login"],
        "signal_server": server_info["signal_server"],
        "trade_server": server_info["trade_server"],
        "version": server_info["version"],
        "token": server_info["token"],
    }


# Example usage:
# try:
#     trade_server_info = fetch_trade_server_info(
#         "terminal/json", "Deriv-Demo", login=30565290
#     )
#     print(trade_server_info)
# except TradeServerInfoError as e:
#     print(f"Error: {e}")
