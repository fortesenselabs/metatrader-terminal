import os
from typing import List, Tuple, Union
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

backend = default_backend()
block_size = 16
algorithm_name = algorithms.AES


def count_accounts_of_type(accounts: List[dict], type: int) -> int:
    has_type = any(account["account_type"] == type for account in accounts)
    has_other_type = any(account["account_type"] != type for account in accounts)
    return (
        1
        if has_type and not has_other_type
        else 0 if not has_type and has_other_type else -1
    )


def filter_accounts_by_type(
    accounts: List[dict], type: int, include: bool
) -> List[dict]:
    return (
        accounts
        if count_accounts_of_type(accounts, type) != -1
        else [
            account
            for account in accounts
            if (include and is_of_type(account))
            or (not include and not is_of_type(account))
        ]
    )


def is_of_type(account: dict) -> bool:
    return account["account_type"] == 2


def filter_accounts_by_real_status(
    accounts: List[dict], is_real: bool, country: Union[str, None] = None
) -> List[dict]:
    return [
        account
        for account in accounts
        if (bool(account.get("real")) == is_real)
        and (not country or country in account.get("countries", []))
    ]


def hex_string_to_bytes(hex_string: str) -> bytes:
    return bytes.fromhex(hex_string)


def bytes_to_hex_string(byte_array: bytes) -> str:
    return byte_array.hex()


def encrypt_data(data: bytes, key: bytes) -> bytes:
    iv = os.urandom(block_size)
    cipher = Cipher(algorithm_name(key), modes.CBC(iv), backend=backend)
    encryptor = cipher.encryptor()
    padded_data = pad_data(data)
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    return iv + encrypted_data


def decrypt_data(encrypted_data: bytes, key: bytes) -> bytes:
    iv = encrypted_data[:block_size]
    encrypted_data = encrypted_data[block_size:]
    cipher = Cipher(algorithm_name(key), modes.CBC(iv), backend=backend)
    decryptor = cipher.decryptor()
    decrypted_data = decryptor.update(encrypted_data) + decryptor.finalize()
    return unpad_data(decrypted_data)


# Padding functions
def pad_data(data: bytes) -> bytes:
    pad_length = block_size - (len(data) % block_size)
    padding = bytes([pad_length]) * pad_length
    return data + padding


def unpad_data(data: bytes) -> bytes:
    pad_length = data[-1]
    return data[:-pad_length]


# Example usage:
# key = os.urandom(32)  # 256-bit key
# encrypted_data = encrypt_data(b"Secret message", key)
# decrypted_data = decrypt_data(encrypted_data, key)
# print(decrypted_data.decode("utf-8"))
