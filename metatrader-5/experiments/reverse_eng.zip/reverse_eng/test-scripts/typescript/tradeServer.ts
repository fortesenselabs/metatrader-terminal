// the REST request function: async function tn(e, t, o) in 00a24b22.js file
//
// class a extends n in file 04a8e93f.js contains the usage of the function, where the function is now called o in the file. Then function on(e, t) in 00a24b22.js in called r in the same file
// r(TradeServerInfo, count=1)
//
async function fetchTradeServerInfo(
  url: string,
  tradeServer: string,
  login?: number
): Promise<TradeServerInfo> {
  let response: Response;
  try {
    const formData = new URLSearchParams();
    formData.append("trade_server", tradeServer);
    formData.append("version", "5");
    if (login) formData.append("login", String(login));

    response = await fetch(url, {
      method: "POST",
      mode: "cors",
      cache: "no-cache",
      body: formData,
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
  } catch (error) {
    throw new TradeServerInfoError({ code: 100, command: -1, count: -1 });
  }

  if (response.status !== 200) {
    if (response.status === 503)
      throw new TradeServerInfoError({ code: 503, command: -1, count: -1 });
    throw new TradeServerInfoError({ code: 1000, command: -1, count: -1 });
  }

  const serverInfo: TradeServerInfo = await response.json();

  return {
    company: serverInfo.company,
    enabled: serverInfo.enabled,
    key: serverInfo.key,
    login: serverInfo.login,
    signal_server: serverInfo.signal_server,
    trade_server: serverInfo.trade_server,
    version: serverInfo.version,
    token: serverInfo.token,
  };
}

interface TradeServerInfo {
  company: string;
  enabled: boolean;
  key: string;
  login: number;
  signal_server: string;
  trade_server: string;
  version: number;
  token: string;
}

class TradeServerInfoError extends Error {
  constructor(public details: TradeServerInfoErrorDetails) {
    super(`Trade server info error - Code: ${details.code}`);
  }
}

interface TradeServerInfoErrorDetails {
  code: number;
  command: number;
  count: number;
}
