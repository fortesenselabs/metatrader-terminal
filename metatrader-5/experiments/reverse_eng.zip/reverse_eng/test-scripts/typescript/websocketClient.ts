// Dc class in 00a24b22.js file
//
// 1. **Property Initialization**:
//    - `this.isReady`, `this.requests`, `this.listeners`, `this.queues`, and `this.systemListeners` are initialized with default values (`false` for `isReady` and new `Map()` instances for the rest).

// 2. **Count Assignment**:
//    - `this.count` is set to `0` initially and then reassigned to the value of `t` provided as an argument.

// 3. **Server Information**:
//    - `this.server` is assigned the value of `e.signal_server`.

// 4. **Token Handling**:
//    - If `e.token` is a string, it's converted into a 64-byte ArrayBuffer using a function (`Oc.setCharString`) and assigned to `this.token`.
//    - If `e.token` is already an ArrayBuffer, it's directly assigned to `this.token`.

// 5. **API Key Assignment**:
//    - `this.apiKey` is assigned the value of `e.apiKey`.

// 6. **Initialization Reset**:
//    - `this.reset()` is called, presumably to reset any internal state or configurations.

// 7. **Binding Event Handlers**:
//    - Event handler methods (`onMessage`, `onParse`, `onClose`, `onTimeout`, `onError`, `onOpen`) are bound to the current instance of the class (`this`) using `bind(this)`.

function setStringToBuffer(buffer, str = "", startIndex = 0) {
  // Ensure the buffer is provided
  if (!buffer) return;

  // Create a DataView for the buffer
  const dataView = new DataView(buffer);

  // Loop through each character in the string
  for (let charIndex = 0; charIndex < str.length; charIndex++) {
    // Get the UTF-16 code of the current character
    const charCode = str.charCodeAt(charIndex);

    // Write the UTF-16 code into the buffer at the specified index
    dataView.setInt8(startIndex, charCode);

    // Move to the next index in the buffer
    startIndex += 1;
  }
}

function decodeUtf8FromArrayBuffer(buffer, startIndex = 0, length = 0) {
  // Slice the portion of the buffer specified by startIndex and length
  const slicedBuffer = buffer.slice(startIndex, startIndex + length);

  // Create a Uint8Array from the sliced buffer
  const uint8Array = new Uint8Array(slicedBuffer);

  // Convert the Uint8Array to a string using UTF-8 decoding
  const decodedString = String.fromCharCode(...uint8Array);

  // Return the decoded string
  return decodedString;
}

class WebSocketClient {
  isReady: boolean = false;
  requests: Map<number, PendingRequest> = new Map();
  listeners: Map<number, Set<Function>> = new Map();
  queues: Map<number, PendingRequest[]> = new Map();
  systemListeners: Map<string, Set<Function>> = new Map();
  count: number;

  constructor(serverInfo: ServerInfo, count: number) {
    this.count = count;
    this.init(serverInfo);
  }

  async init(serverInfo: ServerInfo) {
    this.prepareKeys(serverInfo.token, serverInfo.apiKey);
    await this.connectToServer(serverInfo.signalServer);
  }

  async connectToServer(serverUrl: string) {
    // Implementation
  }

  prepareKeys(token: string | ArrayBuffer, apiKey: string) {
    // Implementation
  }

  async sendCommand(
    command: number,
    data: ArrayBuffer,
    isPrivate: boolean = false,
    isRetry: boolean = false
  ): Promise<Response> {
    // Implementation
  }

  // Other methods...
}

interface ServerInfo {
  signalServer: string;
  token: string | ArrayBuffer;
  apiKey: string;
}

interface Response {
  resCode: number;
  resBody: ArrayBuffer;
}

class PendingRequest {
  constructor(
    public command: number,
    public buffer: ArrayBuffer,
    public promise: Promise<Response>,
    public rejectPromise: (error: Error) => void
  ) {}

  onTimeout(timeoutCallback: (request: PendingRequest) => void) {
    // Implementation
  }
}

class ErrorEvent {
  constructor(
    public code: number,
    public command: number,
    public count: number
  ) {}
}

class WebSocketEvent {
  constructor(public resCode: number, public resBody: ArrayBuffer) {}
}

enum WebSocketEventType {
  Open,
  Close,
  Error,
}
