const cryptoAPI = window.crypto || (window as any).msCrypto;
const subtleCrypto =
  (cryptoAPI && (cryptoAPI.subtle || cryptoAPI.webkitSubtle)) || null;
const blockSize = 16;
const algorithmName: "AES-CBC" = "AES-CBC";

function countAccountsOfType(
  accounts: { account_type: number }[],
  type: number
): number {
  const hasType = accounts.some((account) => account.account_type === type);
  const hasOtherType = accounts.some(
    (account) => account.account_type !== type
  );
  return hasType && !hasOtherType ? 1 : !hasType && hasOtherType ? 0 : -1;
}

function filterAccountsByType(
  accounts: { account_type: number }[],
  type: number,
  include: boolean
): { account_type: number }[] {
  return countAccountsOfType(accounts, type) !== -1
    ? accounts
    : accounts.filter((account) =>
        include ? isOfType(account) : !isOfType(account)
      );
}

function isOfType(account: { account_type: number }): boolean {
  return account.account_type === 2;
}

function filterAccountsByRealStatus(
  accounts: { real?: boolean; countries: string[] }[],
  isReal: boolean,
  country?: string
): { real?: boolean; countries: string[] }[] {
  return accounts.filter((account) => {
    const matchesRealStatus = Boolean(account.real) === isReal;
    return country && account.countries.length
      ? matchesRealStatus && account.countries.includes(country)
      : matchesRealStatus;
  });
}

function hexStringToBuffer(hexString: string): ArrayBuffer {
  const byteArray: number[] = [];
  for (let i = 0; i < hexString.length / 2; i++) {
    byteArray.push(Number(`0x${hexString.substring(2 * i, 2 * i + 2)}`));
  }
  return new Uint8Array(byteArray).buffer;
}

function bufferToHexString(buffer: ArrayBuffer): string {
  const hexArray: String[] = [];
  const dataView = new DataView(buffer);
  for (let i = 0; i < buffer.byteLength; i++) {
    let hex: String = dataView.getUint8(i).toString(16);
    hex.length < 2 && (hex = ["0", hex].join(""));
    hexArray.push(hex);
  }
  return hexArray.join("");
}

async function importKeyFromRaw(rawKey: ArrayBuffer): Promise<CryptoKey> {
  if (!subtleCrypto) throw new Error("Error initializing crypto API");
  const algorithm: AlgorithmIdentifier = { name: algorithmName };
  return subtleCrypto.importKey("raw", rawKey, algorithm, true, [
    "encrypt",
    "decrypt",
  ]);
}

function encryptData(data: ArrayBuffer, key: CryptoKey): Promise<ArrayBuffer> {
  const options: AesCbcParams = {
    name: algorithmName,
    iv: new Uint8Array(blockSize),
  };
  return subtleCrypto.encrypt(options, key, data);
}

function decryptData(
  encryptedData: ArrayBuffer,
  key: CryptoKey
): Promise<ArrayBuffer> {
  const options: AesCbcParams = {
    name: algorithmName,
    iv: new Uint8Array(blockSize),
  };
  return subtleCrypto.decrypt(options, key, encryptedData);
}

// function generateUniqueIdentifier(): string {
//   const { name } = window;
//   if (name && Boolean(name.split("").find((char) => isNaN(parseInt(char, 10)))))
//     return name.substring(0, 12);
//   let cookie = document.cookie;
//   if (
//     cookie &&
//     ((cookie = cookie
//       .split(";")
//       .find((entry) => entry.trim().startsWith("uniq="))),
//     cookie && ((cookie = cookie.split("=")[1]), cookie))
//   ) {
//     const parts = cookie.split("-");
//     if (parts.length === 1 && parts[0].length >= 12)
//       return parts[0].substring(0, 12);
//     if (parts.length > 1) return parts[0] + parts[1];
//   }
//   return "";
// }
