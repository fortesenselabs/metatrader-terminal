function e(e, t, a) {
  const n = e.slice();
  return (n[19] = t[a]), n;
}
function t(t) {
  let n,
    o,
    s,
    r,
    i,
    _,
    l,
    c,
    E,
    m,
    u,
    d,
    p,
    I,
    h,
    A,
    R,
    L,
    P,
    N,
    g,
    S,
    D,
    T,
    f,
    O,
    $,
    V = $e(Object.keys(t[6]).sort()),
    b = [];
  for (let H = 0; H < V.length; H += 1) b[H] = a(e(t, V, H));
  return {
    c() {
      (n = he("div")),
        (o = he("input")),
        (s = Ae()),
        (r = he("label")),
        (i = he("input")),
        (_ = Ve("\r\n                    Show Tags")),
        (l = Ae()),
        (c = he("label")),
        (E = he("input")),
        (m = Ve("\r\n                    Show Date")),
        (u = Ae()),
        (d = he("label")),
        (p = he("input")),
        (I = Ve("\r\n                    Show Secondary")),
        (h = Ae()),
        (A = he("label")),
        (R = he("input")),
        (L = Ve("\r\n                    Show Repeat")),
        (P = Ae()),
        (N = he("div")),
        (g = he("button")),
        (g.textContent = "Select All"),
        (S = Ae()),
        (D = he("button")),
        (D.textContent = "Clear All"),
        (T = Ae()),
        (f = he("div"));
      for (let e = 0; e < b.length; e += 1) b[e].c();
      Re(o, "class", "filter svelte-1feil8p"),
        be(i, "checkbox"),
        Re(i, "class", "svelte-1feil8p"),
        be(E, "checkbox"),
        Re(E, "class", "svelte-1feil8p"),
        be(p, "checkbox"),
        Re(p, "class", "svelte-1feil8p"),
        be(R, "checkbox"),
        Re(R, "class", "svelte-1feil8p"),
        Re(n, "class", "config svelte-1feil8p"),
        Re(N, "class", "controls svelte-1feil8p"),
        Re(f, "class", "tags svelte-1feil8p");
    },
    m(e, a) {
      Pe(e, n, a),
        Ne(n, o),
        He(o, t[5]),
        Ne(n, s),
        Ne(n, r),
        Ne(r, i),
        (i.checked = t[1]),
        Ne(r, _),
        Ne(n, l),
        Ne(n, c),
        Ne(c, E),
        (E.checked = t[2]),
        Ne(c, m),
        Ne(n, u),
        Ne(n, d),
        Ne(d, p),
        (p.checked = t[3]),
        Ne(d, I),
        Ne(n, h),
        Ne(n, A),
        Ne(A, R),
        (R.checked = t[4]),
        Ne(A, L),
        Pe(e, P, a),
        Pe(e, N, a),
        Ne(N, g),
        Ne(N, S),
        Ne(N, D),
        Pe(e, T, a),
        Pe(e, f, a);
      for (let t = 0; t < b.length; t += 1) b[t] && b[t].m(f, null);
      O ||
        (($ = [
          ge(o, "input", t[12]),
          ge(i, "change", t[13]),
          ge(E, "change", t[14]),
          ge(p, "change", t[15]),
          ge(R, "change", t[16]),
          ge(g, "click", t[9]),
          ge(D, "click", t[10]),
        ]),
        (O = !0));
    },
    p(t, n) {
      if (
        (32 & n && o.value !== t[5] && He(o, t[5]),
        2 & n && (i.checked = t[1]),
        4 & n && (E.checked = t[2]),
        8 & n && (p.checked = t[3]),
        16 & n && (R.checked = t[4]),
        321 & n)
      ) {
        let o;
        for (V = $e(Object.keys(t[6]).sort()), o = 0; o < V.length; o += 1) {
          const s = e(t, V, o);
          b[o] ? b[o].p(s, n) : ((b[o] = a(s)), b[o].c(), b[o].m(f, null));
        }
        for (; o < b.length; o += 1) b[o].d(1);
        b.length = V.length;
      }
    },
    d(e) {
      e && (Se(n), Se(P), Se(N), Se(T), Se(f)), we(b, e), (O = !1), Ce($);
    },
  };
}
function a(e) {
  function t() {
    return e[17](e[19]);
  }
  let a,
    n,
    o,
    s,
    r,
    i = e[19] + "";
  return {
    c() {
      (a = he("div")),
        (n = Ve(i)),
        Re(a, "class", "tag svelte-1feil8p"),
        Re(a, "style", (o = e[8](e[19])));
    },
    m(e, o) {
      Pe(e, a, o), Ne(a, n), s || ((r = ge(a, "click", t)), (s = !0));
    },
    p(t, s) {
      (e = t),
        64 & s && i !== (i = e[19] + "") && je(n, i),
        64 & s && o !== (o = e[8](e[19])) && Re(a, "style", o);
    },
    d(e) {
      e && Se(a), (s = !1), r();
    },
  };
}
function n(e) {
  let a,
    n,
    o,
    s,
    r,
    i,
    _ = e[7] && t(e);
  return {
    c() {
      (a = he("div")),
        (n = he("div")),
        (o = he("div")),
        (o.textContent = "l"),
        (s = Ae()),
        _ && _.c(),
        Re(o, "class", "button svelte-1feil8p"),
        Re(n, "class", "buttons svelte-1feil8p"),
        Re(a, "class", "debug svelte-1feil8p"),
        Le(a, "hidden", !e[7]);
    },
    m(t, l) {
      Pe(t, a, l),
        Ne(a, n),
        Ne(n, o),
        Ne(a, s),
        _ && _.m(a, null),
        r || ((i = ge(o, "click", e[11])), (r = !0));
    },
    p(e, n) {
      e[7]
        ? _
          ? _.p(e, n)
          : ((_ = t(e)), _.c(), _.m(a, null))
        : _ && (_.d(1), (_ = null)),
        128 & n && Le(a, "hidden", !e[7]);
    },
    d(e) {
      e && Se(a), _ && _.d(), (r = !1), i();
    },
  };
}
function o(e) {
  let t, a;
  return (
    (t = new _e({ props: { $$slots: { default: [n] }, $$scope: { ctx: e } } })),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p(e, [a]) {
        const n = {};
        4194558 & a && (n.$$scope = { dirty: a, ctx: e }), t.$set(n);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function s(e, t, a) {
  function n(e) {
    const t = fe.indexOf(e);
    !0 === Ie[e]
      ? -1 !== t && (fe.splice(t, 1), a(6, (Ie[e] = !1), Ie))
      : (-1 === t && fe.push(e), a(6, (Ie[e] = !0), Ie)),
      Oe();
  }
  const o = de.getItem("journal") || "10";
  let s = !1,
    r = "1" === o[0],
    i = "1" === o[1],
    _ = "1" === o[2],
    l = "1" === o[3],
    c = de.getItem("f") ?? "";
  return (
    (e.$$.update = () => {
      62 & e.$$.dirty && pe(r, i, _, l, c);
    }),
    [
      n,
      r,
      i,
      _,
      l,
      c,
      Ie,
      s,
      function (e) {
        const t = De(e, !1 === Ie[e]),
          a = Te(t);
        return `background-color: rgba(${t.join(",")}); color: ${a};`;
      },
      function () {
        fe.splice(0, fe.length),
          Object.keys(Ie).forEach((e) => {
            a(6, (Ie[e] = !0), Ie), fe.push(e);
          }),
          Oe();
      },
      function () {
        fe.splice(0, fe.length),
          Object.keys(Ie).forEach((e) => {
            a(6, (Ie[e] = !1), Ie);
          }),
          Oe();
      },
      () => {
        a(7, (s = !s));
      },
      function () {
        (c = this.value), a(5, c);
      },
      function () {
        (r = this.checked), a(1, r);
      },
      function () {
        (i = this.checked), a(2, i);
      },
      function () {
        (_ = this.checked), a(3, _);
      },
      function () {
        (l = this.checked), a(4, l);
      },
      (e) => n(e),
    ]
  );
}
async function r() {
  return [
    await Ge(
      () => import("./ccc2ef3d.js"),
      [
        "ccc2ef3d.js",
        "00a24b22.js",
        "6f913017.css",
        "f54151ac.js",
        "02c71ccc.css",
        "917f94f7.js",
        "7313b880.css",
        "e7dc6a23.css",
      ]
    ),
    await Ge(
      () => import("./909eee49.js"),
      [
        "909eee49.js",
        "00a24b22.js",
        "6f913017.css",
        "917f94f7.js",
        "f54151ac.js",
        "02c71ccc.css",
        "7313b880.css",
        "22a7d1db.js",
        "3b0e4f82.css",
      ]
    ),
    await Ge(
      () => import("./86c0952e.js"),
      [
        "86c0952e.js",
        "00a24b22.js",
        "6f913017.css",
        "6548fd75.js",
        "f54151ac.js",
        "02c71ccc.css",
        "d394a3e3.js",
        "10761cfa.js",
        "917f94f7.js",
        "7313b880.css",
        "c47cc20c.css",
        "f1661fb5.css",
        "f99b83fe.css",
        "972f387d.css",
      ]
    ),
    await Ge(
      () => import("./739e34b2.js"),
      [
        "739e34b2.js",
        "00a24b22.js",
        "6f913017.css",
        "917f94f7.js",
        "f54151ac.js",
        "02c71ccc.css",
        "7313b880.css",
        "af21b248.js",
        "113fef4e.css",
        "712ebc32.js",
        "c697aa44.css",
        "ccc2ef3d.js",
        "e7dc6a23.css",
        "3278e24d.js",
        "d394a3e3.js",
        "10761cfa.js",
        "c47cc20c.css",
        "f1661fb5.css",
        "d09b99f6.js",
        "22a7d1db.js",
        "f60bb92f.js",
        "a4b22e5d.js",
        "a3b77070.css",
        "883cebe6.css",
        "7277e82c.css",
        "6548fd75.js",
        "f99b83fe.css",
        "716cdfe4.js",
        "35bf0960.css",
        "3719adfe.css",
      ]
    ),
  ];
}
async function i() {
  await (async function () {
    return [
      await Ge(() => import("./7953a2e8.js"), []),
      await Ge(
        () => import("./909a8246.js"),
        [
          "909a8246.js",
          "00a24b22.js",
          "6f913017.css",
          "917f94f7.js",
          "f54151ac.js",
          "02c71ccc.css",
          "7313b880.css",
          "04a8e93f.js",
        ]
      ),
      await Ge(
        () => import("./25029c36.js").then((e) => e.m),
        [
          "25029c36.js",
          "00a24b22.js",
          "6f913017.css",
          "d09b99f6.js",
          "917f94f7.js",
          "f54151ac.js",
          "02c71ccc.css",
          "7313b880.css",
          "f60bb92f.js",
          "a4b22e5d.js",
          "a3b77070.css",
          "883cebe6.css",
          "3049ce3f.js",
        ]
      ),
    ];
  })(),
    await (async function () {
      return [
        await Ge(
          () => import("./cddfd7eb.js"),
          [
            "cddfd7eb.js",
            "00a24b22.js",
            "6f913017.css",
            "3278e24d.js",
            "f54151ac.js",
            "02c71ccc.css",
            "d394a3e3.js",
            "10761cfa.js",
            "917f94f7.js",
            "7313b880.css",
            "c47cc20c.css",
            "f1661fb5.css",
            "712ebc32.js",
            "c697aa44.css",
            "d09b99f6.js",
            "22a7d1db.js",
            "f60bb92f.js",
            "a4b22e5d.js",
            "a3b77070.css",
            "883cebe6.css",
            "af21b248.js",
            "113fef4e.css",
            "7277e82c.css",
            "3049ce3f.js",
            "01251fd4.css",
          ]
        ),
        await Ge(
          () => import("./7198716e.js"),
          [
            "7198716e.js",
            "00a24b22.js",
            "6f913017.css",
            "712ebc32.js",
            "c697aa44.css",
            "f54151ac.js",
            "02c71ccc.css",
            "917f94f7.js",
            "7313b880.css",
            "10761cfa.js",
            "c47cc20c.css",
            "8e8d55d7.css",
          ]
        ),
        await Ge(
          () => import("./716cdfe4.js").then((e) => e.j),
          [
            "716cdfe4.js",
            "00a24b22.js",
            "6f913017.css",
            "10761cfa.js",
            "917f94f7.js",
            "f54151ac.js",
            "02c71ccc.css",
            "7313b880.css",
            "c47cc20c.css",
            "35bf0960.css",
          ]
        ),
      ];
    })(),
    await r();
}
async function _() {
  await i(),
    await (async function () {
      await r();
    })(),
    await (async function () {
      return [
        await Ge(
          () => import("./42f624f0.js"),
          ["42f624f0.js", "00a24b22.js", "6f913017.css", "04a8e93f.js"]
        ),
        await Ge(
          () => import("./d35b1395.js"),
          ["d35b1395.js", "00a24b22.js", "6f913017.css", "3d7bfa54.css"]
        ),
        await Ge(
          () => import("./b38e25e8.js"),
          ["b38e25e8.js", "00a24b22.js", "6f913017.css", "981398f2.css"]
        ),
        await Ge(
          () => import("./00a24b22.js").then((e) => e.cM),
          ["00a24b22.js", "6f913017.css"]
        ),
        await Ge(
          () => import("./3c5839d5.js"),
          ["3c5839d5.js", "00a24b22.js", "6f913017.css", "96f8c273.css"]
        ),
      ];
    })();
}
function l() {
  if (yt.length) return yt;
  try {
    const e = new Intl.DisplayNames(["en"], { type: "region" });
    yt = Gt.map(([t]) => e.of(t) || "");
  } catch (e) {
    yt = Gt.map(([, , , , e]) => e);
  }
  return yt.sort(), yt;
}
function c(e) {
  let t = "";
  try {
    t = new Intl.DisplayNames(["en"], { type: "region" }).of(e) || e;
  } catch (a) {
    const n = Gt.find((t) => t[0] === e);
    t = (null == n ? void 0 : n[4]) || e;
  }
  return t;
}
function E() {
  if (kt.length) return kt;
  try {
    const e = new Intl.DisplayNames(["en"], { type: "language" });
    kt = Object.values(jt).map((t) => ("dv" === t ? "Divehi" : e.of(t) || ""));
  } catch (e) {
    kt = Object.keys(jt).map((e) => e[0] + e.slice(1).toLowerCase());
  }
  return kt.sort(), kt;
}
function m(e) {
  let t,
    a,
    n,
    o,
    s = Qe(e[3].url) + "";
  return {
    c() {
      (t = he("div")),
        (t.textContent = `${e[3].name}`),
        (a = Ae()),
        (n = he("a")),
        (o = Ve(s)),
        Re(t, "class", "name svelte-b6pr98"),
        Re(n, "class", "link svelte-b6pr98"),
        Re(n, "href", e[3].url),
        Re(n, "target", "_blank"),
        Re(n, "rel", "noreferrer");
    },
    m(e, s) {
      Pe(e, t, s), Pe(e, a, s), Pe(e, n, s), Ne(n, o);
    },
    p: ze,
    d(e) {
      e && (Se(t), Se(a), Se(n));
    },
  };
}
function u(e) {
  let t, a, n;
  return {
    c() {
      (t = he("div")),
        (t.textContent = `${window.tr(
          window.lang.login.demo.accountOpeningWarning,
          { brokerName: e[3].name }
        )}`),
        (a = Ae()),
        (n = he("div")),
        (n.textContent = `${window.tr(
          window.lang.login.demo.tradeWithRealMoney
        )}`),
        Re(t, "class", "text svelte-b6pr98"),
        Re(n, "class", "text svelte-b6pr98");
    },
    m(e, o) {
      Pe(e, t, o), Pe(e, a, o), Pe(e, n, o);
    },
    p: ze,
    d(e) {
      e && (Se(t), Se(a), Se(n));
    },
  };
}
function d(e) {
  let t,
    a = window.tr(window.lang.login.demo.btnOpenDemo) + "";
  return {
    c() {
      t = Ve(a);
    },
    m(e, a) {
      Pe(e, t, a);
    },
    p: ze,
    d(e) {
      e && Se(t);
    },
  };
}
function p(e) {
  let t, a;
  return (
    (t = new qe({
      props: {
        style: "padding: 0 var(--indent2)",
        active: !0,
        $$slots: { default: [d] },
        $$scope: { ctx: e },
      },
    })),
    t.$on("click", e[5]),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p(e, a) {
        const n = {};
        1024 & a && (n.$$scope = { dirty: a, ctx: e }), t.$set(n);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function I(e) {
  let t, a;
  return (
    (t = new et({ props: { overlay: !0 } })),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function h(e) {
  var t;
  let a, n;
  return (
    (a = new tt({
      props: {
        message: e[1].message,
        warning: "warning" === (null == (t = e[1]) ? void 0 : t.type),
      },
    })),
    {
      c() {
        le(a.$$.fragment);
      },
      m(e, t) {
        ce(a, e, t), (n = !0);
      },
      p(e, t) {
        var n;
        const o = {};
        2 & t && (o.message = e[1].message),
          2 & t &&
            (o.warning = "warning" === (null == (n = e[1]) ? void 0 : n.type)),
          a.$set(o);
      },
      i(e) {
        n || (Ee(a.$$.fragment, e), (n = !0));
      },
      o(e) {
        me(a.$$.fragment, e), (n = !1);
      },
      d(e) {
        ue(a, e);
      },
    }
  );
}
function A(e) {
  let t, a, n, o, s, r, i, _, l, c;
  (a = new ve({
    props: {
      gap: "0",
      marginBottom: "2",
      $$slots: { default: [m] },
      $$scope: { ctx: e },
    },
  })),
    (o = new ve({
      props: {
        marginBottom: "2",
        $$slots: { default: [u] },
        $$scope: { ctx: e },
      },
    })),
    (r = new ve({
      props: {
        style: e[0] ? "" : "justify-content: end;",
        $$slots: { default: [p] },
        $$scope: { ctx: e },
      },
    }));
  let E = e[2] && I(),
    d = e[1] && h(e);
  return {
    c() {
      (t = he("div")),
        le(a.$$.fragment),
        (n = Ae()),
        le(o.$$.fragment),
        (s = Ae()),
        le(r.$$.fragment),
        (i = Ae()),
        E && E.c(),
        (_ = Ae()),
        d && d.c(),
        (l = Me()),
        Re(t, "class", "content svelte-b6pr98");
    },
    m(e, m) {
      Pe(e, t, m),
        ce(a, t, null),
        Ne(t, n),
        ce(o, t, null),
        Ne(t, s),
        ce(r, t, null),
        Ne(t, i),
        E && E.m(t, null),
        Pe(e, _, m),
        d && d.m(e, m),
        Pe(e, l, m),
        (c = !0);
    },
    p(e, n) {
      const s = {};
      1024 & n && (s.$$scope = { dirty: n, ctx: e }), a.$set(s);
      const i = {};
      1024 & n && (i.$$scope = { dirty: n, ctx: e }), o.$set(i);
      const _ = {};
      1 & n && (_.style = e[0] ? "" : "justify-content: end;"),
        1024 & n && (_.$$scope = { dirty: n, ctx: e }),
        r.$set(_),
        e[2]
          ? E
            ? 4 & n && Ee(E, 1)
            : ((E = I()), E.c(), Ee(E, 1), E.m(t, null))
          : E &&
            (Be(),
            me(E, 1, 1, () => {
              E = null;
            }),
            Fe()),
        e[1]
          ? d
            ? (d.p(e, n), 2 & n && Ee(d, 1))
            : ((d = h(e)), d.c(), Ee(d, 1), d.m(l.parentNode, l))
          : d &&
            (Be(),
            me(d, 1, 1, () => {
              d = null;
            }),
            Fe());
    },
    i(e) {
      c ||
        (Ee(a.$$.fragment, e),
        Ee(o.$$.fragment, e),
        Ee(r.$$.fragment, e),
        Ee(E),
        Ee(d),
        (c = !0));
    },
    o(e) {
      me(a.$$.fragment, e),
        me(o.$$.fragment, e),
        me(r.$$.fragment, e),
        me(E),
        me(d),
        (c = !1);
    },
    d(e) {
      e && (Se(t), Se(_), Se(l)), ue(a), ue(o), ue(r), E && E.d(), d && d.d(e);
    },
  };
}
function R(e) {
  let t, a;
  return (
    (t = new Ke({ props: { slot: "close", name: xe } })),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p: ze,
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function L(e) {
  let t, a;
  return (
    (t = new ye({
      props: {
        mobile: e[0],
        title: window.tr(window.lang.login.demo.title),
        draggable: !0,
        closeOnOverlayClick: !1,
        $$slots: { close: [R], default: [A] },
        $$scope: { ctx: e },
      },
    })),
    t.$on("close", e[4]),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p(e, [a]) {
        const n = {};
        1 & a && (n.mobile = e[0]),
          1031 & a && (n.$$scope = { dirty: a, ctx: e }),
          t.$set(n);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function P(e, t, a) {
  const n = ke();
  let { group: o } = t,
    { mobile: s } = t;
  const { broker: r, tradeServerDemo: i, accountUrl: _ } = Ze;
  let l = null,
    E = !1;
  return (
    Ue(() => {
      Ge(() => Promise.resolve().then(() => ca), void 0);
    }),
    (e.$$set = (e) => {
      "group" in e && a(6, (o = e.group)),
        "mobile" in e && a(0, (s = e.mobile));
    }),
    [
      s,
      l,
      E,
      r,
      function () {
        n("cancel");
      },
      async function () {
        if (_) return window.open(_, "_blank"), void n("cancel");
        try {
          const { demo: e } = await Ge(
            () => Promise.resolve().then(() => ca),
            void 0
          );
          a(2, (E = !0));
          const t = await e.demoController.create(i, {
            firstName: We.get("first_name") || "MetaTrader Web",
            secondName: We.get("second_name") || "Demo",
            email: We.get("email") || "autologin@company.com",
            deposit: 1e5,
            leverage: 100,
            group: o,
            agreements: 1,
            country: c(Ze.traderCountry),
          });
          a(2, (E = !1)), n("success", { response: t, isHedgedMargin: Ye(o) });
        } catch (e) {
          a(2, (E = !1)),
            e instanceof Je
              ? a(1, (l = Xe(e.code)))
              : e instanceof Error &&
                a(1, (l = { message: e.message, type: "error" })),
            l || a(1, (l = { message: "Unknown error", type: "error" }));
        }
      },
      o,
    ]
  );
}
function N(e) {
  let t, a;
  return (
    (t = new ye({
      props: {
        mobile: e[1].isMobile,
        title: window.tr(window.lang.login.disclaimer.headerTitle),
        draggable: !0,
        closeOnOverlayClick: !1,
        closeOnEsc: !1,
        hideCloseButton: !0,
        $$slots: { default: [D] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p(e, a) {
        const n = {};
        2 & a && (n.mobile = e[1].isMobile),
          32 & a && (n.$$scope = { dirty: a, ctx: e }),
          t.$set(n);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function g(e) {
  let t;
  const a = e[4].default,
    n = rt(a, e, e[5], null);
  return {
    c() {
      n && n.c();
    },
    m(e, a) {
      n && n.m(e, a), (t = !0);
    },
    p(e, o) {
      n &&
        n.p &&
        (!t || 32 & o) &&
        it(n, a, e, e[5], t ? lt(a, e[5], o, null) : _t(e[5]), null);
    },
    i(e) {
      t || (Ee(n, e), (t = !0));
    },
    o(e) {
      me(n, e), (t = !1);
    },
    d(e) {
      n && n.d(e);
    },
  };
}
function S(e) {
  let t;
  return {
    c() {
      (t = he("div")),
        (t.textContent = `${window.tr(
          window.lang.login.disclaimer.btnAccept
        )}`),
        Re(t, "class", "accept-button svelte-1yp4k0h");
    },
    m(e, a) {
      Pe(e, t, a);
    },
    p: ze,
    d(e) {
      e && Se(t);
    },
  };
}
function D(e) {
  let t,
    a,
    n,
    o,
    s,
    r,
    i,
    _,
    l = window.tr(window.lang.login.disclaimer.text) + "";
  return (
    (i = new qe({
      props: { active: !0, $$slots: { default: [S] }, $$scope: { ctx: e } },
    })),
    i.$on("click", e[3]),
    {
      c() {
        (t = he("div")),
          (a = he("div")),
          (a.textContent = `${window.tr(window.lang.login.disclaimer.title)}`),
          (n = Ae()),
          (o = he("div")),
          (s = Ae()),
          (r = he("div")),
          le(i.$$.fragment),
          Re(a, "class", "title svelte-1yp4k0h"),
          Re(o, "class", "text svelte-1yp4k0h"),
          Re(r, "class", "button svelte-1yp4k0h"),
          Re(t, "class", "content svelte-1yp4k0h");
      },
      m(e, c) {
        Pe(e, t, c),
          Ne(t, a),
          Ne(t, n),
          Ne(t, o),
          (o.innerHTML = l),
          Ne(t, s),
          Ne(t, r),
          ce(i, r, null),
          (_ = !0);
      },
      p(e, t) {
        const a = {};
        32 & t && (a.$$scope = { dirty: t, ctx: e }), i.$set(a);
      },
      i(e) {
        _ || (Ee(i.$$.fragment, e), (_ = !0));
      },
      o(e) {
        me(i.$$.fragment, e), (_ = !1);
      },
      d(e) {
        e && Se(t), ue(i);
      },
    }
  );
}
function T(e) {
  function t(e, t) {
    return e[0] ? 0 : 1;
  }
  let a, n, o, s;
  const r = [g, N],
    i = [];
  return (
    (a = t(e)),
    (n = i[a] = r[a](e)),
    {
      c() {
        n.c(), (o = Me());
      },
      m(e, t) {
        i[a].m(e, t), Pe(e, o, t), (s = !0);
      },
      p(e, [s]) {
        let _ = a;
        (a = t(e)),
          a === _
            ? i[a].p(e, s)
            : (Be(),
              me(i[_], 1, 1, () => {
                i[_] = null;
              }),
              Fe(),
              (n = i[a]),
              n ? n.p(e, s) : ((n = i[a] = r[a](e)), n.c()),
              Ee(n, 1),
              n.m(o.parentNode, o));
      },
      i(e) {
        s || (Ee(n), (s = !0));
      },
      o(e) {
        me(n), (s = !1);
      },
      d(e) {
        e && Se(o), i[a].d(e);
      },
    }
  );
}
function f(e, t, a) {
  let n,
    { $$slots: o = {}, $$scope: s } = t;
  const r = ot.layout.layoutStore;
  st(e, r, (e) => a(1, (n = e)));
  let i = Boolean(de.getItem("disclaimer"));
  const _ = ke();
  return (
    (e.$$set = (e) => {
      "$$scope" in e && a(5, (s = e.$$scope));
    }),
    [
      i,
      n,
      r,
      function () {
        de.setItem("disclaimer", "1"), _("accept"), a(0, (i = !0));
      },
      o,
      s,
    ]
  );
}
function O(e) {
  e[23] = e[22].default;
}
function $(e) {
  e[21] = e[22].default;
}
function V(e) {
  let t,
    a,
    n = !e[0].modules.account.accountStore.isResetPass && b(e);
  return {
    c() {
      n && n.c(), (t = Me());
    },
    m(e, o) {
      n && n.m(e, o), Pe(e, t, o), (a = !0);
    },
    p(e, a) {
      e[0].modules.account.accountStore.isResetPass
        ? n &&
          (Be(),
          me(n, 1, 1, () => {
            n = null;
          }),
          Fe())
        : n
        ? (n.p(e, a), 1 & a && Ee(n, 1))
        : ((n = b(e)), n.c(), Ee(n, 1), n.m(t.parentNode, t));
    },
    i(e) {
      a || (Ee(n), (a = !0));
    },
    o(e) {
      me(n), (a = !1);
    },
    d(e) {
      e && Se(t), n && n.d(e);
    },
  };
}
function b(e) {
  let t;
  const a = e[14].default,
    n = rt(a, e, e[18], Qt);
  return {
    c() {
      n && n.c();
    },
    m(e, a) {
      n && n.m(e, a), (t = !0);
    },
    p(e, o) {
      n &&
        n.p &&
        (!t || 262145 & o) &&
        it(n, a, e, e[18], t ? lt(a, e[18], o, Xt) : _t(e[18]), Qt);
    },
    i(e) {
      t || (Ee(n, e), (t = !0));
    },
    o(e) {
      me(n, e), (t = !1);
    },
    d(e) {
      n && n.d(e);
    },
  };
}
function H(e) {
  function t(e, t) {
    return e[5].isMobile ? 0 : 1;
  }
  let a, n, o, s;
  const r = [j, C],
    i = [];
  return (
    (a = t(e)),
    (n = i[a] = r[a](e)),
    {
      c() {
        n.c(), (o = Me());
      },
      m(e, t) {
        i[a].m(e, t), Pe(e, o, t), (s = !0);
      },
      p(e, s) {
        let _ = a;
        (a = t(e)),
          a === _
            ? i[a].p(e, s)
            : (Be(),
              me(i[_], 1, 1, () => {
                i[_] = null;
              }),
              Fe(),
              (n = i[a]),
              n ? n.p(e, s) : ((n = i[a] = r[a](e)), n.c()),
              Ee(n, 1),
              n.m(o.parentNode, o));
      },
      i(e) {
        s || (Ee(n), (s = !0));
      },
      o(e) {
        me(n), (s = !1);
      },
      d(e) {
        e && Se(o), i[a].d(e);
      },
    }
  );
}
function w(e) {
  let t, a;
  return (
    (t = new Ut({ props: { mobile: e[5].isMobile, group: e[11] } })),
    t.$on("success", e[12]),
    t.$on("cancel", e[15]),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p(e, a) {
        const n = {};
        32 & a && (n.mobile = e[5].isMobile), t.$set(n);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function C(e) {
  let t,
    a,
    n = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: k,
      then: y,
      catch: G,
      value: 22,
      blocks: [, , ,],
    };
  return (
    dt(
      Ge(
        () => import("./00a24b22.js").then((e) => e.cN),
        ["00a24b22.js", "6f913017.css"]
      ),
      n
    ),
    {
      c() {
        (t = Me()), n.block.c();
      },
      m(e, o) {
        Pe(e, t, o),
          n.block.m(e, (n.anchor = o)),
          (n.mount = () => t.parentNode),
          (n.anchor = t),
          (a = !0);
      },
      p(t, a) {
        pt(n, (e = t), a);
      },
      i(e) {
        a || (Ee(n.block), (a = !0));
      },
      o(e) {
        for (let t = 0; t < 3; t += 1) {
          const e = n.blocks[t];
          me(e);
        }
        a = !1;
      },
      d(e) {
        e && Se(t), n.block.d(e), (n.token = null), (n = null);
      },
    }
  );
}
function j(e) {
  let t,
    a,
    n = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: M,
      then: v,
      catch: U,
      value: 22,
      blocks: [, , ,],
    };
  return (
    dt(
      Ge(
        () => import("./7be29ce0.js"),
        [
          "7be29ce0.js",
          "00a24b22.js",
          "6f913017.css",
          "917f94f7.js",
          "f54151ac.js",
          "02c71ccc.css",
          "7313b880.css",
          "af21b248.js",
          "113fef4e.css",
          "602c697f.css",
        ]
      ),
      n
    ),
    {
      c() {
        (t = Me()), n.block.c();
      },
      m(e, o) {
        Pe(e, t, o),
          n.block.m(e, (n.anchor = o)),
          (n.mount = () => t.parentNode),
          (n.anchor = t),
          (a = !0);
      },
      p(t, a) {
        pt(n, (e = t), a);
      },
      i(e) {
        a || (Ee(n.block), (a = !0));
      },
      o(e) {
        for (let t = 0; t < 3; t += 1) {
          const e = n.blocks[t];
          me(e);
        }
        a = !1;
      },
      d(e) {
        e && Se(t), n.block.d(e), (n.token = null), (n = null);
      },
    }
  );
}
function G(e) {
  return { c: ze, m: ze, p: ze, i: ze, o: ze, d: ze };
}
function y(e) {
  function t(t) {
    e[17](t);
  }
  let a, n, o;
  O(e);
  let s = {};
  return (
    void 0 !== e[2] && (s.autoConnect = e[2]),
    (a = new e[23]({ props: s })),
    It.push(() => ht(a, "autoConnect", t)),
    {
      c() {
        le(a.$$.fragment);
      },
      m(e, t) {
        ce(a, e, t), (o = !0);
      },
      p(e, t) {
        O(e);
        const o = {};
        !n && 4 & t && ((n = !0), (o.autoConnect = e[2]), At(() => (n = !1))),
          a.$set(o);
      },
      i(e) {
        o || (Ee(a.$$.fragment, e), (o = !0));
      },
      o(e) {
        me(a.$$.fragment, e), (o = !1);
      },
      d(e) {
        ue(a, e);
      },
    }
  );
}
function k(e) {
  let t, a;
  return (
    (t = new et({})),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p: ze,
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function U(e) {
  return { c: ze, m: ze, p: ze, i: ze, o: ze, d: ze };
}
function v(e) {
  function t(t) {
    e[16](t);
  }
  let a, n, o;
  $(e);
  let s = { index: 0 };
  return (
    void 0 !== e[2] && (s.autoConnect = e[2]),
    (a = new e[21]({ props: s })),
    It.push(() => ht(a, "autoConnect", t)),
    {
      c() {
        le(a.$$.fragment);
      },
      m(e, t) {
        ce(a, e, t), (o = !0);
      },
      p(e, t) {
        $(e);
        const o = {};
        !n && 4 & t && ((n = !0), (o.autoConnect = e[2]), At(() => (n = !1))),
          a.$set(o);
      },
      i(e) {
        o || (Ee(a.$$.fragment, e), (o = !0));
      },
      o(e) {
        me(a.$$.fragment, e), (o = !1);
      },
      d(e) {
        ue(a, e);
      },
    }
  );
}
function M(e) {
  let t, a;
  return (
    (t = new et({})),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p: ze,
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function B(e) {
  function t(e, t) {
    var a, n, o;
    return e[3] && !e[4] && e[11] && !Ze.accountUrl && ta
      ? 0
      : !e[0].modules ||
        e[5].auth !== Et.None ||
        (null == (a = e[0].modules)
          ? void 0
          : a.account.accountStore.isResetPass) ||
        (e[1] &&
          5 ===
            (null ==
            (o = null == (n = e[0].existing[e[1].login]) ? void 0 : n.error)
              ? void 0
              : o.code))
      ? 1
      : -1;
  }
  let a,
    n,
    o,
    s,
    r,
    i = e[0].modules && V(e);
  const _ = [w, H],
    l = [];
  return (
    ~(n = t(e)) && (o = l[n] = _[n](e)),
    {
      c() {
        i && i.c(), (a = Ae()), o && o.c(), (s = Me());
      },
      m(e, t) {
        i && i.m(e, t), Pe(e, a, t), ~n && l[n].m(e, t), Pe(e, s, t), (r = !0);
      },
      p(e, r) {
        e[0].modules
          ? i
            ? (i.p(e, r), 1 & r && Ee(i, 1))
            : ((i = V(e)), i.c(), Ee(i, 1), i.m(a.parentNode, a))
          : i &&
            (Be(),
            me(i, 1, 1, () => {
              i = null;
            }),
            Fe());
        let c = n;
        (n = t(e)),
          n === c
            ? ~n && l[n].p(e, r)
            : (o &&
                (Be(),
                me(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                Fe()),
              ~n
                ? ((o = l[n]),
                  o ? o.p(e, r) : ((o = l[n] = _[n](e)), o.c()),
                  Ee(o, 1),
                  o.m(s.parentNode, s))
                : (o = null));
      },
      i(e) {
        r || (Ee(i), Ee(o), (r = !0));
      },
      o(e) {
        me(i), me(o), (r = !1);
      },
      d(e) {
        e && (Se(a), Se(s)), i && i.d(e), ~n && l[n].d(e);
      },
    }
  );
}
function F(e) {
  let t, a;
  return (
    (t = new Jt({ props: { $$slots: { default: [B] }, $$scope: { ctx: e } } })),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p(e, a) {
        const n = {};
        262207 & a && (n.$$scope = { dirty: a, ctx: e }), t.$set(n);
      },
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function K(e) {
  let t,
    a,
    n = e[6].language,
    o = F(e);
  return {
    c() {
      o.c(), (t = Me());
    },
    m(e, n) {
      o.m(e, n), Pe(e, t, n), (a = !0);
    },
    p(e, [a]) {
      64 & a && ie(n, (n = e[6].language))
        ? (Be(),
          me(o, 1, 1, ze),
          Fe(),
          (o = F(e)),
          o.c(),
          Ee(o, 1),
          o.m(t.parentNode, t))
        : o.p(e, a);
    },
    i(e) {
      a || (Ee(o), (a = !0));
    },
    o(e) {
      me(o), (a = !1);
    },
    d(e) {
      e && Se(t), o.d(e);
    },
  };
}
function x(e) {
  let t = null;
  const a = e.find(
    (e) =>
      !(
        (function (e) {
          const t = e.agreements.some((e) => 0 !== e.flags),
            a = Boolean(8 & e.flags),
            n = Boolean(4 & e.flags);
          return !!(t || a || n);
        })(e) ||
        (e.currency.toLowerCase() !== Ze.traderCurrency.toLowerCase() &&
          (t || (t = e), 1))
      )
  );
  return !a && t ? t : a;
}
function z(e, t, a) {
  let n,
    o,
    s,
    r,
    { $$slots: _ = {}, $$scope: l } = t;
  const c = ot.layout.layoutStore;
  st(e, c, (e) => a(5, (o = e)));
  const E = ot.users.usersStore;
  st(e, E, (e) => a(13, (s = e)));
  const m = ct.authStore;
  st(e, m, (e) => a(0, (n = e)));
  const u = Yt.langReloadStore;
  st(e, u, (e) => a(6, (r = e)));
  let d = s.getCurrentUser(),
    p = !1,
    I = Ze.accountAuto;
  const h = (function () {
    if (!Ze.demoGroups[0]) return;
    const e = Ye(Ze.servers[0].groups[0]);
    let t = mt(Ze.demoGroups, e),
      a = x(t);
    return a || ((t = mt(Ze.demoGroups, !e)), (a = x(t))), a;
  })();
  let A = Boolean(E.getAllUsers().length);
  return (
    Ue(() => {
      (function () {
        const e = (function () {
          const e = We.get("mode");
          return "demo" === e && Ze.demoGroups.length
            ? Et.OpenDemo
            : "real" === e && Ze.realGroups.length
            ? Et.OpenReal
            : Et.Connect;
        })();
        if (ea && e === Et.Connect) {
          const e = Number(ea);
          if (!isNaN(e) && Number.isFinite(e)) {
            const t = s.getUserByLogin(e);
            t
              ? (o.setLayout({ auth: t.id }),
                a(2, (p = Boolean(t.savePassword))))
              : o.setLayout({ auth: Et.Connect });
          }
        } else
          o.setLayout({ auth: (null == d ? void 0 : d.id) ?? e }),
            a(2, (p = Boolean(null == d ? void 0 : d.id)));
      })(),
        "string" != typeof o.auth &&
          (async function () {
            Ge(
              () => import("./42f624f0.js"),
              ["42f624f0.js", "00a24b22.js", "6f913017.css", "04a8e93f.js"]
            ),
              o.auth === Et.OpenDemo
                ? (Ze.demoGroups.length &&
                    (await Ge(
                      () => import("./d35b1395.js"),
                      [
                        "d35b1395.js",
                        "00a24b22.js",
                        "6f913017.css",
                        "3d7bfa54.css",
                      ]
                    )),
                  Ze.realGroups.length &&
                    (await Ge(
                      () => import("./b38e25e8.js"),
                      [
                        "b38e25e8.js",
                        "00a24b22.js",
                        "6f913017.css",
                        "981398f2.css",
                      ]
                    )),
                  await Ge(
                    () => import("./00a24b22.js").then((e) => e.cM),
                    ["00a24b22.js", "6f913017.css"]
                  ))
                : o.auth === Et.OpenReal
                ? (Ze.realGroups.length &&
                    (await Ge(
                      () => import("./b38e25e8.js"),
                      [
                        "b38e25e8.js",
                        "00a24b22.js",
                        "6f913017.css",
                        "981398f2.css",
                      ]
                    )),
                  Ze.demoGroups.length &&
                    (await Ge(
                      () => import("./d35b1395.js"),
                      [
                        "d35b1395.js",
                        "00a24b22.js",
                        "6f913017.css",
                        "3d7bfa54.css",
                      ]
                    )),
                  await Ge(
                    () => import("./00a24b22.js").then((e) => e.cM),
                    ["00a24b22.js", "6f913017.css"]
                  ))
                : (await Ge(
                    () => import("./00a24b22.js").then((e) => e.cM),
                    ["00a24b22.js", "6f913017.css"]
                  ),
                  Ze.realGroups.length &&
                    (await Ge(
                      () => import("./b38e25e8.js"),
                      [
                        "b38e25e8.js",
                        "00a24b22.js",
                        "6f913017.css",
                        "981398f2.css",
                      ]
                    )),
                  Ze.demoGroups.length &&
                    (await Ge(
                      () => import("./d35b1395.js"),
                      [
                        "d35b1395.js",
                        "00a24b22.js",
                        "6f913017.css",
                        "3d7bfa54.css",
                      ]
                    ))),
              await Ge(
                () => import("./0c47227d.js"),
                ["0c47227d.js", "00a24b22.js", "6f913017.css", "917b70f1.css"]
              ),
              setTimeout(() => {
                i();
              }, 2e3);
          })();
    }),
    (e.$$set = (e) => {
      "$$scope" in e && a(18, (l = e.$$scope));
    }),
    (e.$$.update = () => {
      8192 & e.$$.dirty && a(1, (d = s.getCurrentUser())),
        1 & e.$$.dirty && n.modules;
    }),
    [
      n,
      d,
      p,
      I,
      A,
      o,
      r,
      c,
      E,
      m,
      u,
      h,
      function (e) {
        if ((ut(m, (n.createdUser = e.detail.response), n), n.createdUser)) {
          c.setLayout({ auth: n.createdUser.id }), a(4, (A = !0));
          const t = s.getUserById(n.createdUser.id);
          t &&
            s.updateCurrentUser(t.login, {
              isHedgedMargin: e.detail.isHedgedMargin,
            });
        }
      },
      s,
      _,
      () => {
        a(3, (I = !1));
      },
      function (e) {
        (p = e), a(2, p);
      },
      function (e) {
        (p = e), a(2, p);
      },
      l,
    ]
  );
}
function Z(e) {
  e[6] = e[7].default;
}
function W(e) {
  let t,
    a,
    n = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: X,
      then: J,
      catch: Y,
      value: 7,
      blocks: [, , ,],
    };
  return (
    dt(
      Ge(
        () => import("./cddfd7eb.js"),
        [
          "cddfd7eb.js",
          "00a24b22.js",
          "6f913017.css",
          "3278e24d.js",
          "f54151ac.js",
          "02c71ccc.css",
          "d394a3e3.js",
          "10761cfa.js",
          "917f94f7.js",
          "7313b880.css",
          "c47cc20c.css",
          "f1661fb5.css",
          "712ebc32.js",
          "c697aa44.css",
          "d09b99f6.js",
          "22a7d1db.js",
          "f60bb92f.js",
          "a4b22e5d.js",
          "a3b77070.css",
          "883cebe6.css",
          "af21b248.js",
          "113fef4e.css",
          "7277e82c.css",
          "3049ce3f.js",
          "01251fd4.css",
        ]
      ),
      n
    ),
    {
      c() {
        (t = Me()), n.block.c();
      },
      m(e, o) {
        Pe(e, t, o),
          n.block.m(e, (n.anchor = o)),
          (n.mount = () => t.parentNode),
          (n.anchor = t),
          (a = !0);
      },
      p(t, a) {
        pt(n, (e = t), a);
      },
      i(e) {
        a || (Ee(n.block), (a = !0));
      },
      o(e) {
        for (let t = 0; t < 3; t += 1) {
          const e = n.blocks[t];
          me(e);
        }
        a = !1;
      },
      d(e) {
        e && Se(t), n.block.d(e), (n.token = null), (n = null);
      },
    }
  );
}
function Y(e) {
  return { c: ze, m: ze, p: ze, i: ze, o: ze, d: ze };
}
function J(e) {
  function t(e, t) {
    return { props: { modules: e[5] } };
  }
  let a, n, o;
  Z(e);
  var s = e[6];
  return (
    s && (a = Nt(s, t(e))),
    {
      c() {
        a && le(a.$$.fragment), (n = Me());
      },
      m(e, t) {
        a && ce(a, e, t), Pe(e, n, t), (o = !0);
      },
      p(e, o) {
        if ((Z(e), s !== (s = e[6]))) {
          if (a) {
            Be();
            const e = a;
            me(e.$$.fragment, 1, 0, () => {
              ue(e, 1);
            }),
              Fe();
          }
          s
            ? ((a = Nt(s, t(e))),
              le(a.$$.fragment),
              Ee(a.$$.fragment, 1),
              ce(a, n.parentNode, n))
            : (a = null);
        } else if (s) {
          const t = {};
          32 & o && (t.modules = e[5]), a.$set(t);
        }
      },
      i(e) {
        o || (a && Ee(a.$$.fragment, e), (o = !0));
      },
      o(e) {
        a && me(a.$$.fragment, e), (o = !1);
      },
      d(e) {
        e && Se(n), a && ue(a, e);
      },
    }
  );
}
function X(e) {
  let t, a;
  return (
    (t = new et({})),
    {
      c() {
        le(t.$$.fragment);
      },
      m(e, n) {
        ce(t, e, n), (a = !0);
      },
      p: ze,
      i(e) {
        a || (Ee(t.$$.fragment, e), (a = !0));
      },
      o(e) {
        me(t.$$.fragment, e), (a = !1);
      },
      d(e) {
        ue(t, e);
      },
    }
  );
}
function Q(e) {
  let t,
    a,
    n = e[5] && !e[5].disabled && W(e);
  return {
    c() {
      n && n.c(), (t = Me());
    },
    m(e, o) {
      n && n.m(e, o), Pe(e, t, o), (a = !0);
    },
    p(e, a) {
      e[5] && !e[5].disabled
        ? n
          ? (n.p(e, a), 32 & a && Ee(n, 1))
          : ((n = W(e)), n.c(), Ee(n, 1), n.m(t.parentNode, t))
        : n &&
          (Be(),
          me(n, 1, 1, () => {
            n = null;
          }),
          Fe());
    },
    i(e) {
      a || (Ee(n), (a = !0));
    },
    o(e) {
      me(n), (a = !1);
    },
    d(e) {
      e && Se(t), n && n.d(e);
    },
  };
}
function q(e) {
  let t, a, n, o, s, r;
  return (
    (t = new Ct({})),
    (n = new aa({
      props: {
        $$slots: {
          default: [
            Q,
            ({ modules: e }) => ({ 5: e }),
            ({ modules: e }) => (e ? 32 : 0),
          ],
        },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        le(t.$$.fragment), (a = Ae()), le(n.$$.fragment);
      },
      m(i, _) {
        ce(t, i, _),
          Pe(i, a, _),
          ce(n, i, _),
          (o = !0),
          s || ((r = ge(na, "resize", e[1])), (s = !0));
      },
      p(e, [t]) {
        const a = {};
        288 & t && (a.$$scope = { dirty: t, ctx: e }), n.$set(a);
      },
      i(e) {
        o || (Ee(t.$$.fragment, e), Ee(n.$$.fragment, e), (o = !0));
      },
      o(e) {
        me(t.$$.fragment, e), me(n.$$.fragment, e), (o = !1);
      },
      d(e) {
        e && Se(a), ue(t, e), ue(n, e), (s = !1), r();
      },
    }
  );
}
function ee(e, t) {
  return "1" === de.getItem("mobile") || (Lt() && Pt() && (e < 460 || t < 460));
}
function te(e, t, a) {
  var n, o;
  let s;
  const r = ot.layout.layoutStore;
  st(e, r, (e) => a(4, (s = e)));
  let i = (null == (n = window.screen) ? void 0 : n.width) ?? window.innerWidth,
    _ = (null == (o = window.screen) ? void 0 : o.height) ?? window.innerHeight;
  return (
    ut(r, (s.isMobile = ee(i, _)), s),
    ut(r, (s.isSafari = void 0 !== window.safari), s),
    Ue(async () => {}),
    (e.$$.update = () => {
      28 & e.$$.dirty &&
        (ut(r, (s.isMobile = ee(i, _)), s),
        s.isMobile
          ? (document.body.classList.remove("desktop"),
            document.body.classList.add("mobile"))
          : (document.body.classList.remove("mobile"),
            document.body.classList.add("desktop")));
    }),
    [
      r,
      function () {
        var e, t;
        if (
          (a(
            2,
            (i =
              (null == (e = window.screen) ? void 0 : e.width) ??
              window.innerWidth)
          ),
          a(
            3,
            (_ =
              (null == (t = window.screen) ? void 0 : t.height) ??
              window.innerHeight)
          ),
          i > _)
        ) {
          const e = _;
          a(3, (_ = i)), a(2, (i = e));
        }
      },
      i,
      _,
      s,
    ]
  );
}
var ae, ne, oe;
import {
  S as se,
  i as re,
  s as ie,
  aw as _e,
  c as le,
  m as ce,
  t as Ee,
  h as me,
  l as ue,
  ax as de,
  ay as pe,
  az as Ie,
  e as he,
  a as Ae,
  b as Re,
  M as Le,
  d as Pe,
  f as Ne,
  O as ge,
  k as Se,
  aA as De,
  aB as Te,
  aC as fe,
  aD as Oe,
  p as $e,
  n as Ve,
  K as be,
  N as He,
  q as we,
  P as Ce,
  R as je,
  aE as Ge,
  aF as ye,
  a1 as ke,
  a5 as Ue,
  aG as ve,
  B as Me,
  g as Be,
  j as Fe,
  a3 as Ke,
  aH as xe,
  o as ze,
  aI as Ze,
  aJ as We,
  aK as Ye,
  aL as Je,
  aM as Xe,
  aN as Qe,
  aO as qe,
  aP as et,
  aQ as tt,
  ah as at,
  w as nt,
  aR as ot,
  ai as st,
  x as rt,
  y as it,
  z as _t,
  A as lt,
  aS as ct,
  aT as Et,
  aU as mt,
  aV as ut,
  aW as dt,
  aX as pt,
  T as It,
  U as ht,
  W as At,
  u as Rt,
  aY as Lt,
  Z as Pt,
  an as Nt,
  aZ as gt,
  a_ as St,
  a$ as Dt,
  b0 as Tt,
  b1 as ft,
  b2 as Ot,
  b3 as $t,
  b4 as Vt,
  b5 as bt,
  b6 as Ht,
  b7 as wt,
} from "./00a24b22.js";
!(function () {
  function e(e) {
    if (e.ep) return;
    e.ep = !0;
    const t = (function (e) {
      const t = {};
      return (
        e.integrity && (t.integrity = e.integrity),
        e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy),
        "use-credentials" === e.crossOrigin
          ? (t.credentials = "include")
          : "anonymous" === e.crossOrigin
          ? (t.credentials = "omit")
          : (t.credentials = "same-origin"),
        t
      );
    })(e);
    fetch(e.href, t);
  }
  const t = document.createElement("link").relList;
  if (!(t && t.supports && t.supports("modulepreload"))) {
    for (const t of document.querySelectorAll('link[rel="modulepreload"]'))
      e(t);
    new MutationObserver((t) => {
      for (const a of t)
        if ("childList" === a.type)
          for (const t of a.addedNodes)
            "LINK" === t.tagName && "modulepreload" === t.rel && e(t);
    }).observe(document, { childList: !0, subtree: !0 });
  }
})();
class Ct extends se {
  constructor(e) {
    super(), re(this, e, s, o, ie, { toggleTag: 0 });
  }
  get toggleTag() {
    return this.$$.ctx[0];
  }
}
const jt = {
    AFRIKAANS: "af",
    ALBANIAN: "sq",
    ARABIC: "ar",
    ARMENIAN: "hy",
    AZERBAIJANI: "az",
    BANGLA: "bn",
    BELARUSIAN: "be",
    BULGARIAN: "bg",
    CATALAN: "ca",
    CHINESE: "zh",
    CROATIAN: "hr",
    CZECH: "cs",
    DANISH: "da",
    DIVEHI: "dv",
    DUTCH: "nl",
    ENGLISH: "en",
    ESTONIAN: "et",
    FINNISH: "fi",
    FRENCH: "fr",
    GEORGIAN: "ka",
    GERMAN: "de",
    GREEK: "el",
    HEBREW: "he",
    HINDI: "hi",
    HUNGARIAN: "hu",
    ICELANDIC: "is",
    INDONESIAN: "id",
    ITALIAN: "it",
    JAPANESE: "ja",
    KAZAKH: "kk",
    KOREAN: "ko",
    KYRGYZ: "ky",
    LATVIAN: "lv",
    LITHUANIAN: "lt",
    MACEDONIAN: "mk",
    MALAY: "ms",
    MONGOLIAN: "mn",
    NEPALI: "ne",
    NORWEGIAN: "no",
    PERSIAN: "fa",
    POLISH: "pl",
    PORTUGUESE: "pt",
    ROMANIAN: "ro",
    RUSSIAN: "ru",
    SERBIAN: "sr",
    SLOVAK: "sk",
    SLOVENIAN: "sl",
    SPANISH: "es",
    SWAHILI: "sw",
    SWEDISH: "sv",
    THAI: "th",
    TURKISH: "tr",
    UKRAINIAN: "uk",
    URDU: "ur",
    VIETNAMESE: "vi",
  },
  Gt = [
    ["AF", "AFN", jt.ENGLISH, "93", "Afghanistan"],
    ["AX", "EUR", jt.SWEDISH, "358", "Åland Islands"],
    ["AL", "ALL", jt.ALBANIAN, "355", "Albania"],
    ["DZ", "DZD", jt.ARABIC, "213", "Algeria"],
    ["AD", "EUR", jt.CATALAN, "376", "Andorra"],
    ["AO", "AOA", jt.PORTUGUESE, "244", "Angola"],
    ["AI", "XCD", jt.ENGLISH, "1-264", "Anguilla"],
    ["AQ", "USD", jt.ENGLISH, "672", "Antarctica"],
    ["AG", "XCD", jt.ENGLISH, "1-268", "Antigua & Barbuda"],
    ["AR", "ARS", jt.SPANISH, "54", "Argentina"],
    ["AM", "AMD", jt.ARMENIAN, "374", "Armenia"],
    ["AW", "AWG", jt.DUTCH, "297", "Aruba"],
    ["AU", "AUD", jt.ENGLISH, "61", "Australia"],
    ["AT", "EUR", jt.GERMAN, "43", "Austria"],
    ["AZ", "AZN", jt.AZERBAIJANI, "994", "Azerbaijan"],
    ["BS", "BSD", jt.ENGLISH, "1-242", "Bahamas"],
    ["BH", "BHD", jt.ARABIC, "973", "Bahrain"],
    ["BD", "BDT", jt.BANGLA, "880", "Bangladesh"],
    ["BB", "BBD", jt.ENGLISH, "1-246", "Barbados"],
    ["BY", "BYR", jt.BELARUSIAN, "375", "Belarus"],
    ["BE", "EUR", jt.DUTCH, "32", "Belgium"],
    ["BZ", "BZD", jt.ENGLISH, "501", "Belize"],
    ["BJ", "XOF", jt.FRENCH, "229", "Benin"],
    ["BM", "BMD", jt.ENGLISH, "1-441", "Bermuda"],
    ["BT", "BTN", jt.ENGLISH, "975", "Bhutan"],
    ["BO", "BOB", jt.SPANISH, "591", "Bolivia"],
    ["BQ", "USD", jt.DUTCH, "599", "Caribbean Netherlands"],
    ["BA", "BAM", jt.SERBIAN, "387", "Bosnia & Herzegovina"],
    ["BW", "BWP", jt.ENGLISH, "267", "Botswana"],
    ["BV", "NOK", jt.ENGLISH, "47", "Bouvet Island"],
    ["BR", "BRL", jt.PORTUGUESE, "55", "Brazil"],
    ["IO", "USD", jt.ENGLISH, "1-284", "British Indian Ocean Territory"],
    ["BN", "BND", jt.MALAY, "673", "Brunei"],
    ["BG", "BGN", jt.BULGARIAN, "359", "Bulgaria"],
    ["BF", "XOF", jt.FRENCH, "226", "Burkina Faso"],
    ["BI", "BIF", jt.FRENCH, "257", "Burundi"],
    ["KH", "KHR", jt.ENGLISH, "855", "Cambodia"],
    ["CM", "XAF", jt.ENGLISH, "237", "Cameroon"],
    ["CA", "CAD", jt.ENGLISH, "1", "Canada"],
    ["CV", "CVE", jt.FRENCH, "238", "Cape Verde"],
    ["KY", "KYD", jt.ENGLISH, "1-345", "Cayman Islands"],
    ["CF", "XAF", jt.FRENCH, "236", "Central African Republic"],
    ["TD", "XAF", jt.FRENCH, "235", "Chad"],
    ["CL", "CLP", jt.SPANISH, "56", "Chile"],
    ["CN", "CNY", jt.CHINESE, "86", "China"],
    ["CX", "AUD", jt.ENGLISH, "61", "Christmas Island"],
    ["CC", "AUD", jt.ENGLISH, "61", "Cocos (Keeling) Islands"],
    ["CO", "COP", jt.SPANISH, "57", "Colombia"],
    ["KM", "KMF", jt.FRENCH, "269", "Comoros"],
    ["CG", "XAF", jt.ENGLISH, "242", "Congo - Brazzaville"],
    ["CK", "NZD", jt.ENGLISH, "682", "Cook Islands"],
    ["CR", "CRC", jt.SPANISH, "506", "Costa Rica"],
    ["CI", "XOF", jt.ENGLISH, "225", "Côte d’Ivoire"],
    ["HR", "HRK", jt.CROATIAN, "385", "Croatia"],
    ["CU", "CUP", jt.SPANISH, "53", "Cuba"],
    ["CW", "ANG", jt.DUTCH, "599", "Curaçao"],
    ["CY", "EUR", jt.ENGLISH, "357", "Cyprus"],
    ["CZ", "CZK", jt.CZECH, "420", "Czechia"],
    ["CD", "CDF", jt.FRENCH, "243", "Congo - Kinshasa"],
    ["DK", "DKK", jt.DANISH, "45", "Denmark"],
    ["DJ", "DJF", jt.ARABIC, "253", "Djibouti"],
    ["DM", "XCD", jt.ENGLISH, "1-767", "Dominica"],
    ["DO", "DOP", jt.SPANISH, "1-809", "Dominican Republic"],
    ["EC", "USD", jt.SPANISH, "593", "Ecuador"],
    ["EG", "EGP", jt.ARABIC, "20", "Egypt"],
    ["SV", "USD", jt.SPANISH, "503", "El Salvador"],
    ["GQ", "XAF", jt.FRENCH, "240", "Equatorial Guinea"],
    ["ER", "ERN", jt.ENGLISH, "291", "Eritrea"],
    ["EE", "EUR", jt.ESTONIAN, "372", "Estonia"],
    ["SZ", "SZL", jt.ENGLISH, "268", "Eswatini"],
    ["ET", "ETB", jt.ENGLISH, "251", "Ethiopia"],
    ["FK", "FKP", jt.ENGLISH, "500", "Falkland Islands (Islas Malvinas)"],
    ["FO", "DKK", jt.DANISH, "298", "Faroe Islands"],
    ["FJ", "FJD", jt.ENGLISH, "679", "Fiji"],
    ["FI", "EUR", jt.FINNISH, "358", "Finland"],
    ["FR", "EUR", jt.FRENCH, "33", "France"],
    ["GF", "EUR", jt.FRENCH, "594", "French Guiana"],
    ["PF", "EUR", jt.FRENCH, "689", "French Polynesia"],
    ["GA", "XAF", jt.FRENCH, "241", "Gabon"],
    ["GM", "GMD", jt.ENGLISH, "220", "Gambia"],
    ["GE", "GEL", jt.GEORGIAN, "995", "Georgia"],
    ["DE", "EUR", jt.GERMAN, "49", "Germany"],
    ["GH", "GHS", jt.ENGLISH, "233", "Ghana"],
    ["GI", "GIP", jt.ENGLISH, "350", "Gibraltar"],
    ["GR", "EUR", jt.GREEK, "30", "Greece"],
    ["GL", "DKK", jt.ENGLISH, "299", "Greenland"],
    ["GD", "XCD", jt.ENGLISH, "1-473", "Grenada"],
    ["GP", "EUR", jt.FRENCH, "33", "Guadeloupe"],
    ["GU", "USD", jt.ENGLISH, "1-671", "Guam"],
    ["GT", "GTQ", jt.SPANISH, "502", "Guatemala"],
    ["GG", "GGP", jt.ENGLISH, "44-1481", "Guernsey"],
    ["GN", "GNF", jt.FRENCH, "224", "Guinea"],
    ["GW", "GWP", jt.PORTUGUESE, "245", "Guinea-Bissau"],
    ["GY", "GYD", jt.ENGLISH, "592", "Guyana"],
    ["HT", "HTG", jt.ENGLISH, "509", "Haiti"],
    ["HM", "AUD", jt.ENGLISH, "672", "Heard & McDonald Islands"],
    ["HN", "HNL", jt.SPANISH, "504", "Honduras"],
    ["HK", "HKD", jt.CHINESE, "852", "Hong Kong"],
    ["HU", "HUF", jt.HUNGARIAN, "36", "Hungary"],
    ["IS", "ISK", jt.ICELANDIC, "354", "Iceland"],
    ["IN", "INR", jt.HINDI, "91", "India"],
    ["ID", "IDR", jt.INDONESIAN, "62", "Indonesia"],
    ["IR", "IRR", jt.PERSIAN, "98", "Iran"],
    ["IQ", "IQD", jt.ARABIC, "964", "Iraq"],
    ["IE", "EUR", jt.ENGLISH, "353", "Ireland"],
    ["IM", "IMP", jt.ENGLISH, "44", "Isle of Man"],
    ["IL", "ILS", jt.HEBREW, "972", "Israel"],
    ["IT", "EUR", jt.ITALIAN, "39", "Italy"],
    ["JM", "JMD", jt.ENGLISH, "1-876", "Jamaica"],
    ["JP", "JPY", jt.JAPANESE, "81", "Japan"],
    ["JE", "JEP", jt.ENGLISH, "44-1534", "Jersey"],
    ["JO", "JOD", jt.ARABIC, "962", "Jordan"],
    ["KZ", "KZT", jt.KAZAKH, "7", "Kazakhstan"],
    ["KE", "KES", jt.ENGLISH, "254", "Kenya"],
    ["KI", "AUD", jt.ENGLISH, "686", "Kiribati"],
    ["KR", "KRW", jt.KOREAN, "82", "South Korea"],
    ["XK", "EUR", jt.ALBANIAN, "383", "Kosovo"],
    ["KW", "KWD", jt.ARABIC, "965", "Kuwait"],
    ["KG", "KGS", jt.KYRGYZ, "996", "Kyrgyzstan"],
    ["LA", "LAK", jt.ENGLISH, "856", "Laos"],
    ["LV", "EUR", jt.LATVIAN, "371", "Latvia"],
    ["LB", "LBP", jt.ARABIC, "961", "Lebanon"],
    ["LS", "LSL", jt.ENGLISH, "266", "Lesotho"],
    ["LR", "LRD", jt.ENGLISH, "231", "Liberia"],
    ["LY", "LYD", jt.ARABIC, "218", "Libya"],
    ["LI", "CHF", jt.GERMAN, "423", "Liechtenstein"],
    ["LT", "EUR", jt.LITHUANIAN, "370", "Lithuania"],
    ["LU", "EUR", jt.GERMAN, "352", "Luxembourg"],
    ["MO", "MOP", jt.CHINESE, "853", "Macao"],
    ["MK", "MKD", jt.MACEDONIAN, "389", "North Macedonia"],
    ["MG", "MGA", jt.FRENCH, "261", "Madagascar"],
    ["MW", "MWK", jt.ENGLISH, "265", "Malawi"],
    ["MY", "MYR", jt.MALAY, "60", "Malaysia"],
    ["MV", "MVR", jt.DIVEHI, "960", "Maldives"],
    ["ML", "XOF", jt.FRENCH, "223", "Mali"],
    ["MT", "EUR", jt.ENGLISH, "356", "Malta"],
    ["MH", "USD", jt.ENGLISH, "692", "Marshall Islands"],
    ["MQ", "EUR", jt.FRENCH, "596", "Martinique"],
    ["MR", "MRO", jt.ARABIC, "222", "Mauritania"],
    ["MU", "MUR", jt.ENGLISH, "230", "Mauritius"],
    ["YT", "EUR", jt.FRENCH, "262", "Mayotte"],
    ["MX", "MXN", jt.SPANISH, "52", "Mexico"],
    ["FM", "USD", jt.ENGLISH, "691", "Micronesia"],
    ["MD", "MDL", jt.ENGLISH, "373", "Moldova"],
    ["MC", "EUR", jt.FRENCH, "377", "Monaco"],
    ["MN", "MNT", jt.MONGOLIAN, "976", "Mongolia"],
    ["ME", "EUR", jt.SERBIAN, "382", "Montenegro"],
    ["MS", "XCD", jt.ENGLISH, "1-664", "Montserrat"],
    ["MA", "MAD", jt.ARABIC, "212", "Morocco"],
    ["MZ", "MZN", jt.PORTUGUESE, "258", "Mozambique"],
    ["MM", "MMK", jt.CHINESE, "95", "Myanmar (Burma)"],
    ["NA", "NAD", jt.ENGLISH, "264", "Namibia"],
    ["NR", "AUD", jt.ENGLISH, "674", "Nauru"],
    ["NP", "NPR", jt.NEPALI, "977", "Nepal"],
    ["NL", "EUR", jt.DUTCH, "31", "Netherlands"],
    ["NC", "XPF", jt.FRENCH, "687", "New Caledonia"],
    ["NZ", "NZD", jt.ENGLISH, "64", "New Zealand"],
    ["NI", "NIO", jt.SPANISH, "505", "Nicaragua"],
    ["NE", "XOF", jt.FRENCH, "227", "Niger"],
    ["NG", "NGN", jt.ENGLISH, "234", "Nigeria"],
    ["NU", "NZD", jt.FRENCH, "683", "Niue"],
    ["NF", "AUD", jt.ENGLISH, "672", "Norfolk Island"],
    ["MP", "USD", jt.ENGLISH, "1-670", "Northern Mariana Islands"],
    ["NO", "NOK", jt.NORWEGIAN, "47", "Norway"],
    ["OM", "OMR", jt.ARABIC, "968", "Oman"],
    ["PK", "PKR", jt.URDU, "92", "Pakistan"],
    ["PW", "USD", jt.FRENCH, "680", "Palau"],
    ["PS", "ILS", jt.ARABIC, "970", "Palestine"],
    ["PA", "USD", jt.SPANISH, "507", "Panama"],
    ["PG", "PGK", jt.ENGLISH, "675", "Papua New Guinea"],
    ["PY", "PYG", jt.SPANISH, "595", "Paraguay"],
    ["PE", "PEN", jt.SPANISH, "51", "Peru"],
    ["PH", "PHP", jt.ENGLISH, "63", "Philippines"],
    ["PN", "NZD", jt.ENGLISH, "64", "Pitcairn Islands"],
    ["PL", "PLN", jt.POLISH, "48", "Poland"],
    ["PT", "EUR", jt.PORTUGUESE, "351", "Portugal"],
    ["PR", "USD", jt.SPANISH, "1-787", "Puerto Rico"],
    ["QA", "QAR", jt.ARABIC, "974", "Qatar"],
    ["RO", "RON", jt.ROMANIAN, "40", "Romania"],
    ["RU", "RUR", jt.RUSSIAN, "7", "Russia"],
    ["RE", "EUR", jt.FRENCH, "262", "Réunion"],
    ["RW", "RWF", jt.ENGLISH, "250", "Rwanda"],
    ["BL", "EUR", jt.FRENCH, "590", "St. Barthélemy"],
    ["SH", "SHP", jt.ENGLISH, "290", "St. Helena"],
    ["KN", "XCD", jt.ENGLISH, "1-869", "St. Kitts & Nevis"],
    ["LC", "XCD", jt.ENGLISH, "1-758", "St. Lucia"],
    ["MF", "EUR", jt.FRENCH, "590", "St. Martin"],
    ["SX", "ANG", jt.DUTCH, "599", "Sint Maarten"],
    ["PM", "EUR", jt.FRENCH, "508", "St. Pierre & Miquelon"],
    ["VC", "XCD", jt.ENGLISH, "1-784", "St. Vincent & Grenadines"],
    ["WS", "WST", jt.ENGLISH, "685", "Samoa"],
    ["SM", "EUR", jt.ITALIAN, "378", "San Marino"],
    ["ST", "STD", jt.PORTUGUESE, "239", "São Tomé & Príncipe"],
    ["SA", "SAR", jt.ARABIC, "966", "Saudi Arabia"],
    ["SN", "XOF", jt.FRENCH, "221", "Senegal"],
    ["RS", "RSD", jt.SERBIAN, "381", "Serbia"],
    ["SC", "SCR", jt.ENGLISH, "248", "Seychelles"],
    ["SL", "SLL", jt.ENGLISH, "232", "Sierra Leone"],
    ["SG", "SGD", jt.ENGLISH, "65", "Singapore"],
    ["SK", "EUR", jt.SLOVAK, "421", "Slovakia"],
    ["SI", "EUR", jt.SLOVENIAN, "386", "Slovenia"],
    ["SB", "SBD", jt.ENGLISH, "677", "Solomon Islands"],
    ["SO", "SOS", jt.ARABIC, "252", "Somalia"],
    ["ZA", "ZAR", jt.AFRIKAANS, "27", "South Africa"],
    ["GS", "GBP", jt.ENGLISH, "500", "South Georgia & South Sandwich Islands"],
    ["SS", "SSP", jt.ENGLISH, "211", "South Sudan"],
    ["ES", "EUR", jt.SPANISH, "34", "Spain"],
    ["LK", "LKR", jt.ENGLISH, "94", "Sri Lanka"],
    ["SD", "SDG", jt.ENGLISH, "249", "Sudan"],
    ["SR", "SRD", jt.DUTCH, "597", "Suriname"],
    ["SJ", "NOK", jt.ENGLISH, "47", "Svalbard & Jan Mayen"],
    ["SE", "SEK", jt.SWEDISH, "46", "Sweden"],
    ["CH", "CHF", jt.GERMAN, "41", "Switzerland"],
    ["SY", "SYP", jt.ARABIC, "963", "Syria"],
    ["TW", "TWD", jt.CHINESE, "886", "Taiwan"],
    ["TJ", "TJS", jt.RUSSIAN, "992", "Tajikistan"],
    ["TZ", "TZS", jt.SWAHILI, "255", "Tanzania"],
    ["TH", "THB", jt.THAI, "66", "Thailand"],
    ["TL", "USD", jt.PORTUGUESE, "670", "Timor-Leste"],
    ["TG", "XOF", jt.FRENCH, "228", "Togo"],
    ["TK", "NZD", jt.ENGLISH, "690", "Tokelau"],
    ["TO", "TOP", jt.ENGLISH, "676", "Tonga"],
    ["TT", "TTD", jt.ENGLISH, "1-868", "Trinidad & Tobago"],
    ["TN", "TND", jt.ARABIC, "216", "Tunisia"],
    ["TR", "TRY", jt.TURKISH, "90", "Turkey"],
    ["TM", "TMT", jt.RUSSIAN, "993", "Turkmenistan"],
    ["TC", "USD", jt.ENGLISH, "1-649", "Turks & Caicos Islands"],
    ["TV", "AUD", jt.ENGLISH, "688", "Tuvalu"],
    ["UG", "UGX", jt.ENGLISH, "256", "Uganda"],
    ["UA", "UAH", jt.UKRAINIAN, "380", "Ukraine"],
    ["AE", "AED", jt.ARABIC, "971", "United Arab Emirates"],
    ["GB", "GBP", jt.ENGLISH, "44", "United Kingdom"],
    ["US", "USD", jt.ENGLISH, "1", "United States"],
    ["UY", "UYU", jt.SPANISH, "598", "Uruguay"],
    ["UZ", "UZS", jt.RUSSIAN, "998", "Uzbekistan"],
    ["VU", "VUV", jt.ENGLISH, "678", "Vanuatu"],
    ["VA", "EUR", jt.ITALIAN, "379", "Vatican City"],
    ["VE", "VEF", jt.SPANISH, "58", "Venezuela"],
    ["VN", "VND", jt.VIETNAMESE, "84", "Vietnam"],
    ["VG", "USD", jt.ENGLISH, "1-340", "British Virgin Islands"],
    ["VI", "USD", jt.ENGLISH, "1-340", "U.S. Virgin Islands"],
    ["WF", "XPF", jt.FRENCH, "681", "Wallis & Futuna"],
    ["EH", "MAD", jt.ARABIC, "212", "Western Sahara"],
    ["YE", "YER", jt.ARABIC, "967", "Yemen"],
    ["ZM", "ZMW", jt.ENGLISH, "260", "Zambia"],
    ["ZW", "ZWD", jt.ENGLISH, "263", "Zimbabw"],
  ];
let yt = [],
  kt = [];
class Ut extends se {
  constructor(e) {
    super(), re(this, e, P, L, ie, { group: 6, mobile: 0 });
  }
}
class vt {
  constructor(e, t) {
    (this.langStore = e),
      (this.langReloadStore = t),
      (window.tr = vt.transformation);
  }
  static transformation(e, t) {
    return t ? e.replace(/\{(\w+)\}/g, (e, a) => String(t[a])) : e;
  }
  async init() {
    const e = await this.load(this.langStore.language);
    (window.lang = e),
      this.langStoreUnsubscriber ||
        (this.langStoreUnsubscriber = this.langStore.subscribe(() => {
          this.langStore.language !== this.langReloadStore.language &&
            this.init();
        })),
      this.langReloadStore.setLanguage(this.langStore.language);
  }
  setLanguage(e) {
    de.setItem("lang", e), this.langStore.setLanguage(e);
  }
  async load(e) {
    let t;
    switch (e) {
      case "ar":
        t = await Promise.all([
          Ge(() => import("./87b6c980.js").then((e) => e.a), []),
          Ge(() => import("./87b6c980.js").then((e) => e.b), []),
          Ge(() => import("./87b6c980.js").then((e) => e.c), []),
          Ge(() => import("./87b6c980.js").then((e) => e.d), []),
        ]);
        break;
      case "bg":
        t = await Promise.all([
          Ge(() => import("./8a651427.js").then((e) => e.b), []),
          Ge(() => import("./8a651427.js").then((e) => e.a), []),
          Ge(() => import("./8a651427.js").then((e) => e.c), []),
          Ge(() => import("./8a651427.js").then((e) => e.d), []),
        ]);
        break;
      case "zh":
        t = await Promise.all([
          Ge(() => import("./1d8d890d.js").then((e) => e.z), []),
          Ge(() => import("./1d8d890d.js").then((e) => e.a), []),
          Ge(() => import("./1d8d890d.js").then((e) => e.b), []),
          Ge(() => import("./1d8d890d.js").then((e) => e.c), []),
        ]);
        break;
      case "zt":
        t = await Promise.all([
          Ge(() => import("./526c6059.js").then((e) => e.z), []),
          Ge(() => import("./526c6059.js").then((e) => e.a), []),
          Ge(() => import("./526c6059.js").then((e) => e.b), []),
          Ge(() => import("./526c6059.js").then((e) => e.c), []),
        ]);
        break;
      case "hr":
        t = await Promise.all([
          Ge(() => import("./ca75aace.js").then((e) => e.h), []),
          Ge(() => import("./ca75aace.js").then((e) => e.a), []),
          Ge(() => import("./ca75aace.js").then((e) => e.b), []),
          Ge(() => import("./ca75aace.js").then((e) => e.c), []),
        ]);
        break;
      case "cs":
        t = await Promise.all([
          Ge(() => import("./19fea125.js").then((e) => e.c), []),
          Ge(() => import("./19fea125.js").then((e) => e.a), []),
          Ge(() => import("./19fea125.js").then((e) => e.b), []),
          Ge(() => import("./19fea125.js").then((e) => e.d), []),
        ]);
        break;
      case "da":
        t = await Promise.all([
          Ge(() => import("./a95083ee.js").then((e) => e.d), []),
          Ge(() => import("./a95083ee.js").then((e) => e.a), []),
          Ge(() => import("./a95083ee.js").then((e) => e.b), []),
          Ge(() => import("./a95083ee.js").then((e) => e.c), []),
        ]);
        break;
      case "nl":
        t = await Promise.all([
          Ge(() => import("./fc98e5ce.js").then((e) => e.n), []),
          Ge(() => import("./fc98e5ce.js").then((e) => e.a), []),
          Ge(() => import("./fc98e5ce.js").then((e) => e.b), []),
          Ge(() => import("./fc98e5ce.js").then((e) => e.c), []),
        ]);
        break;
      case "et":
        t = await Promise.all([
          Ge(() => import("./12be6bdb.js").then((e) => e.e), []),
          Ge(() => import("./12be6bdb.js").then((e) => e.a), []),
          Ge(() => import("./12be6bdb.js").then((e) => e.b), []),
          Ge(() => import("./12be6bdb.js").then((e) => e.c), []),
        ]);
        break;
      case "fi":
        t = await Promise.all([
          Ge(() => import("./6edd96ff.js").then((e) => e.f), []),
          Ge(() => import("./6edd96ff.js").then((e) => e.a), []),
          Ge(() => import("./6edd96ff.js").then((e) => e.b), []),
          Ge(() => import("./6edd96ff.js").then((e) => e.c), []),
        ]);
        break;
      case "fr":
        t = await Promise.all([
          Ge(() => import("./2b293812.js").then((e) => e.f), []),
          Ge(() => import("./2b293812.js").then((e) => e.a), []),
          Ge(() => import("./2b293812.js").then((e) => e.b), []),
          Ge(() => import("./2b293812.js").then((e) => e.c), []),
        ]);
        break;
      case "ka":
        t = await Promise.all([
          Ge(() => import("./6d98c9f1.js").then((e) => e.k), []),
          Ge(() => import("./6d98c9f1.js").then((e) => e.a), []),
          Ge(() => import("./6d98c9f1.js").then((e) => e.b), []),
          Ge(() => import("./6d98c9f1.js").then((e) => e.c), []),
        ]);
        break;
      case "de":
        t = await Promise.all([
          Ge(() => import("./0e93b44d.js").then((e) => e.d), []),
          Ge(() => import("./0e93b44d.js").then((e) => e.a), []),
          Ge(() => import("./0e93b44d.js").then((e) => e.b), []),
          Ge(() => import("./0e93b44d.js").then((e) => e.c), []),
        ]);
        break;
      case "el":
        t = await Promise.all([
          Ge(() => import("./22f36ebd.js").then((e) => e.e), []),
          Ge(() => import("./22f36ebd.js").then((e) => e.a), []),
          Ge(() => import("./22f36ebd.js").then((e) => e.b), []),
          Ge(() => import("./22f36ebd.js").then((e) => e.c), []),
        ]);
        break;
      case "he":
        t = await Promise.all([
          Ge(() => import("./138ba32c.js").then((e) => e.h), []),
          Ge(() => import("./138ba32c.js").then((e) => e.a), []),
          Ge(() => import("./138ba32c.js").then((e) => e.b), []),
          Ge(() => import("./138ba32c.js").then((e) => e.c), []),
        ]);
        break;
      case "hi":
        t = await Promise.all([
          Ge(() => import("./a5190db0.js").then((e) => e.h), []),
          Ge(() => import("./a5190db0.js").then((e) => e.a), []),
          Ge(() => import("./a5190db0.js").then((e) => e.b), []),
          Ge(() => import("./a5190db0.js").then((e) => e.c), []),
        ]);
        break;
      case "hu":
        t = await Promise.all([
          Ge(() => import("./02e586b3.js").then((e) => e.h), []),
          Ge(() => import("./02e586b3.js").then((e) => e.a), []),
          Ge(() => import("./02e586b3.js").then((e) => e.b), []),
          Ge(() => import("./02e586b3.js").then((e) => e.c), []),
        ]);
        break;
      case "id":
        t = await Promise.all([
          Ge(() => import("./38942436.js").then((e) => e.i), []),
          Ge(() => import("./38942436.js").then((e) => e.a), []),
          Ge(() => import("./38942436.js").then((e) => e.b), []),
          Ge(() => import("./38942436.js").then((e) => e.c), []),
        ]);
        break;
      case "it":
        t = await Promise.all([
          Ge(() => import("./47af3594.js").then((e) => e.i), []),
          Ge(() => import("./47af3594.js").then((e) => e.a), []),
          Ge(() => import("./47af3594.js").then((e) => e.b), []),
          Ge(() => import("./47af3594.js").then((e) => e.c), []),
        ]);
        break;
      case "ja":
        t = await Promise.all([
          Ge(() => import("./c667b17e.js").then((e) => e.j), []),
          Ge(() => import("./c667b17e.js").then((e) => e.a), []),
          Ge(() => import("./c667b17e.js").then((e) => e.b), []),
          Ge(() => import("./c667b17e.js").then((e) => e.c), []),
        ]);
        break;
      case "ko":
        t = await Promise.all([
          Ge(() => import("./7ed30ee4.js").then((e) => e.k), []),
          Ge(() => import("./7ed30ee4.js").then((e) => e.a), []),
          Ge(() => import("./7ed30ee4.js").then((e) => e.b), []),
          Ge(() => import("./7ed30ee4.js").then((e) => e.c), []),
        ]);
        break;
      case "lv":
        t = await Promise.all([
          Ge(() => import("./37ffb080.js").then((e) => e.l), []),
          Ge(() => import("./37ffb080.js").then((e) => e.a), []),
          Ge(() => import("./37ffb080.js").then((e) => e.b), []),
          Ge(() => import("./37ffb080.js").then((e) => e.c), []),
        ]);
        break;
      case "lt":
        t = await Promise.all([
          Ge(() => import("./4693bfef.js").then((e) => e.l), []),
          Ge(() => import("./4693bfef.js").then((e) => e.a), []),
          Ge(() => import("./4693bfef.js").then((e) => e.b), []),
          Ge(() => import("./4693bfef.js").then((e) => e.c), []),
        ]);
        break;
      case "ms":
        t = await Promise.all([
          Ge(() => import("./32e7a095.js").then((e) => e.m), []),
          Ge(() => import("./32e7a095.js").then((e) => e.a), []),
          Ge(() => import("./32e7a095.js").then((e) => e.b), []),
          Ge(() => import("./32e7a095.js").then((e) => e.c), []),
        ]);
        break;
      case "mn":
        t = await Promise.all([
          Ge(() => import("./ddaaa192.js").then((e) => e.m), []),
          Ge(() => import("./ddaaa192.js").then((e) => e.a), []),
          Ge(() => import("./ddaaa192.js").then((e) => e.b), []),
          Ge(() => import("./ddaaa192.js").then((e) => e.c), []),
        ]);
        break;
      case "fa":
        t = await Promise.all([
          Ge(() => import("./32dada42.js").then((e) => e.f), []),
          Ge(() => import("./32dada42.js").then((e) => e.a), []),
          Ge(() => import("./32dada42.js").then((e) => e.b), []),
          Ge(() => import("./32dada42.js").then((e) => e.c), []),
        ]);
        break;
      case "pl":
        t = await Promise.all([
          Ge(() => import("./df055513.js").then((e) => e.p), []),
          Ge(() => import("./df055513.js").then((e) => e.a), []),
          Ge(() => import("./df055513.js").then((e) => e.b), []),
          Ge(() => import("./df055513.js").then((e) => e.c), []),
        ]);
        break;
      case "pt":
        t = await Promise.all([
          Ge(() => import("./114c5001.js").then((e) => e.p), []),
          Ge(() => import("./114c5001.js").then((e) => e.a), []),
          Ge(() => import("./114c5001.js").then((e) => e.b), []),
          Ge(() => import("./114c5001.js").then((e) => e.c), []),
        ]);
        break;
      case "ro":
        t = await Promise.all([
          Ge(() => import("./d4c2c02c.js").then((e) => e.r), []),
          Ge(() => import("./d4c2c02c.js").then((e) => e.a), []),
          Ge(() => import("./d4c2c02c.js").then((e) => e.b), []),
          Ge(() => import("./d4c2c02c.js").then((e) => e.c), []),
        ]);
        break;
      case "ru":
        t = await Promise.all([
          Ge(() => import("./fdab9a13.js").then((e) => e.r), []),
          Ge(() => import("./fdab9a13.js").then((e) => e.a), []),
          Ge(() => import("./fdab9a13.js").then((e) => e.b), []),
          Ge(() => import("./fdab9a13.js").then((e) => e.c), []),
        ]);
        break;
      case "sr":
        t = await Promise.all([
          Ge(() => import("./ee91d23b.js").then((e) => e.s), []),
          Ge(() => import("./ee91d23b.js").then((e) => e.a), []),
          Ge(() => import("./ee91d23b.js").then((e) => e.b), []),
          Ge(() => import("./ee91d23b.js").then((e) => e.c), []),
        ]);
        break;
      case "sk":
        t = await Promise.all([
          Ge(() => import("./f2970876.js").then((e) => e.s), []),
          Ge(() => import("./f2970876.js").then((e) => e.a), []),
          Ge(() => import("./f2970876.js").then((e) => e.b), []),
          Ge(() => import("./f2970876.js").then((e) => e.c), []),
        ]);
        break;
      case "sl":
        t = await Promise.all([
          Ge(() => import("./887bd340.js").then((e) => e.s), []),
          Ge(() => import("./887bd340.js").then((e) => e.a), []),
          Ge(() => import("./887bd340.js").then((e) => e.b), []),
          Ge(() => import("./887bd340.js").then((e) => e.c), []),
        ]);
        break;
      case "es":
        t = await Promise.all([
          Ge(() => import("./e4a6021a.js").then((e) => e.e), []),
          Ge(() => import("./e4a6021a.js").then((e) => e.a), []),
          Ge(() => import("./e4a6021a.js").then((e) => e.b), []),
          Ge(() => import("./e4a6021a.js").then((e) => e.c), []),
        ]);
        break;
      case "sv":
        t = await Promise.all([
          Ge(() => import("./f01c4b88.js").then((e) => e.s), []),
          Ge(() => import("./f01c4b88.js").then((e) => e.a), []),
          Ge(() => import("./f01c4b88.js").then((e) => e.b), []),
          Ge(() => import("./f01c4b88.js").then((e) => e.c), []),
        ]);
        break;
      case "tg":
        t = await Promise.all([
          Ge(() => import("./b63d5356.js").then((e) => e.t), []),
          Ge(() => import("./b63d5356.js").then((e) => e.a), []),
          Ge(() => import("./b63d5356.js").then((e) => e.b), []),
          Ge(() => import("./b63d5356.js").then((e) => e.c), []),
        ]);
        break;
      case "th":
        t = await Promise.all([
          Ge(() => import("./a63d6cc8.js").then((e) => e.t), []),
          Ge(() => import("./a63d6cc8.js").then((e) => e.a), []),
          Ge(() => import("./a63d6cc8.js").then((e) => e.b), []),
          Ge(() => import("./a63d6cc8.js").then((e) => e.c), []),
        ]);
        break;
      case "tr":
        t = await Promise.all([
          Ge(() => import("./bb7af4ec.js").then((e) => e.t), []),
          Ge(() => import("./bb7af4ec.js").then((e) => e.a), []),
          Ge(() => import("./bb7af4ec.js").then((e) => e.b), []),
          Ge(() => import("./bb7af4ec.js").then((e) => e.c), []),
        ]);
        break;
      case "uk":
        t = await Promise.all([
          Ge(() => import("./cd3a0016.js").then((e) => e.u), []),
          Ge(() => import("./cd3a0016.js").then((e) => e.a), []),
          Ge(() => import("./cd3a0016.js").then((e) => e.b), []),
          Ge(() => import("./cd3a0016.js").then((e) => e.c), []),
        ]);
        break;
      case "uz":
        t = await Promise.all([
          Ge(() => import("./35811e6a.js").then((e) => e.u), []),
          Ge(() => import("./35811e6a.js").then((e) => e.a), []),
          Ge(() => import("./35811e6a.js").then((e) => e.b), []),
          Ge(() => import("./35811e6a.js").then((e) => e.c), []),
        ]);
        break;
      case "vi":
        t = await Promise.all([
          Ge(() => import("./c9beca32.js").then((e) => e.v), []),
          Ge(() => import("./c9beca32.js").then((e) => e.a), []),
          Ge(() => import("./c9beca32.js").then((e) => e.b), []),
          Ge(() => import("./c9beca32.js").then((e) => e.c), []),
        ]);
        break;
      default:
        t = await Promise.all([
          Ge(() => import("./5eaedcdc.js").then((e) => e.e), []),
          Ge(() => import("./5eaedcdc.js").then((e) => e.a), []),
          Ge(() => import("./5eaedcdc.js").then((e) => e.b), []),
          Ge(() => import("./5eaedcdc.js").then((e) => e.c), []),
        ]);
    }
    return {
      chart: t[0].chart,
      login: t[1].login,
      trade: t[2].trade,
      ui: t[3].ui,
    };
  }
}
(ae = Object.defineProperty),
  (ne = Object.getOwnPropertyDescriptor),
  (oe = (e, t, a, n) => {
    var o,
      s,
      r = n > 1 ? void 0 : n ? ne(t, a) : t;
    for (o = e.length - 1; o >= 0; o--)
      (s = e[o]) && (r = (n ? s(t, a, r) : s(r)) || r);
    return n && r && ae(t, a, r), r;
  });
class Mt extends nt {
  constructor(e) {
    super(), (this._systemName = "LangStore"), (this.language = e);
  }
  setLanguage(e) {
    this.language = e;
  }
}
oe([at], Mt.prototype, "setLanguage", 1);
const Bt = [
    { id: "en", name: "English", local: "English", short: "en" },
    { id: "ar", name: "Arabic", local: "العربية", short: "ar" },
    { id: "bg", name: "Bulgarian", local: "Български език ", short: "bg" },
    { id: "zh", name: "Chinese Simplified", local: "简体中文", short: "zh" },
    { id: "zt", name: "Chinese Traditional", local: "中國傳統的", short: "zt" },
    { id: "cs", name: "Czech", local: "Čeština", short: "cs" },
    { id: "nl", name: "Dutch", local: "Nederlands", short: "nl" },
    { id: "fr", name: "French", local: "Français", short: "fr" },
    { id: "de", name: "German", local: "Deutsch", short: "de" },
    { id: "el", name: "Greek", local: "Ελληνικά", short: "el" },
    { id: "hi", name: "Hindi", local: "हिन्दी", short: "hi" },
    { id: "hu", name: "Hungarian", local: "Magyar", short: "hu" },
    { id: "id", name: "Indonesian", local: "Bahasa Indonesia", short: "id" },
    { id: "it", name: "Italian", local: "Italiano", short: "it" },
    { id: "ja", name: "Japanese", local: "日本語", short: "ja" },
    { id: "ko", name: "Korean", local: "한국어", short: "ko" },
    { id: "ms", name: "Malay", local: "Bahasa Melayu", short: "ms" },
    { id: "fa", name: "Persian", local: "فارسی", short: "fa" },
    { id: "pl", name: "Polish", local: "Polski", short: "pl" },
    { id: "pt", name: "Portuguese", local: "Portuguê", short: "pt" },
    { id: "ru", name: "Russian", local: "Русский", short: "ru" },
    { id: "es", name: "Spanish", local: "Español", short: "es" },
    { id: "th", name: "Thai", local: "ภาษาไทย", short: "th" },
    { id: "tr", name: "Turkish", local: "Türkçe", short: "tr" },
    { id: "uk", name: "Ukrainian", local: "Українська", short: "uk" },
    { id: "uz", name: "Uzbek", local: "Oʻzbek", short: "uz" },
    { id: "vi", name: "Vietnamese", local: "Tiếng Việt Nam", short: "vi" },
  ],
  Ft = de.getItem("lang"),
  Kt = We.get("lang"),
  xt = Kt ? Bt.find((e) => e.id === Kt) : void 0;
let zt = navigator.language.slice(0, 2).toLowerCase();
"zh-Hans" === navigator.language && (zt = "zh"),
  "zh-Hant" === navigator.language && (zt = "zt");
const Zt = zt ? Bt.find((e) => e.id === zt) : void 0;
let Wt = "en";
Ft
  ? (Wt = Ft)
  : Kt && void 0 !== xt
  ? (Wt = Kt)
  : zt && void 0 !== Zt && (Wt = zt);
const Yt = new (class {
  constructor(e) {
    (this.langStore = new Mt(e)),
      (this.langReloadStore = new Mt(e)),
      (this.langController = new vt(this.langStore, this.langReloadStore));
  }
})(Wt);
class Jt extends se {
  constructor(e) {
    super(), re(this, e, f, T, ie, {});
  }
}
const Xt = (e) => ({ modules: 1 & e }),
  Qt = (e) => ({ modules: e[0].modules }),
  qt = null !== We.get("mode"),
  ea = We.get("login"),
  ta = !(qt || ea);
class aa extends se {
  constructor(e) {
    super(), re(this, e, z, K, ie, {});
  }
}
const { window: na } = Rt;
class oa extends se {
  constructor(e) {
    super(), re(this, e, te, q, ie, {});
  }
}
let sa = class {
  constructor() {
    (this.count = 0),
      (this.init = this.init.bind(this)),
      (this.demo = this.demo.bind(this)),
      (this.close = this.close.bind(this)),
      (this.traderParams = this.traderParams.bind(this)),
      (this.getTraderParams = this.getTraderParams.bind(this)),
      (this.getVerifyCodes = this.getVerifyCodes.bind(this)),
      (this.sendVerifyCodes = this.sendVerifyCodes.bind(this));
  }
  async init(e) {
    var t;
    const a = Tt({});
    if (!(null == (t = this.socket) ? void 0 : t.isReady)) {
      const t = await ft(bt, e, void 0);
      (this.count += 1),
        (this.socket = Ot(t, this.count)),
        await this.socket.connectToServer(),
        await this.socket.sendCommand(29, a);
    }
  }
  async close() {
    var e;
    (null == (e = this.socket) ? void 0 : e.isReady) && this.socket.close();
  }
  demo(e, t) {
    if (!this.socket || !this.socket.isReady)
      throw new Je({ command: -1, code: 103, count: this.count });
    return (this.request = this.openDemo(e, t)), this.request;
  }
  async openDemo(e, t) {
    const a = await this.socket.sendCommand(30, Dt(e, t));
    return { account: $t(a.resBody) };
  }
  async verify(e, t, a) {
    const n = await this.socket.sendCommand(
      27,
      (function (e, t, a) {
        return gt.serialize([
          { propType: 2, propValue: a },
          { propType: 12, propValue: St(), propLength: 16 },
          { propType: 12, propValue: Dt(e, t) },
        ]);
      })(e, t, a)
    );
    return { verify: Vt(n.resBody) };
  }
  getVerifyCodes(e, t, a) {
    if (!this.socket || !this.socket.isReady)
      throw new Je({ command: -1, code: 103, count: this.count });
    return this.verify(e, t, a);
  }
  async sendVerifyCodes(e, t, a, n) {
    if (!this.socket || !this.socket.isReady)
      try {
        await this.init(a), await this.getVerifyCodes(e, t, n);
      } catch (o) {
        throw new Je({ command: -1, code: 103, count: this.count });
      }
    return this.verifyCodes(e, t);
  }
  async verifyCodes(e, t) {
    const a = await this.socket.sendCommand(40, Dt(e, t));
    return { verify: Vt(a.resBody) };
  }
  traderParams() {
    if (!this.socket || !this.socket.isReady)
      throw new Je({ command: -1, code: 103, count: this.count });
    return this.getTraderParams();
  }
  async getTraderParams() {
    return (
      (e = (await this.socket.sendCommand(41)).resBody),
      gt.parse(e, [
        { propType: 11, propLength: 32 },
        { propType: 11, propLength: 32 },
      ])
    );
    var e;
  }
};
const ra = new (class {
    constructor() {
      this.controller = new sa();
    }
  })(),
  ia = {
    init: ra.controller.init,
    close: ra.controller.close,
    open: ra.controller.demo,
    traderParams: ra.controller.traderParams,
    getVerifyCodes: ra.controller.getVerifyCodes,
    sendVerifyCodes: ra.controller.sendVerifyCodes,
  };
class _a {
  constructor(e, t) {
    (this.api = e), (this.usersController = t);
  }
  async create(e, t) {
    await this.api.init(e);
    const a = t.group,
      n = {
        ...a,
        name: a.group,
        description: a.name,
        flag_mask: a.flags,
        type: a.account_type,
        company: "",
        digits: 0,
        leverage: 0,
        deposit: 0,
      },
      o = await this.api.open(t, n);
    if (!(null == o ? void 0 : o.account))
      throw new Je({ code: 1e3, command: 30, count: 0 });
    if (0 !== o.account[0])
      throw new Je({ code: o.account[0], command: 30, count: 0 });
    const [, s, r, i] = o.account,
      _ = {
        login: Number(s),
        password: r,
        savePassword: !0,
        server: e,
        name: `${t.firstName} ${t.secondName}`.trim(),
        balance: t.deposit,
        leverage: t.leverage,
        currency: t.group.currency,
        group: t.group.name,
      };
    return { id: await this.usersController.addUser(_), investor: i };
  }
  async getTraderParams() {
    await this.api.init(Ze.tradeServerDemo);
    const e = await this.api.traderParams();
    e && Ze.setTraderParams(e);
  }
  async getVerifyCodes(e, t, a) {
    await this.api.init(e);
    const n = t.group,
      o = {
        ...n,
        name: n.group,
        description: n.name,
        flag_mask: n.flags,
        type: n.account_type,
        company: "",
        digits: 0,
        leverage: 0,
        deposit: 0,
      };
    return this.api.getVerifyCodes(t, o, a);
  }
  async sendVerifyCodes(e, t, a) {
    const n = t.group,
      o = {
        ...n,
        name: n.group,
        description: n.name,
        flag_mask: n.flags,
        type: n.account_type,
        company: "",
        digits: 0,
        leverage: 0,
        deposit: 0,
      };
    return this.api.sendVerifyCodes(t, o, e, a);
  }
}
const la = new (class {
    constructor(e, t) {
      this.demoController = new _a(e, t);
    }
  })(ia, ot.users.usersController),
  ca = Object.freeze(
    Object.defineProperty({ __proto__: null, demo: la }, Symbol.toStringTag, {
      value: "Module",
    })
  );
ot.theme.themeController.init(),
  document.body.classList.toggle("win", Ht()),
  wt().then(() =>
    Yt.langController.init().then(() =>
      la.demoController.getTraderParams().then(() =>
        ot.init().then(() => {
          document.body.classList.remove("loader");
          const e = document.getElementById("initial-loader-style");
          return null == e || e.remove(), new oa({ target: document.body });
        })
      )
    )
  );
export { l as a, E as b, Yt as c, la as d, c as g, Bt as i, _ as l };
