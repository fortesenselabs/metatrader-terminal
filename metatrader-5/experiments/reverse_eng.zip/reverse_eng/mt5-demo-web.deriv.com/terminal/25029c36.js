function t(t) {
  let e;
  return function (s) {
    if (!s) return;
    const { x: i, y: o } = s.data.global;
    e &&
      Math.abs(i - e.x) < 3 &&
      Math.abs(o - e.y) < 3 &&
      Date.now() - e.date < 250 &&
      t(s),
      (e = { x: i, y: o, date: Date.now() });
  };
}
function e(t) {
  const e = t.sizes;
  return {
    indent: e.indent / 2,
    fontFamily: e.font.family,
    axis: { yVisible: !0, yAlign: "right" },
  };
}
function s(t) {
  switch (t[0]) {
    case 0:
      return t[1];
    case 1:
      return window.tr(window.lang.trade.corporateLink.type.clientAgreement);
    case 2:
      return window.tr(window.lang.trade.corporateLink.type.riskDisclosure);
    case 3:
      return window.tr(
        window.lang.trade.corporateLink.type.clientAgreementAndRiskDisclosure
      );
    case 4:
      return window.tr(
        window.lang.trade.corporateLink.type.complaintsHandlingProcedure
      );
    case 5:
      return window.tr(
        window.lang.trade.corporateLink.type.orderExecutionPolicy
      );
    case 6:
      return window.tr(
        window.lang.trade.corporateLink.type.clientCategorisationNotice
      );
    case 7:
      return window.tr(
        window.lang.trade.corporateLink.type.conflictsOfInterestPolicy
      );
    case 8:
      return window.tr(
        window.lang.trade.corporateLink.type.dataProtectionPolicy
      );
    case 9:
      return window.tr(window.lang.trade.corporateLink.type.fdmDisclaimer);
    default:
      return t[2];
  }
}
var i,
  o,
  r,
  n,
  h,
  a,
  l,
  d,
  c,
  u,
  y,
  g,
  m,
  p,
  b,
  S,
  v,
  f,
  C,
  x,
  w,
  k,
  O,
  T,
  P,
  M,
  L,
  U,
  B,
  D,
  H,
  E,
  R,
  j,
  q,
  A,
  I,
  F,
  _,
  N,
  V,
  W,
  X,
  z,
  K,
  Y,
  $,
  G,
  Q,
  J,
  Z,
  tt,
  et,
  st,
  it,
  ot,
  rt,
  nt,
  ht,
  at,
  lt;
import {
  ah as dt,
  w as ct,
  bW as ut,
  bX as yt,
  bY as gt,
  aL as mt,
  bZ as pt,
  b_ as bt,
  b$ as St,
  c0 as vt,
  a7 as ft,
  bV as Ct,
  D as xt,
  b9 as wt,
  ba as kt,
  c1 as Ot,
  aR as Tt,
  $ as Pt,
  aE as Mt,
} from "./00a24b22.js";
import {
  S as Lt,
  M as Ut,
  a as Bt,
  b as Dt,
  C as Ht,
  V as Et,
  t as Rt,
  B as jt,
  c as qt,
  H as At,
} from "./d09b99f6.js";
import { u as It, v as Ft, w as _t } from "./917f94f7.js";
import { u as Nt } from "./f60bb92f.js";
import { B as Vt, a as Wt } from "./a4b22e5d.js";
import { t as Xt, a as zt, K as Kt, d as Yt } from "./3049ce3f.js";
class $t {
  constructor(t, e, s) {
    (this.api = t),
      (this.accountStore = e),
      (this.usersController = s),
      (this.onUpdate = this.onUpdate.bind(this)),
      this.init();
  }
  init() {
    this.api.view.on(13, this.onUpdate),
      this.api.view.on(14, this.onUpdate),
      this.api.view.on(3, this.onUpdate),
      this.onUpdate();
  }
  update() {
    this.onUpdate();
  }
  destroy() {
    var t, e, s;
    null == (t = this.api) || t.view.off(13, this.onUpdate),
      null == (e = this.api) || e.view.off(14, this.onUpdate),
      null == (s = this.api) || s.view.off(3, this.onUpdate),
      this.accountStore.reset();
  }
  allowedTradeForAccount() {
    return (
      !this.accountStore.isInvestor &&
      !this.accountStore.isTradeDisabled &&
      !this.accountStore.isReadOnly()
    );
  }
  onUpdate() {
    const t = this.api.view.account.getAccount(),
      e = this.usersController.usersStore.getCurrentUser();
    this.accountStore.updateAccount(t, null == e ? void 0 : e.id),
      this.usersController.updateCurrentUser(this.accountStore);
  }
  getNowServerTime() {
    const t = Math.floor(this.accountStore.serverOffsetTime / 3600),
      e = this.accountStore.serverOffsetTime % 3600,
      s = new Date();
    return (
      s.setHours(s.getUTCHours() + t),
      s.setMinutes(s.getUTCMinutes() + e),
      s.getTime()
    );
  }
  changePassword(t, e) {
    return this.api.view.login.changePassword(t, e);
  }
  logout() {
    return this.api.view.login.logout();
  }
  async disconnectOtp(t, e, s, i) {
    return this.api.view.otp.disconnect({
      server: t,
      login: e,
      password: s,
      otp: i,
    });
  }
}
(i = Object.defineProperty),
  (o = Object.getOwnPropertyDescriptor),
  (r = (t, e, s, r) => {
    var n,
      h,
      a = r > 1 ? void 0 : r ? o(e, s) : e;
    for (n = t.length - 1; n >= 0; n--)
      (h = t[n]) && (a = (r ? h(e, s, a) : h(a)) || a);
    return r && a && i(e, s, a), a;
  });
class Gt extends ct {
  constructor() {
    super(),
      (this._systemName = "account"),
      (this.inited = !1),
      (this.assets = 0),
      (this.balance = 0),
      (this.collateral = 0),
      (this.commission = 0),
      (this.company = ""),
      (this.credit = 0),
      (this.currency = ""),
      (this.dayLightMode = 0),
      (this.digits = 0),
      (this.equity = 0),
      (this.floating = 0),
      (this.liabilities = 0),
      (this.margin = 0),
      (this.marginFree = 0),
      (this.marginInitial = 0),
      (this.marginLeverage = 0),
      (this.marginLevel = 0),
      (this.marginMaintenance = 0),
      (this.name = ""),
      (this.profit = 0),
      (this.serverBuild = 0),
      (this.serverName = ""),
      (this.storage = 0),
      (this.timezoneShift = 0),
      (this.type = void 0),
      (this.isReal = !1),
      (this.isDemo = !1),
      (this.isContest = !1),
      (this.isPreliminary = !1),
      (this.group = ""),
      (this.login = 0),
      (this.isInvestor = !1),
      (this.isTradeDisabled = !1),
      (this.readOnly = !1),
      (this.isResetPass = !1),
      (this.isHedgedMargin = !1),
      (this.passwordMin = 8),
      (this.serverOffsetTime = 0),
      (this.riskWarning = 0),
      (this.otpStatus = 0);
  }
  setInit(t) {
    this.inited = t;
  }
  changeRiskWarning(t) {
    this.riskWarning = t;
  }
  isReadOnly() {
    return this.readOnly || [3, 1].includes(this.riskWarning);
  }
  updateAccount(t, e) {
    (this.assets = t.assets),
      (this.balance = t.balance),
      (this.collateral = t.collateral),
      (this.commission = t.commission),
      (this.company = t.company),
      (this.credit = t.credit),
      (this.currency = t.currency),
      (this.dayLightMode = t.dayLightMode),
      (this.digits = t.digits),
      (this.equity = t.equity),
      (this.floating = t.floating),
      (this.liabilities = t.liabilities),
      (this.margin = t.margin),
      (this.marginFree = t.marginFree),
      (this.marginInitial = t.marginInitial),
      (this.marginLeverage = t.marginLeverage),
      (this.marginLevel = t.marginLevel),
      (this.marginMaintenance = t.marginMaintenance),
      (this.name = t.name),
      (this.profit = t.profit),
      (this.serverBuild = t.serverBuild),
      (this.serverName = t.serverName),
      (this.storage = t.storage),
      (this.timezoneShift = t.timezoneShift),
      (this.type = t.type),
      (this.isReal = t.isReal),
      (this.isDemo = t.isDemo),
      (this.isContest = t.isContest),
      (this.isPreliminary = t.isPreliminary),
      (this.login = t.login),
      (this.isInvestor = t.isInvestor),
      (this.isTradeDisabled = t.isTradeDisabled),
      (this.readOnly = t.isReadOnly),
      (this.isHedgedMargin = t.isHedgedMargin),
      (this.isResetPass = t.isResetPass),
      (this.passwordMin = t.passwordMin),
      this.serverOffsetTime !== t.serverOffsetTime &&
        (this.serverOffsetTime = t.serverOffsetTime),
      t.riskWarning &&
        e &&
        (null !== sessionStorage.getItem(e)
          ? (this.riskWarning = 2)
          : (this.riskWarning = 1)),
      (this.otpStatus = t.otpStatus);
  }
  reset() {
    (this.assets = 0),
      (this.balance = 0),
      (this.collateral = 0),
      (this.commission = 0),
      (this.company = ""),
      (this.credit = 0),
      (this.currency = ""),
      (this.dayLightMode = 0),
      (this.digits = 0),
      (this.equity = 0),
      (this.floating = 0),
      (this.liabilities = 0),
      (this.margin = 0),
      (this.marginFree = 0),
      (this.marginInitial = 0),
      (this.marginLeverage = 0),
      (this.marginLevel = 0),
      (this.marginMaintenance = 0),
      (this.name = ""),
      (this.profit = 0),
      (this.serverBuild = 0),
      (this.serverName = ""),
      (this.storage = 0),
      (this.timezoneShift = 0),
      (this.type = void 0),
      (this.isReal = !1),
      (this.isDemo = !1),
      (this.isContest = !1),
      (this.isPreliminary = !1),
      (this.login = 0),
      (this.isInvestor = !1),
      (this.isTradeDisabled = !1),
      (this.readOnly = !1),
      (this.isHedgedMargin = !1),
      (this.isResetPass = !1),
      (this.passwordMin = 8),
      (this.serverOffsetTime = 0),
      (this.riskWarning = 0),
      (this.otpStatus = 1);
  }
}
r([dt], Gt.prototype, "setInit", 1),
  r([dt], Gt.prototype, "changeRiskWarning", 1),
  r([dt], Gt.prototype, "updateAccount", 1),
  r([dt], Gt.prototype, "reset", 1);
class Qt {
  constructor(t, e) {
    (this.accountStore = new Gt()),
      (this.accountController = new $t(t, this.accountStore, e));
  }
}
class Jt {
  constructor(t, e) {
    (this.api = t),
      (this.booksStore = e),
      (this.onUpdateBooks = this.onUpdateBooks.bind(this)),
      this.init();
  }
  init() {
    this.booksStore.reset(), this.api.view.on(8, this.onUpdateBooks);
  }
  destroy() {
    this.api.view.off(8, this.onUpdateBooks), this.booksStore.reset();
  }
  setSpreadSize(t) {
    this.api.view.books.setSpreadSize(t);
  }
  sign(t) {
    t ? this.api.view.books.sign(t) : this.unSign();
  }
  unSign() {
    this.api.view.books.sign();
  }
  onUpdateBooks(t) {
    this.booksStore.setBook(t);
  }
}
(n = Object.defineProperty),
  (h = Object.getOwnPropertyDescriptor),
  (a = (t, e, s, i) => {
    var o,
      r,
      a = i > 1 ? void 0 : i ? h(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (a = (i ? r(e, s, a) : r(a)) || a);
    return i && a && n(e, s, a), a;
  });
class Zt extends ct {
  constructor(t) {
    super(),
      (this._systemName = "BookStore"),
      (this.digits = 5),
      (this.books = []),
      (this.extendedBooks = []),
      (this.symbol = t.symbol),
      (this.books = t.books ? [...t.books] : []),
      (this.extendedBooks = t.extendedBooks ? [...t.extendedBooks] : []),
      (this.digits = t.digits ? t.digits : this.digits),
      (this._systemName = `tick ${this.symbol}`);
  }
  setBook(t) {
    return (
      (this.books = t.books ? [...t.books] : this.books),
      (this.extendedBooks = t.extendedBooks
        ? [...t.extendedBooks]
        : this.books),
      (this.digits = t.digits ?? this.digits),
      this
    );
  }
}
a([dt], Zt.prototype, "setBook", 1);
class te {
  constructor() {
    this.data = {};
  }
  reset() {
    this.data = {};
  }
  getBook(t) {
    return this.data[t] || (this.data[t] = new Zt({ symbol: t })), this.data[t];
  }
  setBook(t) {
    return t.map(
      (t) => (
        this.data[t.symbol] || (this.data[t.symbol] = new Zt(t)),
        this.data[t.symbol].setBook(t),
        this.data[t.symbol]
      )
    );
  }
}
class ee {
  constructor(t) {
    (this.booksStore = new te()),
      (this.booksController = new Jt(t, this.booksStore));
  }
}
class se {
  constructor(t, e, s) {
    (this.api = t),
      (this.symbolsStore = e),
      (this.accountController = s),
      (this.onUpdateSymbols = this.onUpdateSymbols.bind(this)),
      this.init(),
      this.api.view.on(17, this.onUpdateSymbols);
  }
  init() {
    const t = this.api.view.symbols.all();
    this.symbolsStore.reset(t);
  }
  getLeverageBySymbol(t) {
    return this.api.view.margin.getLeveragesBySymbol(t);
  }
  onUpdateSymbols(t) {
    this.api.view.symbols.getMany(t).then((t) => {
      this.symbolsStore.addSymbols(t);
    });
  }
  allowedTradeBySymbol(t) {
    if (!this.accountController.allowedTradeForAccount()) return !1;
    let e = null;
    return (
      "string" != typeof t && null !== t
        ? (e = t)
        : t && (e = this.symbolsStore.getBySymbol(t)),
      !(!e || !e.isTradeEnabled || e.isCollateral)
    );
  }
  getAll() {
    const t = this.api.view.symbols.all();
    this.symbolsStore.setAll(t);
  }
  getBySymbol(t) {
    return this.symbolsStore.getBySymbol(t);
  }
  getBranch(t = "") {
    return this.api.view.symbolTypes.getBranch(t);
  }
  getConfigBySymbol(t) {
    return this.symbolsStore.getBySymbol(t);
  }
  async loadFullSymbols(t) {
    const e = await this.api.view.symbols.getMany(t);
    e.length && this.symbolsStore.addSymbols(e);
  }
}
class ie {
  constructor(t, e) {
    (this.symbolsStore = new Lt()),
      (this.symbolsController = new se(t, this.symbolsStore, e));
  }
}
(l = Object.defineProperty),
  (d = Object.getOwnPropertyDescriptor),
  (c = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? d(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && l(e, s, n), n;
  });
class oe extends ct {
  constructor() {
    super(),
      (this._systemName = "history-deals"),
      (this.index = { id: {}, symbol: {} }),
      (this.items = []),
      (this.sorts = {}),
      (this.keys = Object.values(ut)),
      (this.loading = !1),
      (this.total = null);
  }
  setLoading(t) {
    this.loading = t;
  }
  dealHas(t) {
    return "number" == typeof this.index.id[t];
  }
  reset() {
    (this.index = { id: {}, symbol: {} }),
      (this.items = []),
      (this.sorts = {}),
      (this.total = null);
  }
  getDeals(t) {
    return t && Object.values(ut).includes(t) && this.sorts[t]
      ? [...(this.sorts[t] || [])]
      : [...this.items];
  }
  getDeal(t) {
    const e = this.items[this.index.id[t]];
    return e ? e.value : null;
  }
  getDealsPositionBySymbol(t) {
    return this.index.symbol[t] ?? new Map();
  }
  getDealsBySymbolAndPosition(t, e) {
    const s = this.getDealsPositionBySymbol(t),
      i = null == s ? void 0 : s.get(e);
    return (null == i ? void 0 : i.length) ? i : null;
  }
  updateDeal(t) {
    const e = this.index.id[t.id];
    return (
      this.items &&
        "number" == typeof e &&
        ((this.items[e].value = t), (this.items[e].id = t.deal)),
      this
    );
  }
  setDeals(t) {
    return (
      (this.items = t.map((t) => ({ id: t.deal, value: t }))),
      this.createIndex(),
      this.keys.forEach((t) => {
        this.sorts[t] = (function (t, e) {
          const s = [...t];
          return (
            s.sort((t, s) => {
              const i = "profit" === e ? t.value[e] ?? 0 : t.value[e],
                o = "profit" === e ? s.value[e] ?? 0 : s.value[e];
              return (i ?? 1 / 0) < (o ?? 1 / 0)
                ? -1
                : (i ?? -1 / 0) > (o ?? -1 / 0)
                ? 1
                : 0;
            }),
            s
          );
        })(this.items, t);
      }),
      this
    );
  }
  setTotal(t) {
    return (this.total = t), this;
  }
  createIndex() {
    return (
      (this.index = { id: {}, symbol: {} }),
      this.items.forEach((t, e) => {
        const { deal: s, symbol: i, position: o } = t.value;
        if ((s && (this.index.id[s] = e), this.index.symbol[i]))
          if (this.index.symbol[i].has(o)) {
            const e = this.index.symbol[i].get(o);
            null == e || e.push(t);
          } else this.index.symbol[i].set(o, [t]);
        else
          i &&
            ((this.index.symbol[i] = new Map()),
            this.index.symbol[i].set(o, [t]));
      }),
      this
    );
  }
}
c([dt], oe.prototype, "setLoading", 1),
  c([dt], oe.prototype, "reset", 1),
  c([dt], oe.prototype, "updateDeal", 1),
  c([dt], oe.prototype, "setDeals", 1),
  c([dt], oe.prototype, "setTotal", 1),
  (u = Object.defineProperty),
  (y = Object.getOwnPropertyDescriptor),
  (g = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? y(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && u(e, s, n), n;
  });
class re extends ct {
  constructor() {
    super(),
      (this._systemName = "orders"),
      (this.index = {}),
      (this.items = []),
      (this.sorts = {}),
      (this.keys = Object.values(yt)),
      (this.loading = !1),
      (this.total = null);
  }
  setLoading(t) {
    this.loading = t;
  }
  orderHas(t) {
    return "number" == typeof this.index[t];
  }
  reset() {
    (this.index = {}),
      (this.items = []),
      (this.sorts = {}),
      (this.total = null);
  }
  getOrder(t) {
    const e = this.index[t];
    return "number" == typeof e && this.items[e] ? this.items[e] : null;
  }
  getOrders(t) {
    return t && Object.values(yt).includes(t) && this.sorts[t]
      ? [...(this.sorts[t] || [])]
      : [...this.items];
  }
  updateOrder(t) {
    const e = this.index[t.order];
    return (
      this.items &&
        "number" == typeof e &&
        ((this.items[e].value = t), (this.items[e].id = t.order)),
      this
    );
  }
  setOrders(t) {
    return (
      (this.items = t.map((t) => ({ id: t.order, value: t }))),
      this.createIndex(),
      this.keys.forEach((t) => {
        this.sorts[t] = (function (t, e) {
          const s = [...t];
          return (
            s.sort((t, s) =>
              (t.value[e] ?? 1 / 0) < (s.value[e] ?? 1 / 0)
                ? -1
                : (t.value[e] ?? -1 / 0) > (s.value[e] ?? -1 / 0)
                ? 1
                : 0
            ),
            s
          );
        })(this.items, t);
      }),
      this
    );
  }
  setTotal(t) {
    return (this.total = t), this;
  }
  createIndex() {
    return (
      (this.index = {}),
      this.items.forEach((t, e) => {
        t.value.order && (this.index[t.value.order] = e);
      }),
      this
    );
  }
}
g([dt], re.prototype, "setLoading", 1),
  g([dt], re.prototype, "reset", 1),
  g([dt], re.prototype, "updateOrder", 1),
  g([dt], re.prototype, "setOrders", 1),
  g([dt], re.prototype, "setTotal", 1),
  (m = Object.defineProperty),
  (p = Object.getOwnPropertyDescriptor),
  (b = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? p(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && m(e, s, n), n;
  });
class ne extends ct {
  constructor() {
    super(),
      (this._systemName = "history-positions"),
      (this.index = { id: {}, symbol: {} }),
      (this.items = []),
      (this.sorts = {}),
      (this.keys = Object.values(gt)),
      (this.loading = !1),
      (this.total = null);
  }
  setLoading(t) {
    this.loading = t;
  }
  positionHas(t) {
    return "number" == typeof this.index.id[t];
  }
  reset() {
    (this.index = { id: {}, symbol: {} }),
      (this.items = []),
      (this.sorts = {}),
      (this.total = null);
  }
  getPositions(t) {
    return t && Object.values(gt).includes(t) && this.sorts[t]
      ? [...(this.sorts[t] || [])]
      : [...this.items];
  }
  getPositionsBySymbol(t) {
    return this.index.symbol[t] || [];
  }
  getPositionsBySymbolAndDate(t, e, s) {
    const i = this.index.symbol[t];
    return i
      ? i.filter((t) => {
          const { timeOpen: i, timeClose: o } = t.value;
          return !!o && ((e <= i && s >= i) || (e <= o && s >= o));
        })
      : [];
  }
  getPosition(t) {
    const e = this.items[this.index.id[t]];
    return e ? e.value : null;
  }
  updatePosition(t) {
    const e = this.index.id[t.id];
    return (
      this.items &&
        "number" == typeof e &&
        ((this.items[e].value = t), (this.items[e].id = t.id)),
      this
    );
  }
  setPositions(t) {
    return (
      (this.items = t.map((t) => ({ id: t.id, value: t }))),
      this.createIndex(),
      this.keys.forEach((t) => {
        this.sorts[t] = (function (t, e) {
          const s = [...t];
          return (
            s.sort((t, s) => {
              const i = "profit" === e ? t.value[e] ?? 0 : t.value[e],
                o = "profit" === e ? s.value[e] ?? 0 : s.value[e];
              return (i ?? 1 / 0) < (o ?? 1 / 0)
                ? -1
                : (i ?? -1 / 0) > (o ?? -1 / 0)
                ? 1
                : 0;
            }),
            s
          );
        })(this.items, t);
      }),
      this
    );
  }
  setTotal(t) {
    return (this.total = t), this;
  }
  createIndex() {
    return (
      (this.index = { id: {}, symbol: {} }),
      this.items.forEach((t, e) => {
        const { id: s, symbol: i } = t.value;
        s && (this.index.id[s] = e),
          this.index.symbol[i] || (this.index.symbol[i] = []),
          this.index.symbol[i].push(t);
      }),
      this
    );
  }
}
b([dt], ne.prototype, "setLoading", 1),
  b([dt], ne.prototype, "reset", 1),
  b([dt], ne.prototype, "updatePosition", 1),
  b([dt], ne.prototype, "setPositions", 1),
  b([dt], ne.prototype, "setTotal", 1),
  (S = Object.defineProperty),
  (v = Object.getOwnPropertyDescriptor),
  (f = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? v(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && S(e, s, n), n;
  });
class he extends ct {
  constructor() {
    super(),
      (this._systemName = "history"),
      (this.prevPeriod = 3),
      (this.period = 3);
  }
  setPeriod(t) {
    (this.prevPeriod = this.period), (this.period = t);
  }
  reset() {
    this.period = 3;
  }
}
f([dt], he.prototype, "setPeriod", 1), f([dt], he.prototype, "reset", 1);
class ae {
  constructor(t, e, s, i, o) {
    (this.api = t),
      (this.historyStore = e),
      (this.historyPositionsStore = s),
      (this.historyOrdersStore = i),
      (this.historyDealsStore = o),
      (this.onUpdate = this.onUpdate.bind(this));
  }
  init() {
    this.loadHistory(3), this.onUpdate(), this.unSubscribe(), this.subscribe();
  }
  destroy() {
    this.unSubscribe(),
      this.historyStore.reset(),
      this.historyPositionsStore.reset(),
      this.historyOrdersStore.reset(),
      this.historyDealsStore.reset(),
      this.setLoading(!0);
  }
  subscribe() {
    this.api.view.on(1, this.onUpdate);
  }
  unSubscribe() {
    var t;
    null == (t = this.api) || t.view.off(1, this.onUpdate);
  }
  onUpdate() {
    this.getDeals(), this.getPositions(), this.getOrders();
  }
  getPositions() {
    const { items: t, total: e } = this.api.view.history.positions();
    this.historyPositionsStore.setPositions(t),
      this.historyPositionsStore.setTotal(e);
  }
  getOrders() {
    const { items: t, total: e } = this.api.view.history.orders();
    this.historyOrdersStore.setOrders(t), this.historyOrdersStore.setTotal(e);
  }
  getDeals() {
    const { items: t, total: e } = this.api.view.history.deals();
    this.historyDealsStore.setDeals(t), this.historyDealsStore.setTotal(e);
  }
  async loadHistory(t, e) {
    this.setLoading(!0);
    try {
      await this.api.view.history.load(e || It(t)),
        this.setPeriod(t),
        this.onUpdate();
    } catch (s) {
      if (s instanceof mt) {
        const { command: t, code: e } = s;
      }
    }
    this.setLoading(!1);
  }
  setLoading(t) {
    this.historyDealsStore.setLoading(t),
      this.historyOrdersStore.setLoading(t),
      this.historyPositionsStore.setLoading(t);
  }
  setPeriod(t) {
    this.historyStore.setPeriod(t);
  }
}
class le {
  constructor(t) {
    (this.historyStore = new he()),
      (this.historyPositionsStore = new ne()),
      (this.historyOrdersStore = new re()),
      (this.historyDealsStore = new oe()),
      (this.historyController = new ae(
        t,
        this.historyStore,
        this.historyPositionsStore,
        this.historyOrdersStore,
        this.historyDealsStore
      ));
  }
}
class de {
  constructor(t, e) {
    (this.storage = pt.objects),
      (this.objectsStore = t),
      (this.uiSettingsController = e),
      (this.onSave = this.onSave.bind(this)),
      (this.editObject = this.editObject.bind(this)),
      (this.onFocus = this.onFocus.bind(this)),
      (this.onBLur = this.onBLur.bind(this));
  }
  async init(t) {
    const e = this.uiSettingsController.uiSettingsStore.selectedSymbol;
    if (!e) return this;
    const s = await this.storage.getAll("symbol", e);
    return (
      t
        .on(Ut.SaveSettings, this.onSave)
        .on(Ut.Settings, this.editObject)
        .on(Ut.Focus, this.onFocus)
        .on(Ut.Blur, this.onBLur),
      this.objectsStore.reset(s),
      this
    );
  }
  destroy(t) {
    t.off(Ut.SaveSettings, this.onSave)
      .off(Ut.Settings, this.editObject)
      .off(Ut.Focus, this.onFocus)
      .off(Ut.Blur, this.onBLur);
  }
  onSave(t) {
    const e = this.uiSettingsController.uiSettingsStore.selectedSymbol;
    if (!e) return this;
    const s = { symbol: e, ...t.toJSON() };
    return this.objectsStore.add(s), this.storage.add(s), this;
  }
  remove(t) {
    return this.objectsStore.removeByUid(t), this.storage.remove(t), this;
  }
  editObject(t) {
    this.objectsStore.editObject(t.index);
  }
  onFocus(t) {
    this.objectsStore.selectObject(t.index);
  }
  onBLur() {
    this.objectsStore.selectObject(void 0);
  }
}
(C = Object.defineProperty),
  (x = Object.getOwnPropertyDescriptor),
  (w = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? x(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && C(e, s, n), n;
  });
class ce extends ct {
  constructor() {
    super(),
      (this._systemName = bt.objects),
      (this.items = []),
      (this.index = { uid: {}, index: {} });
  }
  getAll() {
    return this.items;
  }
  reset(t = []) {
    return (
      (this.items = t.map((t) => {
        if ("string" == typeof t.type) {
          const e = t.type.replace(/-/g, "_");
          t.type = CHART_OBJECTS[e];
        }
        return t;
      })),
      this.createIndex(),
      this
    );
  }
  add(t) {
    const e = this.index.index[t.uid];
    return (
      "number" == typeof e ? (this.items[e] = t) : this.items.push(t),
      this.createIndex(),
      this
    );
  }
  removeByUid(t) {
    const e = this.index.index[t];
    "number" == typeof e && this.removeByIndex(e);
  }
  removeByIndex(t) {
    this.items.splice(t, 1), this.createIndex(), this.selectObject(void 0);
  }
  findByUid(t) {
    return this.index.uid[t];
  }
  createIndex() {
    return (
      (this.index = { uid: {}, index: {} }),
      this.items.forEach((t, e) => {
        (this.index.uid[t.uid] = t), (this.index.index[t.uid] = e);
      }),
      this
    );
  }
  editObject(t) {
    this.editObjectIndex = t;
  }
  selectObject(t) {
    this.selectedObjectIndex = t;
  }
}
w([dt], ce.prototype, "reset", 1),
  w([dt], ce.prototype, "add", 1),
  w([dt], ce.prototype, "removeByUid", 1),
  w([dt], ce.prototype, "removeByIndex", 1),
  w([dt], ce.prototype, "editObject", 1),
  w([dt], ce.prototype, "selectObject", 1);
class ue {
  constructor(t) {
    (this.objectsStore = new ce()),
      (this.objectsController = new de(this.objectsStore, t));
  }
}
class ye {
  constructor(t, e, s, i) {
    (this.api = t),
      (this.ticksStore = e),
      (this.symbolsController = s),
      (this.barsController = i),
      (this.onTick = this.onTick.bind(this)),
      this.init();
  }
  init() {
    this.ticksStore.reset(), this.api.view.on(0, this.onTick);
  }
  destroy() {
    var t;
    null == (t = this.api) || t.view.off(0, this.onTick),
      this.ticksStore.getAllSymbols().forEach((t) => this.off(t));
  }
  onTick(t) {
    const e = this.api.view.ticks.getTick(t.symbol, t.delayed),
      s = this.symbolsController.symbolsStore.getBySymbol(t.symbol);
    if (s && e && ((s.delay && t.delayed) || (!s.delay && !t.delayed))) {
      const t = this.ticksStore.setTick(e, !0);
      if (!s) throw new Error(`symbol "${t.symbol}" doesn't exist`);
      this.barsController.barsStore.extends(s, t), t.refresh();
    }
  }
  on(t) {
    this.ticksStore.getTick(t), this.api.view.ticks.subscribe(t);
  }
  off(t) {
    return this.api.view.ticks.unSubscribe(t), this;
  }
}
class ge extends ct {
  constructor(t) {
    super(),
      (this._systemName = "_tick"),
      (this.ask = 0),
      (this.askTrend = 0),
      (this.askHigh = 0),
      (this.askHighTrend = 0),
      (this.askLow = 0),
      (this.askLowTrend = 0),
      (this.askLast = 0),
      (this.askOriginal = 0),
      (this.bid = 0),
      (this.bidTrend = 0),
      (this.bidHigh = 0),
      (this.bidHighTrend = 0),
      (this.bidLow = 0),
      (this.bidLowTrend = 0),
      (this.bidLast = 0),
      (this.bidOriginal = 0),
      (this.last = 0),
      (this.change = 0),
      (this.lastHigh = 0),
      (this.lastLast = 0),
      (this.lastLow = 0),
      (this.lastTrend = 0),
      (this.spread = 0),
      (this.symbol = t),
      (this.time = new Date()),
      (this.timeMs = new Date()),
      (this.volume = 0),
      (this.volumeTrend = 0),
      (this.isReal = !1),
      (this.fields = 0),
      (this.volLast = ""),
      (this._systemName = `tick "${this.symbol}"`),
      (this.priceOpen = 0),
      (this.priceClose = 0),
      (this.low = 0),
      (this.high = 0);
  }
  setTick(t, e = !1) {
    return (
      (this.ask = Number(t.ask)),
      (this.askOriginal = Number(t.askOriginal)),
      (this.askTrend = t.askTrend),
      (this.askHigh = Number(t.askHigh)),
      (this.askHighTrend = t.askHighTrend),
      (this.askLow = Number(t.askLow)),
      (this.askLowTrend = t.askLowTrend),
      (this.askLast = Number(t.askLast)),
      (this.bid = Number(t.bid)),
      (this.bidOriginal = Number(t.bidOriginal)),
      (this.bidTrend = t.bidTrend),
      (this.bidHigh = Number(t.bidHigh)),
      (this.bidHighTrend = t.bidHighTrend),
      (this.bidLow = Number(t.bidLow)),
      (this.bidLowTrend = t.bidLowTrend),
      (this.bidLast = Number(t.bidLast)),
      (this.change = t.change),
      (this.last = Number(t.last)),
      (this.lastHigh = Number(t.lastHigh)),
      (this.lastLast = Number(t.lastLast)),
      (this.lastLow = Number(t.lastLow)),
      (this.lastTrend = t.lastTrend),
      (this.spread = t.spread),
      (this.symbol = t.symbol),
      (this.time = new Date(t.time)),
      (this.timeMs = new Date(t.timeMs)),
      (this.volume = Number(t.volume)),
      (this.volumeTrend = t.volumeTrend),
      (this.isReal = !0),
      (this.fields = t.fields),
      (this.volLast = t.volLast),
      (this.priceOpen = t.priceOpen),
      (this.priceClose = t.priceClose),
      (this.low = t.low),
      (this.high = t.high),
      (this._systemName = `tick ${this.symbol}`),
      e || this.refresh(),
      this
    );
  }
}
(k = Object.defineProperty),
  (O = Object.getOwnPropertyDescriptor),
  (T = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? O(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && k(e, s, n), n;
  });
class me extends ct {
  constructor() {
    super(), (this._systemName = "Ticks"), (this.data = {});
  }
  reset() {
    this.data = {};
  }
  getAllSymbols() {
    return Object.keys(this.data);
  }
  setTick(t, e = !1) {
    return (
      this.data[t.symbol] ||
        ((this.data[t.symbol] = new ge(t.symbol)), e || this.refresh()),
      this.data[t.symbol].setTick(t, e),
      this.data[t.symbol]
    );
  }
  getTick(t) {
    return this.data[t] ? this.data[t] : this.create(t);
  }
  getTicks(t) {
    return t.map((t) => this.getTick(t));
  }
  create(t) {
    return (
      this.data[t] || ((this.data[t] = new ge(t)), this.refresh()), this.data[t]
    );
  }
}
T([dt], me.prototype, "reset", 1);
class pe {
  constructor(t, e, s) {
    (this.ticksStore = new me()),
      (this.ticksController = new ye(t, this.ticksStore, e, s));
  }
}
class be extends Nt {
  constructor(t, e = 2e3) {
    super(t, e), (this.textLength = 0), (this.section = t.section);
  }
  tick() {}
  _init() {
    super._init(), (this.yHeight -= 80);
  }
  _calc() {
    var t;
    const e = null == (t = this.section) ? void 0 : t.indicator;
    if (e)
      return (
        e.calc(),
        (this.yHeight = e.yHeight),
        (this.yMin = e.yMin),
        (this.yMax = e.yMax),
        void this.calcTextLength()
      );
    super._calc(), this.calcTextLength();
  }
  calcTextLength() {
    const { digits: t } = this.section,
      e = this.yMin ? this.yMin.toFixed(t).length : 0,
      s = this.yMax ? this.yMax.toFixed(t).length : 0,
      i = this.textLength;
    return (this.textLength = Math.max(s, e)), [i, this.textLength];
  }
  _draw() {
    const { state: t, section: e, colors: s, style: i } = this,
      o = this._createGraphics();
    if (((o.y = e.y), i.axis.yVisible)) {
      const i = t.yAxisIsLeft ? 0 : t.graphWidth + 1,
        r = t.yAxisWidth;
      o.beginFill(s.chart.backgroundColor),
        o.drawRect(i, 0, r, e.height),
        o.endFill();
      let n = t.yAxisIsLeft ? t.yAxisWidth : t.graphWidth + 1;
      o.beginFill(s.chart.axis.borderColor),
        o.drawRect(n, 0, 1, e.height + 1),
        o.endFill(),
        (n = t.yAxisIsLeft ? t.yAxisWidth : t.graphX),
        o.beginFill(s.chart.axis.borderColor),
        o.drawRect(n, -1, t.graphWidth + 1, 1),
        o.endFill();
    }
    if (!e.collapsed()) {
      const { digits: t } = e;
      this._init();
      const s = Math.ceil(50 / this.yStep),
        r = this._getBeauty(s) / this.getYDigits();
      let n = Math.floor(this.yToValue(e.height) / r) * r;
      const h = this.yToValue(0);
      for (; n < h; ) {
        const e = this.valueToY(n);
        this.commonConfig.grid && this._drawGrid(o, e),
          i.axis.yVisible &&
            (this._drawLabel(o, e, n.toFixed(t)), this._drawDash(o, e)),
          (n += r);
      }
    }
    o.endFill(), this.container.addChild(o);
  }
  _drawLabel(t, e, s) {
    const { state: i, section: o } = this,
      { colors: r } = this;
    if (e < 0 || e > o.height - 10) return;
    const n = this.createText(s);
    r.chart.axis.textColor && (n.tint = r.chart.axis.textColor),
      (n.x = i.yAxisIsLeft ? i.yAxisWidth - n.textWidth - 8 : i.graphWidth + 8),
      (n.y = Math.round(e - 8)),
      t.addChild(n);
  }
  _drawGrid(t, e) {
    const { state: s, section: i, colors: o } = this;
    if (e < 0 || e > i.height - 10) return;
    const r = s.yAxisIsLeft ? s.yAxisWidth + 1 : 0,
      n = s.yAxisIsLeft ? s.graphWidth : s.graphWidth + 1;
    t.beginFill(o.chart.gridColor), t.drawRect(r, e, n, 1);
  }
  _drawDash(t, e) {
    const { state: s, section: i, colors: o } = this,
      r = s.graphWidth + 1;
    e < 0 ||
      e > i.height - 10 ||
      (t.beginFill(o.chart.axis.borderColor), t.drawRect(r, e, 4, 1));
  }
  _getBeauty(t) {
    for (let e = 1; e < 10; e++) {
      const s = 10 ** e;
      for (let e = 1; e < 10; e++) {
        const i = e * s;
        if (t < i) return i;
      }
    }
    return t;
  }
}
class Se extends Nt {
  constructor(t, e = 7e3, s) {
    super(t, e),
      (this.section = t.section),
      (this.onChange = this.onChange.bind(this)),
      (this.objects = s
        .on(Ut.Remove, this.onChange)
        .on(Ut.Focus, this.onChange)
        .on(Ut.Blur, this.onChange)
        .on(Ut.Move, this.onChange)),
      (this.container.interactiveChildren = !1);
  }
  destroy() {
    this.objects
      .off(Ut.Remove, this.onChange)
      .off(Ut.Focus, this.onChange)
      .off(Ut.Blur, this.onChange)
      .off(Ut.Move, this.onChange),
      super.destroy();
  }
  tick() {}
  _init() {
    super._init(), (this.yHeight -= 80);
  }
  _calc() {
    const { indicator: t } = this.section;
    if (t)
      return (
        t.calc(),
        (this.yHeight = t.yHeight),
        (this.yMin = t.yMin),
        void (this.yMax = t.yMax)
      );
    super._calc();
  }
  _draw() {
    this._drawPrice();
  }
  _drawPrice() {
    const { state: t, section: e } = this,
      s = this.colors.chart.selected;
    let i = 0;
    const o = e.y;
    let r = t.width;
    const n = e.height;
    t.yAxisIsLeft
      ? (r = t.yAxisWidth)
      : ((i = t.graphX + t.graphWidth + 1), (r = t.width - i));
    const h = this._createGraphics("mask");
    (h.x = i),
      (h.y = o),
      (h.isMask = !0),
      h.beginFill(),
      h.drawRect(0, 0, r, n),
      h.endFill(),
      this.container.addChild(h);
    const a = this._createGraphics();
    (a.y = o), (a.mask = h), this.container.addChild(a);
    const l = this.changed(
      0,
      t.graphWidth,
      s.marker.textColor,
      s.marker.backgroundColor
    );
    let d, c;
    const u = this.getMin();
    if (u !== Number.MAX_SAFE_INTEGER) {
      d = this.valueToY(u);
      let t = this._minLine;
      d >= 0 && d <= e.height
        ? ((t && !l) ||
            ((this._minLine = this.createPriceLine(
              "min",
              s.marker.backgroundColor,
              s.marker.textColor,
              s.marker.backgroundColor
            )),
            (t = this._minLine)),
          (t.y = d),
          (t.visible = !0),
          this.updatePriceLine("min", u, e.digits),
          a.addChild(t))
        : t && (t.visible = !1);
    }
    const y = this.getMax();
    if (y !== Number.MIN_SAFE_INTEGER) {
      c = this.valueToY(y);
      let t = this._maxLine;
      c >= 0 && c <= e.height
        ? ((t && !l) ||
            ((this._maxLine = this.createPriceLine(
              "max",
              s.marker.backgroundColor,
              s.marker.textColor,
              s.marker.backgroundColor
            )),
            (t = this._maxLine)),
          (t.y = c),
          (t.visible = !0),
          this.updatePriceLine("max", y, e.digits),
          a.addChild(t))
        : t && (t.visible = !1);
    }
    "number" == typeof d &&
      "number" == typeof c &&
      u !== Number.MAX_SAFE_INTEGER &&
      y !== Number.MIN_SAFE_INTEGER &&
      ((d >= 0 && d <= e.height) || (c >= 0 && c <= e.height)) &&
      (a.beginFill(s.diff.color, s.diff.alpha),
      a.drawRect(i + 2, Math.min(c, d), r, Math.max(c, d) - Math.min(c, d)),
      a.endFill());
  }
  onChange() {
    this.draw();
  }
  getMin() {
    let t = Number.MAX_SAFE_INTEGER;
    const { renderers: e } = this.objects.data;
    if (e) {
      const { section: s } = this;
      e.forEach((e) => {
        if (e.focused && e.section === s) {
          const { price1: s, price2: i, price3: o } = e.settings.coordinates,
            r = [t, s, i, o].filter((t) => "number" == typeof t).map(Number);
          t = Math.min(...r);
        }
      });
    }
    return t;
  }
  getMax() {
    let t = Number.MIN_SAFE_INTEGER;
    const { renderers: e } = this.objects.data;
    if (e) {
      const { section: s } = this;
      e.forEach((e) => {
        if (e.focused && e.section === s) {
          const { price1: s, price2: i, price3: o } = e.settings.coordinates,
            r = [t, s, i, o].filter((t) => "number" == typeof t).map(Number);
          t = Math.max(...r);
        }
      });
    }
    return t;
  }
}
class ve extends Nt {
  constructor(t, e = 1e4) {
    super(t, e),
      (this.section = t.section),
      (this.onMouseMove = this.onMouseMove.bind(this)),
      (this.onMouseOut = this.onMouseOut.bind(this)),
      this.stage &&
        (this.stage.removeEventListener("pointerdown", this.onMouseMove),
        this.stage.removeEventListener("pointermove", this.onMouseMove),
        this.stage.removeEventListener("mouseout", this.onMouseOut),
        this.stage.addEventListener("pointerdown", this.onMouseMove),
        this.stage.addEventListener("pointermove", this.onMouseMove),
        this.stage.addEventListener("mouseout", this.onMouseOut)),
      (this.container.interactiveChildren = !1);
  }
  tick() {}
  _init() {
    super._init(), (this.yHeight -= 80);
  }
  _calc() {
    const { indicator: t } = this.section;
    if (t)
      return (
        t.calc(),
        (this.yHeight = t.yHeight),
        (this.yMin = t.yMin),
        void (this.yMax = t.yMax)
      );
    super._calc();
  }
  _draw() {
    const { section: t, state: e } = this;
    if (!e.crosshair) return;
    if (t.collapsed()) return;
    this.line && this.container.addChild(this.line);
    const { xCache: s, yCache: i } = this;
    void 0 !== s && void 0 !== i && this._move(s, i);
  }
  _move(t, e) {
    this.state.crosshair &&
    t > this.state.graphX &&
    t < this.state.graphX + this.state.graphWidth &&
    e > this.section.y &&
    e < this.section.y + this.section.height
      ? ((this.container.visible = !0), this._movePrice(t, e))
      : (this.container.visible = !1);
  }
  _movePrice(t, e) {
    let s = e;
    const { state: i, section: o } = this,
      r = this.bars.value,
      { digits: n } = o;
    let h = this.yToValue(s - o.y);
    const a = this._getLine();
    if (a) {
      if (i.getScale() > 20) {
        const e = i.xToIndex(t),
          o = ["open", "high", "low", "close"],
          n = o.reduce(
            (t, s) => (
              "open" === s
                ? (t.open = r.open(e))
                : "high" === s
                ? (t.high = r.high(e))
                : "low" === s
                ? (t.low = r.low(e))
                : "close" === s && (t.colse = r.close(e)),
              t
            ),
            {}
          ),
          a = o.map((t) => this.valueToY(n[t])),
          l = a.map((t) => Math.abs(s - t)),
          d = l.reduce((t, e) => Math.min(t, e), Number.MAX_VALUE);
        if (d < 10) {
          const t = l.findIndex((t) => t === d);
          t > -1 && ((h = n[o[t]]), (s = a[t]));
        }
      }
      a.y = Math.round(s);
      const e = a.getChildAt(0);
      e &&
        e instanceof Vt &&
        ((e.text = isNaN(h) ? "" : h.toFixed(n)),
        i.yAxisIsLeft &&
          this.changed("price", Math.floor(h)) &&
          (e.x = i.yAxisWidth - e.textWidth - 8));
    }
  }
  _getLine() {
    const { state: t, colors: e } = this,
      { period: s } = this.config,
      i = this.changed(
        "main",
        s,
        t.graphWidth,
        t.graphHeight,
        e.chart.crossHair.lineColor,
        e.chart.crossHair.textColor,
        e.chart.crossHair.textBackgroundColor
      );
    return (
      (this.line && !i) ||
        ((this.line = this.createPriceLine(
          "main",
          e.chart.crossHair.lineColor,
          e.chart.crossHair.textColor,
          e.chart.crossHair.textBackgroundColor,
          0.7
        )),
        this.container.addChild(this.line)),
      this.line
    );
  }
  onMouseMove(t) {
    const { x: e, y: s } = t.data.global;
    (this.xCache = e), (this.yCache = s), this._move(e, s);
  }
  onMouseOut() {
    (this.container.visible = !1), delete this.xCache, delete this.yCache;
  }
  destroy() {
    this.stage &&
      (this.stage.removeEventListener("pointerdown", this.onMouseMove),
      this.stage.removeEventListener("pointermove", this.onMouseMove),
      this.stage.removeEventListener("mouseout", this.onMouseOut)),
      super.destroy();
  }
}
class fe {
  constructor(e, s) {
    (this.startPosition = 0),
      (this.startScale = 0),
      (this.axis = e),
      (this.chart = s),
      (this.onDown = this.onDown.bind(this)),
      (this.onMove = this.onMove.bind(this)),
      (this.onUp = this.onUp.bind(this)),
      (this.onDblClick = t(this.onDblClick.bind(this))),
      (this.axis.view.interactive = !0),
      this.axis.view.addEventListener("pointerdown", this.onDown),
      this.axis.view.addEventListener("pointerup", this.onDblClick);
  }
  onDblClick() {
    this.axis.section.resetYScale(), this.chart.state.refresh();
  }
  destroy() {
    this.axis.view &&
      (this.axis.view.removeEventListener("pointerdown", this.onDown),
      this.axis.view.removeEventListener("pointerup", this.onDblClick),
      this.axis.view.removeEventListener("pointermove", this.onMove),
      this.axis.view.removeEventListener("pointerup", this.onUp),
      this.axis.view.removeEventListener("pointerupoutside", this.onUp));
  }
  onDown(t) {
    const e = t.global.x;
    if (
      e > this.axis.state.graphX &&
      e < this.axis.state.graphX + this.axis.state.graphWidth
    )
      return;
    t.stopPropagation(),
      t.originalEvent.preventDefault(),
      (this.startPosition = t.global.y),
      (this.startScale = this.axis.section.scale);
    const { stage: s } = this.axis;
    s &&
      (s.addEventListener("pointermove", this.onMove),
      s.addEventListener("pointerup", this.onUp),
      s.addEventListener("pointerupoutside", this.onUp)),
      (document.body.style.cursor = "ns-resize");
  }
  onMove(t) {
    t.stopPropagation();
    const e = t.data.global.y - this.startPosition;
    let s = this.startScale;
    (s -= (e / this.axis.section.height) * 0.5),
      (this.axis.section.scale = Math.min(10, Math.max(0.05, s))),
      this.chart.state.refresh();
  }
  onUp() {
    this.axis.stage &&
      (this.axis.stage.removeEventListener("pointermove", this.onMove),
      this.axis.stage.removeEventListener("pointerup", this.onUp),
      this.axis.stage.removeEventListener("pointerupoutside", this.onUp)),
      (document.body.style.cursor = "auto");
  }
}
class Ce {
  constructor(t, e) {
    (this.startPosition = 0),
      (this.startPadding = 0),
      (this.axis = t),
      (this.chart = e),
      (this.onDown = this.onDown.bind(this)),
      (this.onMove = Xt(16, this.onMove.bind(this))),
      (this.onUp = this.onUp.bind(this));
    const s = t.stage;
    s && ((s.interactive = !0), s.addEventListener("pointerdown", this.onDown));
  }
  destroy() {
    var t;
    (null == (t = this.axis) ? void 0 : t.stage) &&
      (this.axis.stage.removeEventListener("pointerdown", this.onDown),
      this.axis.stage.removeEventListener("pointermove", this.onMove),
      this.axis.stage.removeEventListener("pointerup", this.onUp),
      this.axis.stage.removeEventListener("pointerupoutside", this.onUp));
  }
  onDown(t) {
    if (0 !== this.chart.state.mode) return;
    const { x: e, y: s } = t.global;
    if (1 === this.axis.section.scale) return;
    if (
      e < this.axis.state.graphX ||
      e > this.axis.state.graphX + this.axis.state.graphWidth ||
      s < this.axis.section.y ||
      s > this.axis.section.y + this.axis.section.height
    )
      return;
    t.stopPropagation(),
      t.originalEvent.preventDefault(),
      (this.startPosition = s),
      (this.startPadding = this.axis.section.padding);
    const { stage: i } = this.axis;
    i &&
      (i.addEventListener("pointermove", this.onMove),
      i.addEventListener("pointerup", this.onUp),
      i.addEventListener("pointerupoutside", this.onUp)),
      (document.body.style.cursor = "ns-resize");
  }
  onMove(t) {
    t.stopPropagation();
    const { y: e } = t.global;
    (this.axis.section.padding = this.startPadding - (this.startPosition - e)),
      this.chart.redraw();
  }
  onUp() {
    const t = this.axis.stage;
    t &&
      (t.removeEventListener("pointermove", this.onMove),
      t.removeEventListener("pointerup", this.onUp),
      t.removeEventListener("pointerupoutside", this.onUp)),
      (document.body.style.cursor = "auto");
  }
}
class xe {
  constructor(t) {
    (this.digits = 0),
      (this.x = 0),
      (this.y = 0),
      (this.width = 400),
      (this.height = 400),
      (this.scale = t.config.yScale),
      (this.padding = t.config.yPadding),
      this.setDigits(t.config.getDigits()),
      (this.indicator = null);
    const e = t.createOptions(this);
    (this.axis = new be(e)),
      (this.line = new ve(e)),
      (this.selected = new Se(e, 7e3, t.objects)),
      (this.scaleHandler = new fe(this.axis, t)),
      (this.moveHandler = new Ce(this.axis, t));
  }
  setDigits(t) {
    this.digits = t;
  }
  collapsed() {
    return Boolean(this.indicator && this.indicator.isCollapsed());
  }
  destroy() {
    this.axis.destroy(),
      this.line.destroy(),
      this.selected.destroy(),
      this.scaleHandler.destroy(),
      this.moveHandler.destroy();
  }
  redraw() {
    this.axis.draw(), this.line.draw(), this.selected.draw();
  }
  applyTick() {
    this.axis.tick(), this.line.tick(), this.selected.tick();
  }
  resetYScale() {
    (this.scale = 1), (this.padding = 0);
  }
}
(P = Object.defineProperty),
  (M = Object.getOwnPropertyDescriptor),
  (L = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? M(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && P(e, s, n), n;
  }),
  (U = ((t) => ((t.ResizeAxis = "ResizeAxis"), (t.Move = "Move"), t))(U || {}));
class we extends ct {
  constructor() {
    super(...arguments), (this.sections = []);
  }
  add(t) {
    this.sections.push(t);
  }
  move(t, e) {
    const s = this.sections[t];
    return this.sections.splice(t, 1), this.sections.splice(e, 0, s), s;
  }
  remove(t) {
    this.sections[t].destroy(), this.sections.splice(t, 1);
  }
  clear() {
    this.sections = [];
  }
  reset() {
    var t;
    null == (t = this.sections) || t.slice(1).forEach((t) => t.destroy()),
      this.sections.splice(1, this.sections.length - 1);
  }
}
L([dt], we.prototype, "add", 1),
  L([dt], we.prototype, "move", 1),
  L([dt], we.prototype, "remove", 1),
  L([dt], we.prototype, "clear", 1),
  L([dt], we.prototype, "reset", 1);
class ke {
  constructor(t) {
    (this.data = new we()),
      (this.listeners = new Map()),
      (this.width = 0),
      (this.chart = t);
  }
  on(t, e) {
    let s = this.listeners.get(t);
    return s || ((s = new Set()), this.listeners.set(t, s)), s.add(e), this;
  }
  off(t, e) {
    const s = this.listeners.get(t);
    return s && (e && s.has(e) ? s.delete(e) : e || s.clear()), this;
  }
  trigger(t, e) {
    const s = this.listeners.get(t);
    return (
      s &&
        s.forEach((t) => {
          t(e);
        }),
      this
    );
  }
  clear() {
    this.data.clear();
  }
  init() {
    return (
      (this.width = 0),
      this.data.reset(),
      this.data.sections.length || this.add(),
      this.data.sections[0].setDigits(this.chart.config.getDigits()),
      this.resize(),
      this
    );
  }
  add() {
    const { chart: t } = this,
      e = new xe(t);
    return this.data.add(e), this.resize(), e;
  }
  remove(t) {
    return this.data.remove(t), this.resize(), this;
  }
  down(t) {
    const e = this.data.move(t, t + 1);
    return (
      e.indicator && this.chart.indicators.down(e.indicator),
      this.trigger("Move", { from: t, to: t + 1 }),
      this.resize(),
      this
    );
  }
  up(t) {
    const e = this.data.move(t, t - 1);
    return (
      e.indicator && this.chart.indicators.up(e.indicator),
      this.trigger("Move", { from: t, to: t - 1 }),
      this.resize(),
      this
    );
  }
  redraw() {
    return this.data.sections.forEach((t) => t.redraw()), this;
  }
  updateWidth() {
    let t = 0,
      e = !1;
    this.data.sections.forEach((s) => {
      const [i, o] = s.axis.calcTextLength();
      t < o && (t = o), (e = e || i !== o);
    }),
      (this.width = t),
      e && this.chart.resize(),
      this.trigger("ResizeAxis", { width: t });
  }
  applyTick() {
    return (
      this.data.sections.forEach((t) => t.applyTick()), this.resize(), this
    );
  }
  resize() {
    const { state: t } = this.chart,
      e = this.data.sections,
      s = e.filter((t) => t.collapsed()).length;
    let i = e.length - s;
    const o = t.graphHeight - t.graphY;
    let r = e.length;
    if (r) {
      const n = e[0];
      if (
        ((n.x = t.graphX),
        (n.y = t.graphY),
        (n.width = t.graphWidth),
        (n.height = o),
        r > 1)
      ) {
        (r -= 1), (i -= 1);
        const h = 42;
        i ? (n.height = 0.6 * o) : (n.height -= h * s);
        let a = 0.4 * o;
        (a -= s * h), (a /= i), (a -= r);
        let l = n.y + n.height;
        e.slice(1).forEach((e) => {
          (l += 1),
            (e.x = Math.round(t.graphX)),
            (e.y = Math.round(l)),
            (e.width = t.graphWidth),
            (e.height = a),
            e.collapsed() && (e.height = h),
            (l += e.height);
        });
        const d = e[e.length - 1];
        d.collapsed() || (d.height = t.graphHeight - t.graphY - d.y);
      }
    }
    return this.updateWidth(), this;
  }
  get(t) {
    return this.data.sections[t];
  }
  getByCoordinate(t, e) {
    return this.data.sections.find(
      (s) => t >= s.x && t <= s.x + s.width && e >= s.y && e <= s.y + s.height
    );
  }
  getByIndicatorUid(t) {
    return this.data.sections.find(
      (e) => e.indicator && e.indicator.settings.uid === t
    );
  }
  all() {
    return this.data.sections.slice();
  }
  index(t) {
    return this.all().findIndex((e) => e === t.section);
  }
  destroy() {
    this.data.sections.forEach((t) => t.destroy());
  }
}
const Oe = "__global";
class Te {
  constructor(t, e) {
    (this.storage = pt.indicators),
      (this.storageByOrder = pt.indicatorsByOrder),
      (this.indicatorsStore = t),
      (this.uiSettingsController = e),
      (this.onSave = this.onSave.bind(this)),
      (this.onSectionMove = this.onSectionMove.bind(this)),
      (this.onEditIndicator = this.onEditIndicator.bind(this));
  }
  async init(t, e) {
    var s;
    const i = this.uiSettingsController.uiSettingsStore.selectedSymbol;
    if (!i) return;
    const o = await this.storage.getAll("symbol", i),
      r = await this.storage.getAll("symbol", Oe);
    t &&
      (t.on(Ut.SaveSettings, this.onSave),
      t.on(Ut.Settings, this.onEditIndicator)),
      this.indicatorsStore.reset([...r, ...o]);
    const { selectedSymbol: n } = this.uiSettingsController.uiSettingsStore,
      h = await this.storageByOrder.getAll("symbol", n);
    this.indicatorsStore.resetIndicatorsByOrder(
      (null == (s = h[0]) ? void 0 : s.list) || []
    ),
      e && e.on(U.Move, () => this.onSectionMove(e)),
      t && t.on(Ut.Settings, this.onEditIndicator);
  }
  destroy(t, e) {
    null == t || t.off(Ut.SaveSettings, this.onSave),
      null == t || t.off(Ut.Settings, this.onEditIndicator),
      e.off(U.Move);
  }
  onSectionMove(t) {
    const { selectedSymbol: e } = this.uiSettingsController.uiSettingsStore;
    this.indicatorsStore.resetIndicatorsByOrder([]),
      this.storageByOrder.remove(e),
      t.data.sections.forEach((t) => {
        t.indicator &&
          this.indicatorsStore.addIndicatorsByOrder(t.indicator.settings.uid);
      }),
      this.storageByOrder.add({
        symbol: e,
        list: this.indicatorsStore.indicatorsByOrder,
      });
  }
  onSave(t) {
    const { selectedSymbol: e } = this.uiSettingsController.uiSettingsStore;
    if (!e) return this;
    const s = t.toJSON(),
      i = { symbol: 8 & t.flags ? Oe : e, ...s };
    return (
      this.indicatorsStore.add(i),
      this.storage.add(i),
      4 & t.flags &&
        !this.indicatorsStore.indicatorsByOrder.includes(i.uid) &&
        (this.indicatorsStore.addIndicatorsByOrder(i.uid),
        this.storageByOrder.add({
          symbol: e,
          list: this.indicatorsStore.indicatorsByOrder,
        })),
      this
    );
  }
  remove(t) {
    this.indicatorsStore.removeByUid(t), this.storage.remove(t);
    const { selectedSymbol: e } = this.uiSettingsController.uiSettingsStore;
    return (
      this.storageByOrder.remove(e),
      this.storageByOrder.add({
        symbol: e,
        list: this.indicatorsStore.indicatorsByOrder,
      }),
      this
    );
  }
  onEditIndicator(t) {
    this.indicatorsStore.editIndicator(t.index);
  }
}
(B = Object.defineProperty),
  (D = Object.getOwnPropertyDescriptor),
  (H = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? D(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && B(e, s, n), n;
  });
class Pe extends ct {
  constructor() {
    super(),
      (this._systemName = bt.indicators),
      (this.items = []),
      (this.indicatorsByOrder = []),
      (this.index = { uid: {}, index: {} });
  }
  getAll() {
    const t = this.items.filter((t) => 0 === t.flags || !(4 & t.flags)),
      e = [];
    for (let s = 0; s < this.indicatorsByOrder.length; s++) {
      const t = this.indicatorsByOrder[s];
      if (t) {
        const s = this.findByUid(t);
        s && e.push(s);
      }
    }
    return [...t, ...e];
  }
  reset(t = []) {
    return (this.items = [...t]), this.createIndex(), this;
  }
  resetIndicatorsByOrder(t) {
    return (this.indicatorsByOrder = t), this;
  }
  add(t) {
    const e = this.index.index[t.uid];
    return (
      "number" == typeof e ? (this.items[e] = t) : this.items.push(t),
      this.createIndex(),
      this
    );
  }
  addIndicatorsByOrder(t) {
    this.indicatorsByOrder.push(t);
  }
  removeByUid(t) {
    const e = this.index.index[t];
    if ("number" != typeof e) return this;
    this.items.splice(e, 1), this.createIndex();
    const s = this.indicatorsByOrder.indexOf(t);
    return -1 !== s && this.indicatorsByOrder.splice(s, 1), this;
  }
  findByUid(t) {
    return this.index.uid[t] ?? null;
  }
  createIndex() {
    return (
      (this.index = { uid: {}, index: {} }),
      this.items.forEach((t, e) => {
        (this.index.uid[t.uid] = t), (this.index.index[t.uid] = e);
      }),
      this
    );
  }
  editIndicator(t) {
    this.editIndicatorIndex = t;
  }
}
H([dt], Pe.prototype, "reset", 1),
  H([dt], Pe.prototype, "resetIndicatorsByOrder", 1),
  H([dt], Pe.prototype, "add", 1),
  H([dt], Pe.prototype, "addIndicatorsByOrder", 1),
  H([dt], Pe.prototype, "removeByUid", 1),
  H([dt], Pe.prototype, "editIndicator", 1);
class Me {
  constructor(t) {
    (this.indicatorsStore = new Pe()),
      (this.indicatorsController = new Te(this.indicatorsStore, t));
  }
}
(E = Object.defineProperty),
  (R = Object.getOwnPropertyDescriptor),
  (j = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? R(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && E(e, s, n), n;
  });
const Le = [
  "symbol",
  "id",
  "sl",
  "tp",
  "priceClose",
  "priceOpen",
  "timeCreate",
  "typeName",
  "volumeValue",
  "storage",
  "profit",
  "comment",
];
class Ue extends ct {
  constructor() {
    super(),
      (this._systemName = "positions"),
      (this.index = { id: {}, symbol: {} }),
      (this.items = []),
      (this.sorts = {}),
      (this.keys = Le),
      (this.direction = St.None),
      (this.sortBy = "");
  }
  setSort(t, e) {
    return (this.sortBy = t), (this.direction = e), this;
  }
  positionHas(t) {
    return "number" == typeof this.index.id[t];
  }
  reset() {
    (this.index = { id: {}, symbol: {} }), (this.items = []), (this.sorts = {});
  }
  getSortedPositions() {
    if (this.sortBy && this.direction) {
      const t = [...(this.sorts[this.sortBy] ?? [])];
      return this.direction === St.DESC && t.reverse(), t;
    }
    const t = [...this.items];
    return this.direction === St.DESC && t.reverse(), t;
  }
  getPositions() {
    return [...this.items];
  }
  getPositionsBySymbol(t) {
    return this.index.symbol[t] || [];
  }
  hasPositionForSymbol(t) {
    return Boolean(this.index.symbol[t]);
  }
  getPosition(t) {
    const e = this.items[this.index.id[t]];
    return e ? e.value : null;
  }
  updatePosition(t) {
    const e = this.index.id[t.id];
    return (
      this.items && "number" == typeof e && (this.items[e].value = t), this
    );
  }
  setPositions(t) {
    return (
      (this.items = t.items.map((t) => ({ value: t }))),
      this.createIndex(),
      this.keys.forEach((t) => {
        this.sorts[t] = (function (t, e) {
          const s = [...t];
          return (
            s.sort((t, s) =>
              (t.value[e] ?? 1 / 0) < (s.value[e] ?? 1 / 0)
                ? -1
                : (t.value[e] ?? -1 / 0) > (s.value[e] ?? -1 / 0)
                ? 1
                : 0
            ),
            s
          );
        })(this.items, t);
      }),
      this
    );
  }
  createIndex() {
    return (
      (this.index = { id: {}, symbol: {} }),
      this.items.forEach((t, e) => {
        const { id: s, symbol: i } = t.value;
        s && (this.index.id[s] = e),
          this.index.symbol[i] || (this.index.symbol[i] = []),
          this.index.symbol[i].push(t);
      }),
      this
    );
  }
}
j([dt], Ue.prototype, "setSort", 1),
  j([dt], Ue.prototype, "reset", 1),
  j([dt], Ue.prototype, "updatePosition", 1),
  j([dt], Ue.prototype, "setPositions", 1),
  (q = Object.defineProperty),
  (A = Object.getOwnPropertyDescriptor),
  (I = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? A(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && q(e, s, n), n;
  });
class Be extends ct {
  constructor() {
    super(),
      (this._systemName = "trade"),
      (this.transactions = {}),
      (this.prices = {});
  }
  reset() {
    (this.transactions = {}), (this.prices = {});
  }
  resetRequest() {
    this.request = void 0;
  }
  resetQuickTradeRequest() {
    this.quickTradeRequest = void 0;
  }
  setCollateral(t) {
    this.total = t;
  }
  setTransaction(t, e) {
    return (
      (this.transactions[t] = this.transactions[t] || {}),
      "number" == typeof e.state && (this.transactions[t].state = e.state),
      "number" == typeof e.code && (this.transactions[t].code = e.code),
      e.order && (this.transactions[t].order = e.order),
      this
    );
  }
  setRequest(t, e) {
    (this.requestTimeout = e), (this.request = t);
  }
  setQuickTradeRequest(t, e) {
    (this.quickTradeRequestTimeout = e), (this.quickTradeRequest = t);
  }
  clearPrices() {
    this.prices = {};
  }
  setPrice(t, e) {
    e
      ? ((this.prices[t] = e), this.refresh())
      : this.prices[t] && (delete this.prices[t], this.refresh());
  }
}
I([dt], Be.prototype, "resetRequest", 1),
  I([dt], Be.prototype, "resetQuickTradeRequest", 1),
  I([dt], Be.prototype, "setCollateral", 1),
  I([dt], Be.prototype, "setTransaction", 1),
  I([dt], Be.prototype, "setRequest", 1),
  I([dt], Be.prototype, "setQuickTradeRequest", 1),
  I([dt], Be.prototype, "clearPrices", 1),
  (F = Object.defineProperty),
  (_ = Object.getOwnPropertyDescriptor),
  (N = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? _(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && F(e, s, n), n;
  });
const De = [
  "symbol",
  "order",
  "sl",
  "tp",
  "timeSetup",
  "price",
  "priceCurrent",
  "typeName",
  "volumeValue",
];
class He extends ct {
  constructor() {
    super(),
      (this._systemName = "orders"),
      (this.index = { id: {}, symbol: {} }),
      (this.items = []),
      (this.sorts = {}),
      (this.keys = De),
      (this.direction = St.None),
      (this.sortBy = "");
  }
  setSort(t, e) {
    return (this.sortBy = t), (this.direction = e), this;
  }
  orderHas(t) {
    return "number" == typeof this.index.id[t];
  }
  reset() {
    (this.index = { id: {}, symbol: {} }), (this.items = []), (this.sorts = {});
  }
  getSortedOrders() {
    if (this.sortBy && this.direction) {
      const t = [...(this.sorts[this.sortBy] ?? [])];
      return this.direction === St.DESC && t.reverse(), t;
    }
    const t = [...this.items];
    return this.direction === St.DESC && t.reverse(), t;
  }
  getOrders() {
    return [...this.items];
  }
  getOrdersBySymbol(t) {
    return this.index.symbol[t] || [];
  }
  getOrder(t) {
    const e = this.items[this.index.id[t]];
    return e ? e.value : null;
  }
  hasOrderForSymbol(t) {
    return Boolean(this.index.symbol[t]);
  }
  updateOrder(t) {
    const e = this.index.id[t.order];
    return (
      this.items &&
        "number" == typeof e &&
        ((this.items[e].value = t), (this.items[e].id = t.order)),
      this
    );
  }
  setOrders(t) {
    return (
      (this.items = t.map((t) => ({ value: t, id: t.order }))),
      this.createIndex(),
      this.keys.forEach((t) => {
        this.sorts[t] = (function (t, e) {
          const s = [...t];
          return (
            s.sort((t, s) =>
              (t.value[e] ?? 1 / 0) < (s.value[e] ?? 1 / 0)
                ? -1
                : (t.value[e] ?? -1 / 0) > (s.value[e] ?? -1 / 0)
                ? 1
                : 0
            ),
            s
          );
        })(this.items, t);
      }),
      this
    );
  }
  createIndex() {
    return (
      (this.index = { id: {}, symbol: {} }),
      this.items.forEach((t, e) => {
        const { order: s, symbol: i } = t.value;
        s && (this.index.id[s] = e),
          this.index.symbol[i] || (this.index.symbol[i] = []),
          this.index.symbol[i].push(t);
      }),
      this
    );
  }
}
N([dt], He.prototype, "setSort", 1),
  N([dt], He.prototype, "reset", 1),
  N([dt], He.prototype, "updateOrder", 1),
  N([dt], He.prototype, "setOrders", 1);
class Ee {
  constructor(t, e, s, i, o, r) {
    (this.api = t),
      (this.tradeStore = e),
      (this.ordersStore = s),
      (this.positionsStore = i),
      (this.symbolsController = o),
      (this.ticksController = r),
      (this.onUpdateOrder = this.onUpdateOrder.bind(this)),
      (this.onUpdatePosition = this.onUpdatePosition.bind(this)),
      (this.onResponse = this.onResponse.bind(this)),
      (this.onTransaction = this.onTransaction.bind(this)),
      this.init();
  }
  init() {
    this.tradeStore.reset(),
      this.loadOrders(),
      this.loadPositions(),
      this.unSubscribe(),
      this.subscribe();
  }
  destroy() {
    this.unSubscribe(), this.positionsStore.reset(), this.ordersStore.reset();
  }
  subscribe() {
    this.api.view.on(5, this.onUpdateOrder),
      this.api.view.on(4, this.onUpdatePosition),
      this.api.view.on(2, this.onResponse),
      this.api.view.on(1, this.onTransaction);
  }
  onRequote(t) {}
  unSubscribe() {
    var t, e, s, i;
    null == (t = this.api) || t.view.off(5, this.onUpdateOrder),
      null == (e = this.api) || e.view.off(4, this.onUpdatePosition),
      null == (s = this.api) || s.view.off(2, this.onResponse),
      null == (i = this.api) || i.view.off(1, this.onTransaction);
  }
  setRequest(t, e) {
    this.tradeStore.requestTimeout &&
      clearTimeout(this.tradeStore.requestTimeout),
      this.tradeStore.setRequest(t, e && e());
  }
  setQuickTradeRequest(t, e) {
    this.tradeStore.quickTradeRequestTimeout &&
      clearTimeout(this.tradeStore.quickTradeRequestTimeout),
      this.tradeStore.setQuickTradeRequest(t, e && e());
  }
  onResponse(t) {
    const { request: e } = this.tradeStore;
    if (
      t.result &&
      e &&
      "number" == typeof e.action.id &&
      e.action.id === t.action.id
    )
      if (e.quickTrade)
        if (10004 === t.code) {
          const e = this.symbolsController.symbolsStore.getBySymbol(
              t.action.symbol
            ),
            s = 1e3 * ((null == e ? void 0 : e.requoteTimeout) || 7);
          e &&
            this.setQuickTradeRequest(
              { action: t.action, result: t.result },
              () =>
                window.setTimeout(
                  () => this.tradeStore.resetQuickTradeRequest(),
                  s
                )
            );
        } else
          this.setQuickTradeRequest({ action: t.action, result: t.result });
      else if (10005 === t.code) {
        const e = t.action.symbol,
          s = this.symbolsController.symbolsStore.getBySymbol(e),
          i = 1e3 * ((null == s ? void 0 : s.requestTimeout) || 7);
        this.tradeStore.setPrice(e, {
          bid: t.result.bid,
          ask: t.result.ask,
          time: Date.now(),
          timeout: (() => (
            this.tradeStore.prices[e] &&
              window.clearTimeout(this.tradeStore.prices[e].timeout),
            window.setTimeout(() => {
              this.tradeStore.setPrice(e);
            }, i)
          ))(),
        });
      } else if (10004 === t.code) {
        const e = this.symbolsController.symbolsStore.getBySymbol(
            t.action.symbol
          ),
          s = 1e3 * ((null == e ? void 0 : e.requoteTimeout) || 7);
        e &&
          this.setRequest({ action: t.action, result: t.result }, () =>
            window.setTimeout(() => this.tradeStore.resetRequest(), s)
          );
      } else
        this.setRequest({ action: t.action, result: t.result }),
          this.clearPrices();
  }
  clearPrices() {
    Object.keys(this.tradeStore.prices).forEach((t) => {
      var e;
      (null == (e = this.tradeStore.prices[t]) ? void 0 : e.timeout) &&
        window.clearTimeout(this.tradeStore.prices[t].timeout);
    }),
      this.tradeStore.clearPrices();
  }
  onUpdatePosition(t) {
    if (this.positionsStore.positionHas(t)) {
      const e = this.api.view.trade.getPosition(t);
      e && this.positionsStore.updatePosition(e);
    } else this.loadPositions();
  }
  onUpdateOrder(t) {
    if (this.ordersStore.orderHas(t)) {
      const e = this.api.view.trade.getOrder(t);
      e && this.ordersStore.updateOrder(e);
    } else this.loadOrders();
  }
  onTransaction() {
    this.loadPositions(), this.loadOrders();
  }
  loadPositions() {
    this.positionsStore.setPositions(this.api.view.trade.getPositions());
  }
  loadOrders() {
    this.ordersStore.setOrders(this.api.view.trade.getOrders());
  }
  openLimitOrder(t) {
    const e = this.api.view.request.orderOpen(
      t.type,
      t.symbol,
      t.volume,
      t.price,
      t.sl,
      t.tp,
      t.expiration ?? 0,
      t.date ?? 0,
      t.comment ?? "",
      0,
      t.fillingType ?? 2
    );
    "number" == typeof e.action.id &&
      this.tradeStore.setTransaction(e.action.id, { code: e.result.code }),
      this.setRequest(e);
  }
  openStopOrder(t) {
    const e = this.api.view.request.orderOpen(
      t.type,
      t.symbol,
      t.volume,
      t.price,
      t.sl ?? 0,
      t.tp ?? 0,
      t.expiration ?? 0,
      t.date ?? 0,
      t.comment,
      0,
      t.fillingType ?? 2
    );
    "number" == typeof e.action.id &&
      this.tradeStore.setTransaction(e.action.id, { code: e.result.code }),
      this.setRequest(e);
  }
  openStopLimitOrder(t) {
    const e = this.api.view.request.orderOpen(
      t.type,
      t.symbol,
      t.volume,
      t.price,
      t.sl ?? 0,
      t.tp ?? 0,
      t.expiration ?? 0,
      t.date ?? 0,
      t.comment ?? "",
      t.trigger,
      t.fillingType ?? 2
    );
    "number" == typeof e.action.id &&
      this.tradeStore.setTransaction(e.action.id, { code: e.result.code }),
      this.setRequest(e);
  }
  modifyLimitOrder(t) {
    const e = this.api.view.request.orderModify(
      t.id,
      t.price,
      t.sl,
      t.tp,
      t.expiration,
      t.date,
      t.comment
    );
    "number" == typeof e.action.id &&
      this.tradeStore.setTransaction(e.action.id, {
        code: e.result.code,
        order: t.id,
      }),
      this.setRequest(e);
  }
  modifyStopLimitOrder(t) {
    const e = this.api.view.request.orderModify(
      t.id,
      t.price,
      t.sl,
      t.tp,
      t.expiration,
      t.date,
      t.comment,
      t.trigger
    );
    "number" == typeof e.action.id &&
      this.tradeStore.setTransaction(e.action.id, {
        code: e.result.code,
        order: t.id,
      }),
      this.setRequest(e);
  }
  deleteOrder(t) {
    const e = this.api.view.request.orderDelete(t);
    e &&
      ("number" == typeof e.action.id &&
        this.tradeStore.setTransaction(e.action.id, {
          code: e.result.code,
          order: t,
        }),
      this.setRequest(e));
  }
  acceptRequote() {
    var t;
    if (null == (t = this.tradeStore.request) ? void 0 : t.action) {
      const { action: t } = this.tradeStore.request;
      t.position
        ? this.closePosition(t.position, !1, t.volume)
        : this.openPosition({
            type: t.isBuy ? 0 : 1,
            symbol: t.symbol,
            volume: t.volume,
            sl: t.priceSL,
            tp: t.priceTP,
            fillingType: 2,
            comment: t.comment,
          });
    }
  }
  openPosition(t) {
    var e, s;
    const i = this.symbolsController.symbolsStore.getBySymbol(t.symbol);
    if (!i) return;
    let o = 0;
    if (
      i.isInstantExecution &&
      !t.quickTrade &&
      10004 ===
        (null == (s = null == (e = this.tradeStore.request) ? void 0 : e.result)
          ? void 0
          : s.code)
    )
      0 === t.type
        ? (o = this.tradeStore.request.result.ask)
        : 1 === t.type && (o = this.tradeStore.request.result.bid);
    else if (i.isRequestExecution) {
      if (!this.tradeStore.prices[i.symbol])
        return void this.requestPrice(t.type, i.symbol, t.volume);
      0 === t.type
        ? (o = this.tradeStore.prices[i.symbol].ask)
        : 1 === t.type && (o = this.tradeStore.prices[i.symbol].bid);
    } else if (i.isInstantExecution) {
      const e = this.ticksController.ticksStore.getTick(i.symbol);
      if (!e) return;
      0 === t.type ? (o = e.ask) : 1 === t.type && (o = e.bid);
    }
    const r = this.api.view.request.positionOpen(
      t.type,
      t.symbol,
      t.volume,
      o,
      t.sl ?? 0,
      t.tp ?? 0,
      t.fillingType ?? 2,
      t.comment ?? ""
    );
    "number" == typeof r.action.id &&
      this.tradeStore.setTransaction(r.action.id, { code: r.result.code }),
      this.setRequest({ ...r, quickTrade: t.quickTrade });
  }
  requestPrice(t, e, s) {
    const i = this.api.view.request.requestPrice(e, t, s);
    "number" == typeof i.action.id &&
      this.tradeStore.setTransaction(i.action.id, { code: i.result.code }),
      this.setRequest(i);
  }
  modifyPosition(t) {
    const e = this.api.view.request.positionModify(
      t.id,
      t.sl ?? 0,
      t.tp ?? 0,
      t.comment ?? ""
    );
    "number" == typeof e.action.id &&
      this.tradeStore.setTransaction(e.action.id, {
        code: e.result.code,
        order: t.id,
      }),
      this.setRequest(e);
  }
  closePosition(t, e, s) {
    let i;
    const o = this.api.view.trade.getPosition(t);
    if (o) {
      const t = this.symbolsController.symbolsStore.getBySymbol(o.symbol);
      t &&
        t.isRequestExecution &&
        this.tradeStore.prices[t.symbol] &&
        (o.isBuy
          ? (i = this.tradeStore.prices[t.symbol].bid)
          : o.isSell && (i = this.tradeStore.prices[t.symbol].ask));
    }
    const r = this.api.view.request.positionClose(t, e, i, s);
    return (
      "number" == typeof r.action.id &&
        this.tradeStore.setTransaction(r.action.id, {
          code: r.result.code,
          order: t,
        }),
      this.setRequest({ ...r, quickTrade: e }),
      r.action.id
    );
  }
  closePositionByPosition(t, e) {
    const s = this.api.view.request.positionCloseBy(t, e);
    "number" == typeof s.action.id &&
      this.tradeStore.setTransaction(s.action.id, {
        code: s.result.code,
        order: t,
      }),
      this.setRequest(s);
  }
}
class Re {
  constructor(t, e, s) {
    (this.tradeStore = new Be()),
      (this.ordersStore = new He()),
      (this.positionsStore = new Ue()),
      (this.tradeController = new Ee(
        t,
        this.tradeStore,
        this.ordersStore,
        this.positionsStore,
        e,
        s
      ));
  }
}
class je {
  constructor(t, e, s, i, o) {
    (this.resolve = () => {}),
      (this.api = t),
      (this.watchlistStore = e),
      (this.symbolsController = s),
      (this.ticksController = i),
      (this.tradeController = o),
      (this.storage = pt.watchlist),
      (this.onTick = this.onTick.bind(this)),
      (this.update = this.update.bind(this)),
      (this.ready = new Promise((t) => {
        this.resolve = t;
      }));
  }
  async init() {
    const t = (await this.storage.getAll())[0],
      e = (null == t ? void 0 : t.symbols) ?? [];
    this.watchlistStore.reset(this.filterSymbols(e)),
      this.symbolsController.loadFullSymbols(e),
      this.fillSymbolsFromUrl(),
      this.generate(),
      this.resolve(),
      (this.positionsStoreUnsubscribe =
        this.tradeController.positionsStore.subscribe(this.update)),
      (this.orderStoreUnsubscribe = this.tradeController.ordersStore.subscribe(
        this.update
      )),
      this.api.view.on(0, this.onTick);
  }
  onTick(t) {
    if (this.watchlistStore.has(t.symbol)) {
      const t = this.ticksController.ticksStore.getTicks(
          this.watchlistStore.getList()
        ),
        e = (function (t, e) {
          const s = {};
          e.forEach((t) => {
            s[t.symbol] = t;
          });
          const i = {
            [vt.Symbol]: [...t],
            [vt.Bid]: [...t],
            [vt.Ask]: [...t],
            [vt.DailyChange]: [...t],
            [vt.High]: [...t],
            [vt.Low]: [...t],
            [vt.Spread]: [...t],
            [vt.Time]: [...t],
            [vt.BidHigh]: [...t],
            [vt.BidLow]: [...t],
            [vt.AskHigh]: [...t],
            [vt.AskLow]: [...t],
            [vt.PriceOpen]: [...t],
            [vt.PriceClose]: [...t],
            [vt.Last]: [...t],
            [vt.LastHigh]: [...t],
            [vt.LastLow]: [...t],
          };
          return (
            i[vt.Symbol].sort((t, e) =>
              s[t].symbol < s[e].symbol ? -1 : s[t].symbol > s[e].symbol ? 1 : 0
            ),
            i[vt.Bid].sort((t, e) =>
              (s[t].bid ?? 1 / 0) < (s[e].bid ?? 1 / 0)
                ? -1
                : (s[t].bid ?? -1 / 0) > (s[e].bid ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.Ask].sort((t, e) =>
              (s[t].ask ?? 1 / 0) < (s[e].ask ?? 1 / 0)
                ? -1
                : (s[t].ask ?? -1 / 0) > (s[e].ask ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.DailyChange].sort((t, e) =>
              (s[t].change ?? 1 / 0) < (s[e].change ?? 1 / 0)
                ? -1
                : (s[t].change ?? -1 / 0) > (s[e].change ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.Spread].sort((t, e) =>
              (s[t].spread ?? 1 / 0) < (s[e].spread ?? 1 / 0)
                ? -1
                : (s[t].spread ?? -1 / 0) > (s[e].spread ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.Time].sort((t, e) =>
              (s[t].time.getTime() ?? 1 / 0) < (s[e].time.getTime() ?? 1 / 0)
                ? -1
                : (s[t].time.getTime() ?? -1 / 0) >
                  (s[e].time.getTime() ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.BidHigh].sort((t, e) =>
              (s[t].bidHigh ?? 1 / 0) < (s[e].bidHigh ?? 1 / 0)
                ? -1
                : (s[t].bidHigh ?? -1 / 0) > (s[e].bidHigh ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.BidLow].sort((t, e) =>
              (s[t].bidLow ?? 1 / 0) < (s[e].bidLow ?? 1 / 0)
                ? -1
                : (s[t].bidLow ?? -1 / 0) > (s[e].bidLow ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.AskHigh].sort((t, e) =>
              (s[t].askHigh ?? 1 / 0) < (s[e].askHigh ?? 1 / 0)
                ? -1
                : (s[t].askHigh ?? -1 / 0) > (s[e].askHigh ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.AskLow].sort((t, e) =>
              (s[t].askLow ?? 1 / 0) < (s[e].askLow ?? 1 / 0)
                ? -1
                : (s[t].askLow ?? -1 / 0) > (s[e].askLow ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.PriceOpen].sort((t, e) =>
              (s[t].priceOpen ?? 1 / 0) < (s[e].priceOpen ?? 1 / 0)
                ? -1
                : (s[t].priceOpen ?? -1 / 0) > (s[e].priceOpen ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.PriceClose].sort((t, e) =>
              (s[t].priceClose ?? 1 / 0) < (s[e].priceClose ?? 1 / 0)
                ? -1
                : (s[t].priceClose ?? -1 / 0) > (s[e].priceClose ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.Last].sort((t, e) =>
              (s[t].last ?? 1 / 0) < (s[e].last ?? 1 / 0)
                ? -1
                : (s[t].last ?? -1 / 0) > (s[e].last ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.LastHigh].sort((t, e) =>
              (s[t].lastHigh ?? 1 / 0) < (s[e].lastHigh ?? 1 / 0)
                ? -1
                : (s[t].lastHigh ?? -1 / 0) > (s[e].lastHigh ?? -1 / 0)
                ? 1
                : 0
            ),
            i[vt.LastLow].sort((t, e) =>
              (s[t].lastLow ?? 1 / 0) < (s[e].lastLow ?? 1 / 0)
                ? -1
                : (s[t].lastLow ?? -1 / 0) > (s[e].lastLow ?? -1 / 0)
                ? 1
                : 0
            ),
            i
          );
        })(this.watchlistStore.getList(), t);
      this.watchlistStore.setSort(e);
    }
  }
  update() {
    const t = new Set();
    [
      ...this.tradeController.positionsStore.getPositions(),
      ...this.tradeController.ordersStore.getOrders(),
    ].forEach(({ value: { symbol: e } }) => {
      this.watchlistStore.has(e) || t.add(e);
    }),
      t.size && this.add(Array.from(t));
  }
  destroy() {
    var t;
    null == (t = this.api) || t.view.off(0, this.onTick),
      this.watchlistStore.reset(),
      this.positionsStoreUnsubscribe && this.positionsStoreUnsubscribe(),
      this.orderStoreUnsubscribe && this.orderStoreUnsubscribe();
  }
  filterSymbols(t) {
    return t.filter((t) => this.symbolsController.symbolsStore.getBySymbol(t));
  }
  fillSymbolsFromUrl() {
    if (this.watchlistStore.getList().length) return;
    const t = (function () {
        const t = new URLSearchParams(window.self.location.search);
        if (t.get("marketwatch")) {
          const e = t.get("marketwatch");
          if (e)
            return e
              .split(",")
              .filter((t) => t && "string" == typeof t)
              .map((t) => t.trim().toLowerCase());
        }
        return [];
      })(),
      e = [];
    t.forEach((t) => {
      const s = this.symbolsController.symbolsStore.getBySymbol(t);
      s && e.push(s.symbol);
    }),
      this.add(e);
  }
  getList() {
    return this.watchlistStore.getList();
  }
  generate(t = 10) {
    if (this.watchlistStore.getList().length) return this;
    const e = [],
      s = this.api.view.symbolTypes.getTypes();
    for (const i of s) {
      const s = this.symbolsController.symbolsStore.getByCategory(i[1]);
      for (let i = 0; i < s.length && !(e.length >= t); i++)
        e.push(s[i].symbol);
    }
    return this.add(e), this;
  }
  add(t) {
    return (
      t.forEach((t) => this.ticksController.on(t)),
      this.watchlistStore.add(t),
      this.symbolsController.loadFullSymbols(t),
      this.storage
        .add({ symbols: this.watchlistStore.getList() })
        .then(() => {})
        .catch(() => {}),
      this
    );
  }
  remove(t) {
    return (
      this.ticksController.off(t),
      this.watchlistStore.remove(t),
      this.storage
        .add({ symbols: this.watchlistStore.getList() })
        .then(() => {})
        .catch(() => {}),
      this
    );
  }
}
(V = Object.defineProperty),
  (W = Object.getOwnPropertyDescriptor),
  (X = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? W(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && V(e, s, n), n;
  });
class qe extends ct {
  constructor() {
    super(),
      (this._systemName = bt.watchlist),
      (this.list = []),
      (this.index = { symbol: {} }),
      (this.sorts = {});
  }
  has(t) {
    return Boolean(this.index.symbol[t]);
  }
  getList(t) {
    return "number" == typeof t && this.sorts[t]
      ? [...(this.sorts[t] || [])]
      : [...this.list];
  }
  setSort(t) {
    this.sorts = t;
  }
  add(t) {
    return (
      (Array.isArray(t) ? t : [t]).forEach((t) => this.addOne(t)),
      this.resetIndex()
    );
  }
  addOne(t) {
    return (
      -1 === this.list.findIndex((e) => t === e) && this.list.push(t), this
    );
  }
  remove(t) {
    const e = this.list.findIndex((e) => t === e);
    return -1 !== e && this.list.splice(e, 1), this.resetIndex();
  }
  resetIndex() {
    return (
      (this.index = { symbol: {} }),
      this.list.forEach((t) => {
        this.index.symbol[t] = t;
      }),
      this
    );
  }
  reset(t = []) {
    return (this.list = [...t]), this.resetIndex();
  }
}
X([dt], qe.prototype, "setSort", 1),
  X([dt], qe.prototype, "add", 1),
  X([dt], qe.prototype, "remove", 1),
  X([dt], qe.prototype, "reset", 1);
class Ae {
  constructor(t, e, s, i) {
    (this.watchlistStore = new qe()),
      (this.watchlistController = new je(t, this.watchlistStore, e, s, i));
  }
}
class Ie {
  constructor(t, e) {
    (this.marksStore = t),
      (this.interactionController = e),
      (this.storage = pt.marks),
      (this.onChange = this.onChange.bind(this));
  }
  async init() {
    const t = (await this.storage.getAll())[0] || {};
    this.marksStore.reset(t),
      this.marksStoreUnsubscribe &&
        (this.marksStoreUnsubscribe(), delete this.marksStoreUnsubscribe),
      (this.marksStoreUnsubscribe = this.marksStore.subscribe(this.onChange));
  }
  destroy() {
    this.marksStoreUnsubscribe &&
      (this.marksStoreUnsubscribe(), delete this.marksStoreUnsubscribe);
  }
  onChange(t) {
    this.storage.add({ showSlTp: t.showSlTp });
  }
  toggleOrdersTradeMarks(t) {
    if (t && t.data && t.data.ordersTradeMarks) {
      const { uid: e, visible: s } = t.data.ordersTradeMarks;
      t.visible(e, !s);
    }
  }
  async onSelectOrderMark(t) {
    await ft(), this.interactionController.interactionStore.setSelectedOrder(t);
  }
  togglePositionsTradeMarks(t) {
    if (t && t.data && t.data.positionsTradeMarks) {
      const { uid: e, visible: s } = t.data.positionsTradeMarks;
      t.visible(e, !s);
    }
  }
  async onSelectPositionMark(t) {
    await ft(),
      this.interactionController.interactionStore.setSelectedPosition(t);
  }
  toggleHistoryTradeMarks(t) {
    if (t && t.data && t.data.historyTradeMarks) {
      const { uid: e, visible: s } = t.data.historyTradeMarks;
      t.visible(e, !s);
    }
  }
  async onSelectHistoryMark(t) {
    await ft(),
      this.interactionController.interactionStore.setSelectedHistoryPosition(t);
  }
}
class Fe extends ct {
  constructor() {
    super(), (this._systemName = bt.marks), (this.showSlTp = !1);
  }
  reset(t) {
    "boolean" == typeof t.showSlTp && (this.showSlTp = t.showSlTp);
  }
}
class _e {
  constructor(t) {
    (this.marksStore = new Fe()),
      (this.marksController = new Ie(this.marksStore, t));
  }
}
class Ne {
  constructor(t, e, s) {
    (this.interactionStore = t),
      (this.layoutController = e),
      (this.tradeController = s);
  }
  setSelectedForEdit(t = "") {
    this.tradeController.tradeStore.resetRequest(),
      t &&
      (this.tradeController.ordersStore.orderHas(t) ||
        this.tradeController.positionsStore.positionHas(t))
        ? (this.layoutController.layoutStore.setLayout({
            tradeEdit: !1,
            tradeCreate: null,
          }),
          ft().then(() => {
            this.layoutController.layoutStore.setLayout({ tradeEdit: !0 }),
              this.interactionStore.setSelectedForEdit(t);
          }))
        : this.interactionStore.setSelectedForEdit();
  }
}
(z = Object.defineProperty),
  (K = Object.getOwnPropertyDescriptor),
  (Y = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? K(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && z(e, s, n), n;
  });
class Ve extends ct {
  constructor() {
    super(),
      (this.selectedForEdit = ""),
      (this.selectedPosition = ""),
      (this.selectedOrder = ""),
      (this.selectedHistoryPosition = "");
  }
  resetSelected(t = !0) {
    (this.selectedPosition = ""),
      (this.selectedOrder = ""),
      (this.selectedHistoryPosition = ""),
      t && this.refresh();
  }
  setSelectedPosition(t = "") {
    this.resetSelected(!1), (this.selectedPosition = t);
  }
  setSelectedOrder(t = "") {
    this.resetSelected(!1), (this.selectedOrder = t);
  }
  setSelectedHistoryPosition(t = "") {
    this.resetSelected(!1), (this.selectedHistoryPosition = t);
  }
  setSelectedForEdit(t = "") {
    this.selectedForEdit = t;
  }
}
Y([dt], Ve.prototype, "setSelectedPosition", 1),
  Y([dt], Ve.prototype, "setSelectedOrder", 1),
  Y([dt], Ve.prototype, "setSelectedHistoryPosition", 1),
  Y([dt], Ve.prototype, "setSelectedForEdit", 1);
class We {
  constructor(t, e) {
    (this.interactionStore = new Ve()),
      (this.interactionController = new Ne(this.interactionStore, t, e));
  }
}
class Xe {
  constructor(t, e) {
    (this.api = t),
      (this.noticesStore = e),
      (this.onResponse = this.onResponse.bind(this));
  }
  init() {
    this.api.view.off(2, this.onResponse), this.api.view.on(2, this.onResponse);
  }
  destroy() {
    var t;
    null == (t = this.api) || t.view.off(2, this.onResponse);
  }
  onResponse(t) {
    var e, s, i;
    const o = Ft(t.code),
      r = _t(t.code);
    this.add(
      {
        id:
          (null == (e = t.result) ? void 0 : e.order) ||
          String(Math.round(1e4 * Math.random())),
        type: t.action.typeName,
        symbol: t.action.symbol ?? "",
        isBuy: t.action.isBuy,
        isClose: t.action.isClose,
        isCloseBy: t.action.isCloseBy,
        isMarket: t.action.isMarket,
        isPending: t.action.isPending,
        isSell: t.action.isSell,
        volume: String(t.action.volume),
        price: t.action.priceOrder
          ? Ct(t.action.priceOrder, t.action.digits)
          : "",
        time:
          ((i = null == (s = t.result) ? void 0 : s.time),
          i ? xt(new Date(i), "hhhh:mm:ss") : ""),
        code: t.code,
      },
      o || r ? Bt.Info : Bt.Error
    );
  }
  add(t, e, s = 4e3) {
    const i = this.noticesStore.add(t.id, t, e);
    i.timeout && clearTimeout(i.timeout),
      (i.timeout = window.setTimeout(() => this.noticesStore.delete(t.id), s));
  }
}
class ze {
  constructor(t) {
    (this.noticesStore = new Dt()),
      (this.noticesController = new Xe(t, this.noticesStore));
  }
}
($ = Object.defineProperty),
  (G = Object.getOwnPropertyDescriptor),
  (Q = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? G(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && $(e, s, n), n;
  });
class Ke extends ct {
  constructor() {
    super(), (this._systemName = bt.configs), (this.data = {});
  }
  reset(t) {
    (this.data = {}), t.forEach((t) => this.setOptions(t));
  }
  getOptions(t) {
    return this.data[t] ? this.data[t] : this.createOptions(t);
  }
  createOptions(t) {
    return (
      (this.data[t] = (function (t) {
        return {
          symbol: t,
          type: Ht.candle,
          tradeVolume: 0,
          quickTradeVolume: 0,
          period: 60,
          volume: Et.none,
          title: "",
          description: "",
          from: 0,
          xScale: 0.2,
          yScale: 1,
          yPadding: 0,
          magnet: !1,
        };
      })(t)),
      this.data[t]
    );
  }
  setOptionsFromConfig(t) {
    t.symbol && (this.refresh(), (this.data[t.symbol] = t.getOptions()));
  }
  setOptions(t) {
    return this.data[t.symbol]
      ? ((this.data[t.symbol] = { ...this.data[t.symbol], ...t }),
        this.data[t.symbol])
      : ((this.data[t.symbol] = {
          type: t.type ?? Ht.bar,
          tradeVolume: t.tradeVolume,
          quickTradeVolume: t.quickTradeVolume,
          volume: t.volume ?? Et.none,
          period: t.period ?? 60,
          title: t.title ?? "",
          description: t.description ?? "",
          symbol: t.symbol,
          from: t.from ?? 0,
          xScale: t.xScale ?? 0.2,
          yScale: t.yScale ?? 1,
          yPadding: t.yPadding ?? 0,
          magnet: t.magnet ?? !1,
        }),
        this.data[t.symbol]);
  }
}
Q([dt], Ke.prototype, "createOptions", 1),
  Q([dt], Ke.prototype, "setOptions", 1);
class Ye extends ct {
  constructor() {
    super(),
      (this._systemName = "config"),
      (this.tradeVolume = 0),
      (this.quickTradeVolume = 0),
      (this.type = Ht.candle),
      (this.volume = Et.none),
      (this.period = 60),
      (this.title = ""),
      (this.description = ""),
      (this.symbol = ""),
      (this.from = 0),
      (this.xScale = 0.2),
      (this.yScale = 1),
      (this.yPadding = 0),
      (this.symbolConfig = null),
      (this.magnet = !1);
  }
  getDigits() {
    var t;
    return (null == (t = this.symbolConfig) ? void 0 : t.digits) ?? 5;
  }
  setOptions(t, e, s) {
    var i, o;
    let r = !1;
    if (
      (void 0 !== t.type &&
        t.type !== this.type &&
        ((this.type = t.type), t.type, (r = !0)),
      void 0 !== t.tradeVolume &&
        t.tradeVolume !== this.tradeVolume &&
        ((this.tradeVolume = t.tradeVolume), t.tradeVolume, (r = !0)),
      void 0 !== t.quickTradeVolume &&
        t.quickTradeVolume !== this.quickTradeVolume)
    ) {
      (this.quickTradeVolume = t.quickTradeVolume), t.quickTradeVolume;
      const s = e || this.symbolConfig;
      if (s) {
        const e = Math.max(s.lotsStep, s.lotsMin);
        this.quickTradeVolume = Math.min(
          Math.max(t.quickTradeVolume, e),
          null == s ? void 0 : s.lotsMax
        );
      }
      r = !0;
    }
    if (
      (void 0 !== t.volume &&
        t.volume !== this.volume &&
        ((this.volume = t.volume), t.volume, (r = !0)),
      void 0 !== t.period &&
        t.period !== this.period &&
        ((this.period = t.period), t.period, (r = !0)),
      void 0 !== t.title &&
        t.title !== this.title &&
        ((this.title = t.title), t.title, (r = !0)),
      void 0 !== t.description &&
        t.description !== this.description &&
        ((this.description = t.description), t.description, (r = !0)),
      void 0 !== t.symbol &&
        t.symbol !== this.symbol &&
        ((this.symbol = t.symbol), t.symbol, (r = !0)),
      void 0 !== t.from &&
        t.from !== this.from &&
        ((this.from = t.from), t.from, (r = !0)),
      void 0 !== t.xScale &&
        t.xScale !== this.xScale &&
        ((this.xScale = t.xScale), t.xScale, (r = !0)),
      void 0 !== t.yScale &&
        t.yScale !== this.yScale &&
        ((this.yScale = t.yScale), t.yScale, (r = !0)),
      void 0 !== t.yPadding &&
        t.yPadding !== this.yPadding &&
        ((this.yPadding = t.yPadding), t.yPadding, (r = !0)),
      void 0 !== e &&
        (e.symbol !== (null == (i = this.symbolConfig) ? void 0 : i.symbol) ||
          e.isFull !== (null == (o = this.symbolConfig) ? void 0 : o.isFull)))
    ) {
      this.symbolConfig = e;
      const t = Math.max(e.lotsMin, e.lotsStep);
      this.quickTradeVolume < t
        ? (this.quickTradeVolume = t)
        : this.quickTradeVolume > e.lotsMax &&
          ((this.quickTradeVolume = e.lotsMax), this.quickTradeVolume),
        (r = !0);
    }
    return (
      void 0 !== t.magnet &&
        t.magnet !== this.magnet &&
        ((this.magnet = t.magnet), t.magnet, (r = !0)),
      r && !s && this.refresh(),
      this
    );
  }
  getOptions() {
    return {
      type: this.type,
      tradeVolume: this.tradeVolume,
      quickTradeVolume: this.quickTradeVolume,
      volume: this.volume,
      period: this.period,
      title: this.title,
      description: this.description,
      symbol: this.symbol,
      from: this.from,
      xScale: this.xScale,
      yScale: this.yScale,
      yPadding: this.yPadding,
      magnet: this.magnet,
    };
  }
}
class $e {
  constructor(t, e, s, i) {
    (this.configsStore = t),
      (this.configStore = e),
      (this.symbolsController = s),
      (this.stateController = i),
      (this.storage = pt.configs),
      (this.onChangeState = Xt(500, this.onChangeState.bind(this))),
      (this.onChangeConfig = Xt(100, this.onChangeConfig.bind(this)));
  }
  async init(t) {
    const e = await this.storage.getAll();
    this.unsubscribeConfigs && this.unsubscribeConfigs(),
      this.unsubscribeState && this.unsubscribeState(),
      (this.unsubscribeConfigs = this.configStore.subscribe(
        this.onChangeConfig
      )),
      (this.unsubscribeState = this.stateController.stateStore.subscribe(
        this.onChangeState
      )),
      this.configsStore.reset(e),
      this.setConfig(t);
  }
  destroy() {
    this.unsubscribeConfigs && this.unsubscribeConfigs(),
      this.unsubscribeState && this.unsubscribeState();
  }
  onChangeConfig() {
    const t = this.symbolsController.symbolsStore.getBySymbol(
      this.configStore.symbol
    );
    let e = !1;
    if (
      t &&
      (this.configStore.tradeVolume > t.lotsMax
        ? ((this.configStore.tradeVolume = t.lotsMax), (e = !0))
        : this.configStore.tradeVolume < t.lotsMin &&
          ((this.configStore.tradeVolume = t.lotsMin), (e = !0)),
      e)
    )
      return void this.configStore.refresh();
    this.stateController.stateStore.setData({
      yDigits: 10 ** this.configStore.getDigits(),
      xScale: this.configStore.xScale,
      volume: this.configStore.volume,
    });
    const s = this.configStore.getOptions();
    s.symbol &&
      (this.configsStore.setOptions(s),
      this.storage.add({
        type: s.type,
        tradeVolume: s.tradeVolume,
        quickTradeVolume: s.quickTradeVolume,
        volume: s.volume,
        period: s.period,
        title: s.title,
        description: s.description,
        symbol: s.symbol,
        from: s.from,
        xScale: s.xScale,
        yScale: s.yScale,
        yPadding: s.yPadding,
        magnet: s.magnet,
      }));
  }
  onChangeState() {
    const t = this.stateController.stateStore.getFrom(),
      e = this.stateController.stateStore.getScale();
    (t === this.configStore.from && e === this.configStore.xScale) ||
      (this.configStore.setOptions({ from: t, xScale: e }, void 0, !0),
      this.configsStore.setOptionsFromConfig(this.configStore));
  }
  toggleVolume(t) {
    t === this.configStore.volume
      ? this.configStore.setOptions({ volume: Et.none })
      : this.configStore.setOptions({ volume: t });
  }
  setConfig(t) {
    const e = this.configsStore.getOptions(t),
      s = this.symbolsController.symbolsStore.getBySymbol(t);
    if (!s) throw new Error("config dose not exist");
    this.configStore.setOptions(e, s);
  }
}
class Ge {
  constructor(t, e) {
    (this.configsStore = new Ke()),
      (this.configStore = new Ye()),
      (this.configsController = new $e(
        this.configsStore,
        this.configStore,
        t,
        e
      ));
  }
}
const Qe = {
  30: { keyCode: "Escape" },
  0: { keyCode: "F9" },
  5: { keyCode: "KeyI", ctrl: !0 },
  6: { keyCode: "KeyB", alt: !0 },
  4: { keyCode: "KeyB", ctrl: !0 },
  7: { keyCode: "KeyT", alt: !0 },
  8: { keyCode: "KeyM", ctrl: !0 },
  1: { keyCode: "KeyT", ctrl: !0, alt: !0 },
  2: { keyCode: "KeyH", ctrl: !0, alt: !0 },
  3: { keyCode: "KeyJ", ctrl: !0, alt: !0 },
  9: { keyCode: "Digit1", alt: !0 },
  10: { keyCode: "Digit2", alt: !0 },
  11: { keyCode: "Digit3", alt: !0 },
  12: { keyCode: "KeyK", ctrl: !0 },
  13: { keyCode: "KeyL", ctrl: !0 },
  14: { keyCode: "KeyL", alt: !0 },
  15: { keyCode: "KeyH", alt: !0 },
  16: { keyCode: "KeyV", alt: !0 },
  17: { keyCode: "KeyI", alt: !0 },
  18: { keyCode: "KeyA", alt: !0 },
  19: { keyCode: "KeyR", alt: !0 },
  20: { keyCode: "KeyE", alt: !0 },
  21: { keyCode: "KeyC", alt: !0 },
  22: { keyCode: "ArrowRight" },
  23: { keyCode: "ArrowLeft" },
  24: { keyCode: "ArrowRight", alt: !0, shift: !0 },
  25: { keyCode: "KeyR", alt: !0, shift: !0 },
  27: { keyCode: "Equal" },
  26: { keyCode: "Minus" },
  28: { keyCode: "F11" },
  29: { keyCode: "KeyS", ctrl: !0 },
};
class Je {
  constructor(t, e, s, i, o, r) {
    (this.hotkeysStore = t),
      (this.chartController = e),
      (this.layoutController = s),
      (this.uiSettingsController = i),
      (this.configsController = o),
      (this.stateController = r),
      (this.onKeyDown = this.onKeyDown.bind(this));
  }
  init() {
    this.addHandlers(), window.addEventListener("keydown", this.onKeyDown);
  }
  destroy() {
    window.removeEventListener("keydown", this.onKeyDown),
      this.hotkeysStore.clear();
  }
  addHandlers() {
    this.addHandler(30, () =>
      this.stateController.stateStore.setData({ mode: 0 })
    ),
      this.addHandler(0, () =>
        this.layoutController.layoutStore.setLayout({
          tradeCreate:
            null !== this.layoutController.layoutStore.tradeCreate ? null : 0,
        })
      ),
      this.addHandler(5, () =>
        this.layoutController.layoutStore.setLayout({
          indicators: !this.layoutController.layoutStore.indicators,
        })
      ),
      this.addHandler(6, () =>
        this.layoutController.layoutStore.setLayout({
          depthOfMarket: !this.layoutController.layoutStore.depthOfMarket,
        })
      ),
      this.addHandler(7, () =>
        this.uiSettingsController.uiSettingsStore.setSettings({
          quickTrade: !this.uiSettingsController.uiSettingsStore.quickTrade,
        })
      ),
      this.addHandler(8, () =>
        this.layoutController.layoutStore.setLayout({
          symbols: !this.layoutController.layoutStore.symbols,
        })
      ),
      this.addHandler(9, () =>
        this.configsController.configStore.setOptions({ type: Ht.bar })
      ),
      this.addHandler(10, () =>
        this.configsController.configStore.setOptions({ type: Ht.candle })
      ),
      this.addHandler(11, () =>
        this.configsController.configStore.setOptions({ type: Ht.area })
      ),
      this.addHandler(12, () => this.configsController.toggleVolume(Et.real)),
      this.addHandler(13, () => this.configsController.toggleVolume(Et.tick)),
      this.addHandler(14, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(18);
      }),
      this.addHandler(15, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(13);
      }),
      this.addHandler(16, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(19);
      }),
      this.addHandler(17, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(14);
      }),
      this.addHandler(18, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(9);
      }),
      this.addHandler(19, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(15);
      }),
      this.addHandler(20, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(11);
      }),
      this.addHandler(21, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.setMode(10);
      }),
      this.addHandler(23, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.moveLeft();
      }),
      this.addHandler(22, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.moveRight();
      }),
      this.addHandler(24, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.moveToEnd();
      }),
      this.addHandler(25, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.resetView();
      }),
      this.addHandler(26, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.zoomOut();
      }),
      this.addHandler(27, () => {
        var t;
        return null == (t = this.chartController.chartStore.chart)
          ? void 0
          : t.zoomIn();
      }),
      this.addHandler(28, () => Rt()),
      this.addHandler(29, () => this.chartController.takeScreenshot()),
      this.addHandler(1, () =>
        this.layoutController.layoutStore.setLayout({
          botPanel:
            this.layoutController.layoutStore.botPanel === wt.Quotes
              ? wt.None
              : wt.Quotes,
        })
      ),
      this.addHandler(2, () =>
        this.layoutController.layoutStore.setLayout({
          botPanel:
            this.layoutController.layoutStore.botPanel === wt.HistoryPositions
              ? wt.None
              : wt.HistoryPositions,
        })
      ),
      this.addHandler(3, () => {
        this.layoutController.layoutStore.setLayout({
          botPanel:
            this.layoutController.layoutStore.botPanel === wt.Journal
              ? wt.None
              : wt.Journal,
        });
      }),
      this.addHandler(4, () =>
        this.layoutController.layoutStore.setLayout({
          tree: !this.layoutController.layoutStore.tree,
        })
      );
  }
  addHandler(t, e) {
    this.hotkeysStore.addHandler(t, e);
  }
  onKeyDown(t) {
    const e = zt({
      keyCode: t.code,
      ctrl: t.ctrlKey,
      alt: t.altKey,
      shift: t.shiftKey,
      meta: t.metaKey,
    });
    this.hotkeysStore.handlersByHash.has(e) &&
      t.target === document.body &&
      (t.preventDefault(), this.hotkeysStore.handlersByHash.get(e)());
  }
  getTitle(t) {
    if (void 0 === t) return "";
    const e = this.hotkeysStore.hotkeys[t];
    if (!e) return "";
    let s = "";
    return (
      (null == e ? void 0 : e.ctrl) && (s += "Ctrl + "),
      (null == e ? void 0 : e.alt) && (s += (kt() ? "⌥" : "Alt") + " + "),
      (null == e ? void 0 : e.shift) && (s += "Shift + "),
      (null == e ? void 0 : e.meta) && (s += (kt() ? "⌘" : "WIN") + " + "),
      (s += Kt[e.keyCode]),
      s
    );
  }
}
class Ze extends ct {
  constructor() {
    super(),
      (this._systemName = "hotkeys"),
      (this.hotkeys = { ...Qe }),
      (this.handlersByHash = new Map());
  }
  addHandler(t, e) {
    const s = this.hotkeys[t];
    if (!s) return;
    const i = zt(s);
    this.handlersByHash.set(i, e);
  }
  clear() {
    this.handlersByHash.clear();
  }
}
class ts {
  constructor(t, e, s, i, o) {
    (this.hotkeysStore = new Ze()),
      (this.hotkeysController = new Je(this.hotkeysStore, t, e, s, i, o));
  }
}
class es {
  constructor(t, e) {
    (this.stateStore = t),
      (this.uiSettingsController = e),
      (this.onChangeUiSettings = this.onChangeUiSettings.bind(this));
  }
  init(t) {
    this.uiSettingsUnsubscribe &&
      (this.uiSettingsUnsubscribe(), delete this.uiSettingsUnsubscribe),
      (this.uiSettingsUnsubscribe =
        this.uiSettingsController.uiSettingsStore.subscribe(
          this.onChangeUiSettings
        )),
      this.stateStore.reset(t);
  }
  destroy() {
    this.uiSettingsUnsubscribe && this.uiSettingsUnsubscribe();
  }
  onChangeUiSettings() {
    this.stateStore.setData({
      crosshair: this.uiSettingsController.uiSettingsStore.crosshair,
    });
  }
}
(J = Object.defineProperty),
  (Z = Object.getOwnPropertyDescriptor),
  (tt = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? Z(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && J(e, s, n), n;
  });
class ss extends ct {
  constructor() {
    super(),
      (this._systemName = "state"),
      (this.yDigits = 0),
      (this.width = 400),
      (this.height = 400),
      (this.titlePadding = 0),
      (this.loading = !0),
      (this.error = !1),
      (this.moving = !1),
      (this.mode = 0),
      (this.crosshair = !1),
      (this.hidden = !1),
      (this.locked = !1),
      (this.xFrom = 0),
      (this.extrema = [0, 0]),
      (this.xScale = 0.3),
      (this.yAxisIsLeft = !1),
      (this.xStep = 0),
      (this.xCount = 0),
      (this.graphWidth = 0),
      (this.yAxisWidth = 0),
      (this.yVisible = !0),
      (this.graphX = 0),
      (this.axisXHeight = 0),
      (this.graphY = 0),
      (this.xShiftRight = 0),
      (this.xShift = 0),
      (this.xPadding = 0),
      (this.dataMinValue = 0),
      (this.dataMaxValue = 0),
      (this.volume = Et.none);
  }
  reset(t) {
    (this.bars = t), this.calc();
  }
  getFrom() {
    return this.xFrom;
  }
  setFrom(t) {
    this.setPrivateData({ xFrom: t });
  }
  getScale() {
    return this.xScale;
  }
  getStep() {
    return this.xStep;
  }
  getCount() {
    return this.xCount;
  }
  setData(t) {
    let e = !1;
    const s = {};
    return (
      void 0 !== t.width &&
        t.width !== this.width &&
        ((this.width = t.width), (s.width = t.width), (e = !0)),
      void 0 !== t.height &&
        t.height !== this.height &&
        ((this.height = t.height), (s.height = t.height), (e = !0)),
      void 0 !== t.yAxisWidth &&
        this.yAxisWidth !== t.yAxisWidth &&
        ((this.yAxisWidth = t.yAxisWidth),
        (s.yAxisWidth = t.yAxisWidth),
        (e = !0),
        this.calc()),
      void 0 !== t.mode &&
        this.mode !== t.mode &&
        ((this.mode = t.mode), (s.mode = t.mode), (e = !0)),
      void 0 !== t.crosshair &&
        this.crosshair !== t.crosshair &&
        ((this.crosshair = t.crosshair), (s.crosshair = t.crosshair), (e = !0)),
      void 0 !== t.error &&
        this.error !== t.error &&
        ((this.error = t.error), (s.error = t.error), (e = !0)),
      void 0 !== t.loading &&
        this.loading !== t.loading &&
        ((this.loading = t.loading), (s.loading = t.loading), (e = !0)),
      void 0 !== t.hidden &&
        this.hidden !== t.hidden &&
        ((this.hidden = t.hidden), (s.hidden = t.hidden), (e = !0)),
      void 0 !== t.locked &&
        this.locked !== t.locked &&
        ((this.locked = t.locked), (s.locked = t.locked), (e = !0)),
      void 0 !== t.moving &&
        this.moving !== t.moving &&
        ((this.moving = t.moving), (s.moving = t.moving), (e = !0)),
      void 0 !== t.yDigits &&
        this.yDigits !== t.yDigits &&
        ((this.yDigits = t.yDigits), (s.yDigits = t.yDigits), (e = !0)),
      void 0 !== t.xScale &&
        this.xScale !== t.xScale &&
        ((this.xScale = t.xScale), (s.xScale = t.xScale), (e = !0)),
      void 0 !== t.volume &&
        this.volume !== t.volume &&
        ((this.volume = t.volume), (s.volume = t.volume), (e = !0)),
      void 0 !== t.axisXHeight &&
        this.axisXHeight !== t.axisXHeight &&
        ((this.axisXHeight = t.axisXHeight),
        (s.axisXHeight = t.axisXHeight),
        (e = !0)),
      e && this.refresh(),
      e
    );
  }
  setPrivateData(t) {
    let e = !1;
    void 0 !== t.graphWidth &&
      this.graphWidth !== t.graphWidth &&
      ((this.graphWidth = t.graphWidth), (e = !0)),
      void 0 !== t.graphHeight &&
        this.graphHeight !== t.graphHeight &&
        ((this.graphHeight = t.graphHeight), (e = !0)),
      void 0 !== t.graphX &&
        this.graphX !== t.graphX &&
        ((this.graphX = t.graphX), (e = !0)),
      void 0 !== t.graphY &&
        this.graphY !== t.graphY &&
        ((this.graphY = t.graphY), (e = !0)),
      void 0 !== t.xStep &&
        this.xStep !== t.xStep &&
        ((this.xStep = t.xStep), (e = !0)),
      void 0 !== t.xCount &&
        this.xCount !== t.xCount &&
        ((this.xCount = t.xCount), (e = !0)),
      void 0 !== t.xShiftRight &&
        this.xShiftRight !== t.xShiftRight &&
        ((this.xShiftRight = t.xShiftRight), (e = !0)),
      void 0 !== t.xShift &&
        this.xShift !== t.xShift &&
        ((this.xShift = t.xShift), (e = !0)),
      void 0 !== t.xPadding &&
        this.xPadding !== t.xPadding &&
        ((this.xPadding = t.xPadding), (e = !0)),
      void 0 !== t.xFrom &&
        t.xFrom !== this.xFrom &&
        ((this.xFrom = t.xFrom), (e = !0)),
      void 0 !== t.dataMinValue &&
        t.dataMinValue !== this.dataMinValue &&
        ((this.dataMinValue = t.dataMinValue), (e = !0)),
      void 0 !== t.dataMaxValue &&
        t.dataMaxValue !== this.dataMaxValue &&
        ((this.dataMaxValue = t.dataMaxValue), (e = !0)),
      void 0 !== t.extrema &&
        t.extrema !== this.extrema &&
        ((this.extrema = t.extrema), (e = !0)),
      e && this.refresh();
  }
  calc() {
    const { xScale: t } = this,
      e = this.yVisible ? this.yAxisWidth : 0,
      s = this.width - e,
      i = this.yAxisIsLeft ? e : 0,
      o = 40 * t,
      r = Math.ceil(s / o) + 1,
      n = Math.ceil(0.1 * r),
      h = Math.floor(0.8 * r);
    let a = this.xPadding;
    return (
      a || (a = Math.floor(o / 2)),
      this.setPrivateData({
        graphWidth: s,
        graphX: i,
        graphY: 0,
        xStep: o,
        xCount: r,
        xShiftRight: n,
        xShift: h,
        xPadding: a,
      }),
      this.calcX(),
      this
    );
  }
  calcX() {
    this.checkFrom(), this.extremumData();
  }
  resize(t = 400, e = 400) {
    const s = this.yVisible ? this.yAxisWidth : 0;
    this.setData({ width: t, height: e }),
      this.setPrivateData({
        graphWidth: t - s,
        graphHeight: e - this.axisXHeight,
      });
    const i = this.xFrom + this.xCount;
    return (
      this.calc(),
      this.setPrivateData({ xFrom: i - this.xCount }),
      this.calcX(),
      this
    );
  }
  scale(t, e) {
    const s = Math.floor(1e3 * Math.min(1, Math.max(0.03, t))) / 1e3;
    if ("number" == typeof e) {
      const t = this.xToIndex(e),
        i = this.indexToX(t);
      this.setData({ xScale: s });
      const o = this.xFrom + (this.xToIndex(e) - this.xFrom);
      this.calc(),
        this.setPrivateData({ xFrom: o - (this.xToIndex(e) - this.xFrom) }),
        this.move(this.indexToX(t) - i);
    } else {
      const t = this.xPadding / this.xScale;
      this.setData({ xScale: s });
      const e = this.xFrom + this.xCount;
      this.calc(),
        this.setPrivateData({ xFrom: e - this.xCount, xPadding: t * s }),
        this.calcX();
    }
    return this;
  }
  scrollX() {
    return this.xFrom * this.xStep + this.xPadding;
  }
  scrollTo(t) {
    const e = Math.round(t),
      s = Math.ceil(e / this.xStep);
    this.setPrivateData({
      xFrom: s,
      xPadding: -1 * (e - Math.ceil(s * this.xStep)),
    }),
      this.calcX();
  }
  scrollMin() {
    return this.xStep * -this.xShift + this.xPadding;
  }
  scrollMax() {
    var t, e, s;
    return (null == (t = this.bars) ? void 0 : t.value)
      ? ((null == (s = null == (e = this.bars) ? void 0 : e.value)
          ? void 0
          : s.length) ?? 0 - this.xCount + this.xShift - 1) *
          this.xStep +
          this.xPadding
      : 0;
  }
  move(t) {
    var e, s;
    if (0 !== t) {
      const i = -this.xShift;
      if (t < 0 && this.xFrom <= i)
        return this.setPrivateData({ xFrom: i }), this.calcX(), this;
      const o =
        ((null == (s = null == (e = this.bars) ? void 0 : e.value)
          ? void 0
          : s.length) ?? 0) -
        this.xCount +
        this.xShift -
        1;
      if (t > 0 && this.xFrom >= o)
        return this.setPrivateData({ xFrom: o }), this.calcX(), this;
      const r = Math.ceil((t - this.xPadding) / this.xStep) + 1;
      this.setPrivateData({
        xFrom: this.xFrom + r,
        xPadding: this.xPadding - (t - r * this.xStep),
      }),
        this.calcX();
    }
    return this;
  }
  checkFrom() {
    var t, e;
    let s = this.xFrom;
    (s = Math.max(s, -this.xShift)),
      (s = Math.min(
        s,
        ((null == (e = null == (t = this.bars) ? void 0 : t.value)
          ? void 0
          : e.length) || 0) +
          this.xShift -
          this.xCount -
          1
      )),
      this.setPrivateData({ xFrom: s });
  }
  moveToEnd() {
    var t, e;
    return (
      this.setPrivateData({
        xFrom: (
          null == (e = null == (t = this.bars) ? void 0 : t.value)
            ? void 0
            : e.length
        )
          ? this.bars.value.length - this.xCount + this.xShiftRight
          : 0 - this.xCount + this.xShiftRight,
      }),
      this.calcX(),
      this
    );
  }
  moveToStart() {
    return this.setPrivateData({ xFrom: 0 }), this.calcX(), this;
  }
  extremumData() {
    var t, e, s, i;
    const o = Math.max(0, this.xFrom),
      r = Math.max(0, this.xFrom + this.xCount + 1),
      n =
        (null ==
        (e = null == (t = null == this ? void 0 : this.bars) ? void 0 : t.value)
          ? void 0
          : e.minmax(o, r)) ?? [];
    if (n.length) {
      if (
        (this.setPrivateData({ dataMinValue: n[0], dataMaxValue: n[1] }),
        this.volume !== Et.none &&
          ((null == (i = null == (s = this.bars) ? void 0 : s.value)
            ? void 0
            : i.max(o, r, this.volume)) ?? 0) > Number.MIN_VALUE)
      ) {
        const t = 0.25 * (n[1] - n[0]);
        n[0] -= t;
      }
      const t = n[0] * this.yDigits,
        e = n[1] * this.yDigits;
      (this.extrema[0] === t && this.extrema[1] === e) ||
        this.setPrivateData({ extrema: [t, e] });
    }
  }
  startX() {
    var t, e;
    const { graphWidth: s, xPadding: i, xShift: o, xCount: r, xStep: n } = this,
      h = Math.min(
        r + 1,
        ((null == (e = null == (t = this.bars) ? void 0 : t.value)
          ? void 0
          : e.length) ?? 0) +
          2 * o
      );
    return Math.round(s - h * n + n + i);
  }
  xToIndex(t) {
    const e = t - (this.startX() - 0.5 * this.xStep);
    return Math.floor(e / this.xStep) + this.xFrom;
  }
  indexToX(t) {
    return Math.round((t - this.xFrom) * this.xStep + this.startX());
  }
  isEnd() {
    var t, e;
    return (
      this.indexToX(
        ((null == (e = null == (t = this.bars) ? void 0 : t.value)
          ? void 0
          : e.length) || 0) - 1
      ) <
      this.graphX + this.graphWidth
    );
  }
}
tt([dt], ss.prototype, "reset", 1),
  tt([dt], ss.prototype, "scale", 1),
  tt([dt], ss.prototype, "scrollTo", 1),
  tt([dt], ss.prototype, "moveToEnd", 1),
  tt([dt], ss.prototype, "moveToStart", 1);
class is {
  constructor(t) {
    (this.stateStore = new ss()),
      (this.stateController = new es(this.stateStore, t));
  }
}
class os {
  constructor(t, e, s) {
    (this.timeouts = {}),
      (this.api = t),
      (this.barsStore = e),
      (this.configsController = s),
      (this.storage = pt.trade_bars),
      (this.onChangeConfig = this.onChangeConfig.bind(this));
  }
  async init() {
    const { configStore: t } = this.configsController,
      e = await this.storage.getAll();
    this.barsStore.reset(e),
      (this.barsStore.current.value = this.barsStore.find(t.symbol, t.period)),
      (this.configUnsubscribe = t.subscribe(this.onChangeConfig)),
      this.onChangeConfig();
  }
  onChangeConfig() {
    const { symbol: t, period: e } = this.configsController.configStore;
    this.barsStore.current.value = this.barsStore.find(t, e);
  }
  destroy() {
    this.barsStore.reset(), this.configUnsubscribe && this.configUnsubscribe();
  }
  async load(t, e) {
    const s = this.barsStore.current.value,
      { symbol: i, period: o } = s;
    let r;
    try {
      r = (
        await this.api.view.rates.getRates({
          symbol: i,
          period: o,
          from: t / 1e3,
          to: e / 1e3,
        })
      ).buffer;
    } catch (n) {
      const { code: t, command: e, message: i } = n;
      if (((s.pending = !1), (s.pendingDirection = 0), 1e4 === t))
        return (s.pending = !1), null;
      throw n;
    }
    if (
      !(function (t, e) {
        const s = new Uint32Array(t);
        for (let i = 0, o = s.length; i < o; i += 12) {
          const t = 1e3 * s[i];
          if (!Ot(t, e)) return !1;
        }
        return !0;
      })(r, s.period)
    )
      throw (
        ((s.pending = !1),
        (s.pendingDirection = 0),
        new Error(`bars is not aligned by period (${s.symbol}, ${s.period})`))
      );
    return (
      (s.pending = !1),
      (s.real = !0),
      (s.lastLoadedBarTime = s.time(s.length - 1)),
      this.update(i, o, r),
      r
    );
  }
  update(t, e, s) {
    this.barsStore.add(t, e, s);
    const i = this.barsStore.find(t, e).buffer;
    this.updateStorage(t, e, i);
  }
  updateStorage(t, e, s) {
    const i = `${t}_${e}`;
    this.timeouts[i] && window.clearTimeout(this.timeouts[i]),
      (this.timeouts[i] = window.setTimeout(() => {
        this.storage.add({ id: i, symbol: t, period: e, buffer: s });
      }, 1e3));
  }
}
(et = Object.defineProperty),
  (st = Object.getOwnPropertyDescriptor),
  (it = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? st(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && et(e, s, n), n;
  });
class rs extends ct {
  constructor() {
    super(),
      (this._systemName = bt.tradeBars),
      (this.data = {}),
      (this.current = {});
  }
  reset(t = []) {
    return (
      (this.data = {}),
      t.forEach((t) => {
        (this.data[t.symbol] = this.data[t.symbol] || {}),
          (this.data[t.symbol][t.period] = new jt(
            t.symbol,
            t.period,
            t.buffer
          ));
      }),
      this
    );
  }
  add(t, e, s) {
    const i = this.data[t] && this.data[t][e];
    return (
      i
        ? s && i.impose(s)
        : ((this.data[t] = this.data[t] || {}),
          (this.data[t][e] = new jt(t, e, s))),
      this.data[t][e]
    );
  }
  find(t, e) {
    return e
      ? (this.data[t] && this.data[t][e]) || this.add(t, e)
      : this.data[t]
      ? Object.values(this.data[t])
      : [];
  }
  extends(t, e) {
    const s = e.symbol,
      i = this.data[s];
    i && Object.values(i).forEach((s) => s.extends(t, e));
  }
}
it([dt], rs.prototype, "reset", 1), it([dt], rs.prototype, "add", 1);
class ns {
  constructor(t, e) {
    (this.barsStore = new rs()),
      (this.barsController = new os(t, this.barsStore, e));
  }
}
class hs {
  constructor(t, s, i, o, r, n, h, a, l, d, c, u, y, g, m, p) {
    (this.currentStart = null),
      (this.configsController = i),
      (this.stateController = o),
      (this.objectsController = r),
      (this.indicatorsController = n),
      (this.ticksController = h),
      (this.symbolsController = a),
      (this.barsController = l),
      (this.accountController = d),
      (this.interactionController = c),
      (this.tradeController = u),
      (this.historyController = y),
      (this.marksController = g),
      (this.chartController = m),
      (this.config = this.configsController.configStore),
      (this.chart = new p(
        s,
        this.config,
        this.stateController.stateStore,
        e(t),
        t.colors,
        this.barsController.barsStore.current,
        this.accountController.accountStore,
        this.barsController,
        this.chartController
      )),
      (this.error = !1),
      (this.period = this.config.period),
      (this.volume = this.config.volume),
      (this.onTick = this.onTick.bind(this)),
      (this.onChangeState = this.onChangeState.bind(this)),
      (this.onChangeCommonConfig = Yt(
        100,
        this.onChangeCommonConfig.bind(this)
      )),
      (this.onChangeConfig = this.onChangeConfig.bind(this)),
      (this.onChangeTheme = this.onChangeTheme.bind(this)),
      (this.onBarsChange = this.onBarsChange.bind(this)),
      (this.onChartMount = this.onChartMount.bind(this)),
      (this.onRemoveIndicator = this.onRemoveIndicator.bind(this)),
      (this.onRemoveObject = this.onRemoveObject.bind(this)),
      (this.themeUnsubscribe = t.subscribe(this.onChangeTheme));
  }
  onChangeTheme() {
    const t = e(Tt.theme.themeStore);
    (this.chart.style = t),
      this.chart.state.setData({ axisXHeight: 6 * this.chart.style.indent }),
      this.chart.refresh();
  }
  onChangeState() {
    this.chart.redraw();
  }
  onChangeCommonConfig() {
    this.chart.refresh();
  }
  async onChangeConfig(t) {
    t && (await ft(), this.onChange(this.config));
  }
  async onBarsChange() {
    await ft(), this.chart.refresh();
  }
  destroy() {
    this.chartUnsubscriber &&
      (this.chartUnsubscriber(), delete this.chartUnsubscriber),
      this.stateUnsubscriber &&
        (this.stateUnsubscriber(), delete this.stateUnsubscriber),
      this.commonConfigUnsubscriber &&
        (this.commonConfigUnsubscriber(), delete this.commonConfigUnsubscriber),
      this.tickUnsubscribe &&
        (this.tickUnsubscribe(), delete this.tickUnsubscribe),
      this.barsUnsubscribe &&
        (this.barsUnsubscribe(), delete this.barsUnsubscribe),
      this.themeUnsubscribe &&
        (this.themeUnsubscribe(), delete this.themeUnsubscribe),
      this.objectsController.destroy(this.chart.objects),
      this.indicatorsController.destroy(
        this.chart.indicators,
        this.chart.sections
      ),
      this.chart.destroy();
  }
  create() {
    return (
      this.chart.refresh(),
      this.chart.on(qt.Mount, this.onChartMount),
      this.chart
    );
  }
  onChartMount() {
    this.chart.setLoading(!1), this.chart.setError(!1);
  }
  restart() {
    return this.start(), this;
  }
  async start() {
    return (
      (this.currentStart = Math.floor(1e7 * Math.random())),
      this.chart.state.setData({ yAxisWidth: 0 }),
      await this.innerStart(this.currentStart),
      this.chart.sections.resize(),
      this
    );
  }
  onRemoveIndicator(t) {
    this.indicatorsController.remove(t);
  }
  onRemoveObject(t) {
    this.objectsController.remove(t);
  }
  async innerStart(t) {
    const { chart: e, config: s } = this;
    if (
      (this.chart.setLoading("Loading..."),
      this.chart.setError(!1),
      this.barsUnsubscribe &&
        (this.barsUnsubscribe(), delete this.barsUnsubscribe),
      this.chartUnsubscriber &&
        (this.chartUnsubscriber(), delete this.chartUnsubscriber),
      this.stateUnsubscriber &&
        (this.stateUnsubscriber(), delete this.stateUnsubscriber),
      this.commonConfigUnsubscriber &&
        (this.commonConfigUnsubscriber(), delete this.commonConfigUnsubscriber),
      (this.chart.bars.value.askPrice = void 0),
      await ft(),
      this.currentStart !== t)
    )
      return this;
    if (
      (this.chart.sections.init(),
      this.chart.refresh(),
      await this.symbolsController.loadFullSymbols([s.symbol]),
      this.currentStart !== t)
    )
      return this;
    if (!this.symbolsController.symbolsStore.getBySymbol(s.symbol)) {
      const t = `Symbol doesn't exist: "${s.symbol}"`;
      throw (this.chart.setLoading(!1), this.chart.setError(t), Error(t));
    }
    (this.error = !1),
      this.chart.state.setData({ error: this.error }),
      this.chart.state.calc();
    const i = Boolean(e.bars.value.length);
    return (
      await this.indicatorsController.init(e.indicators, e.sections),
      await e.indicators.init(
        {
          interactionController: this.interactionController,
          accountController: this.accountController,
          tradeController: this.tradeController,
          marksController: this.marksController,
          historyController: this.historyController,
          symbolsController: this.symbolsController,
        },
        this.indicatorsController.indicatorsStore.getAll()
      ),
      await this.objectsController.init(e.objects),
      await e.objects.init(this.objectsController.objectsStore.getAll()),
      e.on(qt.RemoveIndicator, this.onRemoveIndicator),
      e.on(qt.RemoveObject, this.onRemoveObject),
      e.refresh(),
      i && this.render(),
      await this.loadCurrentDataBars(),
      this.currentStart !== t ||
        (this.chart.moveToEnd(),
        this.render(),
        (this.chartUnsubscriber = this.config.subscribe(this.onChangeConfig)),
        (this.barsUnsubscribe = this.barsController.barsStore.subscribe(
          this.onBarsChange
        )),
        (this.stateUnsubscriber = this.chart.state.subscribe(
          this.onChangeState
        )),
        (this.commonConfigUnsubscriber = this.chart.commonConfig.subscribe(
          this.onChangeCommonConfig
        )),
        this.chart.setLoading(!1),
        this.chart.state.calc()),
      this
    );
  }
  async loadCurrentDataBars() {
    var t;
    this.chart.resize();
    const e = 2 * this.chart.count();
    try {
      const { timezoneShift: s, dayLightMode: i } =
          this.accountController.accountStore,
        o = (null == (t = this.config.symbolConfig) ? void 0 : t.delay) ?? 0;
      await At.start(
        this.config.symbol,
        this.config.period,
        e,
        o,
        s,
        i,
        this.barsController,
        this.chartController
      );
    } catch (s) {
      s instanceof Error &&
        this.chart.setError(`Failed to load bars - ${s.message}`);
    }
  }
  render() {
    const { chart: t, config: e } = this;
    t.bars.value.period === e.period && (t.moveToEnd(), this.onBars()),
      t.refresh();
  }
  onBars() {
    const t = this.chart.bars.value;
    this.ticksController.on(t.symbol);
    const e = this.ticksController.ticksStore.getTick(t.symbol),
      s = this.symbolsController.symbolsStore.getBySymbol(t.symbol);
    (t.askPrice = (null == s ? void 0 : s.digits)
      ? Pt(e.ask, s.digits)
      : e.ask),
      this.tickUnsubscribe && this.tickUnsubscribe(),
      (this.tickUnsubscribe = e.subscribe(this.onTick));
  }
  onTick() {
    this.chart.tick();
  }
  async onChange(t) {
    t &&
      (t.period !== this.period &&
        ((this.period = t.period),
        await this.loadCurrentDataBars(),
        this.chart.moveToEnd()),
      this.render());
  }
}
class as {
  constructor(t, e, s, i, o, r, n, h, a, l, d, c, u, y, g, m, p) {
    (this.chartStore = t),
      (this.layoutController = e),
      (this.uiSettingsController = s),
      (this.configsController = i),
      (this.themeController = o),
      (this.stateController = r),
      (this.barsController = n),
      (this.symbolsController = h),
      (this.accountController = a),
      (this.watchlistController = l),
      (this.objectsController = d),
      (this.indicatorsController = c),
      (this.ticksController = u),
      (this.interactionController = y),
      (this.tradeController = g),
      (this.historyController = m),
      (this.marksController = p),
      (this.onResizeYAxis = this.onResizeYAxis.bind(this)),
      (this.onChangeChart = this.onChangeChart.bind(this)),
      (this.onChangeUiSettings = this.onChangeUiSettings.bind(this)),
      (this.layoutController = e),
      this.layoutController.layoutStore.subscribe(() => {
        ft().then(() => {
          var t;
          null == (t = this.chartStore.chart) || t.fastResize();
        });
      }),
      this.uiSettingsController.uiSettingsStore.subscribe(
        this.onChangeUiSettings
      );
  }
  async onChangeUiSettings() {
    var t;
    await ft(),
      this.layoutController.layoutStore.isMobile &&
        (null == (t = this.chartStore.chart) || t.fastResize());
  }
  onChangeChart() {
    var t;
    (null == (t = this.chartStore.chart) ? void 0 : t.sections) &&
      (this.chartStore.chart.sections.off(U.ResizeAxis, this.onResizeYAxis),
      this.chartStore.chart.sections.on(U.ResizeAxis, this.onResizeYAxis),
      this.chartStore.chart.sections.resize());
  }
  onResizeYAxis(t) {
    let e = 0;
    if (t.width && Wt.available["Trebuchet MS"]) {
      const s = 6,
        i = 2 * s;
      e = t.width * s + i + this.themeController.themeStore.sizes.indent / 2;
    }
    this.stateController.stateStore.setData({ yAxisWidth: e });
  }
  start() {
    var t;
    this.chartStore.element &&
      (null == (t = this.chartStore.appChart) || t.start());
  }
  async select(t) {
    var e;
    this.uiSettingsController.uiSettingsStore.setSettings({
      selectedSymbol: t,
    }),
      this.configsController.setConfig(this.getRealSelectedSymbol()),
      await (null == (e = this.chartStore.appChart) ? void 0 : e.start());
  }
  async create() {
    var t;
    const { Chart: e } = await Mt(
        () => import("./b16e76aa.js"),
        [
          "b16e76aa.js",
          "a4b22e5d.js",
          "3049ce3f.js",
          "00a24b22.js",
          "6f913017.css",
          "d09b99f6.js",
          "917f94f7.js",
          "f54151ac.js",
          "02c71ccc.css",
          "7313b880.css",
          "f60bb92f.js",
          "a3b77070.css",
          "883cebe6.css",
          "6cf66ffe.js",
        ]
      ),
      s = this.getRealSelectedSymbol();
    return (
      this.configsController.setConfig(s),
      null == (t = this.chartStore.appChart) || t.destroy(),
      this.chartStore.setApp(
        new hs(
          this.themeController.themeStore,
          this.uiSettingsController.uiSettingsStore,
          this.configsController,
          this.stateController,
          this.objectsController,
          this.indicatorsController,
          this.ticksController,
          this.symbolsController,
          this.barsController,
          this.accountController,
          this.interactionController,
          this.tradeController,
          this.historyController,
          this.marksController,
          this,
          e
        )
      ),
      this.chartStore.setChart(this.chartStore.appChart.create()),
      this.chartStore.element &&
        this.chartStore.chart.mount(this.chartStore.element),
      this.chartChangeUnsubscribe &&
        (this.chartChangeUnsubscribe(), delete this.chartChangeUnsubscribe),
      (this.chartChangeUnsubscribe = this.chartStore.subscribe(
        this.onChangeChart
      )),
      this
    );
  }
  destroy() {
    var t;
    null == (t = this.chartStore.appChart) || t.destroy(),
      this.chartChangeUnsubscribe &&
        (this.chartChangeUnsubscribe(), delete this.chartChangeUnsubscribe);
  }
  takeScreenshot() {
    this.chartStore.chart.takeScreenshot();
  }
  getRealSelectedSymbol() {
    let t = this.uiSettingsController.uiSettingsStore.selectedSymbol;
    if (
      (t &&
        (Boolean(this.symbolsController.symbolsStore.getBySymbol(t)) ||
          (t = "")),
      !t)
    ) {
      if (!this.symbolsController.symbolsStore.isEmpty())
        throw new Error("symbols list is empty");
      t =
        this.watchlistController.watchlistStore.getList()[0] ??
        this.symbolsController.symbolsStore.getFirst().symbol;
    }
    return (
      this.uiSettingsController.uiSettingsStore.selectedSymbol !== t &&
        this.uiSettingsController.uiSettingsStore.setSettings({
          selectedSymbol: t,
        }),
      this.uiSettingsController.uiSettingsStore.selectedSymbol
    );
  }
  async loadBars(t, e, s = 0) {
    const i = this.barsController.barsStore.current.value;
    return (
      (i.pending = !0),
      (i.pendingDirection = s),
      this.chartStore.appChart.onBars(),
      this.barsController.load(t, e)
    );
  }
}
(ot = Object.defineProperty),
  (rt = Object.getOwnPropertyDescriptor),
  (nt = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? rt(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && ot(e, s, n), n;
  });
class ls extends ct {
  constructor() {
    super(...arguments), (this._systemName = "chart");
  }
  setChart(t) {
    this.chart = t;
  }
  setApp(t) {
    this.appChart = t;
  }
}
nt([dt], ls.prototype, "setChart", 1), nt([dt], ls.prototype, "setApp", 1);
class ds {
  constructor(t, e, s, i, o, r, n, h, a, l, d, c, u, y, g, m) {
    (this.chartStore = new ls()),
      (this.chartController = new as(
        this.chartStore,
        t,
        e,
        s,
        i,
        o,
        r,
        n,
        h,
        a,
        l,
        d,
        c,
        u,
        y,
        g,
        m
      ));
  }
}
class cs {
  constructor(t) {
    this.api = t;
  }
  async agree() {
    await this.api.view.notify.send({ risk: 1 });
  }
}
class us {
  constructor(t) {
    this.notifyController = new cs(t);
  }
}
(ht = Object.defineProperty),
  (at = Object.getOwnPropertyDescriptor),
  (lt = (t, e, s, i) => {
    var o,
      r,
      n = i > 1 ? void 0 : i ? at(e, s) : e;
    for (o = t.length - 1; o >= 0; o--)
      (r = t[o]) && (n = (i ? r(e, s, n) : r(n)) || n);
    return i && n && ht(e, s, n), n;
  });
class ys extends ct {
  constructor() {
    super(), (this._systemName = "UserSettingsStore"), (this.oneClick = 0);
  }
  setSettings(t) {
    void 0 !== t.oneClick && (this.oneClick = t.oneClick);
  }
  reset(t) {
    (this.oneClick = 0), this.setSettings(t);
  }
}
lt([dt], ys.prototype, "setSettings", 1);
class gs {
  constructor(t) {
    (this.userSettingsStore = t),
      (this.storage = pt.user_settings),
      (this.onChangeUserSettings = this.onChangeUserSettings.bind(this));
  }
  async init() {
    const t = await this.storage.getAll();
    this.userSettingsStore.reset(t[0] || {}),
      this.userSettingsUnsubscribe &&
        (this.userSettingsUnsubscribe(), delete this.userSettingsUnsubscribe),
      (this.userSettingsUnsubscribe = this.userSettingsStore.subscribe(
        this.onChangeUserSettings
      ));
  }
  onChangeUserSettings(t) {
    this.storage.add({ oneClick: t.oneClick });
  }
  destroy() {
    this.userSettingsUnsubscribe &&
      (this.userSettingsUnsubscribe(), delete this.userSettingsUnsubscribe);
  }
}
class ms {
  constructor() {
    (this.userSettingsStore = new ys()),
      (this.userSettingsController = new gs(this.userSettingsStore));
  }
}
class ps {
  constructor(t) {
    this.api = t;
  }
  async getLinks() {
    return (await this.api.view.corporateLinks.getLinks()).map((t) => [
      s(t),
      t[2],
    ]);
  }
}
class bs {
  constructor(t) {
    this.corporateLinksController = new ps(t);
  }
}
const Ss = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      Modules: class {
        constructor(t) {
          (this.disabled = !1),
            (this.api = t),
            Tt.journal.journalController.connectApi(t),
            (this.notify = new us(t)),
            (this.notices = new ze(t)),
            (this.history = new le(t)),
            (this.books = new ee(t)),
            (this.corporateLinks = new bs(t)),
            (this.userSettings = new ms()),
            (this.account = new Qt(t, Tt.users.usersController)),
            (this.objects = new ue(Tt.uiSettings.uiSettingsController)),
            (this.indicators = new Me(Tt.uiSettings.uiSettingsController)),
            (this.symbols = new ie(t, this.account.accountController)),
            (this.state = new is(Tt.uiSettings.uiSettingsController)),
            (this.configs = new Ge(
              this.symbols.symbolsController,
              this.state.stateController
            )),
            (this.bars = new ns(t, this.configs.configsController)),
            (this.ticks = new pe(
              t,
              this.symbols.symbolsController,
              this.bars.barsController
            )),
            (this.trade = new Re(
              t,
              this.symbols.symbolsController,
              this.ticks.ticksController
            )),
            (this.interaction = new We(
              Tt.layout.layoutController,
              this.trade.tradeController
            )),
            (this.marks = new _e(this.interaction.interactionController)),
            (this.watchlist = new Ae(
              t,
              this.symbols.symbolsController,
              this.ticks.ticksController,
              this.trade.tradeController
            )),
            (this.chart = new ds(
              Tt.layout.layoutController,
              Tt.uiSettings.uiSettingsController,
              this.configs.configsController,
              Tt.theme.themeController,
              this.state.stateController,
              this.bars.barsController,
              this.symbols.symbolsController,
              this.account.accountController,
              this.watchlist.watchlistController,
              this.objects.objectsController,
              this.indicators.indicatorsController,
              this.ticks.ticksController,
              this.interaction.interactionController,
              this.trade.tradeController,
              this.history.historyController,
              this.marks.marksController
            )),
            (this.hotkeys = new ts(
              this.chart.chartController,
              Tt.layout.layoutController,
              Tt.uiSettings.uiSettingsController,
              this.configs.configsController,
              this.state.stateController
            ));
        }
        async init() {
          this.account.accountStore.isResetPass ||
            (this.notices.noticesController.init(),
            await this.userSettings.userSettingsController.init(),
            this.ticks.ticksController.init(),
            await this.watchlist.watchlistController.init(),
            await this.configs.configsController.init(
              this.chart.chartController.getRealSelectedSymbol()
            ),
            await this.bars.barsController.init(),
            this.state.stateController.init(
              this.bars.barsController.barsStore.current
            ),
            this.history.historyController.init(),
            this.hotkeys.hotkeysController.init(),
            this.marks.marksController.init());
        }
        async destroy() {
          (this.disabled = !0),
            await ft(),
            this.account.accountController.destroy(),
            this.notices.noticesController.destroy(),
            this.userSettings.userSettingsController.destroy(),
            this.notices.noticesController.destroy(),
            this.configs.configsController.destroy(),
            this.bars.barsController.destroy(),
            this.state.stateController.destroy(),
            this.books.booksController.destroy(),
            this.history.historyController.destroy(),
            this.ticks.ticksController.destroy(),
            this.trade.tradeController.destroy(),
            this.watchlist.watchlistController.destroy(),
            this.marks.marksController.destroy(),
            this.hotkeys.hotkeysController.destroy(),
            this.chart.chartController.destroy(),
            this.api.view.destroy();
        }
      },
    },
    Symbol.toStringTag,
    { value: "Module" }
  )
);
export { U as S, t as a, ke as b, Ss as m };
