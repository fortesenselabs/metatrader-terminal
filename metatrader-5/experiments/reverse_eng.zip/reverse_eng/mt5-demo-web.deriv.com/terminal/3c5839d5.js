function t(t) {
  let n,
    o = window.tr(window.lang.login.form.btn.cancel) + "";
  return {
    c() {
      n = g(o);
    },
    m(t, o) {
      m(t, n, o);
    },
    p: F,
    d(t) {
      t && S(n);
    },
  };
}
function n(t) {
  let n,
    o = window.tr(window.lang.login.otp.disable2FA) + "";
  return {
    c() {
      n = g(o);
    },
    m(t, o) {
      m(t, n, o);
    },
    p: F,
    d(t) {
      t && S(n);
    },
  };
}
function o(o) {
  function e(t) {
    o[9](t);
  }
  function s(t) {
    o[10](t);
  }
  function r(t) {
    o[11](t);
  }
  let a,
    E,
    F,
    O,
    T,
    _,
    j,
    I,
    L,
    M,
    P,
    R,
    U,
    V,
    W,
    z,
    B,
    D,
    G,
    H,
    J,
    K,
    N,
    Q,
    X,
    Y =
      window.tr(window.lang.login.otp.disable2FAAccount, {
        login: o[4].login,
      }) + "";
  O = new c({ props: { name: l } });
  let Z = { name: "otp" };
  return (
    void 0 !== o[1].otp && (Z.value = o[1].otp),
    void 0 !== o[2] && (Z.focus = o[2]),
    void 0 !== o[3] && (Z.errors = o[3]),
    (V = new i({ props: Z })),
    w.push(() => u(V, "value", e)),
    w.push(() => u(V, "focus", s)),
    w.push(() => u(V, "errors", r)),
    (H = new d({
      props: { active: !0, $$slots: { default: [t] }, $$scope: { ctx: o } },
    })),
    H.$on("click", o[6]),
    (K = new d({
      props: { red: !0, $$slots: { default: [n] }, $$scope: { ctx: o } },
    })),
    K.$on("click", o[5]),
    {
      c() {
        (a = $("div")),
          (E = $("div")),
          (F = $("button")),
          p(O.$$.fragment),
          (T = f()),
          (_ = $("div")),
          (j = g(Y)),
          (I = f()),
          (L = $("div")),
          (L.textContent = `${window.tr(
            window.lang.login.otp.disableEnterCode
          )}`),
          (M = f()),
          (P = $("div")),
          (R = $("div")),
          (R.textContent = `${window.tr(
            window.lang.login.otp.oneTimePassword
          )}`),
          (U = f()),
          p(V.$$.fragment),
          (D = f()),
          (G = $("div")),
          p(H.$$.fragment),
          (J = f()),
          p(K.$$.fragment),
          v(F, "class", "back svelte-116wwhc"),
          v(F, "title", window.tr(window.lang.ui.screen.back)),
          v(_, "class", "title svelte-116wwhc"),
          v(E, "class", "header svelte-116wwhc"),
          v(L, "class", "text svelte-116wwhc"),
          v(R, "class", "field"),
          v(P, "class", "password svelte-116wwhc"),
          v(G, "class", "controls svelte-116wwhc"),
          v(a, "class", "content svelte-116wwhc");
      },
      m(t, n) {
        m(t, a, n),
          h(a, E),
          h(E, F),
          b(O, F, null),
          h(E, T),
          h(E, _),
          h(_, j),
          h(a, I),
          h(a, L),
          h(a, M),
          h(a, P),
          h(P, R),
          h(P, U),
          b(V, P, null),
          h(a, D),
          h(a, G),
          b(H, G, null),
          h(G, J),
          b(K, G, null),
          (N = !0),
          Q || ((X = x(F, "click", o[6])), (Q = !0));
      },
      p(t, [n]) {
        (!N || 16 & n) &&
          Y !==
            (Y =
              window.tr(window.lang.login.otp.disable2FAAccount, {
                login: t[4].login,
              }) + "") &&
          C(j, Y);
        const o = {};
        !W && 2 & n && ((W = !0), (o.value = t[1].otp), k(() => (W = !1))),
          !z && 4 & n && ((z = !0), (o.focus = t[2]), k(() => (z = !1))),
          !B && 8 & n && ((B = !0), (o.errors = t[3]), k(() => (B = !1))),
          V.$set(o);
        const e = {};
        32768 & n && (e.$$scope = { dirty: n, ctx: t }), H.$set(e);
        const s = {};
        32768 & n && (s.$$scope = { dirty: n, ctx: t }), K.$set(s);
      },
      i(t) {
        N ||
          (y(O.$$.fragment, t),
          y(V.$$.fragment, t),
          y(H.$$.fragment, t),
          y(K.$$.fragment, t),
          (N = !0));
      },
      o(t) {
        A(O.$$.fragment, t),
          A(V.$$.fragment, t),
          A(H.$$.fragment, t),
          A(K.$$.fragment, t),
          (N = !1);
      },
      d(t) {
        t && S(a), q(O), q(V), q(H), q(K), (Q = !1), X();
      },
    }
  );
}
function e(t, n, o) {
  let e,
    s = F,
    r = () => (s(), (s = O(a, (t) => o(4, (e = t)))), a);
  t.$$.on_destroy.push(() => s());
  let { accountStore: a } = n;
  r();
  let { accountController: c } = n,
    { user: l } = n;
  const i = E(),
    w = { otp: { value: "", validators: ["required"] } },
    u = new T(w).getValues(w);
  let d = "",
    $ = {};
  return (
    (t.$$set = (t) => {
      "accountStore" in t && r(o(0, (a = t.accountStore))),
        "accountController" in t && o(7, (c = t.accountController)),
        "user" in t && o(8, (l = t.user));
    }),
    [
      a,
      u,
      d,
      $,
      e,
      async function () {
        if (l)
          try {
            if (!(await c.disconnectOtp(l.server, l.login, l.password, u.otp)))
              return void o(
                3,
                ($.otp = window.tr(window.lang.login.errors.invalidCode)),
                $
              );
            i("success");
          } catch (t) {
            t instanceof _
              ? i("error", j(t.code))
              : t instanceof Error
              ? i("error", { message: t.message, type: "error" })
              : i("error", {
                  message: window.tr(window.lang.login.errors.unknownError),
                  type: "error",
                });
          }
      },
      function () {
        i("cancel");
      },
      c,
      l,
      function (n) {
        t.$$.not_equal(u.otp, n) && ((u.otp = n), o(1, u));
      },
      function (t) {
        (d = t), o(2, d);
      },
      function (t) {
        ($ = t), o(3, $);
      },
    ]
  );
}
import {
  S as s,
  i as r,
  s as a,
  a3 as c,
  bq as l,
  I as i,
  T as w,
  U as u,
  aO as d,
  e as $,
  c as p,
  a as f,
  n as g,
  b as v,
  d as m,
  f as h,
  m as b,
  O as x,
  R as C,
  W as k,
  t as y,
  h as A,
  k as S,
  l as q,
  a1 as E,
  o as F,
  r as O,
  bi as T,
  aL as _,
  aM as j,
} from "./00a24b22.js";
class I extends s {
  constructor(t) {
    super(),
      r(this, t, e, o, a, { accountStore: 0, accountController: 7, user: 8 });
  }
}
export { I as default };
