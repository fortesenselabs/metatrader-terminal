function t(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.style) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function e(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.coordinates) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function s(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.visualization) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function n(n) {
  function i(t) {
    n[12](t);
  }
  function o(t) {
    n[13](t);
  }
  function r(t) {
    n[14](t);
  }
  let a,
    c,
    l,
    $,
    d,
    p,
    u,
    f,
    h,
    g = { value: "style", $$slots: { default: [t] }, $$scope: { ctx: n } };
  void 0 !== n[2] && (g.group = n[2]),
    (a = new Wt({ props: g })),
    ct.push(() => lt(a, "group", i));
  let m = {
    value: "coordinates",
    $$slots: { default: [e] },
    $$scope: { ctx: n },
  };
  void 0 !== n[2] && (m.group = n[2]),
    ($ = new Wt({ props: m })),
    ct.push(() => lt($, "group", o));
  let v = {
    value: "visualization",
    $$slots: { default: [s] },
    $$scope: { ctx: n },
  };
  return (
    void 0 !== n[2] && (v.group = n[2]),
    (u = new Wt({ props: v })),
    ct.push(() => lt(u, "group", r)),
    {
      c() {
        nt(a.$$.fragment),
          (l = $t()),
          nt($.$$.fragment),
          (p = $t()),
          nt(u.$$.fragment);
      },
      m(t, e) {
        it(a, t, e),
          dt(t, l, e),
          it($, t, e),
          dt(t, p, e),
          it(u, t, e),
          (h = !0);
      },
      p(t, e) {
        const s = {};
        32768 & e && (s.$$scope = { dirty: e, ctx: t }),
          !c && 4 & e && ((c = !0), (s.group = t[2]), pt(() => (c = !1))),
          a.$set(s);
        const n = {};
        32768 & e && (n.$$scope = { dirty: e, ctx: t }),
          !d && 4 & e && ((d = !0), (n.group = t[2]), pt(() => (d = !1))),
          $.$set(n);
        const i = {};
        32768 & e && (i.$$scope = { dirty: e, ctx: t }),
          !f && 4 & e && ((f = !0), (i.group = t[2]), pt(() => (f = !1))),
          u.$set(i);
      },
      i(t) {
        h ||
          (ot(a.$$.fragment, t),
          ot($.$$.fragment, t),
          ot(u.$$.fragment, t),
          (h = !0));
      },
      o(t) {
        rt(a.$$.fragment, t),
          rt($.$$.fragment, t),
          rt(u.$$.fragment, t),
          (h = !1);
      },
      d(t) {
        t && (ut(l), ut(p)), at(a, t), at($, t), at(u, t);
      },
    }
  );
}
function i(t) {
  function e(e) {
    t[4](e);
  }
  function s(e) {
    t[5](e);
  }
  function n(e) {
    t[6](e);
  }
  function i(e) {
    t[7](e);
  }
  let o,
    r,
    a,
    c,
    l,
    $,
    d,
    p,
    u,
    f,
    h,
    g,
    m = {};
  void 0 !== t[3].style.line && (m.styles = t[3].style.line),
    (o = new Yt({ props: m })),
    ct.push(() => lt(o, "styles", e));
  let v = {};
  void 0 !== t[3].style.line.tips && (v.tips = t[3].style.line.tips),
    (c = new qt({ props: v })),
    ct.push(() => lt(c, "tips", s));
  let y = {};
  void 0 !== t[3].style.line.extend && (y.extend = t[3].style.line.extend),
    (d = new Ut({ props: y })),
    ct.push(() => lt(d, "extend", n));
  let w = { angle: !1 };
  return (
    void 0 !== t[3].style.statistics && (w.statistics = t[3].style.statistics),
    (f = new Vt({ props: w })),
    ct.push(() => lt(f, "statistics", i)),
    {
      c() {
        nt(o.$$.fragment),
          (a = $t()),
          nt(c.$$.fragment),
          ($ = $t()),
          nt(d.$$.fragment),
          (u = $t()),
          nt(f.$$.fragment);
      },
      m(t, e) {
        it(o, t, e),
          dt(t, a, e),
          it(c, t, e),
          dt(t, $, e),
          it(d, t, e),
          dt(t, u, e),
          it(f, t, e),
          (g = !0);
      },
      p(t, e) {
        const s = {};
        !r &&
          8 & e &&
          ((r = !0), (s.styles = t[3].style.line), pt(() => (r = !1))),
          o.$set(s);
        const n = {};
        !l &&
          8 & e &&
          ((l = !0), (n.tips = t[3].style.line.tips), pt(() => (l = !1))),
          c.$set(n);
        const i = {};
        !p &&
          8 & e &&
          ((p = !0), (i.extend = t[3].style.line.extend), pt(() => (p = !1))),
          d.$set(i);
        const a = {};
        !h &&
          8 & e &&
          ((h = !0),
          (a.statistics = t[3].style.statistics),
          pt(() => (h = !1))),
          f.$set(a);
      },
      i(t) {
        g ||
          (ot(o.$$.fragment, t),
          ot(c.$$.fragment, t),
          ot(d.$$.fragment, t),
          ot(f.$$.fragment, t),
          (g = !0));
      },
      o(t) {
        rt(o.$$.fragment, t),
          rt(c.$$.fragment, t),
          rt(d.$$.fragment, t),
          rt(f.$$.fragment, t),
          (g = !1);
      },
      d(t) {
        t && (ut(a), ut($), ut(u)), at(o, t), at(c, t), at(d, t), at(f, t);
      },
    }
  );
}
function o(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [i] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        32776 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function r(t) {
  function e(e) {
    t[10](e);
  }
  let s,
    n,
    i,
    o,
    r = { type: "number", step: 0.01, min: -1e5, max: 1e5 };
  return (
    void 0 !== t[3].coordinates.angle && (r.value = t[3].coordinates.angle),
    (n = new xt({ props: r })),
    ct.push(() => lt(n, "value", e)),
    {
      c() {
        (s = ft("div")), nt(n.$$.fragment), bt(s, "width", "104px");
      },
      m(t, e) {
        dt(t, s, e), it(n, s, null), (o = !0);
      },
      p(t, e) {
        const s = {};
        !i &&
          8 & e &&
          ((i = !0), (s.value = t[3].coordinates.angle), pt(() => (i = !1))),
          n.$set(s);
      },
      i(t) {
        o || (ot(n.$$.fragment, t), (o = !0));
      },
      o(t) {
        rt(n.$$.fragment, t), (o = !1);
      },
      d(t) {
        t && ut(s), at(n);
      },
    }
  );
}
function a(t) {
  function e(e) {
    t[11](e);
  }
  let s,
    n,
    i,
    o,
    r = { type: "number", step: 1e-6, min: -1e5, max: 1e5 };
  return (
    void 0 !== t[3].coordinates.pips && (r.value = t[3].coordinates.pips),
    (n = new xt({ props: r })),
    ct.push(() => lt(n, "value", e)),
    {
      c() {
        (s = ft("div")), nt(n.$$.fragment), bt(s, "width", "104px");
      },
      m(t, e) {
        dt(t, s, e), it(n, s, null), (o = !0);
      },
      p(t, e) {
        const s = {};
        !i &&
          8 & e &&
          ((i = !0), (s.value = t[3].coordinates.pips), pt(() => (i = !1))),
          n.$set(s);
      },
      i(t) {
        o || (ot(n.$$.fragment, t), (o = !0));
      },
      o(t) {
        rt(n.$$.fragment, t), (o = !1);
      },
      d(t) {
        t && ut(s), at(n);
      },
    }
  );
}
function c(t) {
  function e(e) {
    t[8](e);
  }
  function s(e) {
    t[9](e);
  }
  let n,
    i,
    o,
    c,
    l,
    $,
    d,
    p,
    u,
    f,
    h,
    g = {
      showPrice: !0,
      showDate: !0,
      date: t[3].coordinates.date1,
      index: 1,
      digits: t[1],
    };
  void 0 !== t[3].coordinates.price1 && (g.price = t[3].coordinates.price1),
    (i = new Xt({ props: g })),
    ct.push(() => lt(i, "price", e));
  let m = {
    showPrice: !0,
    showDate: !0,
    date: t[3].coordinates.date2,
    index: 2,
    digits: t[1],
  };
  return (
    void 0 !== t[3].coordinates.price2 && (m.price = t[3].coordinates.price2),
    (l = new Xt({ props: m })),
    ct.push(() => lt(l, "price", s)),
    (p = new wt({
      props: {
        label: window.tr(window.lang.chart.objects.form.gannAngle),
        $$slots: { default: [r] },
        $$scope: { ctx: t },
      },
    })),
    (f = new wt({
      props: {
        label: window.tr(window.lang.chart.objects.form.pipsPerBar),
        $$slots: { default: [a] },
        $$scope: { ctx: t },
      },
    })),
    {
      c() {
        (n = ft("div")),
          nt(i.$$.fragment),
          (c = $t()),
          nt(l.$$.fragment),
          (d = $t()),
          nt(p.$$.fragment),
          (u = $t()),
          nt(f.$$.fragment),
          ht(n, "class", "coordinates svelte-4j6mye");
      },
      m(t, e) {
        dt(t, n, e),
          it(i, n, null),
          gt(n, c),
          it(l, n, null),
          gt(n, d),
          it(p, n, null),
          gt(n, u),
          it(f, n, null),
          (h = !0);
      },
      p(t, e) {
        const s = {};
        8 & e && (s.date = t[3].coordinates.date1),
          2 & e && (s.digits = t[1]),
          !o &&
            8 & e &&
            ((o = !0), (s.price = t[3].coordinates.price1), pt(() => (o = !1))),
          i.$set(s);
        const n = {};
        8 & e && (n.date = t[3].coordinates.date2),
          2 & e && (n.digits = t[1]),
          !$ &&
            8 & e &&
            (($ = !0), (n.price = t[3].coordinates.price2), pt(() => ($ = !1))),
          l.$set(n);
        const r = {};
        32776 & e && (r.$$scope = { dirty: e, ctx: t }), p.$set(r);
        const a = {};
        32776 & e && (a.$$scope = { dirty: e, ctx: t }), f.$set(a);
      },
      i(t) {
        h ||
          (ot(i.$$.fragment, t),
          ot(l.$$.fragment, t),
          ot(p.$$.fragment, t),
          ot(f.$$.fragment, t),
          (h = !0));
      },
      o(t) {
        rt(i.$$.fragment, t),
          rt(l.$$.fragment, t),
          rt(p.$$.fragment, t),
          rt(f.$$.fragment, t),
          (h = !1);
      },
      d(t) {
        t && ut(n), at(i), at(l), at(p), at(f);
      },
    }
  );
}
function l(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [c] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        32778 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function $(t) {
  let e, s;
  return (
    (e = new Gt({ props: { mask: t[3].mask } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        8 & s && (n.mask = t[3].mask), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function d(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [$] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        32776 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function p(t) {
  let e, s, n, i, r, a, c;
  return (
    (s = new Dt({
      props: {
        group: t[2],
        value: "style",
        $$slots: { default: [o] },
        $$scope: { ctx: t },
      },
    })),
    (i = new Dt({
      props: {
        group: t[2],
        value: "coordinates",
        $$slots: { default: [l] },
        $$scope: { ctx: t },
      },
    })),
    (a = new Dt({
      props: {
        group: t[2],
        value: "visualization",
        $$slots: { default: [d] },
        $$scope: { ctx: t },
      },
    })),
    {
      c() {
        (e = ft("div")),
          nt(s.$$.fragment),
          (n = $t()),
          nt(i.$$.fragment),
          (r = $t()),
          nt(a.$$.fragment),
          ht(e, "slot", "content");
      },
      m(t, o) {
        dt(t, e, o),
          it(s, e, null),
          gt(e, n),
          it(i, e, null),
          gt(e, r),
          it(a, e, null),
          (c = !0);
      },
      p(t, e) {
        const n = {};
        4 & e && (n.group = t[2]),
          32776 & e && (n.$$scope = { dirty: e, ctx: t }),
          s.$set(n);
        const o = {};
        4 & e && (o.group = t[2]),
          32778 & e && (o.$$scope = { dirty: e, ctx: t }),
          i.$set(o);
        const r = {};
        4 & e && (r.group = t[2]),
          32776 & e && (r.$$scope = { dirty: e, ctx: t }),
          a.$set(r);
      },
      i(t) {
        c ||
          (ot(s.$$.fragment, t),
          ot(i.$$.fragment, t),
          ot(a.$$.fragment, t),
          (c = !0));
      },
      o(t) {
        rt(s.$$.fragment, t),
          rt(i.$$.fragment, t),
          rt(a.$$.fragment, t),
          (c = !1);
      },
      d(t) {
        t && ut(e), at(s), at(i), at(a);
      },
    }
  );
}
function u(t) {
  let e, s;
  return (
    (e = new Jt({
      props: { $$slots: { content: [p], default: [n] }, $$scope: { ctx: t } },
    })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, [s]) {
        const n = {};
        32782 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function f(t, e, s) {
  let n,
    i = mt,
    o = () => (i(), (i = vt(r, (t) => s(3, (n = t)))), r);
  t.$$.on_destroy.push(() => i());
  let { settings: r } = e;
  o();
  let { digits: a } = e,
    c = "style";
  return (
    (t.$$set = (t) => {
      "settings" in t && o(s(0, (r = t.settings))),
        "digits" in t && s(1, (a = t.digits));
    }),
    [
      r,
      a,
      c,
      n,
      function (e) {
        t.$$.not_equal(n.style.line, e) && ((n.style.line = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.style.line.tips, e) &&
          ((n.style.line.tips = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.style.line.extend, e) &&
          ((n.style.line.extend = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.style.statistics, e) &&
          ((n.style.statistics = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.price1, e) &&
          ((n.coordinates.price1 = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.price2, e) &&
          ((n.coordinates.price2 = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.angle, e) &&
          ((n.coordinates.angle = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.pips, e) &&
          ((n.coordinates.pips = e), r.set(n));
      },
      function (t) {
        (c = t), s(2, c);
      },
      function (t) {
        (c = t), s(2, c);
      },
      function (t) {
        (c = t), s(2, c);
      },
    ]
  );
}
function h(t, e, s) {
  const n = t.slice();
  return (n[12] = e[s]), (n[13] = e), (n[14] = s), n;
}
function g(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.style) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function m(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.coordinates) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function v(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.visualization) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function y(t) {
  function e(e) {
    t[9](e);
  }
  function s(e) {
    t[10](e);
  }
  function n(e) {
    t[11](e);
  }
  let i,
    o,
    r,
    a,
    c,
    l,
    $,
    d,
    p,
    u = { value: "style", $$slots: { default: [g] }, $$scope: { ctx: t } };
  void 0 !== t[2] && (u.group = t[2]),
    (i = new Wt({ props: u })),
    ct.push(() => lt(i, "group", e));
  let f = {
    value: "coordinates",
    $$slots: { default: [m] },
    $$scope: { ctx: t },
  };
  void 0 !== t[2] && (f.group = t[2]),
    (a = new Wt({ props: f })),
    ct.push(() => lt(a, "group", s));
  let h = {
    value: "visualization",
    $$slots: { default: [v] },
    $$scope: { ctx: t },
  };
  return (
    void 0 !== t[2] && (h.group = t[2]),
    ($ = new Wt({ props: h })),
    ct.push(() => lt($, "group", n)),
    {
      c() {
        nt(i.$$.fragment),
          (r = $t()),
          nt(a.$$.fragment),
          (l = $t()),
          nt($.$$.fragment);
      },
      m(t, e) {
        it(i, t, e),
          dt(t, r, e),
          it(a, t, e),
          dt(t, l, e),
          it($, t, e),
          (p = !0);
      },
      p(t, e) {
        const s = {};
        32768 & e && (s.$$scope = { dirty: e, ctx: t }),
          !o && 4 & e && ((o = !0), (s.group = t[2]), pt(() => (o = !1))),
          i.$set(s);
        const n = {};
        32768 & e && (n.$$scope = { dirty: e, ctx: t }),
          !c && 4 & e && ((c = !0), (n.group = t[2]), pt(() => (c = !1))),
          a.$set(n);
        const r = {};
        32768 & e && (r.$$scope = { dirty: e, ctx: t }),
          !d && 4 & e && ((d = !0), (r.group = t[2]), pt(() => (d = !1))),
          $.$set(r);
      },
      i(t) {
        p ||
          (ot(i.$$.fragment, t),
          ot(a.$$.fragment, t),
          ot($.$$.fragment, t),
          (p = !0));
      },
      o(t) {
        rt(i.$$.fragment, t),
          rt(a.$$.fragment, t),
          rt($.$$.fragment, t),
          (p = !1);
      },
      d(t) {
        t && (ut(r), ut(l)), at(i, t), at(a, t), at($, t);
      },
    }
  );
}
function w(t, e) {
  function s(t) {
    e[4](t, e[12], e[13], e[14]);
  }
  let n,
    i,
    o,
    r,
    a = { visible: !1 };
  return (
    void 0 !== e[12] && (a.styles = e[12]),
    (i = new Ft({ props: a })),
    ct.push(() => lt(i, "styles", s)),
    {
      key: t,
      first: null,
      c() {
        (n = Lt()), nt(i.$$.fragment), (this.first = n);
      },
      m(t, e) {
        dt(t, n, e), it(i, t, e), (r = !0);
      },
      p(t, s) {
        e = t;
        const n = {};
        !o && 8 & s && ((o = !0), (n.styles = e[12]), pt(() => (o = !1))),
          i.$set(n);
      },
      i(t) {
        r || (ot(i.$$.fragment, t), (r = !0));
      },
      o(t) {
        rt(i.$$.fragment, t), (r = !1);
      },
      d(t) {
        t && ut(n), at(i, t);
      },
    }
  );
}
function x(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.showLabels) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function b(t) {
  function e(e) {
    t[5](e);
  }
  function s(e) {
    t[6](e);
  }
  let n,
    i,
    o,
    r,
    a,
    c,
    l,
    $ = [],
    d = new Map(),
    p = _t(t[3].style.levels);
  const u = (t) => t[14];
  for (let m = 0; m < p.length; m += 1) {
    let e = h(t, p, m),
      s = u(e);
    d.set(s, ($[m] = w(s, e)));
  }
  let f = {
    visible: !0,
    alpha: !0,
    color: !1,
    label: window.tr(window.lang.chart.objects.form.background),
  };
  void 0 !== t[3].style.background && (f.styles = t[3].style.background),
    (i = new It({ props: f })),
    ct.push(() => lt(i, "styles", e));
  let g = { $$slots: { default: [x] }, $$scope: { ctx: t } };
  return (
    void 0 !== t[3].style.label.visible &&
      (g.checked = t[3].style.label.visible),
    (a = new Pt({ props: g })),
    ct.push(() => lt(a, "checked", s)),
    {
      c() {
        for (let t = 0; t < $.length; t += 1) $[t].c();
        (n = $t()), nt(i.$$.fragment), (r = $t()), nt(a.$$.fragment);
      },
      m(t, e) {
        for (let s = 0; s < $.length; s += 1) $[s] && $[s].m(t, e);
        dt(t, n, e), it(i, t, e), dt(t, r, e), it(a, t, e), (l = !0);
      },
      p(t, e) {
        8 & e &&
          ((p = _t(t[3].style.levels)),
          kt(),
          ($ = Tt($, e, u, 1, t, p, d, n.parentNode, St, w, n, h)),
          jt());
        const s = {};
        !o &&
          8 & e &&
          ((o = !0), (s.styles = t[3].style.background), pt(() => (o = !1))),
          i.$set(s);
        const r = {};
        32768 & e && (r.$$scope = { dirty: e, ctx: t }),
          !c &&
            8 & e &&
            ((c = !0),
            (r.checked = t[3].style.label.visible),
            pt(() => (c = !1))),
          a.$set(r);
      },
      i(t) {
        if (!l) {
          for (let t = 0; t < p.length; t += 1) ot($[t]);
          ot(i.$$.fragment, t), ot(a.$$.fragment, t), (l = !0);
        }
      },
      o(t) {
        for (let e = 0; e < $.length; e += 1) rt($[e]);
        rt(i.$$.fragment, t), rt(a.$$.fragment, t), (l = !1);
      },
      d(t) {
        t && (ut(n), ut(r));
        for (let e = 0; e < $.length; e += 1) $[e].d(t);
        at(i, t), at(a, t);
      },
    }
  );
}
function _(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [b] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        32776 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function P(t) {
  function e(e) {
    t[7](e);
  }
  function s(e) {
    t[8](e);
  }
  let n,
    i,
    o,
    r,
    a,
    c,
    l,
    $ = {
      showPrice: !0,
      showDate: !0,
      date: t[3].coordinates.date1,
      index: 1,
      digits: t[1],
    };
  void 0 !== t[3].coordinates.price1 && ($.price = t[3].coordinates.price1),
    (i = new Xt({ props: $ })),
    ct.push(() => lt(i, "price", e));
  let d = {
    showPrice: !0,
    showDate: !0,
    date: t[3].coordinates.date2,
    index: 2,
    digits: t[1],
  };
  return (
    void 0 !== t[3].coordinates.price2 && (d.price = t[3].coordinates.price2),
    (a = new Xt({ props: d })),
    ct.push(() => lt(a, "price", s)),
    {
      c() {
        (n = ft("div")),
          nt(i.$$.fragment),
          (r = $t()),
          nt(a.$$.fragment),
          ht(n, "class", "coordinates svelte-4j6mye");
      },
      m(t, e) {
        dt(t, n, e), it(i, n, null), gt(n, r), it(a, n, null), (l = !0);
      },
      p(t, e) {
        const s = {};
        8 & e && (s.date = t[3].coordinates.date1),
          2 & e && (s.digits = t[1]),
          !o &&
            8 & e &&
            ((o = !0), (s.price = t[3].coordinates.price1), pt(() => (o = !1))),
          i.$set(s);
        const n = {};
        8 & e && (n.date = t[3].coordinates.date2),
          2 & e && (n.digits = t[1]),
          !c &&
            8 & e &&
            ((c = !0), (n.price = t[3].coordinates.price2), pt(() => (c = !1))),
          a.$set(n);
      },
      i(t) {
        l || (ot(i.$$.fragment, t), ot(a.$$.fragment, t), (l = !0));
      },
      o(t) {
        rt(i.$$.fragment, t), rt(a.$$.fragment, t), (l = !1);
      },
      d(t) {
        t && ut(n), at(i), at(a);
      },
    }
  );
}
function k(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [P] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        32778 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function T(t) {
  let e, s;
  return (
    (e = new Gt({ props: { mask: t[3].mask } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        8 & s && (n.mask = t[3].mask), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function j(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [T] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        32776 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function L(t) {
  let e, s, n, i, o, r, a;
  return (
    (s = new Dt({
      props: {
        group: t[2],
        value: "style",
        $$slots: { default: [_] },
        $$scope: { ctx: t },
      },
    })),
    (i = new Dt({
      props: {
        group: t[2],
        value: "coordinates",
        $$slots: { default: [k] },
        $$scope: { ctx: t },
      },
    })),
    (r = new Dt({
      props: {
        group: t[2],
        value: "visualization",
        $$slots: { default: [j] },
        $$scope: { ctx: t },
      },
    })),
    {
      c() {
        (e = ft("div")),
          nt(s.$$.fragment),
          (n = $t()),
          nt(i.$$.fragment),
          (o = $t()),
          nt(r.$$.fragment),
          ht(e, "slot", "content");
      },
      m(t, c) {
        dt(t, e, c),
          it(s, e, null),
          gt(e, n),
          it(i, e, null),
          gt(e, o),
          it(r, e, null),
          (a = !0);
      },
      p(t, e) {
        const n = {};
        4 & e && (n.group = t[2]),
          32776 & e && (n.$$scope = { dirty: e, ctx: t }),
          s.$set(n);
        const o = {};
        4 & e && (o.group = t[2]),
          32778 & e && (o.$$scope = { dirty: e, ctx: t }),
          i.$set(o);
        const a = {};
        4 & e && (a.group = t[2]),
          32776 & e && (a.$$scope = { dirty: e, ctx: t }),
          r.$set(a);
      },
      i(t) {
        a ||
          (ot(s.$$.fragment, t),
          ot(i.$$.fragment, t),
          ot(r.$$.fragment, t),
          (a = !0));
      },
      o(t) {
        rt(s.$$.fragment, t),
          rt(i.$$.fragment, t),
          rt(r.$$.fragment, t),
          (a = !1);
      },
      d(t) {
        t && ut(e), at(s), at(i), at(r);
      },
    }
  );
}
function S(t) {
  let e, s;
  return (
    (e = new Jt({
      props: { $$slots: { content: [L], default: [y] }, $$scope: { ctx: t } },
    })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, [s]) {
        const n = {};
        32782 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function M(t, e, s) {
  let n,
    i = mt,
    o = () => (i(), (i = vt(r, (t) => s(3, (n = t)))), r);
  t.$$.on_destroy.push(() => i());
  let { settings: r } = e;
  o();
  let { digits: a } = e,
    c = "style";
  return (
    (t.$$set = (t) => {
      "settings" in t && o(s(0, (r = t.settings))),
        "digits" in t && s(1, (a = t.digits));
    }),
    [
      r,
      a,
      c,
      n,
      function (t, e, s, i) {
        (s[i] = t), r.set(n);
      },
      function (e) {
        t.$$.not_equal(n.style.background, e) &&
          ((n.style.background = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.style.label.visible, e) &&
          ((n.style.label.visible = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.price1, e) &&
          ((n.coordinates.price1 = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.price2, e) &&
          ((n.coordinates.price2 = e), r.set(n));
      },
      function (t) {
        (c = t), s(2, c);
      },
      function (t) {
        (c = t), s(2, c);
      },
      function (t) {
        (c = t), s(2, c);
      },
    ]
  );
}
function O(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.style) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function C(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.coordinates) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function D(t) {
  let e,
    s = window.tr(window.lang.chart.objects.form.tabs.visualization) + "";
  return {
    c() {
      e = yt(s);
    },
    m(t, s) {
      dt(t, e, s);
    },
    p: mt,
    d(t) {
      t && ut(e);
    },
  };
}
function z(t) {
  function e(e) {
    t[8](e);
  }
  function s(e) {
    t[9](e);
  }
  function n(e) {
    t[10](e);
  }
  let i,
    o,
    r,
    a,
    c,
    l,
    $,
    d,
    p,
    u = { value: "style", $$slots: { default: [O] }, $$scope: { ctx: t } };
  void 0 !== t[2] && (u.group = t[2]),
    (i = new Wt({ props: u })),
    ct.push(() => lt(i, "group", e));
  let f = {
    value: "coordinates",
    $$slots: { default: [C] },
    $$scope: { ctx: t },
  };
  void 0 !== t[2] && (f.group = t[2]),
    (a = new Wt({ props: f })),
    ct.push(() => lt(a, "group", s));
  let h = {
    value: "visualization",
    $$slots: { default: [D] },
    $$scope: { ctx: t },
  };
  return (
    void 0 !== t[2] && (h.group = t[2]),
    ($ = new Wt({ props: h })),
    ct.push(() => lt($, "group", n)),
    {
      c() {
        nt(i.$$.fragment),
          (r = $t()),
          nt(a.$$.fragment),
          (l = $t()),
          nt($.$$.fragment);
      },
      m(t, e) {
        it(i, t, e),
          dt(t, r, e),
          it(a, t, e),
          dt(t, l, e),
          it($, t, e),
          (p = !0);
      },
      p(t, e) {
        const s = {};
        2048 & e && (s.$$scope = { dirty: e, ctx: t }),
          !o && 4 & e && ((o = !0), (s.group = t[2]), pt(() => (o = !1))),
          i.$set(s);
        const n = {};
        2048 & e && (n.$$scope = { dirty: e, ctx: t }),
          !c && 4 & e && ((c = !0), (n.group = t[2]), pt(() => (c = !1))),
          a.$set(n);
        const r = {};
        2048 & e && (r.$$scope = { dirty: e, ctx: t }),
          !d && 4 & e && ((d = !0), (r.group = t[2]), pt(() => (d = !1))),
          $.$set(r);
      },
      i(t) {
        p ||
          (ot(i.$$.fragment, t),
          ot(a.$$.fragment, t),
          ot($.$$.fragment, t),
          (p = !0));
      },
      o(t) {
        rt(i.$$.fragment, t),
          rt(a.$$.fragment, t),
          rt($.$$.fragment, t),
          (p = !1);
      },
      d(t) {
        t && (ut(r), ut(l)), at(i, t), at(a, t), at($, t);
      },
    }
  );
}
function Y(t) {
  function e(e) {
    t[4](e);
  }
  function s(e) {
    t[5](e);
  }
  let n,
    i,
    o,
    r,
    a,
    c,
    l = { visible: !0 };
  void 0 !== t[3].style.line && (l.styles = t[3].style.line),
    (n = new Yt({ props: l })),
    ct.push(() => lt(n, "styles", e));
  let $ = {
    visible: !0,
    alpha: !0,
    color: !1,
    label: window.tr(window.lang.chart.objects.form.background),
  };
  return (
    void 0 !== t[3].style.background && ($.styles = t[3].style.background),
    (r = new It({ props: $ })),
    ct.push(() => lt(r, "styles", s)),
    {
      c() {
        nt(n.$$.fragment), (o = $t()), nt(r.$$.fragment);
      },
      m(t, e) {
        it(n, t, e), dt(t, o, e), it(r, t, e), (c = !0);
      },
      p(t, e) {
        const s = {};
        !i &&
          8 & e &&
          ((i = !0), (s.styles = t[3].style.line), pt(() => (i = !1))),
          n.$set(s);
        const o = {};
        !a &&
          8 & e &&
          ((a = !0), (o.styles = t[3].style.background), pt(() => (a = !1))),
          r.$set(o);
      },
      i(t) {
        c || (ot(n.$$.fragment, t), ot(r.$$.fragment, t), (c = !0));
      },
      o(t) {
        rt(n.$$.fragment, t), rt(r.$$.fragment, t), (c = !1);
      },
      d(t) {
        t && ut(o), at(n, t), at(r, t);
      },
    }
  );
}
function q(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [Y] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        2056 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function U(t) {
  function e(e) {
    t[7](e);
  }
  let s,
    n,
    i,
    o,
    r = { type: "number", step: 0.01, min: -1e5, max: 1e5 };
  return (
    void 0 !== t[3].coordinates.pips && (r.value = t[3].coordinates.pips),
    (n = new xt({ props: r })),
    ct.push(() => lt(n, "value", e)),
    {
      c() {
        (s = ft("div")), nt(n.$$.fragment), bt(s, "width", "104px");
      },
      m(t, e) {
        dt(t, s, e), it(n, s, null), (o = !0);
      },
      p(t, e) {
        const s = {};
        !i &&
          8 & e &&
          ((i = !0), (s.value = t[3].coordinates.pips), pt(() => (i = !1))),
          n.$set(s);
      },
      i(t) {
        o || (ot(n.$$.fragment, t), (o = !0));
      },
      o(t) {
        rt(n.$$.fragment, t), (o = !1);
      },
      d(t) {
        t && ut(s), at(n);
      },
    }
  );
}
function V(t) {
  function e(e) {
    t[6](e);
  }
  let s,
    n,
    i,
    o,
    r,
    a,
    c,
    l,
    $ = {
      showPrice: !0,
      showDate: !0,
      date: t[3].coordinates.date1,
      index: 1,
      digits: t[1],
    };
  return (
    void 0 !== t[3].coordinates.price1 && ($.price = t[3].coordinates.price1),
    (n = new Xt({ props: $ })),
    ct.push(() => lt(n, "price", e)),
    (r = new Xt({
      props: {
        showDate: !0,
        date: t[3].coordinates.date2,
        index: 2,
        digits: t[1],
      },
    })),
    (c = new wt({
      props: {
        label: window.tr(window.lang.chart.objects.form.pipsPerBar),
        $$slots: { default: [U] },
        $$scope: { ctx: t },
      },
    })),
    {
      c() {
        (s = ft("div")),
          nt(n.$$.fragment),
          (o = $t()),
          nt(r.$$.fragment),
          (a = $t()),
          nt(c.$$.fragment),
          ht(s, "class", "coordinates svelte-4j6mye");
      },
      m(t, e) {
        dt(t, s, e),
          it(n, s, null),
          gt(s, o),
          it(r, s, null),
          gt(s, a),
          it(c, s, null),
          (l = !0);
      },
      p(t, e) {
        const s = {};
        8 & e && (s.date = t[3].coordinates.date1),
          2 & e && (s.digits = t[1]),
          !i &&
            8 & e &&
            ((i = !0), (s.price = t[3].coordinates.price1), pt(() => (i = !1))),
          n.$set(s);
        const o = {};
        8 & e && (o.date = t[3].coordinates.date2),
          2 & e && (o.digits = t[1]),
          r.$set(o);
        const a = {};
        2056 & e && (a.$$scope = { dirty: e, ctx: t }), c.$set(a);
      },
      i(t) {
        l ||
          (ot(n.$$.fragment, t),
          ot(r.$$.fragment, t),
          ot(c.$$.fragment, t),
          (l = !0));
      },
      o(t) {
        rt(n.$$.fragment, t),
          rt(r.$$.fragment, t),
          rt(c.$$.fragment, t),
          (l = !1);
      },
      d(t) {
        t && ut(s), at(n), at(r), at(c);
      },
    }
  );
}
function X(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [V] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        2058 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function G(t) {
  let e, s;
  return (
    (e = new Gt({ props: { mask: t[3].mask } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        8 & s && (n.mask = t[3].mask), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function I(t) {
  let e, s;
  return (
    (e = new zt({ props: { $$slots: { default: [G] }, $$scope: { ctx: t } } })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, s) {
        const n = {};
        2056 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function F(t) {
  let e, s, n, i, o, r, a;
  return (
    (s = new Dt({
      props: {
        group: t[2],
        value: "style",
        $$slots: { default: [q] },
        $$scope: { ctx: t },
      },
    })),
    (i = new Dt({
      props: {
        group: t[2],
        value: "coordinates",
        $$slots: { default: [X] },
        $$scope: { ctx: t },
      },
    })),
    (r = new Dt({
      props: {
        group: t[2],
        value: "visualization",
        $$slots: { default: [I] },
        $$scope: { ctx: t },
      },
    })),
    {
      c() {
        (e = ft("div")),
          nt(s.$$.fragment),
          (n = $t()),
          nt(i.$$.fragment),
          (o = $t()),
          nt(r.$$.fragment),
          ht(e, "slot", "content");
      },
      m(t, c) {
        dt(t, e, c),
          it(s, e, null),
          gt(e, n),
          it(i, e, null),
          gt(e, o),
          it(r, e, null),
          (a = !0);
      },
      p(t, e) {
        const n = {};
        4 & e && (n.group = t[2]),
          2056 & e && (n.$$scope = { dirty: e, ctx: t }),
          s.$set(n);
        const o = {};
        4 & e && (o.group = t[2]),
          2058 & e && (o.$$scope = { dirty: e, ctx: t }),
          i.$set(o);
        const a = {};
        4 & e && (a.group = t[2]),
          2056 & e && (a.$$scope = { dirty: e, ctx: t }),
          r.$set(a);
      },
      i(t) {
        a ||
          (ot(s.$$.fragment, t),
          ot(i.$$.fragment, t),
          ot(r.$$.fragment, t),
          (a = !0));
      },
      o(t) {
        rt(s.$$.fragment, t),
          rt(i.$$.fragment, t),
          rt(r.$$.fragment, t),
          (a = !1);
      },
      d(t) {
        t && ut(e), at(s), at(i), at(r);
      },
    }
  );
}
function A(t) {
  let e, s;
  return (
    (e = new Jt({
      props: { $$slots: { content: [F], default: [z] }, $$scope: { ctx: t } },
    })),
    {
      c() {
        nt(e.$$.fragment);
      },
      m(t, n) {
        it(e, t, n), (s = !0);
      },
      p(t, [s]) {
        const n = {};
        2062 & s && (n.$$scope = { dirty: s, ctx: t }), e.$set(n);
      },
      i(t) {
        s || (ot(e.$$.fragment, t), (s = !0));
      },
      o(t) {
        rt(e.$$.fragment, t), (s = !1);
      },
      d(t) {
        at(e, t);
      },
    }
  );
}
function N(t, e, s) {
  let n,
    i = mt,
    o = () => (i(), (i = vt(r, (t) => s(3, (n = t)))), r);
  t.$$.on_destroy.push(() => i());
  let { settings: r } = e;
  o();
  let { digits: a } = e,
    c = "style";
  return (
    (t.$$set = (t) => {
      "settings" in t && o(s(0, (r = t.settings))),
        "digits" in t && s(1, (a = t.digits));
    }),
    [
      r,
      a,
      c,
      n,
      function (e) {
        t.$$.not_equal(n.style.line, e) && ((n.style.line = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.style.background, e) &&
          ((n.style.background = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.price1, e) &&
          ((n.coordinates.price1 = e), r.set(n));
      },
      function (e) {
        t.$$.not_equal(n.coordinates.pips, e) &&
          ((n.coordinates.pips = e), r.set(n));
      },
      function (t) {
        (c = t), s(2, c);
      },
      function (t) {
        (c = t), s(2, c);
      },
      function (t) {
        (c = t), s(2, c);
      },
    ]
  );
}
var B, H, J, W, E, K, Q, R, Z;
import {
  S as tt,
  i as et,
  s as st,
  c as nt,
  m as it,
  t as ot,
  h as rt,
  l as at,
  T as ct,
  U as lt,
  a as $t,
  d as dt,
  W as pt,
  k as ut,
  e as ft,
  b as ht,
  f as gt,
  o as mt,
  r as vt,
  n as yt,
  F as wt,
  I as xt,
  L as bt,
  p as _t,
  C as Pt,
  g as kt,
  af as Tt,
  j as jt,
  B as Lt,
  ag as St,
  ah as Mt,
  w as Ot,
  v as Ct,
} from "./00a24b22.js";
import {
  C as Dt,
  S as zt,
  d as Yt,
  T as qt,
  E as Ut,
  o as Vt,
  h as Xt,
  V as Gt,
  e as It,
  i as Ft,
  j as At,
  k as Nt,
  l as Bt,
  m as Ht,
} from "./f60bb92f.js";
import {
  T as Jt,
  b as Wt,
  d as Et,
  f as Kt,
  c as Qt,
  p as Rt,
  a as Zt,
  i as te,
  g as ee,
} from "./917f94f7.js";
/* empty css        */ import { d as se, T as ne } from "./6cf66ffe.js";
const ie = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        default: class extends tt {
          constructor(t) {
            super(), et(this, t, f, u, st, { settings: 0, digits: 1 });
          }
        },
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  ),
  oe = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        default: class extends tt {
          constructor(t) {
            super(), et(this, t, M, S, st, { settings: 0, digits: 1 });
          }
        },
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  ),
  re = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        default: class extends tt {
          constructor(t) {
            super(), et(this, t, N, A, st, { settings: 0, digits: 1 });
          }
        },
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  );
(B = Object.defineProperty),
  (H = Object.getOwnPropertyDescriptor),
  (J = (t, e, s, n) => {
    var i,
      o,
      r = n > 1 ? void 0 : n ? H(e, s) : e;
    for (i = t.length - 1; i >= 0; i--)
      (o = t[i]) && (r = (n ? o(e, s, r) : o(r)) || r);
    return n && r && B(e, s, r), r;
  });
const ae = class t extends Ot {
  constructor(e) {
    super(),
      (this.category = t.category),
      (this.type = 6),
      (this.style = {
        levels: [
          { value: 8, color: 10813440, thickness: 1 },
          { value: 4, color: 6684825, thickness: 1 },
          { value: 3, color: 153, thickness: 1 },
          { value: 2, color: 26009, thickness: 1 },
          { value: 1, color: 8421504, thickness: 1 },
          { value: 0.5, color: 39269, thickness: 1 },
          { value: 0.3, color: 39680, thickness: 1 },
          { value: 0.25, color: 6921728, thickness: 1 },
          { value: 0.125, color: 10513152, thickness: 1 },
        ],
        label: { visible: !0 },
        background: { visible: !0, alpha: 0.1 },
      }),
      (this.uid = Ct(16)),
      (this.parent = ""),
      (this.flags = 0),
      (this.visible = !0),
      (this.lock = !1),
      (this.mask = { period: 511, navigator: !0 }),
      (this.coordinates = {
        date1: 0,
        date2: 0,
        price1: 0,
        price2: 0,
        pips: 1,
        down: !1,
      }),
      (this.isObject = !0),
      e && At(this, e);
  }
  setVisible(t) {
    return (this.visible = t), this;
  }
  setCoordinates(t) {
    const { date1: e, date2: s, price1: n, price2: i, pips: o, down: r } = t;
    return (
      "number" == typeof e && (this.coordinates.date1 = e),
      "number" == typeof s && (this.coordinates.date2 = s),
      "number" == typeof n && (this.coordinates.price1 = n),
      "number" == typeof i && (this.coordinates.price2 = i),
      "number" == typeof o && (this.coordinates.pips = o),
      "boolean" == typeof r && (this.coordinates.down = r),
      this
    );
  }
  toJSON() {
    return {
      ...Nt(this),
      coordinates: { ...this.coordinates },
      style:
        Et(
          {
            levels: [
              { value: 8, color: 10813440, thickness: 1 },
              { value: 4, color: 6684825, thickness: 1 },
              { value: 3, color: 153, thickness: 1 },
              { value: 2, color: 26009, thickness: 1 },
              { value: 1, color: 8421504, thickness: 1 },
              { value: 0.5, color: 39269, thickness: 1 },
              { value: 0.3, color: 39680, thickness: 1 },
              { value: 0.25, color: 6921728, thickness: 1 },
              { value: 0.125, color: 10513152, thickness: 1 },
            ],
            label: { visible: !0 },
            background: { visible: !0, alpha: 0.1 },
          },
          this.style
        ) || {},
    };
  }
};
(ae.category = 3),
  J([Mt], ae.prototype, "setVisible", 1),
  J([Mt], ae.prototype, "setCoordinates", 1);
let ce = ae;
const le = Object.freeze(
  Object.defineProperty(
    { __proto__: null, GannFanSettings: ce },
    Symbol.toStringTag,
    { value: "Module" }
  )
);
class $e extends Bt {
  constructor(t, e = 7e3, s) {
    super(t, e, s),
      (this.onLinePointerDown = this.onLinePointerDown.bind(this)),
      (this.onLinePointerMove = this.onLinePointerMove.bind(this)),
      (this.onLinePointerUp = this.onLinePointerUp.bind(this));
  }
  start(t) {
    var e;
    this.draw();
    const { settings: s, state: n } = this,
      i = this.bars.value,
      { x: o, y: r } = this._mouse(t),
      a = i.time(n.xToIndex(o)),
      c = this.yToValue(r);
    return (
      s.setCoordinates({ date1: a, price1: c, date2: a, price2: c }),
      super.start(t),
      (this.active = !0),
      (this.activePoint = 2),
      null == (e = this.stage) ||
        e
          .on("pointermove", this.onLinePointerMove)
          .on("pointerup", this.onLinePointerUp),
      this
    );
  }
  _drawObject(t) {
    const { state: e, settings: s } = this,
      { coordinates: n } = s,
      i = this.bars.value,
      { date1: o, price1: r, date2: a, price2: c } = n;
    if (!(o && a && r && c)) return;
    const l = e.indexToX(i.index(o)),
      $ = e.indexToX(i.index(a)),
      d = this.valueToY(r),
      p = this.valueToY(c);
    this._drawLine(t, l, d, $, p),
      this._drawSelected(t, l, d, $, p),
      t
        .off("pointerdown", this.onLinePointerDown)
        .on("pointerdown", this.onLinePointerDown);
  }
  _drawSelected(t, e, s, n, i) {
    const { hover: o, focused: r, active: a, activePoint: c } = this;
    if (o || r || a) {
      const o = Ht(this);
      o &&
        ((a && 1 === c) || this._drawPoint(t, o, e, s),
        (a && 2 === c) || this._drawPoint(t, o, n, i));
    }
  }
  _calcPrice2(t = 1) {
    const { settings: e } = this,
      { price1: s, price2: n, pips: i } = e.coordinates;
    return s && n && i ? n + (n - s) * (t > 1 ? t : t - 1) : null;
  }
  onLinePointerDown(t) {
    var e, s;
    const { state: n, settings: i } = this,
      { coordinates: o } = i,
      r = this.bars.value,
      { date1: a, price1: c, date2: l, price2: $ } = o;
    if (!(a && l && c && $)) return;
    const d = n.indexToX(r.index(a)),
      p = n.indexToX(r.index(l)),
      u = this.valueToY(c),
      f = this.valueToY($),
      { x: h, y: g } = this._mouse(t);
    Kt(h, g, p, f) < 7
      ? (this.activePoint = 2)
      : Kt(h, g, d, u) < 7 && (this.activePoint = 1),
      null == (e = this.stage) ||
        e
          .off("pointermove", this.onLinePointerMove)
          .off("pointerup", this.onLinePointerUp),
      this.activePoint &&
        ((this._moveStartPoint = { x: h, y: g }),
        (this._moveStartCoordinates = { ...Qt(o), price2: $ }),
        this.draw(),
        this.trigger("focus", { event: t, instance: this, multiselect: !1 }),
        t.doubleClick ||
          null == (s = this.stage) ||
          s
            .on("pointermove", this.onLinePointerMove)
            .on("pointerup", this.onLinePointerUp));
  }
  onLinePointerMove(t) {
    const { activePoint: e } = this;
    if (e) {
      this.active = !0;
      const { settings: s, state: n } = this,
        i = this.bars.value,
        o = this._moveStartCoordinates;
      if (!o) return;
      const r = this._moveStartPoint,
        { x: a, y: c } = this._mouse(t),
        l = a - r.x,
        $ = c - r.y;
      if (1 === e) {
        if (!o.date1 || !o.price1) return;
        let t = n.indexToX(i.index(o.date1)),
          e = this.valueToY(o.price1);
        (t += l),
          (e += $),
          s.setCoordinates({
            date1: i.time(n.xToIndex(t)),
            price1: this.yToValue(e),
          });
      }
      if (2 === e) {
        if (!o.date2 || !o.price2) return;
        let t = n.indexToX(i.index(o.date2)),
          e = this.valueToY(o.price2);
        (t += l),
          (e += $),
          s.setCoordinates({
            date2: i.time(n.xToIndex(t)),
            price2: this.yToValue(e),
          });
      }
      this.draw();
    }
  }
  onLinePointerUp() {
    var t;
    (this.active = !1),
      (this.activePoint = void 0),
      this.draw(),
      null == (t = this.stage) ||
        t
          .off("pointermove", this.onLinePointerMove)
          .off("pointerup", this.onLinePointerUp);
  }
}
const de = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      GannFan: class extends $e {
        _drawLine(t, e, s, n) {
          const { levels: i, background: o, label: r } = this.settings.style;
          let a;
          const c = this._createGraphics("bg");
          (c.interactive = !1),
            (c.mask = this._mask ? this._mask : this._createMask()),
            this.container.addChild(c),
            i.forEach((i) => {
              const { thickness: l, color: $, alpha: d, value: p } = i,
                u = this._calcPrice2(p);
              if (null === u) return;
              const f = this.valueToY(u);
              if (o.visible && o.alpha && a) {
                c.lineStyle(0, 0, 0), c.beginFill($, o.alpha), c.moveTo(e, s);
                const t = Rt(5e3, Zt(e, s, n, f));
                c.lineTo(e + t.x, s + t.y);
                const i = Rt(5e3, Zt(e, s, n, a));
                c.lineTo(e + i.x, s + i.y), c.endFill();
              }
              if (r.visible) {
                const e = this.createText(p.toFixed(2));
                (e.tint = $), (e.x = n + 6), (e.y = f - 20), t.addChild(e);
              }
              const h = Rt(5e3, Zt(e, s, n, f));
              t.lineTo(e + h.x, s + h.y),
                this._drawLineSegment(t, e, s, e + h.x, s + h.y, l, $, d, !0),
                (a = f);
            });
        }
      },
    },
    Symbol.toStringTag,
    { value: "Module" }
  )
);
(W = Object.defineProperty),
  (E = Object.getOwnPropertyDescriptor),
  (K = (t, e, s, n) => {
    var i,
      o,
      r = n > 1 ? void 0 : n ? E(e, s) : e;
    for (i = t.length - 1; i >= 0; i--)
      (o = t[i]) && (r = (n ? o(e, s, r) : o(r)) || r);
    return n && r && W(e, s, r), r;
  });
const pe = class t extends Ot {
  constructor(e) {
    super(),
      (this.category = t.category),
      (this.type = 7),
      (this.style = {
        line: { color: 10813440, thickness: 1, alpha: 1, visible: !0 },
        background: { color: 10813440, alpha: 0.05, visible: !0 },
      }),
      (this.uid = Ct(16)),
      (this.parent = ""),
      (this.flags = 0),
      (this.visible = !0),
      (this.lock = !1),
      (this.mask = { period: 511, navigator: !0 }),
      (this.coordinates = {
        date1: 0,
        date2: 0,
        price1: 0,
        price2: 0,
        pips: 1,
        down: !1,
      }),
      (this.isObject = !0),
      e && At(this, e);
  }
  setVisible(t) {
    return (this.visible = t), this;
  }
  setCoordinates(t) {
    const { date1: e, date2: s, price1: n, price2: i, pips: o, down: r } = t;
    return (
      "number" == typeof e && (this.coordinates.date1 = e),
      "number" == typeof s && (this.coordinates.date2 = s),
      "number" == typeof n && (this.coordinates.price1 = n),
      "number" == typeof i && (this.coordinates.price2 = i),
      "number" == typeof o && (this.coordinates.pips = o),
      "boolean" == typeof r && (this.coordinates.down = r),
      this
    );
  }
  toJSON() {
    return {
      ...Nt(this),
      coordinates: { ...this.coordinates },
      style:
        Et(
          {
            line: { color: 10813440, thickness: 1, alpha: 1, visible: !0 },
            background: { color: 10813440, alpha: 0.05, visible: !0 },
          },
          this.style
        ) || {},
    };
  }
};
(pe.category = 3),
  K([Mt], pe.prototype, "setVisible", 1),
  K([Mt], pe.prototype, "setCoordinates", 1);
let ue = pe;
const fe = Object.freeze(
    Object.defineProperty(
      { __proto__: null, GannGridSettings: ue },
      Symbol.toStringTag,
      { value: "Module" }
    )
  ),
  he = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        GannGrid: class extends $e {
          onLinePointerMove(t) {
            const { activePoint: e } = this;
            if (e) {
              this.active = !0;
              const { settings: s, state: n } = this,
                i = this.bars.value,
                o = this._moveStartCoordinates;
              if (!o) return;
              const r = this._moveStartPoint,
                { x: a, y: c } = this._mouse(t),
                l = a - r.x,
                $ = c - r.y;
              if (!(o.date1 && o.price1 && o.date2 && o.price2)) return;
              let d = n.indexToX(i.index(o.date1)),
                p = this.valueToY(o.price1),
                u = n.indexToX(i.index(o.date2)),
                f = this.valueToY(o.price2);
              1 === e &&
                ((p = Math.max(p + $, f + 10)),
                (d = Math.min(d + l, u - 10)),
                s.setCoordinates({
                  date1: i.time(n.xToIndex(d)),
                  price1: this.yToValue(p),
                })),
                2 === e &&
                  ((f = Math.min(f + $, p - 10)),
                  (u = Math.max(u + l, d + 10)),
                  s.setCoordinates({
                    date2: i.time(n.xToIndex(u)),
                    price2: this.yToValue(f),
                  })),
                this.draw();
            }
          }
          _drawLine(t, e, s, n) {
            let i = n;
            const { state: o, settings: r } = this,
              { line: a, background: c } = r.style,
              { down: l } = r.coordinates,
              $ = this._calcPrice2();
            if (null === $) return;
            let d = this.valueToY($);
            d > s - 10 && (d = s - 10), e > i - 10 && (i = e + 10);
            const p = Zt(e, s, i, d);
            if (
              (this._drawLineSegment(
                t,
                e,
                s,
                i,
                d,
                a.thickness,
                a.color,
                1,
                !0
              ),
              c.visible)
            ) {
              const t = this._createGraphics("bg");
              (t.interactive = !1),
                (t.mask = this._mask ? this._mask : this._createMask()),
                this.container.addChild(t);
              const e = Rt(5e4, -p),
                s = Rt(5e4, p);
              t.lineStyle(0, 0, 0),
                t.beginFill(c.color, c.alpha),
                t.moveTo(i - e.x, d - e.y),
                t.lineTo(i + e.x, d + e.y),
                t.lineTo(i + s.x + e.x, d + s.y + e.y),
                t.lineTo(i + s.x - e.x, d + s.y - e.y),
                t.endFill();
            }
            if (a.visible) {
              const n = Math.max(e, i) - Math.min(e, i);
              let r = Math.max(s, d) - Math.min(s, d);
              if ((l && (r *= -1), Math.abs(n) > 5 && Math.abs(r) > 5)) {
                let e = Rt(5e4, p),
                  s = i,
                  c = d;
                for (; s < o.graphWidth; ) {
                  const i = s + e.x,
                    o = c + e.y;
                  this._drawLineSegment(
                    t,
                    s,
                    c,
                    i,
                    o,
                    a.thickness,
                    a.color,
                    1,
                    !0
                  ),
                    (s += n),
                    (c += r);
                }
                (s = i - n), (c = d - r);
                let $ = !0;
                for (; c > 0 && $; ) {
                  const i = s + e.x,
                    d = c + e.y;
                  this._drawLineSegment(
                    t,
                    s,
                    c,
                    i,
                    d,
                    a.thickness,
                    a.color,
                    1,
                    !0
                  ),
                    (s -= n),
                    (c -= r);
                  const p = l
                    ? te(s, c, i, d, 0, o.graphHeight, 5e4, o.graphHeight)
                    : te(s, c, i, d, 0, 0, 5e4, 0);
                  s < 0 && !p.line2 && ($ = !1);
                }
                for (
                  e = Rt(5e4, -p),
                    s = o.graphWidth,
                    c = d + Math.tan((-p * Math.PI) / 180) * (s - i);
                  (!l && c > 0) || (l && c < o.graphHeight);

                ) {
                  const n = s - e.x,
                    i = c - e.y;
                  this._drawLineSegment(
                    t,
                    s,
                    c,
                    n,
                    i,
                    a.thickness,
                    a.color,
                    1,
                    !0
                  ),
                    (c -= r);
                }
              }
            }
          }
        },
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  );
(Q = Object.defineProperty),
  (R = Object.getOwnPropertyDescriptor),
  (Z = (t, e, s, n) => {
    var i,
      o,
      r = n > 1 ? void 0 : n ? R(e, s) : e;
    for (i = t.length - 1; i >= 0; i--)
      (o = t[i]) && (r = (n ? o(e, s, r) : o(r)) || r);
    return n && r && Q(e, s, r), r;
  });
const ge = class t extends Ot {
  constructor(e) {
    super(),
      (this.category = t.category),
      (this.type = 8),
      (this.uid = Ct(16)),
      (this.parent = ""),
      (this.flags = 0),
      (this.visible = !0),
      (this.lock = !1),
      (this.mask = { period: 511, navigator: !0 }),
      (this.style = se()),
      (this.coordinates = {
        date1: 0,
        date2: 0,
        price1: 0,
        price2: 0,
        angle: 0,
        pips: 0,
      }),
      (this.isObject = !0),
      e && At(this, e);
    const { coordinates: s } = this;
    (s.angle = 0), (s.pips = 1);
    const { style: n } = this;
    n.statistics.angle = !1;
  }
  setVisible(t) {
    return (this.visible = t), this;
  }
  setCoordinates(t) {
    const { date1: e, date2: s, price1: n, price2: i, angle: o, pips: r } = t;
    return (
      "number" == typeof e && (this.coordinates.date1 = e),
      "number" == typeof s && (this.coordinates.date2 = s),
      "number" == typeof n && (this.coordinates.price1 = n),
      "number" == typeof i && (this.coordinates.price2 = i),
      "number" == typeof o && (this.coordinates.angle = o),
      "number" == typeof r && (this.coordinates.pips = r),
      this
    );
  }
  toJSON() {
    return {
      ...Nt(this),
      coordinates: { ...this.coordinates },
      style: Et(se(), this.style) || {},
    };
  }
};
(ge.category = 3),
  Z([Mt], ge.prototype, "setVisible", 1),
  Z([Mt], ge.prototype, "setCoordinates", 1);
let me = ge;
const ve = Object.freeze(
    Object.defineProperty(
      { __proto__: null, GannLineSettings: me },
      Symbol.toStringTag,
      { value: "Module" }
    )
  ),
  ye = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        GannLine: class extends ne {
          constructor(t, e = 7e3, s) {
            super(t, e, s),
              (this.onLinePointerDown = this.onLinePointerDown.bind(this)),
              (this.onLinePointerMove = this.onLinePointerMove.bind(this)),
              (this.onLinePointerUp = this.onLinePointerUp.bind(this));
          }
          start(t) {
            var e;
            this.draw();
            const { settings: s, state: n } = this,
              i = this.bars.value,
              { x: o, y: r } = this._mouse(t),
              a = i.time(n.xToIndex(o)),
              c = this.yToValue(r);
            return (
              s.setCoordinates({ date1: a, price1: c, angle: 0, pips: 1 }),
              super.start(t),
              (this.active = !0),
              (this.activePoint = 2),
              null == (e = this.stage) ||
                e
                  .on("pointermove", this.onLinePointerMove)
                  .on("pointerup", this.onLinePointerUp),
              this
            );
          }
          _drawObject(t) {
            const { state: e, settings: s } = this,
              { coordinates: n, style: i } = s,
              o = this.bars.value,
              { date1: r, price1: a, date2: c } = n,
              l = this.calcPrice2();
            if (!(r && a && c && l)) return;
            const $ = e.indexToX(o.index(r)),
              d = e.indexToX(o.index(c)),
              p = this.valueToY(a),
              u = this.valueToY(l),
              f = Zt($, p, d, u);
            let h = $,
              g = p,
              m = d,
              v = u;
            const { extend: y } = i.line;
            if (y.left || y.right) {
              if (y.left) {
                const t = Rt(5e3, f + 180);
                (h += t.x), (g += t.y);
              }
              if (y.right) {
                const t = Rt(5e3, f);
                (m += t.x), (v += t.y);
              }
            }
            this._drawTrend(t, h, g, m, v);
            const { tips: w } = i.line;
            (w.left || w.right) &&
              (w.left && this._drawTip(t, f, $, p),
              w.right && this._drawTip(t, f + 180, d, u)),
              this._drawStatistics($, p, d, u),
              this._drawSelected(t, $, p, d, u),
              t
                .off("pointerdown", this.onLinePointerDown)
                .on("pointerdown", this.onLinePointerDown);
          }
          _drawSelected(t, e, s, n, i) {
            super._drawSelected(t, e, s, n, i);
            const { hover: o, focused: r, active: a } = this;
            if (o || r || a) {
              const o = Ht(this);
              if (o) {
                const r = ee(e, s, n, i);
                this._drawPoint(t, o, r.x, r.y, 5);
              }
            }
          }
          _drawStatisticsPrice(t, e = 0, s = 0) {
            const { coordinates: n } = this.settings,
              i = n.price2 || this.calcPrice2();
            super._drawStatisticsPrice(t, e, s), i && (n.price2 = i);
          }
          onLinePointerDown(t) {
            var e, s;
            const { state: n, settings: i } = this,
              { coordinates: o } = i,
              r = this.bars.value,
              { date1: a, price1: c, date2: l } = o,
              $ = this.calcPrice2();
            if (!(a && l && c && $)) return;
            const d = n.indexToX(r.index(a)),
              p = this.valueToY(c),
              u = n.indexToX(r.index(l)),
              f = this.valueToY($),
              { x: h, y: g } = this._mouse(t);
            Kt(h, g, u, f) < 7
              ? (this.activePoint = 2)
              : Kt(h, g, d, p) < 7 && (this.activePoint = 1),
              null == (e = this.stage) ||
                e
                  .off("pointermove", this.onLinePointerMove)
                  .off("pointerup", this.onLinePointerUp),
              this.activePoint &&
                ((this._moveStartPoint = { x: h, y: g }),
                (this._moveStartCoordinates = { ...o, price2: $ }),
                this.draw(),
                this.trigger("focus", {
                  event: t,
                  instance: this,
                  multiselect: !1,
                }),
                t.doubleClick ||
                  null == (s = this.stage) ||
                  s
                    .on("pointermove", this.onLinePointerMove)
                    .on("pointerup", this.onLinePointerUp));
          }
          onLinePointerMove(t) {
            const { activePoint: e } = this;
            if (e) {
              this.active = !0;
              const { settings: s, state: n } = this,
                i = this.bars.value,
                o = this._moveStartCoordinates;
              if (!o) return;
              const r = this._moveStartPoint,
                { x: a, y: c } = this._mouse(t),
                l = a - r.x,
                $ = c - r.y;
              if (1 === e) {
                if (!(o.date1 && o.date2 && o.price1 && o.price2)) return;
                let t = n.indexToX(i.index(o.date1)),
                  e = this.valueToY(o.price1);
                if (((t += l), (e += $), i.time(n.xToIndex(t)) < o.date2)) {
                  s.setCoordinates({
                    date1: i.time(n.xToIndex(t)),
                    price1: this.yToValue(e),
                  });
                  const r = this.calcGannAngle.call(this, o.price2);
                  s.setCoordinates({ angle: r });
                }
              } else if (2 === e) {
                if (!o.date1 || !o.date2 || !o.price2) return;
                let t = n.indexToX(i.index(o.date2)),
                  e = this.valueToY(o.price2);
                (t += l), (e += $);
                const r = this.calcGannAngle.call(this, this.yToValue(e));
                i.time(n.xToIndex(t)) > o.date1 &&
                  s.setCoordinates({ date2: i.time(n.xToIndex(t)), angle: r });
              }
              this.draw();
            }
          }
          onLinePointerUp() {
            var t;
            (this.active = !1),
              (this.activePoint = void 0),
              this.draw(),
              null == (t = this.stage) ||
                t
                  .off("pointermove", this.onLinePointerMove)
                  .off("pointerup", this.onLinePointerUp);
          }
          calcGannAngle(t) {
            const { section: e, settings: s } = this,
              { date1: n, price1: i, date2: o, pips: r } = s.coordinates,
              a = this.bars.value;
            if (n && o && i && r) {
              const s = a.index(o) - a.index(n);
              if (s >= 1) {
                let n = ((t - i) * 10 ** e.digits) / s;
                return (n *= 100), (n /= r), n < 0 ? (n -= 0.5) : (n += 0.5), n;
              }
            }
          }
          calcPrice2() {
            const { section: t, settings: e } = this,
              { date1: s, price1: n, date2: i, pips: o } = e.coordinates;
            let { angle: r } = e.coordinates;
            const a = this.bars.value;
            if (r && s && i && n && o) {
              r > 1e5 && (r = 1e5), r < -1e5 && (r = -1e5);
              let e = a.index(i) - a.index(s);
              return (e /= 10 ** t.digits), n + (e * r * o) / 100;
            }
          }
        },
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  );
export {
  oe as a,
  re as b,
  fe as c,
  he as d,
  ve as e,
  ye as f,
  de as r,
  le as s,
  ie as t,
};
