function t(t) {
  return s.serialize([
    { propType: 6, propValue: 5 },
    { propType: 18, propValue: BigInt(t.login ?? 0) },
    {
      propType: 11,
      propValue: (t.password || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (t.otp || "").substring(0, 64),
      propLength: 128,
    },
    {
      propType: 11,
      propValue: (t.otp_secret || "").substring(0, 64),
      propLength: 128,
    },
    {
      propType: 11,
      propValue: (t.otp_secret_check || "").substring(0, 64),
      propLength: 128,
    },
    { propType: 12, propValue: e(), propLength: 16 },
  ]);
}
import {
  aZ as s,
  a_ as e,
  b1 as o,
  b5 as p,
  b2 as r,
  aL as c,
} from "./00a24b22.js";
class n {
  constructor(t) {
    this.socket = t;
  }
}
class a extends n {
  static async connectOtp(s) {
    const e = await o(p, s.server, s.login),
      n = r(e, 1);
    await n.connectToServer();
    try {
      await n.sendCommand(43, t(s)), n.close();
    } catch (a) {
      if (a instanceof c) {
        const { code: t, message: s, command: e } = a;
      }
      throw a;
    }
  }
  async disconnectOtp(s) {
    const e = await o(p, s.server, s.login),
      n = r(e, 1);
    await n.connectToServer();
    try {
      await n.sendCommand(43, t(s)), n.close();
    } catch (a) {
      if (a instanceof c) {
        const { code: t, message: s, command: e } = a;
      }
      throw a;
    }
  }
}
class i {
  constructor(t) {
    (this.disconnect = this.disconnect.bind(this)), (this.otpApi = t);
  }
  static async connect(t) {
    await a.connectOtp({
      server: t.server,
      login: t.login,
      password: t.password,
      otp_secret: t.otp_secret,
      otp_secret_check: t.otp_secret_check,
    });
  }
  async disconnect(t) {
    try {
      return (
        await this.otpApi.disconnectOtp({
          server: t.server,
          login: t.login,
          password: t.password,
          otp: t.otp,
        }),
        !0
      );
    } catch {
      return !1;
    }
  }
}
export { n as A, i as O, a };
