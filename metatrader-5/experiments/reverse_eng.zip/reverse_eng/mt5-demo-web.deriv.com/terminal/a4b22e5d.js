function t(t) {
  var e,
    r,
    i,
    s,
    n = { userAgent: "", platform: "", maxTouchPoints: 0 };
  return (
    t || "undefined" == typeof navigator
      ? "string" == typeof t
        ? (n.userAgent = t)
        : t &&
          t.userAgent &&
          (n = {
            userAgent: t.userAgent,
            platform: t.platform,
            maxTouchPoints: t.maxTouchPoints || 0,
          })
      : (n = {
          userAgent: navigator.userAgent,
          platform: navigator.platform,
          maxTouchPoints: navigator.maxTouchPoints || 0,
        }),
    void 0 !== (r = (e = n.userAgent).split("[FBAN"))[1] && (e = r[0]),
    void 0 !== (r = e.split("Twitter"))[1] && (e = r[0]),
    (i = (function (t) {
      return function (e) {
        return e.test(t);
      };
    })(e)),
    ((s = {
      apple: {
        phone: i(Yt) && !i(re),
        ipod: i(qt),
        tablet: !i(Yt) && (i(Kt) || le(n)) && !i(re),
        universal: i(Zt),
        device: (i(Yt) || i(qt) || i(Kt) || i(Zt) || le(n)) && !i(re),
      },
      amazon: { phone: i(te), tablet: !i(te) && i(ee), device: i(te) || i(ee) },
      android: {
        phone: (!i(re) && i(te)) || (!i(re) && i(Qt)),
        tablet: !i(re) && !i(te) && !i(Qt) && (i(ee) || i(Jt)),
        device:
          (!i(re) && (i(te) || i(ee) || i(Qt) || i(Jt))) || i(/\bokhttp\b/i),
      },
      windows: { phone: i(re), tablet: i(ie), device: i(re) || i(ie) },
      other: {
        blackberry: i(se),
        blackberry10: i(ne),
        opera: i(oe),
        firefox: i(he),
        chrome: i(ae),
        device: i(se) || i(ne) || i(oe) || i(he) || i(ae),
      },
      any: !1,
      phone: !1,
      tablet: !1,
    }).any =
      s.apple.device || s.android.device || s.windows.device || s.other.device),
    (s.phone = s.apple.phone || s.android.phone || s.windows.phone),
    (s.tablet = s.apple.tablet || s.android.tablet || s.windows.tablet),
    s
  );
}
function e(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default")
    ? t.default
    : t;
}
function r(t) {
  var e, r;
  return t.__esModule
    ? t
    : ("function" == typeof (e = t.default)
        ? ((r = function t() {
            return this instanceof t
              ? Reflect.construct(e, arguments, this.constructor)
              : e.apply(this, arguments);
          }),
          (r.prototype = e.prototype))
        : (r = {}),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.keys(t).forEach(function (e) {
        var i = Object.getOwnPropertyDescriptor(t, e);
        Object.defineProperty(
          r,
          e,
          i.get
            ? i
            : {
                enumerable: !0,
                get: function () {
                  return t[e];
                },
              }
        );
      }),
      r);
}
function i(t, e, r) {
  var i, n, a, h, l, u, p, f, g, _, y, v;
  if (
    ((r = r || 2),
    (h = []),
    !(a = s(t, 0, (n = (i = e && e.length) ? e[0] * r : t.length), r, !0)) ||
      a.next === a.prev)
  )
    return h;
  if (
    (i &&
      (a = (function (t, e, r, i) {
        var n,
          o,
          a,
          h = [];
        for (n = 0, o = e.length; n < o; n++)
          (a = s(t, e[n] * i, n < o - 1 ? e[n + 1] * i : t.length, i, !1)) ===
            a.next && (a.steiner = !0),
            h.push(m(a));
        for (h.sort(c), n = 0; n < h.length; n++) r = d(h[n], r);
        return r;
      })(t, e, a, r)),
    t.length > 80 * r)
  ) {
    for (l = p = t[0], u = f = t[1], v = r; v < n; v += r)
      (g = t[v]) < l && (l = g),
        (_ = t[v + 1]) < u && (u = _),
        g > p && (p = g),
        _ > f && (f = _);
    y = 0 !== (y = Math.max(p - l, f - u)) ? 32767 / y : 0;
  }
  return o(a, h, r, l, u, y, 0), h;
}
function s(t, e, r, i, s) {
  var n, o;
  if (s === I(t, e, r, i) > 0)
    for (n = e; n < r; n += i) o = w(n, t[n], t[n + 1], o);
  else for (n = r - i; n >= e; n -= i) o = w(n, t[n], t[n + 1], o);
  return o && v(o, o.next) && (S(o), (o = o.next)), o;
}
function n(t, e) {
  if (!t) return t;
  e || (e = t);
  var r,
    i = t;
  do {
    if (((r = !1), i.steiner || (!v(i, i.next) && 0 !== y(i.prev, i, i.next))))
      i = i.next;
    else {
      if ((S(i), (i = e = i.prev) === i.next)) break;
      r = !0;
    }
  } while (r || i !== e);
  return e;
}
function o(t, e, r, i, s, c, d) {
  if (t) {
    !d &&
      c &&
      (function (t, e, r, i) {
        var s = t;
        do {
          0 === s.z && (s.z = f(s.x, s.y, e, r, i)),
            (s.prevZ = s.prev),
            (s.nextZ = s.next),
            (s = s.next);
        } while (s !== t);
        (s.prevZ.nextZ = null),
          (s.prevZ = null),
          (function (t) {
            var e,
              r,
              i,
              s,
              n,
              o,
              a,
              h,
              l = 1;
            do {
              for (r = t, t = null, n = null, o = 0; r; ) {
                for (
                  o++, i = r, a = 0, e = 0;
                  e < l && (a++, (i = i.nextZ));
                  e++
                );
                for (h = l; a > 0 || (h > 0 && i); )
                  0 !== a && (0 === h || !i || r.z <= i.z)
                    ? ((s = r), (r = r.nextZ), a--)
                    : ((s = i), (i = i.nextZ), h--),
                    n ? (n.nextZ = s) : (t = s),
                    (s.prevZ = n),
                    (n = s);
                r = i;
              }
              (n.nextZ = null), (l *= 2);
            } while (o > 1);
          })(s);
      })(t, i, s, c);
    for (var p, m, g = t; t.prev !== t.next; )
      if (((p = t.prev), (m = t.next), c ? h(t, i, s, c) : a(t)))
        e.push((p.i / r) | 0),
          e.push((t.i / r) | 0),
          e.push((m.i / r) | 0),
          S(t),
          (t = m.next),
          (g = m.next);
      else if ((t = m) === g) {
        d
          ? 1 === d
            ? o((t = l(n(t), e, r)), e, r, i, s, c, 2)
            : 2 === d && u(t, e, r, i, s, c)
          : o(n(t), e, r, i, s, c, 1);
        break;
      }
  }
}
function a(t) {
  var e,
    r,
    i,
    s,
    n,
    o,
    a,
    h,
    l,
    u,
    c,
    d = t.prev,
    p = t,
    f = t.next;
  if (y(d, p, f) >= 0) return !1;
  for (
    e = d.x,
      r = p.x,
      i = f.x,
      s = d.y,
      n = p.y,
      o = f.y,
      a = e < r ? (e < i ? e : i) : r < i ? r : i,
      h = s < n ? (s < o ? s : o) : n < o ? n : o,
      l = e > r ? (e > i ? e : i) : r > i ? r : i,
      u = s > n ? (s > o ? s : o) : n > o ? n : o,
      c = f.next;
    c !== d;

  ) {
    if (
      c.x >= a &&
      c.x <= l &&
      c.y >= h &&
      c.y <= u &&
      g(e, s, r, n, i, o, c.x, c.y) &&
      y(c.prev, c, c.next) >= 0
    )
      return !1;
    c = c.next;
  }
  return !0;
}
function h(t, e, r, i) {
  var s,
    n,
    o,
    a,
    h,
    l,
    u,
    c,
    d,
    p,
    m,
    _,
    v,
    x,
    b = t.prev,
    E = t,
    T = t.next;
  if (y(b, E, T) >= 0) return !1;
  for (
    s = b.x,
      n = E.x,
      o = T.x,
      a = b.y,
      h = E.y,
      l = T.y,
      d = s > n ? (s > o ? s : o) : n > o ? n : o,
      p = a > h ? (a > l ? a : l) : h > l ? h : l,
      m = f(
        (u = s < n ? (s < o ? s : o) : n < o ? n : o),
        (c = a < h ? (a < l ? a : l) : h < l ? h : l),
        e,
        r,
        i
      ),
      _ = f(d, p, e, r, i),
      v = t.prevZ,
      x = t.nextZ;
    v && v.z >= m && x && x.z <= _;

  ) {
    if (
      v.x >= u &&
      v.x <= d &&
      v.y >= c &&
      v.y <= p &&
      v !== b &&
      v !== T &&
      g(s, a, n, h, o, l, v.x, v.y) &&
      y(v.prev, v, v.next) >= 0
    )
      return !1;
    if (
      ((v = v.prevZ),
      x.x >= u &&
        x.x <= d &&
        x.y >= c &&
        x.y <= p &&
        x !== b &&
        x !== T &&
        g(s, a, n, h, o, l, x.x, x.y) &&
        y(x.prev, x, x.next) >= 0)
    )
      return !1;
    x = x.nextZ;
  }
  for (; v && v.z >= m; ) {
    if (
      v.x >= u &&
      v.x <= d &&
      v.y >= c &&
      v.y <= p &&
      v !== b &&
      v !== T &&
      g(s, a, n, h, o, l, v.x, v.y) &&
      y(v.prev, v, v.next) >= 0
    )
      return !1;
    v = v.prevZ;
  }
  for (; x && x.z <= _; ) {
    if (
      x.x >= u &&
      x.x <= d &&
      x.y >= c &&
      x.y <= p &&
      x !== b &&
      x !== T &&
      g(s, a, n, h, o, l, x.x, x.y) &&
      y(x.prev, x, x.next) >= 0
    )
      return !1;
    x = x.nextZ;
  }
  return !0;
}
function l(t, e, r) {
  var i,
    s,
    o = t;
  do {
    !v((i = o.prev), (s = o.next.next)) &&
      x(i, o, o.next, s) &&
      T(i, s) &&
      T(s, i) &&
      (e.push((i.i / r) | 0),
      e.push((o.i / r) | 0),
      e.push((s.i / r) | 0),
      S(o),
      S(o.next),
      (o = t = s)),
      (o = o.next);
  } while (o !== t);
  return n(o);
}
function u(t, e, r, i, s, a) {
  var h,
    l,
    u = t;
  do {
    for (h = u.next.next; h !== u.prev; ) {
      if (u.i !== h.i && _(u, h))
        return (
          (l = A(u, h)),
          (u = n(u, u.next)),
          (l = n(l, l.next)),
          o(u, e, r, i, s, a, 0),
          void o(l, e, r, i, s, a, 0)
        );
      h = h.next;
    }
    u = u.next;
  } while (u !== t);
}
function c(t, e) {
  return t.x - e.x;
}
function d(t, e) {
  var r,
    i = (function (t, e) {
      var r,
        i,
        s,
        n,
        o,
        a,
        h,
        l = e,
        u = t.x,
        c = t.y,
        d = -1 / 0;
      do {
        if (
          c <= l.y &&
          c >= l.next.y &&
          l.next.y !== l.y &&
          (i = l.x + ((c - l.y) * (l.next.x - l.x)) / (l.next.y - l.y)) <= u &&
          i > d &&
          ((d = i), (r = l.x < l.next.x ? l : l.next), i === u)
        )
          return r;
        l = l.next;
      } while (l !== e);
      if (!r) return null;
      (s = r), (n = r.x), (o = r.y), (a = 1 / 0), (l = r);
      do {
        u >= l.x &&
          l.x >= n &&
          u !== l.x &&
          g(c < o ? u : d, c, n, o, c < o ? d : u, c, l.x, l.y) &&
          ((h = Math.abs(c - l.y) / (u - l.x)),
          T(l, t) &&
            (h < a || (h === a && (l.x > r.x || (l.x === r.x && p(r, l))))) &&
            ((r = l), (a = h))),
          (l = l.next);
      } while (l !== s);
      return r;
    })(t, e);
  return i ? (n((r = A(i, t)), r.next), n(i, i.next)) : e;
}
function p(t, e) {
  return y(t.prev, t, e.prev) < 0 && y(e.next, t, t.next) < 0;
}
function f(t, e, r, i, s) {
  return (
    (t =
      1431655765 &
      ((t =
        858993459 &
        ((t =
          252645135 &
          ((t = 16711935 & ((t = ((t - r) * s) | 0) | (t << 8))) | (t << 4))) |
          (t << 2))) |
        (t << 1))) |
    ((e =
      1431655765 &
      ((e =
        858993459 &
        ((e =
          252645135 &
          ((e = 16711935 & ((e = ((e - i) * s) | 0) | (e << 8))) | (e << 4))) |
          (e << 2))) |
        (e << 1))) <<
      1)
  );
}
function m(t) {
  var e = t,
    r = t;
  do {
    (e.x < r.x || (e.x === r.x && e.y < r.y)) && (r = e), (e = e.next);
  } while (e !== t);
  return r;
}
function g(t, e, r, i, s, n, o, a) {
  return (
    (s - o) * (e - a) >= (t - o) * (n - a) &&
    (t - o) * (i - a) >= (r - o) * (e - a) &&
    (r - o) * (n - a) >= (s - o) * (i - a)
  );
}
function _(t, e) {
  return (
    t.next.i !== e.i &&
    t.prev.i !== e.i &&
    !(function (t, e) {
      var r = t;
      do {
        if (
          r.i !== t.i &&
          r.next.i !== t.i &&
          r.i !== e.i &&
          r.next.i !== e.i &&
          x(r, r.next, t, e)
        )
          return !0;
        r = r.next;
      } while (r !== t);
      return !1;
    })(t, e) &&
    ((T(t, e) &&
      T(e, t) &&
      (function (t, e) {
        var r = t,
          i = !1,
          s = (t.x + e.x) / 2,
          n = (t.y + e.y) / 2;
        do {
          r.y > n != r.next.y > n &&
            r.next.y !== r.y &&
            s < ((r.next.x - r.x) * (n - r.y)) / (r.next.y - r.y) + r.x &&
            (i = !i),
            (r = r.next);
        } while (r !== t);
        return i;
      })(t, e) &&
      (y(t.prev, t, e.prev) || y(t, e.prev, e))) ||
      (v(t, e) && y(t.prev, t, t.next) > 0 && y(e.prev, e, e.next) > 0))
  );
}
function y(t, e, r) {
  return (e.y - t.y) * (r.x - e.x) - (e.x - t.x) * (r.y - e.y);
}
function v(t, e) {
  return t.x === e.x && t.y === e.y;
}
function x(t, e, r, i) {
  var s = E(y(t, e, r)),
    n = E(y(t, e, i)),
    o = E(y(r, i, t)),
    a = E(y(r, i, e));
  return (
    (s !== n && o !== a) ||
    !(0 !== s || !b(t, r, e)) ||
    !(0 !== n || !b(t, i, e)) ||
    !(0 !== o || !b(r, t, i)) ||
    !(0 !== a || !b(r, e, i))
  );
}
function b(t, e, r) {
  return (
    e.x <= Math.max(t.x, r.x) &&
    e.x >= Math.min(t.x, r.x) &&
    e.y <= Math.max(t.y, r.y) &&
    e.y >= Math.min(t.y, r.y)
  );
}
function E(t) {
  return t > 0 ? 1 : t < 0 ? -1 : 0;
}
function T(t, e) {
  return y(t.prev, t, t.next) < 0
    ? y(t, e, t.next) >= 0 && y(t, t.prev, e) >= 0
    : y(t, e, t.prev) < 0 || y(t, t.next, e) < 0;
}
function A(t, e) {
  var r = new R(t.i, t.x, t.y),
    i = new R(e.i, e.x, e.y),
    s = t.next,
    n = e.prev;
  return (
    (t.next = e),
    (e.prev = t),
    (r.next = s),
    (s.prev = r),
    (i.next = r),
    (r.prev = i),
    (n.next = i),
    (i.prev = n),
    i
  );
}
function w(t, e, r, i) {
  var s = new R(t, e, r);
  return (
    i
      ? ((s.next = i.next), (s.prev = i), (i.next.prev = s), (i.next = s))
      : ((s.prev = s), (s.next = s)),
    s
  );
}
function S(t) {
  (t.next.prev = t.prev),
    (t.prev.next = t.next),
    t.prevZ && (t.prevZ.nextZ = t.nextZ),
    t.nextZ && (t.nextZ.prevZ = t.prevZ);
}
function R(t, e, r) {
  (this.i = t),
    (this.x = e),
    (this.y = r),
    (this.prev = null),
    (this.next = null),
    (this.z = 0),
    (this.prevZ = null),
    (this.nextZ = null),
    (this.steiner = !1);
}
function I(t, e, r, i) {
  var s,
    n,
    o = 0;
  for (s = e, n = r - i; s < r; s += i)
    (o += (t[n] - t[s]) * (t[s + 1] + t[n + 1])), (n = s);
  return o;
}
function C(t, e) {
  var r, i, s, n;
  return t === 1 / 0 ||
    t === -1 / 0 ||
    t != t ||
    (t && t > -1e3 && t < 1e3) ||
    Br.call(/e/, e)
    ? e
    : ((r = /[0-9](?=(?:[0-9]{3})+(?![0-9]))/g),
      "number" == typeof t && (i = t < 0 ? -kr(-t) : kr(t)) !== t
        ? ((s = String(i)),
          (n = Pr.call(e, s.length + 1)),
          Mr.call(s, r, "$&_") +
            "." +
            Mr.call(Mr.call(n, /([0-9]{3})/g, "$&_"), /_$/, ""))
        : Mr.call(e, r, "$&_"));
}
function P(t, e, r) {
  var i = "double" === (r.quoteStyle || e) ? '"' : "'";
  return i + t + i;
}
function M(t) {
  return Mr.call(String(t), /"/g, "&quot;");
}
function D(t) {
  return !(
    "[object Array]" !== F(t) ||
    (Xr && "object" == typeof t && Xr in t)
  );
}
function O(t) {
  return !(
    "[object RegExp]" !== F(t) ||
    (Xr && "object" == typeof t && Xr in t)
  );
}
function B(t) {
  if (jr) return t && "object" == typeof t && t instanceof Symbol;
  if ("symbol" == typeof t) return !0;
  if (!t || "object" != typeof t || !Hr) return !1;
  try {
    return Hr.call(t), !0;
  } catch (e) {}
  return !1;
}
function N(t, e) {
  return Kr.call(t, e);
}
function F(t) {
  return Rr.call(t);
}
function L(t, e) {
  if (t.indexOf) return t.indexOf(e);
  for (var r = 0, i = t.length; r < i; r++) if (t[r] === e) return r;
  return -1;
}
function k(t, e) {
  var r, i;
  return t.length > e.maxStringLength
    ? ((i =
        "... " +
        (r = t.length - e.maxStringLength) +
        " more character" +
        (r > 1 ? "s" : "")),
      k(Pr.call(t, 0, e.maxStringLength), e) + i)
    : P(
        Mr.call(Mr.call(t, /(['\\])/g, "\\$1"), /[\x00-\x1f]/g, U),
        "single",
        e
      );
}
function U(t) {
  var e = t.charCodeAt(0),
    r = { 8: "b", 9: "t", 10: "n", 12: "f", 13: "r" }[e];
  return r ? "\\" + r : "\\x" + (e < 16 ? "0" : "") + Dr.call(e.toString(16));
}
function G(t) {
  return "Object(" + t + ")";
}
function H(t) {
  return t + " { ? }";
}
function j(t, e, r, i) {
  return t + " (" + e + ") {" + (i ? X(r, i) : Fr.call(r, ", ")) + "}";
}
function X(t, e) {
  if (0 === t.length) return "";
  var r = "\n" + e.prev + e.base;
  return r + Fr.call(t, "," + r) + "\n" + e.prev;
}
function V(t, e) {
  var r,
    i,
    s,
    n,
    o,
    a,
    h = D(t),
    l = [];
  if (h)
    for (l.length = t.length, r = 0; r < t.length; r++)
      l[r] = N(t, r) ? e(t[r], t) : "";
  if (((i = "function" == typeof Gr ? Gr(t) : []), jr))
    for (s = {}, n = 0; n < i.length; n++) s["$" + i[n]] = i[n];
  for (o in t)
    N(t, o) &&
      ((h && String(Number(o)) === o && o < t.length) ||
        (jr && s["$" + o] instanceof Symbol) ||
        (Br.call(/[^\w$]/, o)
          ? l.push(e(o, t) + ": " + e(t[o], t))
          : l.push(o + ": " + e(t[o], t))));
  if ("function" == typeof Gr)
    for (a = 0; a < i.length; a++)
      Vr.call(t, i[a]) && l.push("[" + e(i[a]) + "]: " + e(t[i[a]], t));
  return l;
}
function z() {
  (this.protocol = null),
    (this.slashes = null),
    (this.auth = null),
    (this.host = null),
    (this.port = null),
    (this.hostname = null),
    (this.hash = null),
    (this.search = null),
    (this.query = null),
    (this.pathname = null),
    (this.path = null),
    (this.href = null);
}
function W(t, e, r = 3) {
  if (En[e]) return;
  let i = new Error().stack;
  typeof i > "u" ||
    ((i = i.split("\n").splice(r).join("\n")), console.groupCollapsed),
    (En[e] = !0);
}
function $(t) {
  if ("string" != typeof t)
    throw new TypeError(`Path must be a string. Received ${JSON.stringify(t)}`);
}
function Y(t) {
  return t.split("?")[0].split("#")[0];
}
async function q() {
  return (
    An ??
      (An = (async () => {
        var t;
        const e = document.createElement("canvas").getContext("webgl");
        if (!e) return un.UNPACK;
        const r = await new Promise((t) => {
          const e = document.createElement("video");
          (e.onloadeddata = () => t(e)),
            (e.onerror = () => t(null)),
            (e.autoplay = !1),
            (e.crossOrigin = "anonymous"),
            (e.preload = "auto"),
            (e.src =
              "data:video/webm;base64,GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQJChYECGFOAZwEAAAAAAAHTEU2bdLpNu4tTq4QVSalmU6yBoU27i1OrhBZUrmtTrIHGTbuMU6uEElTDZ1OsggEXTbuMU6uEHFO7a1OsggG97AEAAAAAAABZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmoCrXsYMPQkBNgIRMYXZmV0GETGF2ZkSJiEBEAAAAAAAAFlSua8yuAQAAAAAAAEPXgQFzxYgAAAAAAAAAAZyBACK1nIN1bmSIgQCGhVZfVlA5g4EBI+ODhAJiWgDglLCBArqBApqBAlPAgQFVsIRVuYEBElTDZ9Vzc9JjwItjxYgAAAAAAAAAAWfInEWjh0VOQ09ERVJEh49MYXZjIGxpYnZweC12cDlnyKJFo4hEVVJBVElPTkSHlDAwOjAwOjAwLjA0MDAwMDAwMAAAH0O2dcfngQCgwqGggQAAAIJJg0IAABAAFgA4JBwYSgAAICAAEb///4r+AAB1oZ2mm+6BAaWWgkmDQgAAEAAWADgkHBhKAAAgIABIQBxTu2uRu4+zgQC3iveBAfGCAXHwgQM="),
            e.load();
        });
        if (!r) return un.UNPACK;
        const i = e.createTexture();
        e.bindTexture(e.TEXTURE_2D, i);
        const s = e.createFramebuffer();
        e.bindFramebuffer(e.FRAMEBUFFER, s),
          e.framebufferTexture2D(
            e.FRAMEBUFFER,
            e.COLOR_ATTACHMENT0,
            e.TEXTURE_2D,
            i,
            0
          ),
          e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1),
          e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, e.NONE),
          e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, r);
        const n = new Uint8Array(4);
        return (
          e.readPixels(0, 0, 1, 1, e.RGBA, e.UNSIGNED_BYTE, n),
          e.deleteFramebuffer(s),
          e.deleteTexture(i),
          null == (t = e.getExtension("WEBGL_lose_context")) || t.loseContext(),
          n[0] <= n[3] ? un.PMA : un.UNPACK
        );
      })()),
    An
  );
}
function K(t, e) {
  return In[e ? 1 : 0][t];
}
function Z(t) {
  if (4 === t.BYTES_PER_ELEMENT)
    return t instanceof Float32Array
      ? "Float32Array"
      : t instanceof Uint32Array
      ? "Uint32Array"
      : "Int32Array";
  if (2 === t.BYTES_PER_ELEMENT) {
    if (t instanceof Uint16Array) return "Uint16Array";
  } else if (1 === t.BYTES_PER_ELEMENT && t instanceof Uint8Array)
    return "Uint8Array";
  return null;
}
function Q(t) {
  return (
    (t += 0 === t ? 1 : 0),
    --t,
    (t |= t >>> 1),
    (t |= t >>> 2),
    (t |= t >>> 4),
    1 + ((t |= t >>> 8) | (t >>> 16))
  );
}
function J(t) {
  return !(t & (t - 1) || !t);
}
function tt(t) {
  let e = (t > 65535 ? 1 : 0) << 4,
    r = ((t >>>= e) > 255 ? 1 : 0) << 3;
  return (
    (e |= r),
    (r = ((t >>>= r) > 15 ? 1 : 0) << 2),
    (e |= r),
    (r = ((t >>>= r) > 3 ? 1 : 0) << 1),
    (e |= r),
    e | ((t >>>= r) >> 1)
  );
}
function et(t, e, r) {
  const i = t.length;
  let s;
  if (e >= i || 0 === r) return;
  const n = i - (r = e + r > i ? i - e : r);
  for (s = e; s < n; ++s) t[s] = t[s + r];
  t.length = n;
}
function rt(t) {
  return 0 === t ? 0 : t < 0 ? -1 : 1;
}
function it() {
  return ++Cn;
}
function st(t, e, r) {
  for (let i = 0, s = 4 * r * e; i < e; ++i, s += 4)
    if (0 !== t[s + 3]) return !1;
  return !0;
}
function nt(t, e, r, i, s) {
  const n = 4 * e;
  for (let o = i, a = i * n + 4 * r; o <= s; ++o, a += n)
    if (0 !== t[a + 3]) return !1;
  return !0;
}
function ot(t, e = 1) {
  var r;
  const i = null == (r = _n.RETINA_PREFIX) ? void 0 : r.exec(t);
  return i ? parseFloat(i[1]) : e;
}
function at(t) {
  let e = "";
  for (let r = 0; r < t; ++r)
    r > 0 && (e += "\nelse "), r < t - 1 && (e += `if(test == ${r}.0){}`);
  return e;
}
function ht(t, e) {
  if (!t) return null;
  let r = "";
  if ("string" == typeof t) {
    const e = /\.(\w{3,4})(?:$|\?|#)/i.exec(t);
    e && (r = e[1].toLowerCase());
  }
  for (let i = jn.length - 1; i >= 0; --i) {
    const s = jn[i];
    if (s.test && s.test(t, r)) return new s(t, e);
  }
  throw new Error("Unrecognized source type to auto-detect Resource");
}
function lt(t, e, r) {
  const i = t.createShader(e);
  return t.shaderSource(i, r), t.compileShader(i), i;
}
function ut(t) {
  const e = new Array(t);
  for (let r = 0; r < e.length; r++) e[r] = !1;
  return e;
}
function ct(t, e) {
  switch (t) {
    case "float":
    case "int":
    case "uint":
    case "sampler2D":
    case "sampler2DArray":
      return 0;
    case "vec2":
      return new Float32Array(2 * e);
    case "vec3":
      return new Float32Array(3 * e);
    case "vec4":
      return new Float32Array(4 * e);
    case "ivec2":
      return new Int32Array(2 * e);
    case "ivec3":
      return new Int32Array(3 * e);
    case "ivec4":
      return new Int32Array(4 * e);
    case "uvec2":
      return new Uint32Array(2 * e);
    case "uvec3":
      return new Uint32Array(3 * e);
    case "uvec4":
      return new Uint32Array(4 * e);
    case "bool":
      return !1;
    case "bvec2":
      return ut(2 * e);
    case "bvec3":
      return ut(3 * e);
    case "bvec4":
      return ut(4 * e);
    case "mat2":
      return new Float32Array([1, 0, 0, 1]);
    case "mat3":
      return new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
    case "mat4":
      return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  }
  return null;
}
function dt(t, e) {
  const r = t
      .getShaderSource(e)
      .split("\n")
      .map((t, e) => `${e}: ${t}`),
    i = t.getShaderInfoLog(e).split("\n"),
    s = {},
    n = i
      .map((t) => parseFloat(t.replace(/^ERROR\: 0\:([\d]+)\:.*$/, "$1")))
      .filter((t) => !(!t || s[t] || ((s[t] = !0), 0))),
    o = [""];
  n.forEach((t) => {
    (r[t - 1] = `%c${r[t - 1]}%c`),
      o.push(
        "background: #FF0000; color:#FFFFFF; font-size: 10px",
        "font-size: 10px"
      );
  });
  const a = r.join("\n");
  o[0] = a;
}
function pt(t) {
  return Bo[t];
}
function ft(t, e) {
  if (!No) {
    const e = Object.keys(Fo);
    No = {};
    for (let r = 0; r < e.length; ++r) {
      const i = e[r];
      No[t[i]] = Fo[i];
    }
  }
  return No[e];
}
function mt(t, e, r) {
  if ("precision" !== t.substring(0, 9)) {
    let i = e;
    return (
      e === pn.HIGH && r !== pn.HIGH && (i = pn.MEDIUM),
      `precision ${i} float;\n${t}`
    );
  }
  return r !== pn.HIGH && "precision highp" === t.substring(0, 15)
    ? t.replace("precision highp", "precision mediump")
    : t;
}
function gt(t) {
  (t.destroy = function () {}),
    (t.on = function () {}),
    (t.once = function () {}),
    (t.emit = function () {});
}
function _t(t, e, r, i, s) {
  r.buffer.update(s);
}
function yt(t, e) {
  return t.zIndex === e.zIndex
    ? t._lastSortedIndex - e._lastSortedIndex
    : t.zIndex - e.zIndex;
}
function vt(t) {
  return "dynamic" === t || "static" === t;
}
function xt(t, e) {
  if (Array.isArray(e)) {
    for (const r of e) if (t.startsWith(`data:${r}`)) return !0;
    return !1;
  }
  return t.startsWith(`data:${e}`);
}
function bt(t, e) {
  const r = t.split("?")[0],
    i = Tn.extname(r).toLowerCase();
  return Array.isArray(e) ? e.includes(i) : i === e;
}
function Et(t, e, r, i, s) {
  const n = e[r];
  for (let o = 0; o < n.length; o++) {
    const a = n[o];
    r < e.length - 1
      ? Et(t.replace(i[r], a), e, r + 1, i, s)
      : s.push(t.replace(i[r], a));
  }
}
function Tt(t) {
  const e = t.match(/\{(.*?)\}/g),
    r = [];
  if (e) {
    const i = [];
    e.forEach((t) => {
      const e = t.substring(1, t.length - 1).split(",");
      i.push(e);
    }),
      Et(t, i, 0, e, r);
  } else r.push(t);
  return r;
}
function At(t, e, r) {
  t.resource.internal = !0;
  const i = new ha(t),
    s = () => {
      delete e.promiseCache[r], ol.has(r) && ol.remove(r);
    };
  return (
    i.baseTexture.once("destroyed", () => {
      r in e.promiseCache && s();
    }),
    i.once("destroyed", () => {
      t.destroyed || s();
    }),
    i
  );
}
function wt(t) {
  return !Ol && "" !== document.createElement("video").canPlayType(t);
}
function St() {
  Gl = {
    s3tc: Ul.getExtension("WEBGL_compressed_texture_s3tc"),
    s3tc_sRGB: Ul.getExtension("WEBGL_compressed_texture_s3tc_srgb"),
    etc: Ul.getExtension("WEBGL_compressed_texture_etc"),
    etc1: Ul.getExtension("WEBGL_compressed_texture_etc1"),
    pvrtc:
      Ul.getExtension("WEBGL_compressed_texture_pvrtc") ||
      Ul.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
    atc: Ul.getExtension("WEBGL_compressed_texture_atc"),
    astc: Ul.getExtension("WEBGL_compressed_texture_astc"),
  };
}
function Rt(t) {
  switch (t) {
    case rn.RGBA:
      return rn.RGBA_INTEGER;
    case rn.RGB:
      return rn.RGB_INTEGER;
    case rn.RG:
      return rn.RG_INTEGER;
    case rn.RED:
      return rn.RED_INTEGER;
    default:
      return t;
  }
}
function It(t, e = !1) {
  const r = t.length;
  if (r < 6) return;
  let i = 0;
  for (let s = 0, n = t[r - 2], o = t[r - 1]; s < r; s += 2) {
    const e = t[s],
      r = t[s + 1];
    (i += (e - n) * (r + o)), (n = e), (o = r);
  }
  if ((!e && i > 0) || (e && i <= 0)) {
    const e = r / 2;
    for (let i = e + (e % 2); i < r; i += 2) {
      const e = r - i - 2,
        s = r - i - 1,
        n = i,
        o = i + 1;
      ([t[e], t[n]] = [t[n], t[e]]), ([t[s], t[o]] = [t[o], t[s]]);
    }
  }
}
function Ct(t, e, r, i, s, n, o, a) {
  let h, l;
  o ? ((h = i), (l = -r)) : ((h = -i), (l = r));
  const u = t - r * s + h,
    c = e - i * s + l,
    d = t + r * n + h,
    p = e + i * n + l;
  return a.push(u, c, d, p), 2;
}
function Pt(t, e, r, i, s, n, o, a) {
  const h = r - t,
    l = i - e;
  let u = Math.atan2(h, l),
    c = Math.atan2(s - t, n - e);
  a && u < c ? (u += 2 * Math.PI) : !a && u > c && (c += 2 * Math.PI);
  let d = u;
  const p = c - u,
    f = Math.abs(p),
    m = Math.sqrt(h * h + l * l),
    g = 1 + (((15 * f * Math.sqrt(m)) / Math.PI) >> 0),
    _ = p / g;
  if (((d += _), a)) {
    o.push(t, e, r, i);
    for (let r = 1, i = d; r < g; r++, i += _)
      o.push(t, e, t + Math.sin(i) * m, e + Math.cos(i) * m);
    o.push(t, e, s, n);
  } else {
    o.push(r, i, t, e);
    for (let r = 1, i = d; r < g; r++, i += _)
      o.push(t + Math.sin(i) * m, e + Math.cos(i) * m, t, e);
    o.push(s, n, t, e);
  }
  return 2 * g;
}
function Mt(t, e) {
  t.lineStyle.native
    ? (function (t, e) {
        let r = 0;
        const i = t.shape,
          s = t.points || i.points,
          n = i.type !== Hs.POLY || i.closeStroke;
        if (0 === s.length) return;
        const o = e.points,
          a = e.indices,
          h = s.length / 2,
          l = o.length / 2;
        let u = l;
        for (o.push(s[0], s[1]), r = 1; r < h; r++)
          o.push(s[2 * r], s[2 * r + 1]), a.push(u, u + 1), u++;
        n && a.push(u, l);
      })(t, e)
    : (function (t, e) {
        const r = t.shape;
        let i = t.points || r.points.slice();
        const s = e.closePointEps;
        if (0 === i.length) return;
        const n = t.lineStyle,
          o = new ho(i[0], i[1]),
          a = new ho(i[i.length - 2], i[i.length - 1]),
          h = r.type !== Hs.POLY || r.closeStroke,
          l = Math.abs(o.x - a.x) < s && Math.abs(o.y - a.y) < s;
        if (h) {
          (i = i.slice()),
            l && (i.pop(), i.pop(), a.set(i[i.length - 2], i[i.length - 1]));
          const t = 0.5 * (o.x + a.x),
            e = 0.5 * (a.y + o.y);
          i.unshift(t, e), i.push(t, e);
        }
        const u = e.points,
          c = i.length / 2;
        let d = i.length;
        const p = u.length / 2,
          f = n.width / 2,
          m = f * f,
          g = n.miterLimit * n.miterLimit;
        let _ = i[0],
          y = i[1],
          v = i[2],
          x = i[3],
          b = 0,
          E = 0,
          T = -(y - x),
          A = _ - v,
          w = 0,
          S = 0,
          R = Math.sqrt(T * T + A * A);
        (T /= R), (A /= R), (T *= f), (A *= f);
        const I = n.alignment,
          C = 2 * (1 - I),
          P = 2 * I;
        h ||
          (n.cap === Ws.ROUND
            ? (d +=
                Pt(
                  _ - T * (C - P) * 0.5,
                  y - A * (C - P) * 0.5,
                  _ - T * C,
                  y - A * C,
                  _ + T * P,
                  y + A * P,
                  u,
                  !0
                ) + 2)
            : n.cap === Ws.SQUARE && (d += Ct(_, y, T, A, C, P, !0, u))),
          u.push(_ - T * C, y - A * C, _ + T * P, y + A * P);
        for (let O = 1; O < c - 1; ++O) {
          (_ = i[2 * (O - 1)]),
            (y = i[2 * (O - 1) + 1]),
            (v = i[2 * O]),
            (x = i[2 * O + 1]),
            (b = i[2 * (O + 1)]),
            (E = i[2 * (O + 1) + 1]),
            (T = -(y - x)),
            (A = _ - v),
            (R = Math.sqrt(T * T + A * A)),
            (T /= R),
            (A /= R),
            (T *= f),
            (A *= f),
            (w = -(x - E)),
            (S = v - b),
            (R = Math.sqrt(w * w + S * S)),
            (w /= R),
            (S /= R),
            (w *= f),
            (S *= f);
          const t = v - _,
            e = y - x,
            r = v - b,
            s = E - x,
            o = t * r + e * s,
            a = e * r - s * t,
            h = a < 0;
          if (Math.abs(a) < 0.001 * Math.abs(o)) {
            u.push(v - T * C, x - A * C, v + T * P, x + A * P),
              o >= 0 &&
                (n.join === zs.ROUND
                  ? (d +=
                      Pt(
                        v,
                        x,
                        v - T * C,
                        x - A * C,
                        v - w * C,
                        x - S * C,
                        u,
                        !1
                      ) + 4)
                  : (d += 2),
                u.push(v - w * P, x - S * P, v + w * C, x + S * C));
            continue;
          }
          const l = (-T + _) * (-A + x) - (-T + v) * (-A + y),
            c = (-w + b) * (-S + x) - (-w + v) * (-S + E),
            p = (t * c - r * l) / a,
            I = (s * l - e * c) / a,
            M = (p - v) * (p - v) + (I - x) * (I - x),
            D = v + (p - v) * C,
            B = x + (I - x) * C,
            N = v - (p - v) * P,
            F = x - (I - x) * P,
            L = h ? C : P,
            k = M <= Math.min(t * t + e * e, r * r + s * s) + L * L * m;
          let U = n.join;
          if ((U === zs.MITER && M / m > g && (U = zs.BEVEL), k))
            switch (U) {
              case zs.MITER:
                u.push(D, B, N, F);
                break;
              case zs.BEVEL:
                h
                  ? u.push(
                      D,
                      B,
                      v + T * P,
                      x + A * P,
                      D,
                      B,
                      v + w * P,
                      x + S * P
                    )
                  : u.push(
                      v - T * C,
                      x - A * C,
                      N,
                      F,
                      v - w * C,
                      x - S * C,
                      N,
                      F
                    ),
                  (d += 2);
                break;
              case zs.ROUND:
                h
                  ? (u.push(D, B, v + T * P, x + A * P),
                    (d +=
                      Pt(
                        v,
                        x,
                        v + T * P,
                        x + A * P,
                        v + w * P,
                        x + S * P,
                        u,
                        !0
                      ) + 4),
                    u.push(D, B, v + w * P, x + S * P))
                  : (u.push(v - T * C, x - A * C, N, F),
                    (d +=
                      Pt(
                        v,
                        x,
                        v - T * C,
                        x - A * C,
                        v - w * C,
                        x - S * C,
                        u,
                        !1
                      ) + 4),
                    u.push(v - w * C, x - S * C, N, F));
            }
          else {
            switch ((u.push(v - T * C, x - A * C, v + T * P, x + A * P), U)) {
              case zs.MITER:
                h ? u.push(N, F, N, F) : u.push(D, B, D, B), (d += 2);
                break;
              case zs.ROUND:
                d += h
                  ? Pt(
                      v,
                      x,
                      v + T * P,
                      x + A * P,
                      v + w * P,
                      x + S * P,
                      u,
                      !0
                    ) + 2
                  : Pt(
                      v,
                      x,
                      v - T * C,
                      x - A * C,
                      v - w * C,
                      x - S * C,
                      u,
                      !1
                    ) + 2;
            }
            u.push(v - w * C, x - S * C, v + w * P, x + S * P), (d += 2);
          }
        }
        (_ = i[2 * (c - 2)]),
          (y = i[2 * (c - 2) + 1]),
          (v = i[2 * (c - 1)]),
          (x = i[2 * (c - 1) + 1]),
          (T = -(y - x)),
          (A = _ - v),
          (R = Math.sqrt(T * T + A * A)),
          (T /= R),
          (A /= R),
          (T *= f),
          (A *= f),
          u.push(v - T * C, x - A * C, v + T * P, x + A * P),
          h ||
            (n.cap === Ws.ROUND
              ? (d +=
                  Pt(
                    v - T * (C - P) * 0.5,
                    x - A * (C - P) * 0.5,
                    v - T * C,
                    x - A * C,
                    v + T * P,
                    x + A * P,
                    u,
                    !1
                  ) + 2)
              : n.cap === Ws.SQUARE && (d += Ct(v, x, T, A, C, P, !1, u)));
        const M = e.indices,
          D = ou.epsilon * ou.epsilon;
        for (let O = p; O < d + p - 2; ++O)
          (_ = u[2 * O]),
            (y = u[2 * O + 1]),
            (v = u[2 * (O + 1)]),
            (x = u[2 * (O + 1) + 1]),
            (b = u[2 * (O + 2)]),
            (E = u[2 * (O + 2) + 1]),
            !(Math.abs(_ * (x - E) + v * (E - y) + b * (y - x)) < D) &&
              M.push(O, O + 1, O + 2);
      })(t, e);
}
function Dt(t) {
  const e = Rn.shared,
    r = (t) => {
      const r = e.setValue(t);
      return 1 === r.alpha ? r.toHex() : r.toRgbaString();
    };
  return Array.isArray(t) ? t.map(r) : r(t);
}
function Ot(t, e, r) {
  for (const i in r)
    Array.isArray(e[i]) ? (t[i] = e[i].slice()) : (t[i] = e[i]);
}
function Bt(t, e) {
  var r;
  let i = !1;
  if (null == (r = null == t ? void 0 : t._textures) ? void 0 : r.length)
    for (let s = 0; s < t._textures.length; s++)
      if (t._textures[s] instanceof ha) {
        const r = t._textures[s].baseTexture;
        e.includes(r) || (e.push(r), (i = !0));
      }
  return i;
}
function Nt(t, e) {
  if (t.baseTexture instanceof Yn) {
    const r = t.baseTexture;
    return e.includes(r) || e.push(r), !0;
  }
  return !1;
}
function Ft(t, e) {
  if (t._texture && t._texture instanceof ha) {
    const r = t._texture.baseTexture;
    return e.includes(r) || e.push(r), !0;
  }
  return !1;
}
function Lt(t, e) {
  return e instanceof Gu && (e.updateText(!0), !0);
}
function kt(t, e) {
  if (e instanceof Lu) {
    const t = e.toFontString();
    return Bu.measureFont(t), !0;
  }
  return !1;
}
function Ut(t, e) {
  if (t instanceof Gu) {
    e.includes(t.style) || e.push(t.style), e.includes(t) || e.push(t);
    const r = t._texture.baseTexture;
    return e.includes(r) || e.push(r), !0;
  }
  return !1;
}
function Gt(t, e) {
  return t instanceof Lu && (e.includes(t) || e.push(t), !0);
}
function Ht(t, e) {
  return (
    e instanceof Yn && (e._glTextures[t.CONTEXT_UID] || t.texture.bind(e), !0)
  );
}
function jt(t, e) {
  if (!(e instanceof Eu)) return !1;
  const { geometry: r } = e;
  e.finishPoly(), r.updateBatches();
  const { batches: i } = r;
  for (let s = 0; s < i.length; s++) {
    const { texture: e } = i[s].style;
    e && Ht(t, e.baseTexture);
  }
  return r.batchable || t.geometry.bind(r, e._resolveDirectShader(t)), !0;
}
function Xt(t, e) {
  return t instanceof Eu && (e.push(t), !0);
}
function Vt(t, e, r) {
  const i = {};
  if (
    (t.forEach((t) => {
      i[t] = e;
    }),
    Object.keys(e.textures).forEach((t) => {
      i[t] = e.textures[t];
    }),
    !r)
  ) {
    const r = Tn.dirname(t[0]);
    e.linkedSheets.forEach((t, s) => {
      const n = Vt([`${r}/${e.data.meta.related_multi_packs[s]}`], t, !0);
      Object.assign(i, n);
    });
  }
  return i;
}
function zt(t, e, r, i, s, n, o) {
  const a = r.text,
    h = r.fontProperties;
  e.translate(i, s), e.scale(n, n);
  const l = o.strokeThickness / 2,
    u = -o.strokeThickness / 2;
  if (
    ((e.font = o.toFontString()),
    (e.lineWidth = o.strokeThickness),
    (e.textBaseline = o.textBaseline),
    (e.lineJoin = o.lineJoin),
    (e.miterLimit = o.miterLimit),
    (e.fillStyle = (function (t, e, r, i, s, n) {
      const o = r.fill;
      if (!Array.isArray(o)) return o;
      if (1 === o.length) return o[0];
      let a;
      const h = r.dropShadow ? r.dropShadowDistance : 0,
        l = r.padding || 0,
        u = t.width / i - h - 2 * l,
        c = t.height / i - h - 2 * l,
        d = o.slice(),
        p = r.fillGradientStops.slice();
      if (!p.length) {
        const t = d.length + 1;
        for (let e = 1; e < t; ++e) p.push(e / t);
      }
      if (
        (d.unshift(o[0]),
        p.unshift(0),
        d.push(o[o.length - 1]),
        p.push(1),
        r.fillGradientType === $s.LINEAR_VERTICAL)
      ) {
        a = e.createLinearGradient(u / 2, l, u / 2, c + l);
        let t = 0;
        const i = (n.fontProperties.fontSize + r.strokeThickness) / c;
        for (let e = 0; e < s.length; e++) {
          const r = n.lineHeight * e;
          for (let e = 0; e < d.length; e++) {
            let s = 0;
            s = "number" == typeof p[e] ? p[e] : e / d.length;
            const n = r / c + s * i;
            let o = Math.max(t, n);
            (o = Math.min(o, 1)), a.addColorStop(o, d[e]), (t = o);
          }
        }
      } else {
        a = e.createLinearGradient(l, c / 2, u + l, c / 2);
        const t = d.length + 1;
        let r = 1;
        for (let e = 0; e < d.length; e++) {
          let i;
          (i = "number" == typeof p[e] ? p[e] : r / t),
            a.addColorStop(i, d[e]),
            r++;
        }
      }
      return a;
    })(t, e, o, n, [a], r)),
    (e.strokeStyle = o.stroke),
    o.dropShadow)
  ) {
    const t = o.dropShadowColor,
      r = o.dropShadowBlur * n,
      i = o.dropShadowDistance * n;
    (e.shadowColor = Rn.shared
      .setValue(t)
      .setAlpha(o.dropShadowAlpha)
      .toRgbaString()),
      (e.shadowBlur = r),
      (e.shadowOffsetX = Math.cos(o.dropShadowAngle) * i),
      (e.shadowOffsetY = Math.sin(o.dropShadowAngle) * i);
  } else
    (e.shadowColor = "black"),
      (e.shadowBlur = 0),
      (e.shadowOffsetX = 0),
      (e.shadowOffsetY = 0);
  o.stroke &&
    o.strokeThickness &&
    e.strokeText(a, l, u + r.lineHeight - h.descent),
    o.fill && e.fillText(a, l, u + r.lineHeight - h.descent),
    e.setTransform(1, 0, 0, 1, 0, 0),
    (e.fillStyle = "rgba(0, 0, 0, 0)");
}
function Wt(t) {
  return t.codePointAt ? t.codePointAt(0) : t.charCodeAt(0);
}
function $t(t) {
  return Array.from ? Array.from(t) : t.split("");
}
var Yt,
  qt,
  Kt,
  Zt,
  Qt,
  Jt,
  te,
  ee,
  re,
  ie,
  se,
  ne,
  oe,
  ae,
  he,
  le,
  ue,
  ce,
  de,
  pe,
  fe,
  me,
  ge,
  _e,
  ye,
  ve,
  xe,
  be,
  Ee,
  Te,
  Ae,
  we,
  Se,
  Re,
  Ie,
  Ce,
  Pe,
  Me,
  De,
  Oe,
  Be,
  Ne,
  Fe,
  Le,
  ke,
  Ue,
  Ge,
  He,
  je,
  Xe,
  Ve,
  ze,
  We,
  $e,
  Ye,
  qe,
  Ke,
  Ze,
  Qe,
  Je,
  tr,
  er,
  rr,
  ir,
  sr,
  nr,
  or,
  ar,
  hr,
  lr,
  ur,
  cr,
  dr,
  pr,
  fr,
  mr,
  gr,
  _r,
  yr,
  vr,
  xr,
  br,
  Er,
  Tr,
  Ar,
  wr,
  Sr,
  Rr,
  Ir,
  Cr,
  Pr,
  Mr,
  Dr,
  Or,
  Br,
  Nr,
  Fr,
  Lr,
  kr,
  Ur,
  Gr,
  Hr,
  jr,
  Xr,
  Vr,
  zr,
  Wr,
  $r,
  Yr,
  qr,
  Kr,
  Zr,
  Qr,
  Jr,
  ti,
  ei,
  ri,
  ii,
  si,
  ni,
  oi,
  ai,
  hi,
  li,
  ui,
  ci,
  di,
  pi,
  fi,
  mi,
  gi,
  _i,
  yi,
  vi,
  xi,
  bi,
  Ei,
  Ti,
  Ai,
  wi,
  Si,
  Ri,
  Ii,
  Ci,
  Pi,
  Mi,
  Di,
  Oi,
  Bi,
  Ni,
  Fi,
  Li,
  ki,
  Ui,
  Gi,
  Hi,
  ji,
  Xi,
  Vi,
  zi,
  Wi,
  $i,
  Yi,
  qi,
  Ki,
  Zi,
  Qi,
  Ji,
  ts,
  es,
  rs,
  is,
  ss,
  ns,
  os,
  as,
  hs,
  ls,
  us,
  cs,
  ds,
  ps,
  fs,
  ms,
  gs,
  _s,
  ys,
  vs,
  xs,
  bs,
  Es,
  Ts,
  As,
  ws,
  Ss,
  Rs,
  Is,
  Cs,
  Ps,
  Ms,
  Ds,
  Os,
  Bs,
  Ns,
  Fs,
  Ls,
  ks,
  Us,
  Gs,
  Hs,
  js,
  Xs,
  Vs,
  zs,
  Ws,
  $s,
  Ys,
  qs,
  Ks,
  Zs = ((t) => (
    (t[(t.WEBGL_LEGACY = 0)] = "WEBGL_LEGACY"),
    (t[(t.WEBGL = 1)] = "WEBGL"),
    (t[(t.WEBGL2 = 2)] = "WEBGL2"),
    t
  ))(Zs || {}),
  Qs = ((t) => (
    (t[(t.UNKNOWN = 0)] = "UNKNOWN"),
    (t[(t.WEBGL = 1)] = "WEBGL"),
    (t[(t.CANVAS = 2)] = "CANVAS"),
    t
  ))(Qs || {}),
  Js = ((t) => (
    (t[(t.COLOR = 16384)] = "COLOR"),
    (t[(t.DEPTH = 256)] = "DEPTH"),
    (t[(t.STENCIL = 1024)] = "STENCIL"),
    t
  ))(Js || {}),
  tn = ((t) => (
    (t[(t.NORMAL = 0)] = "NORMAL"),
    (t[(t.ADD = 1)] = "ADD"),
    (t[(t.MULTIPLY = 2)] = "MULTIPLY"),
    (t[(t.SCREEN = 3)] = "SCREEN"),
    (t[(t.OVERLAY = 4)] = "OVERLAY"),
    (t[(t.DARKEN = 5)] = "DARKEN"),
    (t[(t.LIGHTEN = 6)] = "LIGHTEN"),
    (t[(t.COLOR_DODGE = 7)] = "COLOR_DODGE"),
    (t[(t.COLOR_BURN = 8)] = "COLOR_BURN"),
    (t[(t.HARD_LIGHT = 9)] = "HARD_LIGHT"),
    (t[(t.SOFT_LIGHT = 10)] = "SOFT_LIGHT"),
    (t[(t.DIFFERENCE = 11)] = "DIFFERENCE"),
    (t[(t.EXCLUSION = 12)] = "EXCLUSION"),
    (t[(t.HUE = 13)] = "HUE"),
    (t[(t.SATURATION = 14)] = "SATURATION"),
    (t[(t.COLOR = 15)] = "COLOR"),
    (t[(t.LUMINOSITY = 16)] = "LUMINOSITY"),
    (t[(t.NORMAL_NPM = 17)] = "NORMAL_NPM"),
    (t[(t.ADD_NPM = 18)] = "ADD_NPM"),
    (t[(t.SCREEN_NPM = 19)] = "SCREEN_NPM"),
    (t[(t.NONE = 20)] = "NONE"),
    (t[(t.SRC_OVER = 0)] = "SRC_OVER"),
    (t[(t.SRC_IN = 21)] = "SRC_IN"),
    (t[(t.SRC_OUT = 22)] = "SRC_OUT"),
    (t[(t.SRC_ATOP = 23)] = "SRC_ATOP"),
    (t[(t.DST_OVER = 24)] = "DST_OVER"),
    (t[(t.DST_IN = 25)] = "DST_IN"),
    (t[(t.DST_OUT = 26)] = "DST_OUT"),
    (t[(t.DST_ATOP = 27)] = "DST_ATOP"),
    (t[(t.ERASE = 26)] = "ERASE"),
    (t[(t.SUBTRACT = 28)] = "SUBTRACT"),
    (t[(t.XOR = 29)] = "XOR"),
    t
  ))(tn || {}),
  en = ((t) => (
    (t[(t.POINTS = 0)] = "POINTS"),
    (t[(t.LINES = 1)] = "LINES"),
    (t[(t.LINE_LOOP = 2)] = "LINE_LOOP"),
    (t[(t.LINE_STRIP = 3)] = "LINE_STRIP"),
    (t[(t.TRIANGLES = 4)] = "TRIANGLES"),
    (t[(t.TRIANGLE_STRIP = 5)] = "TRIANGLE_STRIP"),
    (t[(t.TRIANGLE_FAN = 6)] = "TRIANGLE_FAN"),
    t
  ))(en || {}),
  rn = ((t) => (
    (t[(t.RGBA = 6408)] = "RGBA"),
    (t[(t.RGB = 6407)] = "RGB"),
    (t[(t.RG = 33319)] = "RG"),
    (t[(t.RED = 6403)] = "RED"),
    (t[(t.RGBA_INTEGER = 36249)] = "RGBA_INTEGER"),
    (t[(t.RGB_INTEGER = 36248)] = "RGB_INTEGER"),
    (t[(t.RG_INTEGER = 33320)] = "RG_INTEGER"),
    (t[(t.RED_INTEGER = 36244)] = "RED_INTEGER"),
    (t[(t.ALPHA = 6406)] = "ALPHA"),
    (t[(t.LUMINANCE = 6409)] = "LUMINANCE"),
    (t[(t.LUMINANCE_ALPHA = 6410)] = "LUMINANCE_ALPHA"),
    (t[(t.DEPTH_COMPONENT = 6402)] = "DEPTH_COMPONENT"),
    (t[(t.DEPTH_STENCIL = 34041)] = "DEPTH_STENCIL"),
    t
  ))(rn || {}),
  sn = ((t) => (
    (t[(t.TEXTURE_2D = 3553)] = "TEXTURE_2D"),
    (t[(t.TEXTURE_CUBE_MAP = 34067)] = "TEXTURE_CUBE_MAP"),
    (t[(t.TEXTURE_2D_ARRAY = 35866)] = "TEXTURE_2D_ARRAY"),
    (t[(t.TEXTURE_CUBE_MAP_POSITIVE_X = 34069)] =
      "TEXTURE_CUBE_MAP_POSITIVE_X"),
    (t[(t.TEXTURE_CUBE_MAP_NEGATIVE_X = 34070)] =
      "TEXTURE_CUBE_MAP_NEGATIVE_X"),
    (t[(t.TEXTURE_CUBE_MAP_POSITIVE_Y = 34071)] =
      "TEXTURE_CUBE_MAP_POSITIVE_Y"),
    (t[(t.TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072)] =
      "TEXTURE_CUBE_MAP_NEGATIVE_Y"),
    (t[(t.TEXTURE_CUBE_MAP_POSITIVE_Z = 34073)] =
      "TEXTURE_CUBE_MAP_POSITIVE_Z"),
    (t[(t.TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074)] =
      "TEXTURE_CUBE_MAP_NEGATIVE_Z"),
    t
  ))(sn || {}),
  nn = ((t) => (
    (t[(t.UNSIGNED_BYTE = 5121)] = "UNSIGNED_BYTE"),
    (t[(t.UNSIGNED_SHORT = 5123)] = "UNSIGNED_SHORT"),
    (t[(t.UNSIGNED_SHORT_5_6_5 = 33635)] = "UNSIGNED_SHORT_5_6_5"),
    (t[(t.UNSIGNED_SHORT_4_4_4_4 = 32819)] = "UNSIGNED_SHORT_4_4_4_4"),
    (t[(t.UNSIGNED_SHORT_5_5_5_1 = 32820)] = "UNSIGNED_SHORT_5_5_5_1"),
    (t[(t.UNSIGNED_INT = 5125)] = "UNSIGNED_INT"),
    (t[(t.UNSIGNED_INT_10F_11F_11F_REV = 35899)] =
      "UNSIGNED_INT_10F_11F_11F_REV"),
    (t[(t.UNSIGNED_INT_2_10_10_10_REV = 33640)] =
      "UNSIGNED_INT_2_10_10_10_REV"),
    (t[(t.UNSIGNED_INT_24_8 = 34042)] = "UNSIGNED_INT_24_8"),
    (t[(t.UNSIGNED_INT_5_9_9_9_REV = 35902)] = "UNSIGNED_INT_5_9_9_9_REV"),
    (t[(t.BYTE = 5120)] = "BYTE"),
    (t[(t.SHORT = 5122)] = "SHORT"),
    (t[(t.INT = 5124)] = "INT"),
    (t[(t.FLOAT = 5126)] = "FLOAT"),
    (t[(t.FLOAT_32_UNSIGNED_INT_24_8_REV = 36269)] =
      "FLOAT_32_UNSIGNED_INT_24_8_REV"),
    (t[(t.HALF_FLOAT = 36193)] = "HALF_FLOAT"),
    t
  ))(nn || {}),
  on = ((t) => (
    (t[(t.FLOAT = 0)] = "FLOAT"),
    (t[(t.INT = 1)] = "INT"),
    (t[(t.UINT = 2)] = "UINT"),
    t
  ))(on || {}),
  an = ((t) => (
    (t[(t.NEAREST = 0)] = "NEAREST"), (t[(t.LINEAR = 1)] = "LINEAR"), t
  ))(an || {}),
  hn = ((t) => (
    (t[(t.CLAMP = 33071)] = "CLAMP"),
    (t[(t.REPEAT = 10497)] = "REPEAT"),
    (t[(t.MIRRORED_REPEAT = 33648)] = "MIRRORED_REPEAT"),
    t
  ))(hn || {}),
  ln = ((t) => (
    (t[(t.OFF = 0)] = "OFF"),
    (t[(t.POW2 = 1)] = "POW2"),
    (t[(t.ON = 2)] = "ON"),
    (t[(t.ON_MANUAL = 3)] = "ON_MANUAL"),
    t
  ))(ln || {}),
  un = ((t) => (
    (t[(t.NPM = 0)] = "NPM"),
    (t[(t.UNPACK = 1)] = "UNPACK"),
    (t[(t.PMA = 2)] = "PMA"),
    (t[(t.NO_PREMULTIPLIED_ALPHA = 0)] = "NO_PREMULTIPLIED_ALPHA"),
    (t[(t.PREMULTIPLY_ON_UPLOAD = 1)] = "PREMULTIPLY_ON_UPLOAD"),
    (t[(t.PREMULTIPLIED_ALPHA = 2)] = "PREMULTIPLIED_ALPHA"),
    t
  ))(un || {}),
  cn = ((t) => (
    (t[(t.NO = 0)] = "NO"),
    (t[(t.YES = 1)] = "YES"),
    (t[(t.AUTO = 2)] = "AUTO"),
    (t[(t.BLEND = 0)] = "BLEND"),
    (t[(t.CLEAR = 1)] = "CLEAR"),
    (t[(t.BLIT = 2)] = "BLIT"),
    t
  ))(cn || {}),
  dn = ((t) => ((t[(t.AUTO = 0)] = "AUTO"), (t[(t.MANUAL = 1)] = "MANUAL"), t))(
    dn || {}
  ),
  pn = ((t) => (
    (t.LOW = "lowp"), (t.MEDIUM = "mediump"), (t.HIGH = "highp"), t
  ))(pn || {}),
  fn = ((t) => (
    (t[(t.NONE = 0)] = "NONE"),
    (t[(t.SCISSOR = 1)] = "SCISSOR"),
    (t[(t.STENCIL = 2)] = "STENCIL"),
    (t[(t.SPRITE = 3)] = "SPRITE"),
    (t[(t.COLOR = 4)] = "COLOR"),
    t
  ))(fn || {}),
  mn = ((t) => (
    (t[(t.NONE = 0)] = "NONE"),
    (t[(t.LOW = 2)] = "LOW"),
    (t[(t.MEDIUM = 4)] = "MEDIUM"),
    (t[(t.HIGH = 8)] = "HIGH"),
    t
  ))(mn || {}),
  gn = ((t) => (
    (t[(t.ELEMENT_ARRAY_BUFFER = 34963)] = "ELEMENT_ARRAY_BUFFER"),
    (t[(t.ARRAY_BUFFER = 34962)] = "ARRAY_BUFFER"),
    (t[(t.UNIFORM_BUFFER = 35345)] = "UNIFORM_BUFFER"),
    t
  ))(gn || {});
const _n = {
  ADAPTER: {
    createCanvas: (t, e) => {
      const r = document.createElement("canvas");
      return (r.width = t), (r.height = e), r;
    },
    getCanvasRenderingContext2D: () => CanvasRenderingContext2D,
    getWebGLRenderingContext: () => WebGLRenderingContext,
    getNavigator: () => navigator,
    getBaseUrl: () => document.baseURI ?? window.location.href,
    getFontFaceSet: () => document.fonts,
    fetch: (t, e) => fetch(t, e),
    parseXML: (t) => new DOMParser().parseFromString(t, "text/xml"),
  },
  RESOLUTION: 1,
  CREATE_IMAGE_BITMAP: !1,
  ROUND_PIXELS: !1,
};
(Yt = /iPhone/i),
  (qt = /iPod/i),
  (Kt = /iPad/i),
  (Zt = /\biOS-universal(?:.+)Mac\b/i),
  (Qt = /\bAndroid(?:.+)Mobile\b/i),
  (Jt = /Android/i),
  (te = /(?:SD4930UR|\bSilk(?:.+)Mobile\b)/i),
  (ee = /Silk/i),
  (re = /Windows Phone/i),
  (ie = /\bWindows(?:.+)ARM\b/i),
  (se = /BlackBerry/i),
  (ne = /BB10/i),
  (oe = /Opera Mini/i),
  (ae = /\b(CriOS|Chrome)(?:.+)Mobile/i),
  (he = /Mobile(?:.+)Firefox\b/i),
  (le = function (t) {
    return (
      void 0 !== t &&
      "MacIntel" === t.platform &&
      "number" == typeof t.maxTouchPoints &&
      t.maxTouchPoints > 1 &&
      "undefined" == typeof MSStream
    );
  });
const yn = (t.default ?? t)(globalThis.navigator);
(_n.RETINA_PREFIX = /@([0-9\.]+)x/),
  (_n.FAIL_IF_MAJOR_PERFORMANCE_CAVEAT = !1),
  (ue =
    "undefined" != typeof globalThis
      ? globalThis
      : "undefined" != typeof window
      ? window
      : "undefined" != typeof global
      ? global
      : "undefined" != typeof self
      ? self
      : {}),
  (function (t) {
    function e() {}
    function r(t, e, r) {
      (this.fn = t), (this.context = e), (this.once = r || !1);
    }
    function i(t, e, i, s, n) {
      if ("function" != typeof i)
        throw new TypeError("The listener must be a function");
      var o = new r(i, s || t, n),
        h = a ? a + e : e;
      return (
        t._events[h]
          ? t._events[h].fn
            ? (t._events[h] = [t._events[h], o])
            : t._events[h].push(o)
          : ((t._events[h] = o), t._eventsCount++),
        t
      );
    }
    function s(t, r) {
      0 == --t._eventsCount ? (t._events = new e()) : delete t._events[r];
    }
    function n() {
      (this._events = new e()), (this._eventsCount = 0);
    }
    var o = Object.prototype.hasOwnProperty,
      a = "~";
    Object.create &&
      ((e.prototype = Object.create(null)), new e().__proto__ || (a = !1)),
      (n.prototype.eventNames = function () {
        var t,
          e,
          r = [];
        if (0 === this._eventsCount) return r;
        for (e in (t = this._events))
          o.call(t, e) && r.push(a ? e.slice(1) : e);
        return Object.getOwnPropertySymbols
          ? r.concat(Object.getOwnPropertySymbols(t))
          : r;
      }),
      (n.prototype.listeners = function (t) {
        var e,
          r,
          i,
          s = a ? a + t : t,
          n = this._events[s];
        if (!n) return [];
        if (n.fn) return [n.fn];
        for (e = 0, r = n.length, i = new Array(r); e < r; e++) i[e] = n[e].fn;
        return i;
      }),
      (n.prototype.listenerCount = function (t) {
        var e = a ? a + t : t,
          r = this._events[e];
        return r ? (r.fn ? 1 : r.length) : 0;
      }),
      (n.prototype.emit = function (t, e, r, i, s, n) {
        var o,
          h,
          l,
          u,
          c,
          d,
          p = a ? a + t : t;
        if (!this._events[p]) return !1;
        if (((o = this._events[p]), (h = arguments.length), o.fn)) {
          switch ((o.once && this.removeListener(t, o.fn, void 0, !0), h)) {
            case 1:
              return o.fn.call(o.context), !0;
            case 2:
              return o.fn.call(o.context, e), !0;
            case 3:
              return o.fn.call(o.context, e, r), !0;
            case 4:
              return o.fn.call(o.context, e, r, i), !0;
            case 5:
              return o.fn.call(o.context, e, r, i, s), !0;
            case 6:
              return o.fn.call(o.context, e, r, i, s, n), !0;
          }
          for (u = 1, l = new Array(h - 1); u < h; u++) l[u - 1] = arguments[u];
          o.fn.apply(o.context, l);
        } else
          for (c = o.length, u = 0; u < c; u++)
            switch (
              (o[u].once && this.removeListener(t, o[u].fn, void 0, !0), h)
            ) {
              case 1:
                o[u].fn.call(o[u].context);
                break;
              case 2:
                o[u].fn.call(o[u].context, e);
                break;
              case 3:
                o[u].fn.call(o[u].context, e, r);
                break;
              case 4:
                o[u].fn.call(o[u].context, e, r, i);
                break;
              default:
                if (!l)
                  for (d = 1, l = new Array(h - 1); d < h; d++)
                    l[d - 1] = arguments[d];
                o[u].fn.apply(o[u].context, l);
            }
        return !0;
      }),
      (n.prototype.on = function (t, e, r) {
        return i(this, t, e, r, !1);
      }),
      (n.prototype.once = function (t, e, r) {
        return i(this, t, e, r, !0);
      }),
      (n.prototype.removeListener = function (t, e, r, i) {
        var n,
          o,
          h,
          l,
          u = a ? a + t : t;
        if (!this._events[u]) return this;
        if (!e) return s(this, u), this;
        if ((n = this._events[u]).fn)
          n.fn !== e || (i && !n.once) || (r && n.context !== r) || s(this, u);
        else {
          for (o = 0, h = [], l = n.length; o < l; o++)
            (n[o].fn !== e || (i && !n[o].once) || (r && n[o].context !== r)) &&
              h.push(n[o]);
          h.length ? (this._events[u] = 1 === h.length ? h[0] : h) : s(this, u);
        }
        return this;
      }),
      (n.prototype.removeAllListeners = function (t) {
        var r;
        return (
          t
            ? ((r = a ? a + t : t), this._events[r] && s(this, r))
            : ((this._events = new e()), (this._eventsCount = 0)),
          this
        );
      }),
      (n.prototype.off = n.prototype.removeListener),
      (n.prototype.addListener = n.prototype.on),
      (n.prefixed = a),
      (n.EventEmitter = n),
      (t.exports = n);
  })((ce = { exports: {} }));
const vn = e(ce.exports);
((de = { exports: {} }).exports = i),
  (de.exports.default = i),
  (i.deviation = function (t, e, r, i) {
    var s,
      n,
      o,
      a,
      h,
      l,
      u,
      c,
      d = e && e.length,
      p = d ? e[0] * r : t.length,
      f = Math.abs(I(t, 0, p, r));
    if (d)
      for (s = 0, n = e.length; s < n; s++)
        (o = e[s] * r),
          (a = s < n - 1 ? e[s + 1] * r : t.length),
          (f -= Math.abs(I(t, o, a, r)));
    for (h = 0, s = 0; s < i.length; s += 3)
      (l = i[s] * r),
        (u = i[s + 1] * r),
        (c = i[s + 2] * r),
        (h += Math.abs(
          (t[l] - t[c]) * (t[u + 1] - t[l + 1]) -
            (t[l] - t[u]) * (t[c + 1] - t[l + 1])
        ));
    return 0 === f && 0 === h ? 0 : Math.abs((h - f) / f);
  }),
  (i.flatten = function (t) {
    var e,
      r,
      i,
      s = t[0][0].length,
      n = { vertices: [], holes: [], dimensions: s },
      o = 0;
    for (e = 0; e < t.length; e++) {
      for (r = 0; r < t[e].length; r++)
        for (i = 0; i < s; i++) n.vertices.push(t[e][r][i]);
      e > 0 && ((o += t[e - 1].length), n.holes.push(o));
    }
    return n;
  });
const xn = e(de.exports);
if (
  ((qs = pe = { exports: {} }),
  (Ks = pe.exports),
  (function (t) {
    function e(t) {
      throw new RangeError(T[t]);
    }
    function r(t, e) {
      for (var r = t.length, i = []; r--; ) i[r] = e(t[r]);
      return i;
    }
    function i(t, e) {
      var i = t.split("@"),
        s = "";
      return (
        i.length > 1 && ((s = i[0] + "@"), (t = i[1])),
        s + r((t = t.replace(E, ".")).split("."), e).join(".")
      );
    }
    function s(t) {
      for (var e, r, i = [], s = 0, n = t.length; s < n; )
        (e = t.charCodeAt(s++)) >= 55296 && e <= 56319 && s < n
          ? 56320 == (64512 & (r = t.charCodeAt(s++)))
            ? i.push(((1023 & e) << 10) + (1023 & r) + 65536)
            : (i.push(e), s--)
          : i.push(e);
      return i;
    }
    function n(t) {
      return r(t, function (t) {
        var e = "";
        return (
          t > 65535 &&
            ((e += S((((t -= 65536) >>> 10) & 1023) | 55296)),
            (t = 56320 | (1023 & t))),
          e + S(t)
        );
      }).join("");
    }
    function o(t, e) {
      return t + 22 + 75 * (t < 26) - ((0 != e) << 5);
    }
    function a(t, e, r) {
      var i = 0;
      for (t = r ? w(t / g) : t >> 1, t += w(t / e); t > (A * f) >> 1; i += d)
        t = w(t / A);
      return w(i + ((A + 1) * t) / (t + m));
    }
    function h(t) {
      var r,
        i,
        s,
        o,
        h,
        l,
        u,
        m,
        g,
        x,
        b,
        E = [],
        T = t.length,
        A = 0,
        S = y,
        R = _;
      for ((i = t.lastIndexOf(v)) < 0 && (i = 0), s = 0; s < i; ++s)
        t.charCodeAt(s) >= 128 && e("not-basic"), E.push(t.charCodeAt(s));
      for (o = i > 0 ? i + 1 : 0; o < T; ) {
        for (
          h = A, l = 1, u = d;
          o >= T && e("invalid-input"),
            ((m =
              (b = t.charCodeAt(o++)) - 48 < 10
                ? b - 22
                : b - 65 < 26
                ? b - 65
                : b - 97 < 26
                ? b - 97
                : d) >= d ||
              m > w((c - A) / l)) &&
              e("overflow"),
            (A += m * l),
            !(m < (g = u <= R ? p : u >= R + f ? f : u - R));
          u += d
        )
          l > w(c / (x = d - g)) && e("overflow"), (l *= x);
        (R = a(A - h, (r = E.length + 1), 0 == h)),
          w(A / r) > c - S && e("overflow"),
          (S += w(A / r)),
          (A %= r),
          E.splice(A++, 0, S);
      }
      return n(E);
    }
    function l(t) {
      var r,
        i,
        n,
        h,
        l,
        u,
        m,
        g,
        x,
        b,
        E,
        T,
        A,
        R,
        I,
        C = [];
      for (T = (t = s(t)).length, r = y, i = 0, l = _, u = 0; u < T; ++u)
        (E = t[u]) < 128 && C.push(S(E));
      for (n = h = C.length, h && C.push(v); n < T; ) {
        for (m = c, u = 0; u < T; ++u) (E = t[u]) >= r && E < m && (m = E);
        for (
          m - r > w((c - i) / (A = n + 1)) && e("overflow"),
            i += (m - r) * A,
            r = m,
            u = 0;
          u < T;
          ++u
        )
          if (((E = t[u]) < r && ++i > c && e("overflow"), E == r)) {
            for (
              g = i, x = d;
              !(g < (b = x <= l ? p : x >= l + f ? f : x - l));
              x += d
            )
              (I = g - b),
                (R = d - b),
                C.push(S(o(b + (I % R), 0))),
                (g = w(I / R));
            C.push(S(o(g, 0))), (l = a(i, A, n == h)), (i = 0), ++n;
          }
        ++i, ++r;
      }
      return C.join("");
    }
    var u,
      c,
      d,
      p,
      f,
      m,
      g,
      _,
      y,
      v,
      x,
      b,
      E,
      T,
      A,
      w,
      S,
      R,
      I = Ks && !Ks.nodeType && Ks,
      C = qs && !qs.nodeType && qs,
      P = "object" == typeof ue && ue;
    if (
      ((P.global !== P && P.window !== P && P.self !== P) || (t = P),
      (c = 2147483647),
      (f = 26),
      (m = 38),
      (g = 700),
      (_ = 72),
      (y = 128),
      (v = "-"),
      (x = /^xn--/),
      (b = /[^\x20-\x7E]/),
      (E = /[\x2E\u3002\uFF0E\uFF61]/g),
      (T = {
        overflow: "Overflow: input needs wider integers to process",
        "not-basic": "Illegal input >= 0x80 (not a basic code point)",
        "invalid-input": "Invalid input",
      }),
      (A = (d = 36) - (p = 1)),
      (w = Math.floor),
      (S = String.fromCharCode),
      (u = {
        version: "1.4.1",
        ucs2: { decode: s, encode: n },
        decode: h,
        encode: l,
        toASCII: function (t) {
          return i(t, function (t) {
            return b.test(t) ? "xn--" + l(t) : t;
          });
        },
        toUnicode: function (t) {
          return i(t, function (t) {
            return x.test(t) ? h(t.slice(4).toLowerCase()) : t;
          });
        },
      }),
      I && C)
    )
      if (qs.exports == I) C.exports = u;
      else for (R in u) u.hasOwnProperty(R) && (I[R] = u[R]);
    else t.punycode = u;
  })(ue),
  (fe = pe.exports),
  (me = function () {
    var t, e, r, i, s;
    if (
      "function" != typeof Symbol ||
      "function" != typeof Object.getOwnPropertySymbols
    )
      return !1;
    if ("symbol" == typeof Symbol.iterator) return !0;
    if (((t = {}), (e = Symbol("test")), (r = Object(e)), "string" == typeof e))
      return !1;
    if ("[object Symbol]" !== Object.prototype.toString.call(e)) return !1;
    if ("[object Symbol]" !== Object.prototype.toString.call(r)) return !1;
    for (e in ((t[e] = 42), t)) return !1;
    return !(
      ("function" == typeof Object.keys && 0 !== Object.keys(t).length) ||
      ("function" == typeof Object.getOwnPropertyNames &&
        0 !== Object.getOwnPropertyNames(t).length) ||
      1 !== (i = Object.getOwnPropertySymbols(t)).length ||
      i[0] !== e ||
      !Object.prototype.propertyIsEnumerable.call(t, e) ||
      ("function" == typeof Object.getOwnPropertyDescriptor &&
        (42 !== (s = Object.getOwnPropertyDescriptor(t, e)).value ||
          !0 !== s.enumerable))
    );
  }),
  (ge = "undefined" != typeof Symbol && Symbol),
  (_e = me),
  (ye = function () {
    return (
      "function" == typeof ge &&
      "function" == typeof Symbol &&
      "symbol" == typeof ge("foo") &&
      "symbol" == typeof Symbol("bar") &&
      _e()
    );
  }),
  (ve = { foo: {} }),
  (xe = Object),
  (be = function () {
    return (
      { __proto__: ve }.foo === ve.foo && !({ __proto__: null } instanceof xe)
    );
  }),
  (Ee = Object.prototype.toString),
  (Te = Math.max),
  (Ae = function (t, e) {
    var r,
      i,
      s = [];
    for (r = 0; r < t.length; r += 1) s[r] = t[r];
    for (i = 0; i < e.length; i += 1) s[i + t.length] = e[i];
    return s;
  }),
  (we = function (t, e) {
    var r,
      i,
      s = [];
    for (r = e || 0, i = 0; r < t.length; r += 1, i += 1) s[i] = t[r];
    return s;
  }),
  (Se = function (t, e) {
    var r,
      i = "";
    for (r = 0; r < t.length; r += 1) (i += t[r]), r + 1 < t.length && (i += e);
    return i;
  }),
  (Re = function (t) {
    var e,
      r,
      i,
      s,
      n,
      o,
      a,
      h = this;
    if ("function" != typeof h || "[object Function]" !== Ee.apply(h))
      throw new TypeError(
        "Function.prototype.bind called on incompatible " + h
      );
    for (
      e = we(arguments, 1),
        i = function () {
          if (this instanceof r) {
            var i = h.apply(this, Ae(e, arguments));
            return Object(i) === i ? i : this;
          }
          return h.apply(t, Ae(e, arguments));
        },
        s = Te(0, h.length - e.length),
        n = [],
        o = 0;
      o < s;
      o++
    )
      n[o] = "$" + o;
    return (
      (r = Function(
        "binder",
        "return function (" +
          Se(n, ",") +
          "){ return binder.apply(this,arguments); }"
      )(i)),
      h.prototype &&
        (((a = function () {}).prototype = h.prototype),
        (r.prototype = new a()),
        (a.prototype = null)),
      r
    );
  }),
  (Ie = Function.prototype.bind || Re),
  (Ce = {}.hasOwnProperty),
  (Me = (Pe = Function.prototype.call).bind
    ? Pe.bind(Ce)
    : function (t, e) {
        return Pe.call(Ce, t, e);
      }),
  (Oe = SyntaxError),
  (Be = Function),
  (Ne = TypeError),
  (Fe = function (t) {
    try {
      return Be('"use strict"; return (' + t + ").constructor;")();
    } catch (e) {}
  }),
  (Le = Object.getOwnPropertyDescriptor))
)
  try {
    Le({}, "");
  } catch (fc) {
    Le = null;
  }
if (
  ((ke = function () {
    throw new Ne();
  }),
  (Ue = Le
    ? (function () {
        try {
          return ke;
        } catch (t) {
          try {
            return Le(arguments, "callee").get;
          } catch (e) {
            return ke;
          }
        }
      })()
    : ke),
  (Ge = ye()),
  (He = be()),
  (je =
    Object.getPrototypeOf ||
    (He
      ? function (t) {
          return t.__proto__;
        }
      : null)),
  (Xe = {}),
  (Ve = "undefined" != typeof Uint8Array && je ? je(Uint8Array) : De),
  (ze = {
    "%AggregateError%":
      "undefined" == typeof AggregateError ? De : AggregateError,
    "%Array%": Array,
    "%ArrayBuffer%": "undefined" == typeof ArrayBuffer ? De : ArrayBuffer,
    "%ArrayIteratorPrototype%": Ge && je ? je([][Symbol.iterator]()) : De,
    "%AsyncFromSyncIteratorPrototype%": De,
    "%AsyncFunction%": Xe,
    "%AsyncGenerator%": Xe,
    "%AsyncGeneratorFunction%": Xe,
    "%AsyncIteratorPrototype%": Xe,
    "%Atomics%": "undefined" == typeof Atomics ? De : Atomics,
    "%BigInt%": "undefined" == typeof BigInt ? De : BigInt,
    "%BigInt64Array%": "undefined" == typeof BigInt64Array ? De : BigInt64Array,
    "%BigUint64Array%":
      "undefined" == typeof BigUint64Array ? De : BigUint64Array,
    "%Boolean%": Boolean,
    "%DataView%": "undefined" == typeof DataView ? De : DataView,
    "%Date%": Date,
    "%decodeURI%": decodeURI,
    "%decodeURIComponent%": decodeURIComponent,
    "%encodeURI%": encodeURI,
    "%encodeURIComponent%": encodeURIComponent,
    "%Error%": Error,
    "%eval%": eval,
    "%EvalError%": EvalError,
    "%Float32Array%": "undefined" == typeof Float32Array ? De : Float32Array,
    "%Float64Array%": "undefined" == typeof Float64Array ? De : Float64Array,
    "%FinalizationRegistry%":
      "undefined" == typeof FinalizationRegistry ? De : FinalizationRegistry,
    "%Function%": Be,
    "%GeneratorFunction%": Xe,
    "%Int8Array%": "undefined" == typeof Int8Array ? De : Int8Array,
    "%Int16Array%": "undefined" == typeof Int16Array ? De : Int16Array,
    "%Int32Array%": "undefined" == typeof Int32Array ? De : Int32Array,
    "%isFinite%": isFinite,
    "%isNaN%": isNaN,
    "%IteratorPrototype%": Ge && je ? je(je([][Symbol.iterator]())) : De,
    "%JSON%": "object" == typeof JSON ? JSON : De,
    "%Map%": "undefined" == typeof Map ? De : Map,
    "%MapIteratorPrototype%":
      "undefined" != typeof Map && Ge && je
        ? je(new Map()[Symbol.iterator]())
        : De,
    "%Math%": Math,
    "%Number%": Number,
    "%Object%": Object,
    "%parseFloat%": parseFloat,
    "%parseInt%": parseInt,
    "%Promise%": "undefined" == typeof Promise ? De : Promise,
    "%Proxy%": "undefined" == typeof Proxy ? De : Proxy,
    "%RangeError%": RangeError,
    "%ReferenceError%": ReferenceError,
    "%Reflect%": "undefined" == typeof Reflect ? De : Reflect,
    "%RegExp%": RegExp,
    "%Set%": "undefined" == typeof Set ? De : Set,
    "%SetIteratorPrototype%":
      "undefined" != typeof Set && Ge && je
        ? je(new Set()[Symbol.iterator]())
        : De,
    "%SharedArrayBuffer%":
      "undefined" == typeof SharedArrayBuffer ? De : SharedArrayBuffer,
    "%String%": String,
    "%StringIteratorPrototype%": Ge && je ? je(""[Symbol.iterator]()) : De,
    "%Symbol%": Ge ? Symbol : De,
    "%SyntaxError%": Oe,
    "%ThrowTypeError%": Ue,
    "%TypedArray%": Ve,
    "%TypeError%": Ne,
    "%Uint8Array%": "undefined" == typeof Uint8Array ? De : Uint8Array,
    "%Uint8ClampedArray%":
      "undefined" == typeof Uint8ClampedArray ? De : Uint8ClampedArray,
    "%Uint16Array%": "undefined" == typeof Uint16Array ? De : Uint16Array,
    "%Uint32Array%": "undefined" == typeof Uint32Array ? De : Uint32Array,
    "%URIError%": URIError,
    "%WeakMap%": "undefined" == typeof WeakMap ? De : WeakMap,
    "%WeakRef%": "undefined" == typeof WeakRef ? De : WeakRef,
    "%WeakSet%": "undefined" == typeof WeakSet ? De : WeakSet,
  }),
  je)
)
  try {
    null.error;
  } catch (fc) {
    (We = je(je(fc))), (ze["%Error.prototype%"] = We);
  }
($e = function t(e) {
  var r, i, s;
  return (
    "%AsyncFunction%" === e
      ? (r = Fe("async function () {}"))
      : "%GeneratorFunction%" === e
      ? (r = Fe("function* () {}"))
      : "%AsyncGeneratorFunction%" === e
      ? (r = Fe("async function* () {}"))
      : "%AsyncGenerator%" === e
      ? (i = t("%AsyncGeneratorFunction%")) && (r = i.prototype)
      : "%AsyncIteratorPrototype%" === e &&
        (s = t("%AsyncGenerator%")) &&
        je &&
        (r = je(s.prototype)),
    (ze[e] = r),
    r
  );
}),
  (Ye = {
    "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
    "%ArrayPrototype%": ["Array", "prototype"],
    "%ArrayProto_entries%": ["Array", "prototype", "entries"],
    "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
    "%ArrayProto_keys%": ["Array", "prototype", "keys"],
    "%ArrayProto_values%": ["Array", "prototype", "values"],
    "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
    "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
    "%AsyncGeneratorPrototype%": [
      "AsyncGeneratorFunction",
      "prototype",
      "prototype",
    ],
    "%BooleanPrototype%": ["Boolean", "prototype"],
    "%DataViewPrototype%": ["DataView", "prototype"],
    "%DatePrototype%": ["Date", "prototype"],
    "%ErrorPrototype%": ["Error", "prototype"],
    "%EvalErrorPrototype%": ["EvalError", "prototype"],
    "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
    "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
    "%FunctionPrototype%": ["Function", "prototype"],
    "%Generator%": ["GeneratorFunction", "prototype"],
    "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
    "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
    "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
    "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
    "%JSONParse%": ["JSON", "parse"],
    "%JSONStringify%": ["JSON", "stringify"],
    "%MapPrototype%": ["Map", "prototype"],
    "%NumberPrototype%": ["Number", "prototype"],
    "%ObjectPrototype%": ["Object", "prototype"],
    "%ObjProto_toString%": ["Object", "prototype", "toString"],
    "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
    "%PromisePrototype%": ["Promise", "prototype"],
    "%PromiseProto_then%": ["Promise", "prototype", "then"],
    "%Promise_all%": ["Promise", "all"],
    "%Promise_reject%": ["Promise", "reject"],
    "%Promise_resolve%": ["Promise", "resolve"],
    "%RangeErrorPrototype%": ["RangeError", "prototype"],
    "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
    "%RegExpPrototype%": ["RegExp", "prototype"],
    "%SetPrototype%": ["Set", "prototype"],
    "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
    "%StringPrototype%": ["String", "prototype"],
    "%SymbolPrototype%": ["Symbol", "prototype"],
    "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
    "%TypedArrayPrototype%": ["TypedArray", "prototype"],
    "%TypeErrorPrototype%": ["TypeError", "prototype"],
    "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
    "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
    "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
    "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
    "%URIErrorPrototype%": ["URIError", "prototype"],
    "%WeakMapPrototype%": ["WeakMap", "prototype"],
    "%WeakSetPrototype%": ["WeakSet", "prototype"],
  }),
  (Ke = Me),
  (Ze = (qe = Ie).call(Function.call, Array.prototype.concat)),
  (Qe = qe.call(Function.apply, Array.prototype.splice)),
  (Je = qe.call(Function.call, String.prototype.replace)),
  (tr = qe.call(Function.call, String.prototype.slice)),
  (er = qe.call(Function.call, RegExp.prototype.exec)),
  (rr =
    /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g),
  (ir = /\\(\\)?/g),
  (sr = function (t) {
    var e,
      r = tr(t, 0, 1),
      i = tr(t, -1);
    if ("%" === r && "%" !== i)
      throw new Oe("invalid intrinsic syntax, expected closing `%`");
    if ("%" === i && "%" !== r)
      throw new Oe("invalid intrinsic syntax, expected opening `%`");
    return (
      (e = []),
      Je(t, rr, function (t, r, i, s) {
        e[e.length] = i ? Je(s, ir, "$1") : r || t;
      }),
      e
    );
  }),
  (nr = function (t, e) {
    var r,
      i,
      s = t;
    if ((Ke(Ye, s) && (s = "%" + (r = Ye[s])[0] + "%"), Ke(ze, s))) {
      if (((i = ze[s]) === Xe && (i = $e(s)), void 0 === i && !e))
        throw new Ne(
          "intrinsic " +
            t +
            " exists, but is not available. Please file an issue!"
        );
      return { alias: r, name: s, value: i };
    }
    throw new Oe("intrinsic " + t + " does not exist!");
  }),
  (or = function (t, e) {
    var r, i, s, n, o, a, h, l, u, c, d, p, f;
    if ("string" != typeof t || 0 === t.length)
      throw new Ne("intrinsic name must be a non-empty string");
    if (arguments.length > 1 && "boolean" != typeof e)
      throw new Ne('"allowMissing" argument must be a boolean');
    if (null === er(/^%?[^%]*%?$/, t))
      throw new Oe(
        "`%` may not be present anywhere but at the beginning and end of the intrinsic name"
      );
    for (
      i = (r = sr(t)).length > 0 ? r[0] : "",
        n = (s = nr("%" + i + "%", e)).name,
        o = s.value,
        a = !1,
        (h = s.alias) && ((i = h[0]), Qe(r, Ze([0, 1], h))),
        l = 1,
        u = !0;
      l < r.length;
      l += 1
    ) {
      if (
        ((c = r[l]),
        (d = tr(c, 0, 1)),
        (p = tr(c, -1)),
        ('"' === d ||
          "'" === d ||
          "`" === d ||
          '"' === p ||
          "'" === p ||
          "`" === p) &&
          d !== p)
      )
        throw new Oe("property names with quotes must have matching quotes");
      if (
        (("constructor" !== c && u) || (a = !0),
        Ke(ze, (n = "%" + (i += "." + c) + "%")))
      )
        o = ze[n];
      else if (null != o) {
        if (!(c in o)) {
          if (!e)
            throw new Ne(
              "base intrinsic for " +
                t +
                " exists, but the property is not available."
            );
          return;
        }
        Le && l + 1 >= r.length
          ? (o =
              (u = !!(f = Le(o, c))) &&
              "get" in f &&
              !("originalValue" in f.get)
                ? f.get
                : o[c])
          : ((u = Ke(o, c)), (o = o[c])),
          u && !a && (ze[n] = o);
      }
    }
    return o;
  }),
  (function (t) {
    var e,
      r = Ie,
      i = or,
      s = i("%Function.prototype.apply%"),
      n = i("%Function.prototype.call%"),
      o = i("%Reflect.apply%", !0) || r.call(n, s),
      a = i("%Object.getOwnPropertyDescriptor%", !0),
      h = i("%Object.defineProperty%", !0),
      l = i("%Math.max%");
    if (h)
      try {
        h({}, "a", { value: 1 });
      } catch (fc) {
        h = null;
      }
    (t.exports = function (t) {
      var e = o(r, n, arguments);
      return (
        a &&
          h &&
          a(e, "length").configurable &&
          h(e, "length", {
            value: 1 + l(0, t.length - (arguments.length - 1)),
          }),
        e
      );
    }),
      (e = function () {
        return o(r, s, arguments);
      }),
      h ? h(t.exports, "apply", { value: e }) : (t.exports.apply = e);
  })((ar = { exports: {} })),
  (ur = (lr = ar.exports)((hr = or)("String.prototype.indexOf"))),
  (cr = function (t, e) {
    var r = hr(t, !!e);
    return "function" == typeof r && ur(t, ".prototype.") > -1 ? lr(r) : r;
  });
const bn = r(
  Object.freeze(
    Object.defineProperty(
      { __proto__: null, default: {} },
      Symbol.toStringTag,
      { value: "Module" }
    )
  )
);
(dr = "function" == typeof Map && Map.prototype),
  (pr =
    Object.getOwnPropertyDescriptor && dr
      ? Object.getOwnPropertyDescriptor(Map.prototype, "size")
      : null),
  (fr = dr && pr && "function" == typeof pr.get ? pr.get : null),
  (mr = dr && Map.prototype.forEach),
  (gr = "function" == typeof Set && Set.prototype),
  (_r =
    Object.getOwnPropertyDescriptor && gr
      ? Object.getOwnPropertyDescriptor(Set.prototype, "size")
      : null),
  (yr = gr && _r && "function" == typeof _r.get ? _r.get : null),
  (vr = gr && Set.prototype.forEach),
  (xr = "function" == typeof WeakMap && WeakMap.prototype),
  (br = xr ? WeakMap.prototype.has : null),
  (Er = "function" == typeof WeakSet && WeakSet.prototype),
  (Tr = Er ? WeakSet.prototype.has : null),
  (Ar = "function" == typeof WeakRef && WeakRef.prototype),
  (wr = Ar ? WeakRef.prototype.deref : null),
  (Sr = Boolean.prototype.valueOf),
  (Rr = Object.prototype.toString),
  (Ir = Function.prototype.toString),
  (Cr = String.prototype.match),
  (Pr = String.prototype.slice),
  (Mr = String.prototype.replace),
  (Dr = String.prototype.toUpperCase),
  (Or = String.prototype.toLowerCase),
  (Br = RegExp.prototype.test),
  (Nr = Array.prototype.concat),
  (Fr = Array.prototype.join),
  (Lr = Array.prototype.slice),
  (kr = Math.floor),
  (Ur = "function" == typeof BigInt ? BigInt.prototype.valueOf : null),
  (Gr = Object.getOwnPropertySymbols),
  (Hr =
    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
      ? Symbol.prototype.toString
      : null),
  (jr = "function" == typeof Symbol && "object" == typeof Symbol.iterator),
  (Xr =
    "function" == typeof Symbol && Symbol.toStringTag && (Symbol.toStringTag, 1)
      ? Symbol.toStringTag
      : null),
  (Vr = Object.prototype.propertyIsEnumerable),
  (zr =
    ("function" == typeof Reflect
      ? Reflect.getPrototypeOf
      : Object.getPrototypeOf) ||
    ([].__proto__ === Array.prototype
      ? function (t) {
          return t.__proto__;
        }
      : null)),
  ($r = (Wr = bn).custom),
  (Yr = B($r) ? $r : null),
  (qr = function t(e, r, i, s) {
    function n(e, r, n) {
      if ((r && (s = Lr.call(s)).push(r), n)) {
        var o = { depth: I.depth };
        return (
          N(I, "quoteStyle") && (o.quoteStyle = I.quoteStyle), t(e, o, i + 1, s)
        );
      }
      return t(e, I, i + 1, s);
    }
    var o,
      a,
      h,
      l,
      u,
      c,
      d,
      p,
      f,
      m,
      g,
      _,
      y,
      v,
      x,
      b,
      E,
      T,
      A,
      w,
      S,
      R,
      I = r || {};
    if (
      N(I, "quoteStyle") &&
      "single" !== I.quoteStyle &&
      "double" !== I.quoteStyle
    )
      throw new TypeError('option "quoteStyle" must be "single" or "double"');
    if (
      N(I, "maxStringLength") &&
      ("number" == typeof I.maxStringLength
        ? I.maxStringLength < 0 && I.maxStringLength !== 1 / 0
        : null !== I.maxStringLength)
    )
      throw new TypeError(
        'option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`'
      );
    if (
      "boolean" != typeof (o = !N(I, "customInspect") || I.customInspect) &&
      "symbol" !== o
    )
      throw new TypeError(
        "option \"customInspect\", if provided, must be `true`, `false`, or `'symbol'`"
      );
    if (
      N(I, "indent") &&
      null !== I.indent &&
      "\t" !== I.indent &&
      !(parseInt(I.indent, 10) === I.indent && I.indent > 0)
    )
      throw new TypeError(
        'option "indent" must be "\\t", an integer > 0, or `null`'
      );
    if (N(I, "numericSeparator") && "boolean" != typeof I.numericSeparator)
      throw new TypeError(
        'option "numericSeparator", if provided, must be `true` or `false`'
      );
    if (((a = I.numericSeparator), void 0 === e)) return "undefined";
    if (null === e) return "null";
    if ("boolean" == typeof e) return e ? "true" : "false";
    if ("string" == typeof e) return k(e, I);
    if ("number" == typeof e)
      return 0 === e
        ? 1 / 0 / e > 0
          ? "0"
          : "-0"
        : ((h = String(e)), a ? C(e, h) : h);
    if ("bigint" == typeof e) return (l = String(e) + "n"), a ? C(e, l) : l;
    if (
      ((u = void 0 === I.depth ? 5 : I.depth),
      void 0 === i && (i = 0),
      i >= u && u > 0 && "object" == typeof e)
    )
      return D(e) ? "[Array]" : "[Object]";
    if (
      ((c = (function (t, e) {
        var r;
        if ("\t" === t.indent) r = "\t";
        else {
          if (!("number" == typeof t.indent && t.indent > 0)) return null;
          r = Fr.call(Array(t.indent + 1), " ");
        }
        return { base: r, prev: Fr.call(Array(e + 1), r) };
      })(I, i)),
      void 0 === s)
    )
      s = [];
    else if (L(s, e) >= 0) return "[Circular]";
    if ("function" == typeof e && !O(e))
      return (
        "[Function" +
        ((d = (function (t) {
          if (t.name) return t.name;
          var e = Cr.call(Ir.call(t), /^function\s*([\w$]+)/);
          return e ? e[1] : null;
        })(e))
          ? ": " + d
          : " (anonymous)") +
        "]" +
        ((p = V(e, n)).length > 0 ? " { " + Fr.call(p, ", ") + " }" : "")
      );
    if (B(e))
      return (
        (f = jr
          ? Mr.call(String(e), /^(Symbol\(.*\))_[^)]*$/, "$1")
          : Hr.call(e)),
        "object" != typeof e || jr ? f : G(f)
      );
    if (
      (R = e) &&
      "object" == typeof R &&
      (("undefined" != typeof HTMLElement && R instanceof HTMLElement) ||
        ("string" == typeof R.nodeName && "function" == typeof R.getAttribute))
    ) {
      for (
        m = "<" + Or.call(String(e.nodeName)), g = e.attributes || [], _ = 0;
        _ < g.length;
        _++
      )
        m += " " + g[_].name + "=" + P(M(g[_].value), "double", I);
      return (
        (m += ">"),
        e.childNodes && e.childNodes.length && (m += "..."),
        m + "</" + Or.call(String(e.nodeName)) + ">"
      );
    }
    if (D(e))
      return 0 === e.length
        ? "[]"
        : ((y = V(e, n)),
          c &&
          !(function (t) {
            for (var e = 0; e < t.length; e++)
              if (L(t[e], "\n") >= 0) return !1;
            return !0;
          })(y)
            ? "[" + X(y, c) + "]"
            : "[ " + Fr.call(y, ", ") + " ]");
    if (
      (function (t) {
        return !(
          "[object Error]" !== F(t) ||
          (Xr && "object" == typeof t && Xr in t)
        );
      })(e)
    )
      return (
        (v = V(e, n)),
        "cause" in Error.prototype || !("cause" in e) || Vr.call(e, "cause")
          ? 0 === v.length
            ? "[" + String(e) + "]"
            : "{ [" + String(e) + "] " + Fr.call(v, ", ") + " }"
          : "{ [" +
            String(e) +
            "] " +
            Fr.call(Nr.call("[cause]: " + n(e.cause), v), ", ") +
            " }"
      );
    if ("object" == typeof e && o) {
      if (Yr && "function" == typeof e[Yr] && Wr)
        return Wr(e, { depth: u - i });
      if ("symbol" !== o && "function" == typeof e.inspect) return e.inspect();
    }
    return (function (t) {
      if (!fr || !t || "object" != typeof t) return !1;
      try {
        fr.call(t);
        try {
          yr.call(t);
        } catch (m) {
          return !0;
        }
        return t instanceof Map;
      } catch (fc) {}
      return !1;
    })(e)
      ? ((x = []),
        mr &&
          mr.call(e, function (t, r) {
            x.push(n(r, e, !0) + " => " + n(t, e));
          }),
        j("Map", fr.call(e), x, c))
      : (function (t) {
          if (!yr || !t || "object" != typeof t) return !1;
          try {
            yr.call(t);
            try {
              fr.call(t);
            } catch (e) {
              return !0;
            }
            return t instanceof Set;
          } catch (fc) {}
          return !1;
        })(e)
      ? ((b = []),
        vr &&
          vr.call(e, function (t) {
            b.push(n(t, e));
          }),
        j("Set", yr.call(e), b, c))
      : (function (t) {
          if (!br || !t || "object" != typeof t) return !1;
          try {
            br.call(t, br);
            try {
              Tr.call(t, Tr);
            } catch (m) {
              return !0;
            }
            return t instanceof WeakMap;
          } catch (fc) {}
          return !1;
        })(e)
      ? H("WeakMap")
      : (function (t) {
          if (!Tr || !t || "object" != typeof t) return !1;
          try {
            Tr.call(t, Tr);
            try {
              br.call(t, br);
            } catch (m) {
              return !0;
            }
            return t instanceof WeakSet;
          } catch (fc) {}
          return !1;
        })(e)
      ? H("WeakSet")
      : (function (t) {
          if (!wr || !t || "object" != typeof t) return !1;
          try {
            return wr.call(t), !0;
          } catch (fc) {}
          return !1;
        })(e)
      ? H("WeakRef")
      : (function (t) {
          return !(
            "[object Number]" !== F(t) ||
            (Xr && "object" == typeof t && Xr in t)
          );
        })(e)
      ? G(n(Number(e)))
      : (function (t) {
          if (!t || "object" != typeof t || !Ur) return !1;
          try {
            return Ur.call(t), !0;
          } catch (fc) {}
          return !1;
        })(e)
      ? G(n(Ur.call(e)))
      : (function (t) {
          return !(
            "[object Boolean]" !== F(t) ||
            (Xr && "object" == typeof t && Xr in t)
          );
        })(e)
      ? G(Sr.call(e))
      : (function (t) {
          return !(
            "[object String]" !== F(t) ||
            (Xr && "object" == typeof t && Xr in t)
          );
        })(e)
      ? G(n(String(e)))
      : e === ue
      ? "undefined" != typeof window
        ? "{ [object Window] }"
        : "{ [object global] }"
      : (function (t) {
          return !(
            "[object Date]" !== F(t) ||
            (Xr && "object" == typeof t && Xr in t)
          );
        })(e) || O(e)
      ? String(e)
      : ((E = V(e, n)),
        (T = zr
          ? zr(e) === Object.prototype
          : e instanceof Object || e.constructor === Object),
        (A = e instanceof Object ? "" : "null prototype"),
        (w =
          !T && Xr && Object(e) === e && Xr in e
            ? Pr.call(F(e), 8, -1)
            : A
            ? "Object"
            : ""),
        (S =
          (T || "function" != typeof e.constructor
            ? ""
            : e.constructor.name
            ? e.constructor.name + " "
            : "") +
          (w || A
            ? "[" + Fr.call(Nr.call([], w || [], A || []), ": ") + "] "
            : "")),
        0 === E.length
          ? S + "{}"
          : c
          ? S + "{" + X(E, c) + "}"
          : S + "{ " + Fr.call(E, ", ") + " }");
  }),
  (Kr =
    Object.prototype.hasOwnProperty ||
    function (t) {
      return t in this;
    }),
  (Qr = cr),
  (Jr = qr),
  (ti = (Zr = or)("%TypeError%")),
  (ei = Zr("%WeakMap%", !0)),
  (ri = Zr("%Map%", !0)),
  (ii = Qr("WeakMap.prototype.get", !0)),
  (si = Qr("WeakMap.prototype.set", !0)),
  (ni = Qr("WeakMap.prototype.has", !0)),
  (oi = Qr("Map.prototype.get", !0)),
  (ai = Qr("Map.prototype.set", !0)),
  (hi = Qr("Map.prototype.has", !0)),
  (li = function (t, e) {
    for (var r, i = t; null !== (r = i.next); i = r)
      if (r.key === e)
        return (i.next = r.next), (r.next = t.next), (t.next = r), r;
  }),
  (ui = function (t, e) {
    var r = li(t, e);
    return r && r.value;
  }),
  (ci = function (t, e, r) {
    var i = li(t, e);
    i ? (i.value = r) : (t.next = { key: e, next: t.next, value: r });
  }),
  (di = function (t, e) {
    return !!li(t, e);
  }),
  (pi = function () {
    var t,
      e,
      r,
      i = {
        assert: function (t) {
          if (!i.has(t)) throw new ti("Side channel does not contain " + Jr(t));
        },
        get: function (i) {
          if (ei && i && ("object" == typeof i || "function" == typeof i)) {
            if (t) return ii(t, i);
          } else if (ri) {
            if (e) return oi(e, i);
          } else if (r) return ui(r, i);
        },
        has: function (i) {
          if (ei && i && ("object" == typeof i || "function" == typeof i)) {
            if (t) return ni(t, i);
          } else if (ri) {
            if (e) return hi(e, i);
          } else if (r) return di(r, i);
          return !1;
        },
        set: function (i, s) {
          ei && i && ("object" == typeof i || "function" == typeof i)
            ? (t || (t = new ei()), si(t, i, s))
            : ri
            ? (e || (e = new ri()), ai(e, i, s))
            : (r || (r = { key: {}, next: null }), ci(r, i, s));
        },
      };
    return i;
  }),
  (fi = String.prototype.replace),
  (mi = /%20/g),
  (_i = gi =
    {
      default: "RFC3986",
      formatters: {
        RFC1738: function (t) {
          return fi.call(t, mi, "+");
        },
        RFC3986: function (t) {
          return String(t);
        },
      },
      RFC1738: "RFC1738",
      RFC3986: "RFC3986",
    }),
  (yi = Object.prototype.hasOwnProperty),
  (vi = Array.isArray),
  (xi = (function () {
    var t,
      e = [];
    for (t = 0; t < 256; ++t)
      e.push("%" + ((t < 16 ? "0" : "") + t.toString(16)).toUpperCase());
    return e;
  })()),
  (bi = function (t) {
    for (var e, r, i, s; t.length > 1; )
      if (((r = (e = t.pop()).obj[e.prop]), vi(r))) {
        for (i = [], s = 0; s < r.length; ++s) void 0 !== r[s] && i.push(r[s]);
        e.obj[e.prop] = i;
      }
  }),
  (Ti = function t(e, r, i) {
    if (!r) return e;
    if ("object" != typeof r) {
      if (vi(e)) e.push(r);
      else {
        if (!e || "object" != typeof e) return [e, r];
        ((i && (i.plainObjects || i.allowPrototypes)) ||
          !yi.call(Object.prototype, r)) &&
          (e[r] = !0);
      }
      return e;
    }
    if (!e || "object" != typeof e) return [e].concat(r);
    var s = e;
    return (
      vi(e) && !vi(r) && (s = Ei(e, i)),
      vi(e) && vi(r)
        ? (r.forEach(function (r, s) {
            if (yi.call(e, s)) {
              var n = e[s];
              n && "object" == typeof n && r && "object" == typeof r
                ? (e[s] = t(n, r, i))
                : e.push(r);
            } else e[s] = r;
          }),
          e)
        : Object.keys(r).reduce(function (e, s) {
            var n = r[s];
            return yi.call(e, s) ? (e[s] = t(e[s], n, i)) : (e[s] = n), e;
          }, s)
    );
  }),
  (wi = pi),
  (Si = Ai =
    {
      arrayToObject: (Ei = function (t, e) {
        var r,
          i = e && e.plainObjects ? Object.create(null) : {};
        for (r = 0; r < t.length; ++r) void 0 !== t[r] && (i[r] = t[r]);
        return i;
      }),
      assign: function (t, e) {
        return Object.keys(e).reduce(function (t, r) {
          return (t[r] = e[r]), t;
        }, t);
      },
      combine: function (t, e) {
        return [].concat(t, e);
      },
      compact: function (t) {
        var e,
          r,
          i,
          s,
          n,
          o,
          a,
          h = [{ obj: { o: t }, prop: "o" }],
          l = [];
        for (e = 0; e < h.length; ++e)
          for (
            i = (r = h[e]).obj[r.prop], s = Object.keys(i), n = 0;
            n < s.length;
            ++n
          )
            "object" == typeof (a = i[(o = s[n])]) &&
              null !== a &&
              -1 === l.indexOf(a) &&
              (h.push({ obj: i, prop: o }), l.push(a));
        return bi(h), t;
      },
      decode: function (t, e, r) {
        var i = t.replace(/\+/g, " ");
        if ("iso-8859-1" === r) return i.replace(/%[0-9a-f]{2}/gi, unescape);
        try {
          return decodeURIComponent(i);
        } catch (fc) {
          return i;
        }
      },
      encode: function (t, e, r, i, s) {
        var n, o, a, h;
        if (0 === t.length) return t;
        if (
          ((n = t),
          "symbol" == typeof t
            ? (n = Symbol.prototype.toString.call(t))
            : "string" != typeof t && (n = String(t)),
          "iso-8859-1" === r)
        )
          return escape(n).replace(/%u[0-9a-f]{4}/gi, function (t) {
            return "%26%23" + parseInt(t.slice(2), 16) + "%3B";
          });
        for (o = "", a = 0; a < n.length; ++a)
          45 === (h = n.charCodeAt(a)) ||
          46 === h ||
          95 === h ||
          126 === h ||
          (h >= 48 && h <= 57) ||
          (h >= 65 && h <= 90) ||
          (h >= 97 && h <= 122) ||
          (s === _i.RFC1738 && (40 === h || 41 === h))
            ? (o += n.charAt(a))
            : h < 128
            ? (o += xi[h])
            : h < 2048
            ? (o += xi[192 | (h >> 6)] + xi[128 | (63 & h)])
            : h < 55296 || h >= 57344
            ? (o +=
                xi[224 | (h >> 12)] +
                xi[128 | ((h >> 6) & 63)] +
                xi[128 | (63 & h)])
            : ((a += 1),
              (h = 65536 + (((1023 & h) << 10) | (1023 & n.charCodeAt(a)))),
              (o +=
                xi[240 | (h >> 18)] +
                xi[128 | ((h >> 12) & 63)] +
                xi[128 | ((h >> 6) & 63)] +
                xi[128 | (63 & h)]));
        return o;
      },
      isBuffer: function (t) {
        return !(
          !t ||
          "object" != typeof t ||
          !(
            t.constructor &&
            t.constructor.isBuffer &&
            t.constructor.isBuffer(t)
          )
        );
      },
      isRegExp: function (t) {
        return "[object RegExp]" === Object.prototype.toString.call(t);
      },
      maybeMap: function (t, e) {
        var r, i;
        if (vi(t)) {
          for (r = [], i = 0; i < t.length; i += 1) r.push(e(t[i]));
          return r;
        }
        return e(t);
      },
      merge: Ti,
    }),
  (Ri = gi),
  (Ii = Object.prototype.hasOwnProperty),
  (Ci = {
    brackets: function (t) {
      return t + "[]";
    },
    comma: "comma",
    indices: function (t, e) {
      return t + "[" + e + "]";
    },
    repeat: function (t) {
      return t;
    },
  }),
  (Pi = Array.isArray),
  (Mi = Array.prototype.push),
  (Di = function (t, e) {
    Mi.apply(t, Pi(e) ? e : [e]);
  }),
  (Oi = Date.prototype.toISOString),
  (Bi = Ri.default),
  (Ni = {
    addQueryPrefix: !1,
    allowDots: !1,
    charset: "utf-8",
    charsetSentinel: !1,
    delimiter: "&",
    encode: !0,
    encoder: Si.encode,
    encodeValuesOnly: !1,
    format: Bi,
    formatter: Ri.formatters[Bi],
    indices: !1,
    serializeDate: function (t) {
      return Oi.call(t);
    },
    skipNulls: !1,
    strictNullHandling: !1,
  }),
  (Fi = function (t) {
    return (
      "string" == typeof t ||
      "number" == typeof t ||
      "boolean" == typeof t ||
      "symbol" == typeof t ||
      "bigint" == typeof t
    );
  }),
  (Li = {}),
  (ki = function t(e, r, i, s, n, o, a, h, l, u, c, d, p, f, m, g) {
    for (
      var _, y, v, x, b, E, T, A, w, S, R = e, I = g, C = 0, P = !1;
      void 0 !== (I = I.get(Li)) && !P;

    ) {
      if (((C += 1), void 0 !== (_ = I.get(e)))) {
        if (_ === C) throw new RangeError("Cyclic object value");
        P = !0;
      }
      void 0 === I.get(Li) && (C = 0);
    }
    if (
      ("function" == typeof h
        ? (R = h(r, R))
        : R instanceof Date
        ? (R = c(R))
        : "comma" === i &&
          Pi(R) &&
          (R = Si.maybeMap(R, function (t) {
            return t instanceof Date ? c(t) : t;
          })),
      null === R)
    ) {
      if (n) return a && !f ? a(r, Ni.encoder, m, "key", d) : r;
      R = "";
    }
    if (Fi(R) || Si.isBuffer(R))
      return a
        ? [
            p(f ? r : a(r, Ni.encoder, m, "key", d)) +
              "=" +
              p(a(R, Ni.encoder, m, "value", d)),
          ]
        : [p(r) + "=" + p(String(R))];
    if (((y = []), void 0 === R)) return y;
    for (
      "comma" === i && Pi(R)
        ? (f && a && (R = Si.maybeMap(R, a)),
          (v = [{ value: R.length > 0 ? R.join(",") || null : void 0 }]))
        : Pi(h)
        ? (v = h)
        : ((x = Object.keys(R)), (v = l ? x.sort(l) : x)),
        b = s && Pi(R) && 1 === R.length ? r + "[]" : r,
        E = 0;
      E < v.length;
      ++E
    )
      (A =
        "object" == typeof (T = v[E]) && void 0 !== T.value ? T.value : R[T]),
        (o && null === A) ||
          ((w = Pi(R)
            ? "function" == typeof i
              ? i(b, T)
              : b
            : b + (u ? "." + T : "[" + T + "]")),
          g.set(e, C),
          (S = wi()).set(Li, g),
          Di(
            y,
            t(
              A,
              w,
              i,
              s,
              n,
              o,
              "comma" === i && f && Pi(R) ? null : a,
              h,
              l,
              u,
              c,
              d,
              p,
              f,
              m,
              S
            )
          ));
    return y;
  }),
  (Ui = function (t) {
    var e, r, i, s;
    if (!t) return Ni;
    if (
      null !== t.encoder &&
      void 0 !== t.encoder &&
      "function" != typeof t.encoder
    )
      throw new TypeError("Encoder has to be a function.");
    if (
      ((e = t.charset || Ni.charset),
      void 0 !== t.charset &&
        "utf-8" !== t.charset &&
        "iso-8859-1" !== t.charset)
    )
      throw new TypeError(
        "The charset option must be either utf-8, iso-8859-1, or undefined"
      );
    if (((r = Ri.default), void 0 !== t.format)) {
      if (!Ii.call(Ri.formatters, t.format))
        throw new TypeError("Unknown format option provided.");
      r = t.format;
    }
    return (
      (i = Ri.formatters[r]),
      (s = Ni.filter),
      ("function" == typeof t.filter || Pi(t.filter)) && (s = t.filter),
      {
        addQueryPrefix:
          "boolean" == typeof t.addQueryPrefix
            ? t.addQueryPrefix
            : Ni.addQueryPrefix,
        allowDots: void 0 === t.allowDots ? Ni.allowDots : !!t.allowDots,
        charset: e,
        charsetSentinel:
          "boolean" == typeof t.charsetSentinel
            ? t.charsetSentinel
            : Ni.charsetSentinel,
        delimiter: void 0 === t.delimiter ? Ni.delimiter : t.delimiter,
        encode: "boolean" == typeof t.encode ? t.encode : Ni.encode,
        encoder: "function" == typeof t.encoder ? t.encoder : Ni.encoder,
        encodeValuesOnly:
          "boolean" == typeof t.encodeValuesOnly
            ? t.encodeValuesOnly
            : Ni.encodeValuesOnly,
        filter: s,
        format: r,
        formatter: i,
        serializeDate:
          "function" == typeof t.serializeDate
            ? t.serializeDate
            : Ni.serializeDate,
        skipNulls: "boolean" == typeof t.skipNulls ? t.skipNulls : Ni.skipNulls,
        sort: "function" == typeof t.sort ? t.sort : null,
        strictNullHandling:
          "boolean" == typeof t.strictNullHandling
            ? t.strictNullHandling
            : Ni.strictNullHandling,
      }
    );
  }),
  (Gi = function (t, e) {
    var r,
      i,
      s,
      n,
      o,
      a,
      h,
      l,
      u,
      c,
      d = t,
      p = Ui(e);
    if (
      ("function" == typeof p.filter
        ? (d = (0, p.filter)("", d))
        : Pi(p.filter) && (r = p.filter),
      (i = []),
      "object" != typeof d || null === d)
    )
      return "";
    if (
      ((s =
        e && e.arrayFormat in Ci
          ? e.arrayFormat
          : e && "indices" in e
          ? e.indices
            ? "indices"
            : "repeat"
          : "indices"),
      (n = Ci[s]),
      e && "commaRoundTrip" in e && "boolean" != typeof e.commaRoundTrip)
    )
      throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
    for (
      o = "comma" === n && e && e.commaRoundTrip,
        r || (r = Object.keys(d)),
        p.sort && r.sort(p.sort),
        a = wi(),
        h = 0;
      h < r.length;
      ++h
    )
      (l = r[h]),
        (p.skipNulls && null === d[l]) ||
          Di(
            i,
            ki(
              d[l],
              l,
              n,
              o,
              p.strictNullHandling,
              p.skipNulls,
              p.encode ? p.encoder : null,
              p.filter,
              p.sort,
              p.allowDots,
              p.serializeDate,
              p.format,
              p.formatter,
              p.encodeValuesOnly,
              p.charset,
              a
            )
          );
    return (
      (u = i.join(p.delimiter)),
      (c = !0 === p.addQueryPrefix ? "?" : ""),
      p.charsetSentinel &&
        ("iso-8859-1" === p.charset
          ? (c += "utf8=%26%2310003%3B&")
          : (c += "utf8=%E2%9C%93&")),
      u.length > 0 ? c + u : ""
    );
  }),
  (Hi = Ai),
  (ji = Object.prototype.hasOwnProperty),
  (Xi = Array.isArray),
  (Vi = {
    allowDots: !1,
    allowPrototypes: !1,
    allowSparse: !1,
    arrayLimit: 20,
    charset: "utf-8",
    charsetSentinel: !1,
    comma: !1,
    decoder: Hi.decode,
    delimiter: "&",
    depth: 5,
    ignoreQueryPrefix: !1,
    interpretNumericEntities: !1,
    parameterLimit: 1e3,
    parseArrays: !0,
    plainObjects: !1,
    strictNullHandling: !1,
  }),
  (zi = function (t) {
    return t.replace(/&#(\d+);/g, function (t, e) {
      return String.fromCharCode(parseInt(e, 10));
    });
  }),
  (Wi = function (t, e) {
    return t && "string" == typeof t && e.comma && t.indexOf(",") > -1
      ? t.split(",")
      : t;
  }),
  ($i = function (t, e) {
    var r,
      i,
      s,
      n,
      o,
      a,
      h = { __proto__: null },
      l = e.ignoreQueryPrefix ? t.replace(/^\?/, "") : t,
      u = e.parameterLimit === 1 / 0 ? void 0 : e.parameterLimit,
      c = l.split(e.delimiter, u),
      d = -1,
      p = e.charset;
    if (e.charsetSentinel)
      for (r = 0; r < c.length; ++r)
        0 === c[r].indexOf("utf8=") &&
          ("utf8=%E2%9C%93" === c[r]
            ? (p = "utf-8")
            : "utf8=%26%2310003%3B" === c[r] && (p = "iso-8859-1"),
          (d = r),
          (r = c.length));
    for (r = 0; r < c.length; ++r)
      r !== d &&
        (-1 ===
        (n = -1 === (s = (i = c[r]).indexOf("]=")) ? i.indexOf("=") : s + 1)
          ? ((o = e.decoder(i, Vi.decoder, p, "key")),
            (a = e.strictNullHandling ? null : ""))
          : ((o = e.decoder(i.slice(0, n), Vi.decoder, p, "key")),
            (a = Hi.maybeMap(Wi(i.slice(n + 1), e), function (t) {
              return e.decoder(t, Vi.decoder, p, "value");
            }))),
        a && e.interpretNumericEntities && "iso-8859-1" === p && (a = zi(a)),
        i.indexOf("[]=") > -1 && (a = Xi(a) ? [a] : a),
        ji.call(h, o) ? (h[o] = Hi.combine(h[o], a)) : (h[o] = a));
    return h;
  }),
  (Yi = function (t, e, r, i) {
    var s,
      n,
      o,
      a,
      h,
      l = i ? e : Wi(e, r);
    for (s = t.length - 1; s >= 0; --s)
      "[]" === (o = t[s]) && r.parseArrays
        ? (n = [].concat(l))
        : ((n = r.plainObjects ? Object.create(null) : {}),
          (a =
            "[" === o.charAt(0) && "]" === o.charAt(o.length - 1)
              ? o.slice(1, -1)
              : o),
          (h = parseInt(a, 10)),
          r.parseArrays || "" !== a
            ? !isNaN(h) &&
              o !== a &&
              String(h) === a &&
              h >= 0 &&
              r.parseArrays &&
              h <= r.arrayLimit
              ? ((n = [])[h] = l)
              : "__proto__" !== a && (n[a] = l)
            : (n = { 0: l })),
        (l = n);
    return l;
  }),
  (qi = function (t, e, r, i) {
    var s, n, o, a, h, l, u;
    if (t) {
      if (
        ((s = r.allowDots ? t.replace(/\.([^.[]+)/g, "[$1]") : t),
        (n = /(\[[^[\]]*])/),
        (o = /(\[[^[\]]*])/g),
        (l = []),
        (h = (a = r.depth > 0 && n.exec(s)) ? s.slice(0, a.index) : s))
      ) {
        if (
          !r.plainObjects &&
          ji.call(Object.prototype, h) &&
          !r.allowPrototypes
        )
          return;
        l.push(h);
      }
      for (u = 0; r.depth > 0 && null !== (a = o.exec(s)) && u < r.depth; ) {
        if (
          ((u += 1),
          !r.plainObjects &&
            ji.call(Object.prototype, a[1].slice(1, -1)) &&
            !r.allowPrototypes)
        )
          return;
        l.push(a[1]);
      }
      return a && l.push("[" + s.slice(a.index) + "]"), Yi(l, e, r, i);
    }
  }),
  (Ki = function (t) {
    if (!t) return Vi;
    if (
      null !== t.decoder &&
      void 0 !== t.decoder &&
      "function" != typeof t.decoder
    )
      throw new TypeError("Decoder has to be a function.");
    if (
      void 0 !== t.charset &&
      "utf-8" !== t.charset &&
      "iso-8859-1" !== t.charset
    )
      throw new TypeError(
        "The charset option must be either utf-8, iso-8859-1, or undefined"
      );
    var e = void 0 === t.charset ? Vi.charset : t.charset;
    return {
      allowDots: void 0 === t.allowDots ? Vi.allowDots : !!t.allowDots,
      allowPrototypes:
        "boolean" == typeof t.allowPrototypes
          ? t.allowPrototypes
          : Vi.allowPrototypes,
      allowSparse:
        "boolean" == typeof t.allowSparse ? t.allowSparse : Vi.allowSparse,
      arrayLimit:
        "number" == typeof t.arrayLimit ? t.arrayLimit : Vi.arrayLimit,
      charset: e,
      charsetSentinel:
        "boolean" == typeof t.charsetSentinel
          ? t.charsetSentinel
          : Vi.charsetSentinel,
      comma: "boolean" == typeof t.comma ? t.comma : Vi.comma,
      decoder: "function" == typeof t.decoder ? t.decoder : Vi.decoder,
      delimiter:
        "string" == typeof t.delimiter || Hi.isRegExp(t.delimiter)
          ? t.delimiter
          : Vi.delimiter,
      depth: "number" == typeof t.depth || !1 === t.depth ? +t.depth : Vi.depth,
      ignoreQueryPrefix: !0 === t.ignoreQueryPrefix,
      interpretNumericEntities:
        "boolean" == typeof t.interpretNumericEntities
          ? t.interpretNumericEntities
          : Vi.interpretNumericEntities,
      parameterLimit:
        "number" == typeof t.parameterLimit
          ? t.parameterLimit
          : Vi.parameterLimit,
      parseArrays: !1 !== t.parseArrays,
      plainObjects:
        "boolean" == typeof t.plainObjects ? t.plainObjects : Vi.plainObjects,
      strictNullHandling:
        "boolean" == typeof t.strictNullHandling
          ? t.strictNullHandling
          : Vi.strictNullHandling,
    };
  }),
  (Zi = {
    formats: gi,
    parse: function (t, e) {
      var r,
        i,
        s,
        n,
        o,
        a,
        h = Ki(e);
      if ("" === t || null == t)
        return h.plainObjects ? Object.create(null) : {};
      for (
        r = "string" == typeof t ? $i(t, h) : t,
          i = h.plainObjects ? Object.create(null) : {},
          s = Object.keys(r),
          n = 0;
        n < s.length;
        ++n
      )
        (o = s[n]),
          (a = qi(o, r[o], h, "string" == typeof t)),
          (i = Hi.merge(i, a, h));
      return !0 === h.allowSparse ? i : Hi.compact(i);
    },
    stringify: Gi,
  }),
  (Qi = fe),
  (Ji = /^([a-z0-9.+-]+:)/i),
  (ts = /:[0-9]*$/),
  (es = /^(\/\/?(?!\/)[^?\s]*)(\?[^\s]*)?$/),
  (rs = ["{", "}", "|", "\\", "^", "`"].concat([
    "<",
    ">",
    '"',
    "`",
    " ",
    "\r",
    "\n",
    "\t",
  ])),
  (is = ["'"].concat(rs)),
  (ss = ["%", "/", "?", ";", "#"].concat(is)),
  (ns = ["/", "?", "#"]),
  (os = /^[+a-z0-9A-Z_-]{0,63}$/),
  (as = /^([+a-z0-9A-Z_-]{0,63})(.*)$/),
  (hs = { javascript: !0, "javascript:": !0 }),
  (ls = { javascript: !0, "javascript:": !0 }),
  (us = {
    http: !0,
    https: !0,
    ftp: !0,
    gopher: !0,
    file: !0,
    "http:": !0,
    "https:": !0,
    "ftp:": !0,
    "gopher:": !0,
    "file:": !0,
  }),
  (cs = Zi),
  (z.prototype.parse = function (t, e, r) {
    var i,
      s,
      n,
      o,
      a,
      h,
      l,
      u,
      c,
      d,
      p,
      f,
      m,
      g,
      _,
      y,
      v,
      x,
      b,
      E,
      T,
      A,
      w,
      S,
      R,
      I,
      C,
      P,
      M,
      D,
      O;
    if ("string" != typeof t)
      throw new TypeError("Parameter 'url' must be a string, not " + typeof t);
    if (
      ((s = -1 !== (i = t.indexOf("?")) && i < t.indexOf("#") ? "?" : "#"),
      (o = /\\/g),
      ((n = t.split(s))[0] = n[0].replace(o, "/")),
      (a = (a = t = n.join(s)).trim()),
      !r && 1 === t.split("#").length && (h = es.exec(a)))
    )
      return (
        (this.path = a),
        (this.href = a),
        (this.pathname = h[1]),
        h[2]
          ? ((this.search = h[2]),
            (this.query = e
              ? cs.parse(this.search.substr(1))
              : this.search.substr(1)))
          : e && ((this.search = ""), (this.query = {})),
        this
      );
    if (
      ((l = Ji.exec(a)) &&
        ((u = (l = l[0]).toLowerCase()),
        (this.protocol = u),
        (a = a.substr(l.length))),
      (r || l || a.match(/^\/\/[^@/]+@[^@/]+/)) &&
        (!(c = "//" === a.substr(0, 2)) ||
          (l && ls[l]) ||
          ((a = a.substr(2)), (this.slashes = !0))),
      !ls[l] && (c || (l && !us[l])))
    ) {
      for (d = -1, p = 0; p < ns.length; p++)
        -1 !== (f = a.indexOf(ns[p])) && (-1 === d || f < d) && (d = f);
      for (
        -1 !== (g = -1 === d ? a.lastIndexOf("@") : a.lastIndexOf("@", d)) &&
          ((m = a.slice(0, g)),
          (a = a.slice(g + 1)),
          (this.auth = decodeURIComponent(m))),
          d = -1,
          p = 0;
        p < ss.length;
        p++
      )
        -1 !== (f = a.indexOf(ss[p])) && (-1 === d || f < d) && (d = f);
      if (
        (-1 === d && (d = a.length),
        (this.host = a.slice(0, d)),
        (a = a.slice(d)),
        this.parseHost(),
        (this.hostname = this.hostname || ""),
        !(_ =
          "[" === this.hostname[0] &&
          "]" === this.hostname[this.hostname.length - 1]))
      )
        for (p = 0, v = (y = this.hostname.split(/\./)).length; p < v; p++)
          if ((x = y[p]) && !x.match(os)) {
            for (b = "", E = 0, T = x.length; E < T; E++)
              x.charCodeAt(E) > 127 ? (b += "x") : (b += x[E]);
            if (!b.match(os)) {
              (A = y.slice(0, p)),
                (w = y.slice(p + 1)),
                (S = x.match(as)) && (A.push(S[1]), w.unshift(S[2])),
                w.length && (a = "/" + w.join(".") + a),
                (this.hostname = A.join("."));
              break;
            }
          }
      this.hostname.length > 255
        ? (this.hostname = "")
        : (this.hostname = this.hostname.toLowerCase()),
        _ || (this.hostname = Qi.toASCII(this.hostname)),
        (R = this.port ? ":" + this.port : ""),
        (I = this.hostname || ""),
        (this.host = I + R),
        (this.href += this.host),
        _ &&
          ((this.hostname = this.hostname.substr(1, this.hostname.length - 2)),
          "/" !== a[0] && (a = "/" + a));
    }
    if (!hs[u])
      for (p = 0, v = is.length; p < v; p++)
        (C = is[p]),
          -1 !== a.indexOf(C) &&
            ((P = encodeURIComponent(C)) === C && (P = escape(C)),
            (a = a.split(C).join(P)));
    return (
      -1 !== (M = a.indexOf("#")) &&
        ((this.hash = a.substr(M)), (a = a.slice(0, M))),
      -1 !== (D = a.indexOf("?"))
        ? ((this.search = a.substr(D)),
          (this.query = a.substr(D + 1)),
          e && (this.query = cs.parse(this.query)),
          (a = a.slice(0, D)))
        : e && ((this.search = ""), (this.query = {})),
      a && (this.pathname = a),
      us[u] && this.hostname && !this.pathname && (this.pathname = "/"),
      (this.pathname || this.search) &&
        ((R = this.pathname || ""),
        (O = this.search || ""),
        (this.path = R + O)),
      (this.href = this.format()),
      this
    );
  }),
  (z.prototype.format = function () {
    var t,
      e,
      r,
      i,
      s,
      n,
      o = this.auth || "";
    return (
      o && ((o = (o = encodeURIComponent(o)).replace(/%3A/i, ":")), (o += "@")),
      (t = this.protocol || ""),
      (e = this.pathname || ""),
      (r = this.hash || ""),
      (i = !1),
      (s = ""),
      this.host
        ? (i = o + this.host)
        : this.hostname &&
          ((i =
            o +
            (-1 === this.hostname.indexOf(":")
              ? this.hostname
              : "[" + this.hostname + "]")),
          this.port && (i += ":" + this.port)),
      this.query &&
        "object" == typeof this.query &&
        Object.keys(this.query).length &&
        (s = cs.stringify(this.query, {
          arrayFormat: "repeat",
          addQueryPrefix: !1,
        })),
      (n = this.search || (s && "?" + s) || ""),
      t && ":" !== t.substr(-1) && (t += ":"),
      this.slashes || ((!t || us[t]) && !1 !== i)
        ? ((i = "//" + (i || "")), e && "/" !== e.charAt(0) && (e = "/" + e))
        : i || (i = ""),
      r && "#" !== r.charAt(0) && (r = "#" + r),
      n && "?" !== n.charAt(0) && (n = "?" + n),
      t +
        i +
        (e = e.replace(/[?#]/g, function (t) {
          return encodeURIComponent(t);
        })) +
        (n = n.replace("#", "%23")) +
        r
    );
  }),
  (z.prototype.resolve = function (t) {
    return this.resolveObject(
      (function (t, e, r) {
        if (t && "object" == typeof t && t instanceof z) return t;
        var i = new z();
        return i.parse(t, !1, !0), i;
      })(t)
    ).format();
  }),
  (z.prototype.resolveObject = function (t) {
    var e,
      r,
      i,
      s,
      n,
      o,
      a,
      h,
      l,
      u,
      c,
      d,
      p,
      f,
      m,
      g,
      _,
      y,
      v,
      x,
      b,
      E,
      T,
      A,
      w,
      S;
    for (
      "string" == typeof t && ((e = new z()).parse(t, !1, !0), (t = e)),
        r = new z(),
        i = Object.keys(this),
        s = 0;
      s < i.length;
      s++
    )
      r[(n = i[s])] = this[n];
    if (((r.hash = t.hash), "" === t.href)) return (r.href = r.format()), r;
    if (t.slashes && !t.protocol) {
      for (o = Object.keys(t), a = 0; a < o.length; a++)
        "protocol" !== (h = o[a]) && (r[h] = t[h]);
      return (
        us[r.protocol] &&
          r.hostname &&
          !r.pathname &&
          ((r.pathname = "/"), (r.path = r.pathname)),
        (r.href = r.format()),
        r
      );
    }
    if (t.protocol && t.protocol !== r.protocol) {
      if (!us[t.protocol]) {
        for (l = Object.keys(t), u = 0; u < l.length; u++) r[(c = l[u])] = t[c];
        return (r.href = r.format()), r;
      }
      if (((r.protocol = t.protocol), t.host || ls[t.protocol]))
        r.pathname = t.pathname;
      else {
        for (
          d = (t.pathname || "").split("/");
          d.length && !(t.host = d.shift());

        );
        t.host || (t.host = ""),
          t.hostname || (t.hostname = ""),
          "" !== d[0] && d.unshift(""),
          d.length < 2 && d.unshift(""),
          (r.pathname = d.join("/"));
      }
      return (
        (r.search = t.search),
        (r.query = t.query),
        (r.host = t.host || ""),
        (r.auth = t.auth),
        (r.hostname = t.hostname || t.host),
        (r.port = t.port),
        (r.pathname || r.search) &&
          ((p = r.pathname || ""), (f = r.search || ""), (r.path = p + f)),
        (r.slashes = r.slashes || t.slashes),
        (r.href = r.format()),
        r
      );
    }
    if (
      ((m = r.pathname && "/" === r.pathname.charAt(0)),
      (y = _ =
        (g = t.host || (t.pathname && "/" === t.pathname.charAt(0))) ||
        m ||
        (r.host && t.pathname)),
      (v = (r.pathname && r.pathname.split("/")) || []),
      (d = (t.pathname && t.pathname.split("/")) || []),
      (x = r.protocol && !us[r.protocol]) &&
        ((r.hostname = ""),
        (r.port = null),
        r.host && ("" === v[0] ? (v[0] = r.host) : v.unshift(r.host)),
        (r.host = ""),
        t.protocol &&
          ((t.hostname = null),
          (t.port = null),
          t.host && ("" === d[0] ? (d[0] = t.host) : d.unshift(t.host)),
          (t.host = null)),
        (_ = _ && ("" === d[0] || "" === v[0]))),
      g)
    )
      (r.host = t.host || "" === t.host ? t.host : r.host),
        (r.hostname =
          t.hostname || "" === t.hostname ? t.hostname : r.hostname),
        (r.search = t.search),
        (r.query = t.query),
        (v = d);
    else if (d.length)
      v || (v = []),
        v.pop(),
        (v = v.concat(d)),
        (r.search = t.search),
        (r.query = t.query);
    else if (null != t.search)
      return (
        x &&
          ((r.host = v.shift()),
          (r.hostname = r.host),
          (b = !!(r.host && r.host.indexOf("@") > 0) && r.host.split("@")) &&
            ((r.auth = b.shift()),
            (r.hostname = b.shift()),
            (r.host = r.hostname))),
        (r.search = t.search),
        (r.query = t.query),
        (null === r.pathname && null === r.search) ||
          (r.path =
            (r.pathname ? r.pathname : "") + (r.search ? r.search : "")),
        (r.href = r.format()),
        r
      );
    if (!v.length)
      return (
        (r.pathname = null),
        r.search ? (r.path = "/" + r.search) : (r.path = null),
        (r.href = r.format()),
        r
      );
    for (
      E = v.slice(-1)[0],
        T =
          ((r.host || t.host || v.length > 1) && ("." === E || ".." === E)) ||
          "" === E,
        A = 0,
        w = v.length;
      w >= 0;
      w--
    )
      "." === (E = v[w])
        ? v.splice(w, 1)
        : ".." === E
        ? (v.splice(w, 1), A++)
        : A && (v.splice(w, 1), A--);
    if (!_ && !y) for (; A--; A) v.unshift("..");
    return (
      !_ || "" === v[0] || (v[0] && "/" === v[0].charAt(0)) || v.unshift(""),
      T && "/" !== v.join("/").substr(-1) && v.push(""),
      (S = "" === v[0] || (v[0] && "/" === v[0].charAt(0))),
      x &&
        ((r.hostname = S ? "" : v.length ? v.shift() : ""),
        (r.host = r.hostname),
        (b = !!(r.host && r.host.indexOf("@") > 0) && r.host.split("@")) &&
          ((r.auth = b.shift()),
          (r.hostname = b.shift()),
          (r.host = r.hostname))),
      (_ = _ || (r.host && v.length)) && !S && v.unshift(""),
      v.length > 0
        ? (r.pathname = v.join("/"))
        : ((r.pathname = null), (r.path = null)),
      (null === r.pathname && null === r.search) ||
        (r.path = (r.pathname ? r.pathname : "") + (r.search ? r.search : "")),
      (r.auth = t.auth || r.auth),
      (r.slashes = r.slashes || t.slashes),
      (r.href = r.format()),
      r
    );
  }),
  (z.prototype.parseHost = function () {
    var t = this.host,
      e = ts.exec(t);
    e &&
      (":" !== (e = e[0]) && (this.port = e.substr(1)),
      (t = t.substr(0, t.length - e.length))),
      t && (this.hostname = t);
  });
const En = {},
  Tn = {
    toPosix: (t) =>
      t.replace(
        new RegExp("\\".replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"),
        "/"
      ),
    isUrl(t) {
      return /^https?:/.test(this.toPosix(t));
    },
    isDataUrl: (t) =>
      /^data:([a-z]+\/[a-z0-9-+.]+(;[a-z0-9-.!#$%*+.{}|~`]+=[a-z0-9-.!#$%*+.{}()_|~`]+)*)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s<>]*?)$/i.test(
        t
      ),
    isBlobUrl: (t) => t.startsWith("blob:"),
    hasProtocol(t) {
      return /^[^/:]+:/.test(this.toPosix(t));
    },
    getProtocol(t) {
      $(t), (t = this.toPosix(t));
      const e = /^file:\/\/\//.exec(t);
      if (e) return e[0];
      const r = /^[^/:]+:\/{0,2}/.exec(t);
      return r ? r[0] : "";
    },
    toAbsolute(t, e, r) {
      if (($(t), this.isDataUrl(t) || this.isBlobUrl(t))) return t;
      const i = Y(this.toPosix(e ?? _n.ADAPTER.getBaseUrl())),
        s = Y(this.toPosix(r ?? this.rootname(i)));
      return (t = this.toPosix(t)).startsWith("/")
        ? Tn.join(s, t.slice(1))
        : this.isAbsolute(t)
        ? t
        : this.join(i, t);
    },
    normalize(t) {
      if (($(t), 0 === t.length)) return ".";
      if (this.isDataUrl(t) || this.isBlobUrl(t)) return t;
      let e = "";
      const r = (t = this.toPosix(t)).startsWith("/");
      this.hasProtocol(t) && ((e = this.rootname(t)), (t = t.slice(e.length)));
      const i = t.endsWith("/");
      return (
        (t = (function (t, e) {
          let r = "",
            i = 0,
            s = -1,
            n = 0,
            o = -1;
          for (let a = 0; a <= t.length; ++a) {
            if (a < t.length) o = t.charCodeAt(a);
            else {
              if (47 === o) break;
              o = 47;
            }
            if (47 === o) {
              if (s !== a - 1 && 1 !== n)
                if (s !== a - 1 && 2 === n) {
                  if (
                    r.length < 2 ||
                    2 !== i ||
                    46 !== r.charCodeAt(r.length - 1) ||
                    46 !== r.charCodeAt(r.length - 2)
                  )
                    if (r.length > 2) {
                      const t = r.lastIndexOf("/");
                      if (t !== r.length - 1) {
                        -1 === t
                          ? ((r = ""), (i = 0))
                          : ((r = r.slice(0, t)),
                            (i = r.length - 1 - r.lastIndexOf("/"))),
                          (s = a),
                          (n = 0);
                        continue;
                      }
                    } else if (2 === r.length || 1 === r.length) {
                      (r = ""), (i = 0), (s = a), (n = 0);
                      continue;
                    }
                } else
                  r.length > 0
                    ? (r += `/${t.slice(s + 1, a)}`)
                    : (r = t.slice(s + 1, a)),
                    (i = a - s - 1);
              (s = a), (n = 0);
            } else 46 === o && -1 !== n ? ++n : (n = -1);
          }
          return r;
        })(t)).length > 0 &&
          i &&
          (t += "/"),
        r ? `/${t}` : e + t
      );
    },
    isAbsolute(t) {
      return (
        $(t), (t = this.toPosix(t)), !!this.hasProtocol(t) || t.startsWith("/")
      );
    },
    join(...t) {
      if (0 === t.length) return ".";
      let e;
      for (let r = 0; r < t.length; ++r) {
        const i = t[r];
        if (($(i), i.length > 0))
          if (void 0 === e) e = i;
          else {
            const s = t[r - 1] ?? "";
            this.extname(s) ? (e += `/../${i}`) : (e += `/${i}`);
          }
      }
      return void 0 === e ? "." : this.normalize(e);
    },
    dirname(t) {
      if (($(t), 0 === t.length)) return ".";
      let e = (t = this.toPosix(t)).charCodeAt(0);
      const r = 47 === e;
      let i = -1,
        s = !0;
      const n = this.getProtocol(t),
        o = t;
      for (let a = (t = t.slice(n.length)).length - 1; a >= 1; --a)
        if (((e = t.charCodeAt(a)), 47 === e)) {
          if (!s) {
            i = a;
            break;
          }
        } else s = !1;
      return -1 === i
        ? r
          ? "/"
          : this.isUrl(o)
          ? n + t
          : n
        : r && 1 === i
        ? "//"
        : n + t.slice(0, i);
    },
    rootname(t) {
      $(t);
      let e = "";
      if (
        ((e = (t = this.toPosix(t)).startsWith("/")
          ? "/"
          : this.getProtocol(t)),
        this.isUrl(t))
      ) {
        const r = t.indexOf("/", e.length);
        (e = -1 !== r ? t.slice(0, r) : t), e.endsWith("/") || (e += "/");
      }
      return e;
    },
    basename(t, e) {
      $(t), e && $(e), (t = Y(this.toPosix(t)));
      let r,
        i = 0,
        s = -1,
        n = !0;
      if (void 0 !== e && e.length > 0 && e.length <= t.length) {
        if (e.length === t.length && e === t) return "";
        let o = e.length - 1,
          a = -1;
        for (r = t.length - 1; r >= 0; --r) {
          const h = t.charCodeAt(r);
          if (47 === h) {
            if (!n) {
              i = r + 1;
              break;
            }
          } else
            -1 === a && ((n = !1), (a = r + 1)),
              o >= 0 &&
                (h === e.charCodeAt(o)
                  ? -1 == --o && (s = r)
                  : ((o = -1), (s = a)));
        }
        return i === s ? (s = a) : -1 === s && (s = t.length), t.slice(i, s);
      }
      for (r = t.length - 1; r >= 0; --r)
        if (47 === t.charCodeAt(r)) {
          if (!n) {
            i = r + 1;
            break;
          }
        } else -1 === s && ((n = !1), (s = r + 1));
      return -1 === s ? "" : t.slice(i, s);
    },
    extname(t) {
      $(t);
      let e = -1,
        r = 0,
        i = -1,
        s = !0,
        n = 0;
      for (let o = (t = Y(this.toPosix(t))).length - 1; o >= 0; --o) {
        const a = t.charCodeAt(o);
        if (47 !== a)
          -1 === i && ((s = !1), (i = o + 1)),
            46 === a
              ? -1 === e
                ? (e = o)
                : 1 !== n && (n = 1)
              : -1 !== e && (n = -1);
        else if (!s) {
          r = o + 1;
          break;
        }
      }
      return -1 === e ||
        -1 === i ||
        0 === n ||
        (1 === n && e === i - 1 && e === r + 1)
        ? ""
        : t.slice(e, i);
    },
    parse(t) {
      $(t);
      const e = { root: "", dir: "", base: "", ext: "", name: "" };
      if (0 === t.length) return e;
      let r = (t = Y(this.toPosix(t))).charCodeAt(0);
      const i = this.isAbsolute(t);
      let s;
      (e.root = this.rootname(t)), (s = i || this.hasProtocol(t) ? 1 : 0);
      let n = -1,
        o = 0,
        a = -1,
        h = !0,
        l = t.length - 1,
        u = 0;
      for (; l >= s; --l)
        if (((r = t.charCodeAt(l)), 47 !== r))
          -1 === a && ((h = !1), (a = l + 1)),
            46 === r
              ? -1 === n
                ? (n = l)
                : 1 !== u && (u = 1)
              : -1 !== n && (u = -1);
        else if (!h) {
          o = l + 1;
          break;
        }
      return (
        -1 === n ||
        -1 === a ||
        0 === u ||
        (1 === u && n === a - 1 && n === o + 1)
          ? -1 !== a &&
            (e.base = e.name = 0 === o && i ? t.slice(1, a) : t.slice(o, a))
          : (0 === o && i
              ? ((e.name = t.slice(1, n)), (e.base = t.slice(1, a)))
              : ((e.name = t.slice(o, n)), (e.base = t.slice(o, a))),
            (e.ext = t.slice(n, a))),
        (e.dir = this.dirname(t)),
        e
      );
    },
    sep: "/",
    delimiter: ":",
  };
let An, wn;
(ds = { grad: 0.9, turn: 360, rad: 360 / (2 * Math.PI) }),
  (ps = function (t) {
    return "string" == typeof t ? t.length > 0 : "number" == typeof t;
  }),
  (fs = function (t, e, r) {
    return (
      void 0 === e && (e = 0),
      void 0 === r && (r = Math.pow(10, e)),
      Math.round(r * t) / r + 0
    );
  }),
  (ms = function (t, e, r) {
    return (
      void 0 === e && (e = 0),
      void 0 === r && (r = 1),
      t > r ? r : t > e ? t : e
    );
  }),
  (gs = function (t) {
    return (t = isFinite(t) ? t % 360 : 0) > 0 ? t : t + 360;
  }),
  (_s = function (t) {
    return {
      r: ms(t.r, 0, 255),
      g: ms(t.g, 0, 255),
      b: ms(t.b, 0, 255),
      a: ms(t.a),
    };
  }),
  (ys = function (t) {
    return { r: fs(t.r), g: fs(t.g), b: fs(t.b), a: fs(t.a, 3) };
  }),
  (vs = /^#([0-9a-f]{3,8})$/i),
  (xs = function (t) {
    var e = t.toString(16);
    return e.length < 2 ? "0" + e : e;
  }),
  (bs = function (t) {
    var e = t.r,
      r = t.g,
      i = t.b,
      s = t.a,
      n = Math.max(e, r, i),
      o = n - Math.min(e, r, i),
      a = o
        ? n === e
          ? (r - i) / o
          : n === r
          ? 2 + (i - e) / o
          : 4 + (e - r) / o
        : 0;
    return {
      h: 60 * (a < 0 ? a + 6 : a),
      s: n ? (o / n) * 100 : 0,
      v: (n / 255) * 100,
      a: s,
    };
  }),
  (Es = function (t) {
    var e,
      r,
      i,
      s,
      n,
      o = t.h,
      a = t.s,
      h = t.v,
      l = t.a;
    return (
      (a /= 100),
      {
        r:
          255 *
          [
            (h /= 100),
            (i = h * (1 - ((o = (o / 360) * 6) - (e = Math.floor(o))) * a)),
            (r = h * (1 - a)),
            r,
            (s = h * (1 - (1 - o + e) * a)),
            h,
          ][(n = e % 6)],
        g: 255 * [s, h, h, i, r, r][n],
        b: 255 * [r, r, s, h, h, i][n],
        a: l,
      }
    );
  }),
  (Ts = function (t) {
    return { h: gs(t.h), s: ms(t.s, 0, 100), l: ms(t.l, 0, 100), a: ms(t.a) };
  }),
  (As = function (t) {
    return { h: fs(t.h), s: fs(t.s), l: fs(t.l), a: fs(t.a, 3) };
  }),
  (ws = function (t) {
    return Es(
      ((r = (e = t).s),
      {
        h: e.h,
        s:
          (r *= ((i = e.l) < 50 ? i : 100 - i) / 100) > 0
            ? ((2 * r) / (i + r)) * 100
            : 0,
        v: i + r,
        a: e.a,
      })
    );
    var e, r, i;
  }),
  (Ss = function (t) {
    return {
      h: (e = bs(t)).h,
      s:
        (s = ((200 - (r = e.s)) * (i = e.v)) / 100) > 0 && s < 200
          ? ((r * i) / 100 / (s <= 100 ? s : 200 - s)) * 100
          : 0,
      l: s / 2,
      a: e.a,
    };
    var e, r, i, s;
  }),
  (Rs =
    /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s*,\s*([+-]?\d*\.?\d+)%\s*,\s*([+-]?\d*\.?\d+)%\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i),
  (Is =
    /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s+([+-]?\d*\.?\d+)%\s+([+-]?\d*\.?\d+)%\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i),
  (Cs =
    /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i),
  (Ps =
    /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i),
  (Ms = {
    string: [
      [
        function (t) {
          var e = vs.exec(t);
          return e
            ? (t = e[1]).length <= 4
              ? {
                  r: parseInt(t[0] + t[0], 16),
                  g: parseInt(t[1] + t[1], 16),
                  b: parseInt(t[2] + t[2], 16),
                  a:
                    4 === t.length ? fs(parseInt(t[3] + t[3], 16) / 255, 2) : 1,
                }
              : 6 === t.length || 8 === t.length
              ? {
                  r: parseInt(t.substr(0, 2), 16),
                  g: parseInt(t.substr(2, 2), 16),
                  b: parseInt(t.substr(4, 2), 16),
                  a:
                    8 === t.length
                      ? fs(parseInt(t.substr(6, 2), 16) / 255, 2)
                      : 1,
                }
              : null
            : null;
        },
        "hex",
      ],
      [
        function (t) {
          var e = Cs.exec(t) || Ps.exec(t);
          return e
            ? e[2] !== e[4] || e[4] !== e[6]
              ? null
              : _s({
                  r: Number(e[1]) / (e[2] ? 100 / 255 : 1),
                  g: Number(e[3]) / (e[4] ? 100 / 255 : 1),
                  b: Number(e[5]) / (e[6] ? 100 / 255 : 1),
                  a: void 0 === e[7] ? 1 : Number(e[7]) / (e[8] ? 100 : 1),
                })
            : null;
        },
        "rgb",
      ],
      [
        function (t) {
          var e,
            r,
            i,
            s = Rs.exec(t) || Is.exec(t);
          return s
            ? ((i = Ts({
                h:
                  ((e = s[1]),
                  (r = s[2]),
                  void 0 === r && (r = "deg"),
                  Number(e) * (ds[r] || 1)),
                s: Number(s[3]),
                l: Number(s[4]),
                a: void 0 === s[5] ? 1 : Number(s[5]) / (s[6] ? 100 : 1),
              })),
              ws(i))
            : null;
        },
        "hsl",
      ],
    ],
    object: [
      [
        function (t) {
          var e = t.r,
            r = t.g,
            i = t.b,
            s = t.a,
            n = void 0 === s ? 1 : s;
          return ps(e) && ps(r) && ps(i)
            ? _s({ r: Number(e), g: Number(r), b: Number(i), a: Number(n) })
            : null;
        },
        "rgb",
      ],
      [
        function (t) {
          var e,
            r = t.h,
            i = t.s,
            s = t.l,
            n = t.a,
            o = void 0 === n ? 1 : n;
          return ps(r) && ps(i) && ps(s)
            ? ((e = Ts({
                h: Number(r),
                s: Number(i),
                l: Number(s),
                a: Number(o),
              })),
              ws(e))
            : null;
        },
        "hsl",
      ],
      [
        function (t) {
          var e,
            r,
            i = t.h,
            s = t.s,
            n = t.v,
            o = t.a,
            a = void 0 === o ? 1 : o;
          return ps(i) && ps(s) && ps(n)
            ? ((r = { h: Number(i), s: Number(s), v: Number(n), a: Number(a) }),
              (e = {
                h: gs(r.h),
                s: ms(r.s, 0, 100),
                v: ms(r.v, 0, 100),
                a: ms(r.a),
              }),
              Es(e))
            : null;
        },
        "hsv",
      ],
    ],
  }),
  (Ds = function (t, e) {
    var r, i;
    for (r = 0; r < e.length; r++) if ((i = e[r][0](t))) return [i, e[r][1]];
    return [null, void 0];
  }),
  (Os = function (t) {
    return "string" == typeof t
      ? Ds(t.trim(), Ms.string)
      : "object" == typeof t && null !== t
      ? Ds(t, Ms.object)
      : [null, void 0];
  }),
  (Bs = function (t, e) {
    var r = Ss(t);
    return { h: r.h, s: ms(r.s + 100 * e, 0, 100), l: r.l, a: r.a };
  }),
  (Ns = function (t) {
    return (299 * t.r + 587 * t.g + 114 * t.b) / 1e3 / 255;
  }),
  (Fs = function (t, e) {
    var r = Ss(t);
    return { h: r.h, s: r.s, l: ms(r.l + 100 * e, 0, 100), a: r.a };
  }),
  (Ls = (function () {
    function t(t) {
      (this.parsed = Os(t)[0]),
        (this.rgba = this.parsed || { r: 0, g: 0, b: 0, a: 1 });
    }
    return (
      (t.prototype.isValid = function () {
        return null !== this.parsed;
      }),
      (t.prototype.brightness = function () {
        return fs(Ns(this.rgba), 2);
      }),
      (t.prototype.isDark = function () {
        return Ns(this.rgba) < 0.5;
      }),
      (t.prototype.isLight = function () {
        return Ns(this.rgba) >= 0.5;
      }),
      (t.prototype.toHex = function () {
        return (
          (e = (t = ys(this.rgba)).r),
          (r = t.g),
          (i = t.b),
          (n = (s = t.a) < 1 ? xs(fs(255 * s)) : ""),
          "#" + xs(e) + xs(r) + xs(i) + n
        );
        var t, e, r, i, s, n;
      }),
      (t.prototype.toRgb = function () {
        return ys(this.rgba);
      }),
      (t.prototype.toRgbString = function () {
        return (
          (e = (t = ys(this.rgba)).r),
          (r = t.g),
          (i = t.b),
          (s = t.a) < 1
            ? "rgba(" + e + ", " + r + ", " + i + ", " + s + ")"
            : "rgb(" + e + ", " + r + ", " + i + ")"
        );
        var t, e, r, i, s;
      }),
      (t.prototype.toHsl = function () {
        return As(Ss(this.rgba));
      }),
      (t.prototype.toHslString = function () {
        return (
          (e = (t = As(Ss(this.rgba))).h),
          (r = t.s),
          (i = t.l),
          (s = t.a) < 1
            ? "hsla(" + e + ", " + r + "%, " + i + "%, " + s + ")"
            : "hsl(" + e + ", " + r + "%, " + i + "%)"
        );
        var t, e, r, i, s;
      }),
      (t.prototype.toHsv = function () {
        return (
          (t = bs(this.rgba)),
          { h: fs(t.h), s: fs(t.s), v: fs(t.v), a: fs(t.a, 3) }
        );
        var t;
      }),
      (t.prototype.invert = function () {
        return ks({
          r: 255 - (t = this.rgba).r,
          g: 255 - t.g,
          b: 255 - t.b,
          a: t.a,
        });
        var t;
      }),
      (t.prototype.saturate = function (t) {
        return void 0 === t && (t = 0.1), ks(Bs(this.rgba, t));
      }),
      (t.prototype.desaturate = function (t) {
        return void 0 === t && (t = 0.1), ks(Bs(this.rgba, -t));
      }),
      (t.prototype.grayscale = function () {
        return ks(Bs(this.rgba, -1));
      }),
      (t.prototype.lighten = function (t) {
        return void 0 === t && (t = 0.1), ks(Fs(this.rgba, t));
      }),
      (t.prototype.darken = function (t) {
        return void 0 === t && (t = 0.1), ks(Fs(this.rgba, -t));
      }),
      (t.prototype.rotate = function (t) {
        return void 0 === t && (t = 15), this.hue(this.hue() + t);
      }),
      (t.prototype.alpha = function (t) {
        return "number" == typeof t
          ? ks({ r: (e = this.rgba).r, g: e.g, b: e.b, a: t })
          : fs(this.rgba.a, 3);
        var e;
      }),
      (t.prototype.hue = function (t) {
        var e = Ss(this.rgba);
        return "number" == typeof t
          ? ks({ h: t, s: e.s, l: e.l, a: e.a })
          : fs(e.h);
      }),
      (t.prototype.isEqual = function (t) {
        return this.toHex() === ks(t).toHex();
      }),
      t
    );
  })()),
  (ks = function (t) {
    return t instanceof Ls ? t : new Ls(t);
  }),
  (Us = []),
  [
    function (t, e) {
      var r,
        i,
        s = {
          white: "#ffffff",
          bisque: "#ffe4c4",
          blue: "#0000ff",
          cadetblue: "#5f9ea0",
          chartreuse: "#7fff00",
          chocolate: "#d2691e",
          coral: "#ff7f50",
          antiquewhite: "#faebd7",
          aqua: "#00ffff",
          azure: "#f0ffff",
          whitesmoke: "#f5f5f5",
          papayawhip: "#ffefd5",
          plum: "#dda0dd",
          blanchedalmond: "#ffebcd",
          black: "#000000",
          gold: "#ffd700",
          goldenrod: "#daa520",
          gainsboro: "#dcdcdc",
          cornsilk: "#fff8dc",
          cornflowerblue: "#6495ed",
          burlywood: "#deb887",
          aquamarine: "#7fffd4",
          beige: "#f5f5dc",
          crimson: "#dc143c",
          cyan: "#00ffff",
          darkblue: "#00008b",
          darkcyan: "#008b8b",
          darkgoldenrod: "#b8860b",
          darkkhaki: "#bdb76b",
          darkgray: "#a9a9a9",
          darkgreen: "#006400",
          darkgrey: "#a9a9a9",
          peachpuff: "#ffdab9",
          darkmagenta: "#8b008b",
          darkred: "#8b0000",
          darkorchid: "#9932cc",
          darkorange: "#ff8c00",
          darkslateblue: "#483d8b",
          gray: "#808080",
          darkslategray: "#2f4f4f",
          darkslategrey: "#2f4f4f",
          deeppink: "#ff1493",
          deepskyblue: "#00bfff",
          wheat: "#f5deb3",
          firebrick: "#b22222",
          floralwhite: "#fffaf0",
          ghostwhite: "#f8f8ff",
          darkviolet: "#9400d3",
          magenta: "#ff00ff",
          green: "#008000",
          dodgerblue: "#1e90ff",
          grey: "#808080",
          honeydew: "#f0fff0",
          hotpink: "#ff69b4",
          blueviolet: "#8a2be2",
          forestgreen: "#228b22",
          lawngreen: "#7cfc00",
          indianred: "#cd5c5c",
          indigo: "#4b0082",
          fuchsia: "#ff00ff",
          brown: "#a52a2a",
          maroon: "#800000",
          mediumblue: "#0000cd",
          lightcoral: "#f08080",
          darkturquoise: "#00ced1",
          lightcyan: "#e0ffff",
          ivory: "#fffff0",
          lightyellow: "#ffffe0",
          lightsalmon: "#ffa07a",
          lightseagreen: "#20b2aa",
          linen: "#faf0e6",
          mediumaquamarine: "#66cdaa",
          lemonchiffon: "#fffacd",
          lime: "#00ff00",
          khaki: "#f0e68c",
          mediumseagreen: "#3cb371",
          limegreen: "#32cd32",
          mediumspringgreen: "#00fa9a",
          lightskyblue: "#87cefa",
          lightblue: "#add8e6",
          midnightblue: "#191970",
          lightpink: "#ffb6c1",
          mistyrose: "#ffe4e1",
          moccasin: "#ffe4b5",
          mintcream: "#f5fffa",
          lightslategray: "#778899",
          lightslategrey: "#778899",
          navajowhite: "#ffdead",
          navy: "#000080",
          mediumvioletred: "#c71585",
          powderblue: "#b0e0e6",
          palegoldenrod: "#eee8aa",
          oldlace: "#fdf5e6",
          paleturquoise: "#afeeee",
          mediumturquoise: "#48d1cc",
          mediumorchid: "#ba55d3",
          rebeccapurple: "#663399",
          lightsteelblue: "#b0c4de",
          mediumslateblue: "#7b68ee",
          thistle: "#d8bfd8",
          tan: "#d2b48c",
          orchid: "#da70d6",
          mediumpurple: "#9370db",
          purple: "#800080",
          pink: "#ffc0cb",
          skyblue: "#87ceeb",
          springgreen: "#00ff7f",
          palegreen: "#98fb98",
          red: "#ff0000",
          yellow: "#ffff00",
          slateblue: "#6a5acd",
          lavenderblush: "#fff0f5",
          peru: "#cd853f",
          palevioletred: "#db7093",
          violet: "#ee82ee",
          teal: "#008080",
          slategray: "#708090",
          slategrey: "#708090",
          aliceblue: "#f0f8ff",
          darkseagreen: "#8fbc8f",
          darkolivegreen: "#556b2f",
          greenyellow: "#adff2f",
          seagreen: "#2e8b57",
          seashell: "#fff5ee",
          tomato: "#ff6347",
          silver: "#c0c0c0",
          sienna: "#a0522d",
          lavender: "#e6e6fa",
          lightgreen: "#90ee90",
          orange: "#ffa500",
          orangered: "#ff4500",
          steelblue: "#4682b4",
          royalblue: "#4169e1",
          turquoise: "#40e0d0",
          yellowgreen: "#9acd32",
          salmon: "#fa8072",
          saddlebrown: "#8b4513",
          sandybrown: "#f4a460",
          rosybrown: "#bc8f8f",
          darksalmon: "#e9967a",
          lightgoldenrodyellow: "#fafad2",
          snow: "#fffafa",
          lightgrey: "#d3d3d3",
          lightgray: "#d3d3d3",
          dimgray: "#696969",
          dimgrey: "#696969",
          olivedrab: "#6b8e23",
          olive: "#808000",
        },
        n = {};
      for (r in s) n[s[r]] = r;
      (i = {}),
        (t.prototype.toName = function (e) {
          var r, o, a, h, l, u, c, d, p;
          if (!(this.rgba.a || this.rgba.r || this.rgba.g || this.rgba.b))
            return "transparent";
          if ((a = n[this.toHex()])) return a;
          if (null == e ? void 0 : e.closest) {
            if (((h = this.toRgb()), (l = 1 / 0), (u = "black"), !i.length))
              for (c in s) i[c] = new t(s[c]).toRgb();
            for (d in s)
              (r = h),
                (o = i[d]),
                (p =
                  Math.pow(r.r - o.r, 2) +
                  Math.pow(r.g - o.g, 2) +
                  Math.pow(r.b - o.b, 2)) < l && ((l = p), (u = d));
            return u;
          }
        }),
        e.string.push([
          function (e) {
            var r = e.toLowerCase(),
              i = "transparent" === r ? "#0000" : s[r];
            return i ? new t(i).toRgb() : null;
          },
          "name",
        ]);
    },
  ].forEach(function (t) {
    Us.indexOf(t) < 0 && (t(Ls, Ms), Us.push(t));
  });
const Sn = class t {
  constructor(t = 16777215) {
    (this._value = null),
      (this._components = new Float32Array(4)),
      this._components.fill(1),
      (this._int = 16777215),
      (this.value = t);
  }
  get red() {
    return this._components[0];
  }
  get green() {
    return this._components[1];
  }
  get blue() {
    return this._components[2];
  }
  get alpha() {
    return this._components[3];
  }
  setValue(t) {
    return (this.value = t), this;
  }
  set value(e) {
    if (e instanceof t)
      (this._value = this.cloneSource(e._value)),
        (this._int = e._int),
        this._components.set(e._components);
    else {
      if (null === e) throw new Error("Cannot set PIXI.Color#value to null");
      (null === this._value || !this.isSourceEqual(this._value, e)) &&
        (this.normalize(e), (this._value = this.cloneSource(e)));
    }
  }
  get value() {
    return this._value;
  }
  cloneSource(t) {
    return "string" == typeof t ||
      "number" == typeof t ||
      t instanceof Number ||
      null === t
      ? t
      : Array.isArray(t) || ArrayBuffer.isView(t)
      ? t.slice(0)
      : "object" == typeof t && null !== t
      ? { ...t }
      : t;
  }
  isSourceEqual(t, e) {
    const r = typeof t;
    if (r !== typeof e) return !1;
    if ("number" === r || "string" === r || t instanceof Number) return t === e;
    if (
      (Array.isArray(t) && Array.isArray(e)) ||
      (ArrayBuffer.isView(t) && ArrayBuffer.isView(e))
    )
      return t.length === e.length && t.every((t, r) => t === e[r]);
    if (null !== t && null !== e) {
      const r = Object.keys(t),
        i = Object.keys(e);
      return r.length === i.length && r.every((r) => t[r] === e[r]);
    }
    return t === e;
  }
  toRgba() {
    const [t, e, r, i] = this._components;
    return { r: t, g: e, b: r, a: i };
  }
  toRgb() {
    const [t, e, r] = this._components;
    return { r: t, g: e, b: r };
  }
  toRgbaString() {
    const [t, e, r] = this.toUint8RgbArray();
    return `rgba(${t},${e},${r},${this.alpha})`;
  }
  toUint8RgbArray(t) {
    const [e, r, i] = this._components;
    return (
      ((t = t ?? [])[0] = Math.round(255 * e)),
      (t[1] = Math.round(255 * r)),
      (t[2] = Math.round(255 * i)),
      t
    );
  }
  toRgbArray(t) {
    t = t ?? [];
    const [e, r, i] = this._components;
    return (t[0] = e), (t[1] = r), (t[2] = i), t;
  }
  toNumber() {
    return this._int;
  }
  toLittleEndianNumber() {
    const t = this._int;
    return (t >> 16) + (65280 & t) + ((255 & t) << 16);
  }
  multiply(e) {
    const [r, i, s, n] = t.temp.setValue(e)._components;
    return (
      (this._components[0] *= r),
      (this._components[1] *= i),
      (this._components[2] *= s),
      (this._components[3] *= n),
      this.refreshInt(),
      (this._value = null),
      this
    );
  }
  premultiply(t, e = !0) {
    return (
      e &&
        ((this._components[0] *= t),
        (this._components[1] *= t),
        (this._components[2] *= t)),
      (this._components[3] = t),
      this.refreshInt(),
      (this._value = null),
      this
    );
  }
  toPremultiplied(t, e = !0) {
    if (1 === t) return (255 << 24) + this._int;
    if (0 === t) return e ? 0 : this._int;
    let r = (this._int >> 16) & 255,
      i = (this._int >> 8) & 255,
      s = 255 & this._int;
    return (
      e &&
        ((r = (r * t + 0.5) | 0),
        (i = (i * t + 0.5) | 0),
        (s = (s * t + 0.5) | 0)),
      ((255 * t) << 24) + (r << 16) + (i << 8) + s
    );
  }
  toHex() {
    const t = this._int.toString(16);
    return `#${"000000".substring(0, 6 - t.length) + t}`;
  }
  toHexa() {
    const t = Math.round(255 * this._components[3]).toString(16);
    return this.toHex() + "00".substring(0, 2 - t.length) + t;
  }
  setAlpha(t) {
    return (this._components[3] = this._clamp(t)), this;
  }
  round(t) {
    const [e, r, i] = this._components;
    return (
      (this._components[0] = Math.round(e * t) / t),
      (this._components[1] = Math.round(r * t) / t),
      (this._components[2] = Math.round(i * t) / t),
      this.refreshInt(),
      (this._value = null),
      this
    );
  }
  toArray(t) {
    t = t ?? [];
    const [e, r, i, s] = this._components;
    return (t[0] = e), (t[1] = r), (t[2] = i), (t[3] = s), t;
  }
  normalize(e) {
    let r, i, s, n;
    if (
      ("number" == typeof e || e instanceof Number) &&
      e >= 0 &&
      e <= 16777215
    )
      (r = ((e >> 16) & 255) / 255),
        (i = ((e >> 8) & 255) / 255),
        (s = (255 & e) / 255),
        (n = 1);
    else if (
      (Array.isArray(e) || e instanceof Float32Array) &&
      e.length >= 3 &&
      e.length <= 4
    )
      (e = this._clamp(e)), ([r, i, s, n = 1] = e);
    else if (
      (e instanceof Uint8Array || e instanceof Uint8ClampedArray) &&
      e.length >= 3 &&
      e.length <= 4
    )
      (e = this._clamp(e, 0, 255)),
        ([r, i, s, n = 255] = e),
        (r /= 255),
        (i /= 255),
        (s /= 255),
        (n /= 255);
    else if ("string" == typeof e || "object" == typeof e) {
      if ("string" == typeof e) {
        const r = t.HEX_PATTERN.exec(e);
        r && (e = `#${r[2]}`);
      }
      const o = ks(e);
      o.isValid() &&
        (({ r: r, g: i, b: s, a: n } = o.rgba),
        (r /= 255),
        (i /= 255),
        (s /= 255));
    }
    if (void 0 === r) throw new Error(`Unable to convert color ${e}`);
    (this._components[0] = r),
      (this._components[1] = i),
      (this._components[2] = s),
      (this._components[3] = n),
      this.refreshInt();
  }
  refreshInt() {
    this._clamp(this._components);
    const [t, e, r] = this._components;
    this._int = ((255 * t) << 16) + ((255 * e) << 8) + ((255 * r) | 0);
  }
  _clamp(t, e = 0, r = 1) {
    return "number" == typeof t
      ? Math.min(Math.max(t, e), r)
      : (t.forEach((i, s) => {
          t[s] = Math.min(Math.max(i, e), r);
        }),
        t);
  }
};
(Sn.shared = new Sn()),
  (Sn.temp = new Sn()),
  (Sn.HEX_PATTERN = /^(#|0x)?(([a-f0-9]{3}){1,2}([a-f0-9]{2})?)$/i);
let Rn = Sn;
const In = (function () {
  const t = [],
    e = [];
  for (let i = 0; i < 32; i++) (t[i] = i), (e[i] = i);
  (t[tn.NORMAL_NPM] = tn.NORMAL),
    (t[tn.ADD_NPM] = tn.ADD),
    (t[tn.SCREEN_NPM] = tn.SCREEN),
    (e[tn.NORMAL] = tn.NORMAL_NPM),
    (e[tn.ADD] = tn.ADD_NPM),
    (e[tn.SCREEN] = tn.SCREEN_NPM);
  const r = [];
  return r.push(e), r.push(t), r;
})();
let Cn = 0;
const Pn = class {
  constructor(t, e, r, i) {
    (this.left = t), (this.top = e), (this.right = r), (this.bottom = i);
  }
  get width() {
    return this.right - this.left;
  }
  get height() {
    return this.bottom - this.top;
  }
  isEmpty() {
    return this.left === this.right || this.top === this.bottom;
  }
};
Pn.EMPTY = new Pn(0, 0, 0, 0);
let Mn = Pn;
const Dn = {},
  On = Object.create(null),
  Bn = Object.create(null);
class Nn {
  constructor(t, e, r) {
    (this._canvas = _n.ADAPTER.createCanvas()),
      (this._context = this._canvas.getContext("2d")),
      (this.resolution = r || _n.RESOLUTION),
      this.resize(t, e);
  }
  clear() {
    this._checkDestroyed(),
      this._context.setTransform(1, 0, 0, 1, 0, 0),
      this._context.clearRect(0, 0, this._canvas.width, this._canvas.height);
  }
  resize(t, e) {
    this._checkDestroyed(),
      (this._canvas.width = Math.round(t * this.resolution)),
      (this._canvas.height = Math.round(e * this.resolution));
  }
  destroy() {
    (this._context = null), (this._canvas = null);
  }
  get width() {
    return this._checkDestroyed(), this._canvas.width;
  }
  set width(t) {
    this._checkDestroyed(), (this._canvas.width = Math.round(t));
  }
  get height() {
    return this._checkDestroyed(), this._canvas.height;
  }
  set height(t) {
    this._checkDestroyed(), (this._canvas.height = Math.round(t));
  }
  get canvas() {
    return this._checkDestroyed(), this._canvas;
  }
  get context() {
    return this._checkDestroyed(), this._context;
  }
  _checkDestroyed() {
    if (null === this._canvas)
      throw new TypeError("The CanvasRenderTarget has already been destroyed");
  }
}
Gs = ((t) => (
  (t.Renderer = "renderer"),
  (t.Application = "application"),
  (t.RendererSystem = "renderer-webgl-system"),
  (t.RendererPlugin = "renderer-webgl-plugin"),
  (t.CanvasRendererSystem = "renderer-canvas-system"),
  (t.CanvasRendererPlugin = "renderer-canvas-plugin"),
  (t.Asset = "asset"),
  (t.LoadParser = "load-parser"),
  (t.ResolveParser = "resolve-parser"),
  (t.CacheParser = "cache-parser"),
  (t.DetectionParser = "detection-parser"),
  t
))(Gs || {});
const Fn = (t) => {
    if ("function" == typeof t || ("object" == typeof t && t.extension)) {
      if (!t.extension)
        throw new Error("Extension class must have an extension object");
      t = {
        ...("object" != typeof t.extension
          ? { type: t.extension }
          : t.extension),
        ref: t,
      };
    }
    if ("object" != typeof t) throw new Error("Invalid extension type");
    return "string" == typeof (t = { ...t }).type && (t.type = [t.type]), t;
  },
  Ln = (t, e) => Fn(t).priority ?? e,
  kn = {
    _addHandlers: {},
    _removeHandlers: {},
    _queue: {},
    remove(...t) {
      return (
        t.map(Fn).forEach((t) => {
          t.type.forEach((e) => {
            var r, i;
            return null == (i = (r = this._removeHandlers)[e])
              ? void 0
              : i.call(r, t);
          });
        }),
        this
      );
    },
    add(...t) {
      return (
        t.map(Fn).forEach((t) => {
          t.type.forEach((e) => {
            const r = this._addHandlers,
              i = this._queue;
            r[e] ? r[e](t) : ((i[e] = i[e] || []), i[e].push(t));
          });
        }),
        this
      );
    },
    handle(t, e, r) {
      const i = this._addHandlers,
        s = this._removeHandlers;
      if (i[t] || s[t])
        throw new Error(`Extension type ${t} already has a handler`);
      (i[t] = e), (s[t] = r);
      const n = this._queue;
      return n[t] && (n[t].forEach((t) => e(t)), delete n[t]), this;
    },
    handleByMap(t, e) {
      return this.handle(
        t,
        (t) => {
          e[t.name] = t.ref;
        },
        (t) => {
          delete e[t.name];
        }
      );
    },
    handleByList(t, e, r = -1) {
      return this.handle(
        t,
        (t) => {
          e.includes(t.ref) ||
            (e.push(t.ref), e.sort((t, e) => Ln(e, r) - Ln(t, r)));
        },
        (t) => {
          const r = e.indexOf(t.ref);
          -1 !== r && e.splice(r, 1);
        }
      );
    },
  };
class Un {
  constructor(t) {
    "number" == typeof t
      ? (this.rawBinaryData = new ArrayBuffer(t))
      : t instanceof Uint8Array
      ? (this.rawBinaryData = t.buffer)
      : (this.rawBinaryData = t),
      (this.uint32View = new Uint32Array(this.rawBinaryData)),
      (this.float32View = new Float32Array(this.rawBinaryData));
  }
  get int8View() {
    return (
      this._int8View || (this._int8View = new Int8Array(this.rawBinaryData)),
      this._int8View
    );
  }
  get uint8View() {
    return (
      this._uint8View || (this._uint8View = new Uint8Array(this.rawBinaryData)),
      this._uint8View
    );
  }
  get int16View() {
    return (
      this._int16View || (this._int16View = new Int16Array(this.rawBinaryData)),
      this._int16View
    );
  }
  get uint16View() {
    return (
      this._uint16View ||
        (this._uint16View = new Uint16Array(this.rawBinaryData)),
      this._uint16View
    );
  }
  get int32View() {
    return (
      this._int32View || (this._int32View = new Int32Array(this.rawBinaryData)),
      this._int32View
    );
  }
  view(t) {
    return this[`${t}View`];
  }
  destroy() {
    (this.rawBinaryData = null),
      (this._int8View = null),
      (this._uint8View = null),
      (this._int16View = null),
      (this._uint16View = null),
      (this._int32View = null),
      (this.uint32View = null),
      (this.float32View = null);
  }
  static sizeOf(t) {
    switch (t) {
      case "int8":
      case "uint8":
        return 1;
      case "int16":
      case "uint16":
        return 2;
      case "int32":
      case "uint32":
      case "float32":
        return 4;
      default:
        throw new Error(`${t} isn't a valid view type`);
    }
  }
}
const Gn = [
  "precision mediump float;",
  "void main(void){",
  "float test = 0.1;",
  "%forloop%",
  "gl_FragColor = vec4(0.0);",
  "}",
].join("\n");
class Hn {
  constructor() {
    (this.data = 0),
      (this.blendMode = tn.NORMAL),
      (this.polygonOffset = 0),
      (this.blend = !0),
      (this.depthMask = !0);
  }
  get blend() {
    return !!(1 & this.data);
  }
  set blend(t) {
    !!(1 & this.data) !== t && (this.data ^= 1);
  }
  get offsets() {
    return !!(2 & this.data);
  }
  set offsets(t) {
    !!(2 & this.data) !== t && (this.data ^= 2);
  }
  get culling() {
    return !!(4 & this.data);
  }
  set culling(t) {
    !!(4 & this.data) !== t && (this.data ^= 4);
  }
  get depthTest() {
    return !!(8 & this.data);
  }
  set depthTest(t) {
    !!(8 & this.data) !== t && (this.data ^= 8);
  }
  get depthMask() {
    return !!(32 & this.data);
  }
  set depthMask(t) {
    !!(32 & this.data) !== t && (this.data ^= 32);
  }
  get clockwiseFrontFace() {
    return !!(16 & this.data);
  }
  set clockwiseFrontFace(t) {
    !!(16 & this.data) !== t && (this.data ^= 16);
  }
  get blendMode() {
    return this._blendMode;
  }
  set blendMode(t) {
    (this.blend = t !== tn.NONE), (this._blendMode = t);
  }
  get polygonOffset() {
    return this._polygonOffset;
  }
  set polygonOffset(t) {
    (this.offsets = !!t), (this._polygonOffset = t);
  }
  static for2d() {
    const t = new Hn();
    return (t.depthTest = !1), (t.blend = !0), t;
  }
}
Hn.prototype.toString = function () {
  return `[@pixi/core:State blendMode=${this.blendMode} clockwiseFrontFace=${this.clockwiseFrontFace} culling=${this.culling} depthMask=${this.depthMask} polygonOffset=${this.polygonOffset}]`;
};
const jn = [];
class Xn {
  constructor(t) {
    (this.items = []), (this._name = t), (this._aliasCount = 0);
  }
  emit(t, e, r, i, s, n, o, a) {
    if (arguments.length > 8) throw new Error("max arguments reached");
    const { name: h, items: l } = this;
    this._aliasCount++;
    for (let u = 0, c = l.length; u < c; u++) l[u][h](t, e, r, i, s, n, o, a);
    return l === this.items && this._aliasCount--, this;
  }
  ensureNonAliasedItems() {
    this._aliasCount > 0 &&
      this.items.length > 1 &&
      ((this._aliasCount = 0), (this.items = this.items.slice(0)));
  }
  add(t) {
    return (
      t[this._name] &&
        (this.ensureNonAliasedItems(), this.remove(t), this.items.push(t)),
      this
    );
  }
  remove(t) {
    const e = this.items.indexOf(t);
    return (
      -1 !== e && (this.ensureNonAliasedItems(), this.items.splice(e, 1)), this
    );
  }
  contains(t) {
    return this.items.includes(t);
  }
  removeAll() {
    return this.ensureNonAliasedItems(), (this.items.length = 0), this;
  }
  destroy() {
    this.removeAll(), (this.items = null), (this._name = null);
  }
  get empty() {
    return 0 === this.items.length;
  }
  get name() {
    return this._name;
  }
}
Object.defineProperties(Xn.prototype, {
  dispatch: { value: Xn.prototype.emit },
  run: { value: Xn.prototype.emit },
});
class Vn {
  constructor(t = 0, e = 0) {
    (this._width = t),
      (this._height = e),
      (this.destroyed = !1),
      (this.internal = !1),
      (this.onResize = new Xn("setRealSize")),
      (this.onUpdate = new Xn("update")),
      (this.onError = new Xn("onError"));
  }
  bind(t) {
    this.onResize.add(t),
      this.onUpdate.add(t),
      this.onError.add(t),
      (this._width || this._height) &&
        this.onResize.emit(this._width, this._height);
  }
  unbind(t) {
    this.onResize.remove(t), this.onUpdate.remove(t), this.onError.remove(t);
  }
  resize(t, e) {
    (t !== this._width || e !== this._height) &&
      ((this._width = t), (this._height = e), this.onResize.emit(t, e));
  }
  get valid() {
    return !!this._width && !!this._height;
  }
  update() {
    this.destroyed || this.onUpdate.emit();
  }
  load() {
    return Promise.resolve(this);
  }
  get width() {
    return this._width;
  }
  get height() {
    return this._height;
  }
  style(t, e, r) {
    return !1;
  }
  dispose() {}
  destroy() {
    this.destroyed ||
      ((this.destroyed = !0),
      this.dispose(),
      this.onError.removeAll(),
      (this.onError = null),
      this.onResize.removeAll(),
      (this.onResize = null),
      this.onUpdate.removeAll(),
      (this.onUpdate = null));
  }
  static test(t, e) {
    return !1;
  }
}
class zn extends Vn {
  constructor(t, e) {
    const { width: r, height: i } = e || {};
    if (!r || !i) throw new Error("BufferResource width or height invalid");
    super(r, i),
      (this.data = t),
      (this.unpackAlignment = e.unpackAlignment ?? 4);
  }
  upload(t, e, r) {
    const i = t.gl;
    i.pixelStorei(i.UNPACK_ALIGNMENT, this.unpackAlignment),
      i.pixelStorei(
        i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,
        e.alphaMode === un.UNPACK
      );
    const s = e.realWidth,
      n = e.realHeight;
    return (
      r.width === s && r.height === n
        ? i.texSubImage2D(e.target, 0, 0, 0, s, n, e.format, r.type, this.data)
        : ((r.width = s),
          (r.height = n),
          i.texImage2D(
            e.target,
            0,
            r.internalFormat,
            s,
            n,
            0,
            e.format,
            r.type,
            this.data
          )),
      !0
    );
  }
  dispose() {
    this.data = null;
  }
  static test(t) {
    return (
      null === t ||
      t instanceof Int8Array ||
      t instanceof Uint8Array ||
      t instanceof Uint8ClampedArray ||
      t instanceof Int16Array ||
      t instanceof Uint16Array ||
      t instanceof Int32Array ||
      t instanceof Uint32Array ||
      t instanceof Float32Array
    );
  }
}
const Wn = { scaleMode: an.NEAREST, alphaMode: un.NPM },
  $n = class t extends vn {
    constructor(e = null, r = null) {
      super(), (r = Object.assign({}, t.defaultOptions, r));
      const {
        alphaMode: i,
        mipmap: s,
        anisotropicLevel: n,
        scaleMode: o,
        width: a,
        height: h,
        wrapMode: l,
        format: u,
        type: c,
        target: d,
        resolution: p,
        resourceOptions: f,
      } = r;
      e && !(e instanceof Vn) && ((e = ht(e, f)).internal = !0),
        (this.resolution = p || _n.RESOLUTION),
        (this.width = Math.round((a || 0) * this.resolution) / this.resolution),
        (this.height =
          Math.round((h || 0) * this.resolution) / this.resolution),
        (this._mipmap = s),
        (this.anisotropicLevel = n),
        (this._wrapMode = l),
        (this._scaleMode = o),
        (this.format = u),
        (this.type = c),
        (this.target = d),
        (this.alphaMode = i),
        (this.uid = it()),
        (this.touched = 0),
        (this.isPowerOfTwo = !1),
        this._refreshPOT(),
        (this._glTextures = {}),
        (this.dirtyId = 0),
        (this.dirtyStyleId = 0),
        (this.cacheId = null),
        (this.valid = a > 0 && h > 0),
        (this.textureCacheIds = []),
        (this.destroyed = !1),
        (this.resource = null),
        (this._batchEnabled = 0),
        (this._batchLocation = 0),
        (this.parentTextureArray = null),
        this.setResource(e);
    }
    get realWidth() {
      return Math.round(this.width * this.resolution);
    }
    get realHeight() {
      return Math.round(this.height * this.resolution);
    }
    get mipmap() {
      return this._mipmap;
    }
    set mipmap(t) {
      this._mipmap !== t && ((this._mipmap = t), this.dirtyStyleId++);
    }
    get scaleMode() {
      return this._scaleMode;
    }
    set scaleMode(t) {
      this._scaleMode !== t && ((this._scaleMode = t), this.dirtyStyleId++);
    }
    get wrapMode() {
      return this._wrapMode;
    }
    set wrapMode(t) {
      this._wrapMode !== t && ((this._wrapMode = t), this.dirtyStyleId++);
    }
    setStyle(t, e) {
      let r;
      return (
        void 0 !== t &&
          t !== this.scaleMode &&
          ((this.scaleMode = t), (r = !0)),
        void 0 !== e && e !== this.mipmap && ((this.mipmap = e), (r = !0)),
        r && this.dirtyStyleId++,
        this
      );
    }
    setSize(t, e, r) {
      return (r = r || this.resolution), this.setRealSize(t * r, e * r, r);
    }
    setRealSize(t, e, r) {
      return (
        (this.resolution = r || this.resolution),
        (this.width = Math.round(t) / this.resolution),
        (this.height = Math.round(e) / this.resolution),
        this._refreshPOT(),
        this.update(),
        this
      );
    }
    _refreshPOT() {
      this.isPowerOfTwo = J(this.realWidth) && J(this.realHeight);
    }
    setResolution(t) {
      const e = this.resolution;
      return (
        e === t ||
          ((this.resolution = t),
          this.valid &&
            ((this.width = Math.round(this.width * e) / t),
            (this.height = Math.round(this.height * e) / t),
            this.emit("update", this)),
          this._refreshPOT()),
        this
      );
    }
    setResource(t) {
      if (this.resource === t) return this;
      if (this.resource) throw new Error("Resource can be set only once");
      return t.bind(this), (this.resource = t), this;
    }
    update() {
      this.valid
        ? (this.dirtyId++, this.dirtyStyleId++, this.emit("update", this))
        : this.width > 0 &&
          this.height > 0 &&
          ((this.valid = !0),
          this.emit("loaded", this),
          this.emit("update", this));
    }
    onError(t) {
      this.emit("error", this, t);
    }
    destroy() {
      this.resource &&
        (this.resource.unbind(this),
        this.resource.internal && this.resource.destroy(),
        (this.resource = null)),
        this.cacheId &&
          (delete Bn[this.cacheId],
          delete On[this.cacheId],
          (this.cacheId = null)),
        (this.valid = !1),
        this.dispose(),
        t.removeFromCache(this),
        (this.textureCacheIds = null),
        (this.destroyed = !0),
        this.emit("destroyed", this),
        this.removeAllListeners();
    }
    dispose() {
      this.emit("dispose", this);
    }
    castToBaseTexture() {
      return this;
    }
    static from(e, r, i = _n.STRICT_TEXTURE_CACHE) {
      const s = "string" == typeof e;
      let n = null;
      if (s) n = e;
      else {
        if (!e._pixiId) {
          const t = (null == r ? void 0 : r.pixiIdPrefix) || "pixiid";
          e._pixiId = `${t}_${it()}`;
        }
        n = e._pixiId;
      }
      let o = Bn[n];
      if (s && i && !o)
        throw new Error(
          `The cacheId "${n}" does not exist in BaseTextureCache.`
        );
      return o || ((o = new t(e, r)), (o.cacheId = n), t.addToCache(o, n)), o;
    }
    static fromBuffer(e, r, i, s) {
      e = e || new Float32Array(r * i * 4);
      const n = new zn(e, {
        width: r,
        height: i,
        ...(null == s ? void 0 : s.resourceOptions),
      });
      let o, a;
      return (
        e instanceof Float32Array
          ? ((o = rn.RGBA), (a = nn.FLOAT))
          : e instanceof Int32Array
          ? ((o = rn.RGBA_INTEGER), (a = nn.INT))
          : e instanceof Uint32Array
          ? ((o = rn.RGBA_INTEGER), (a = nn.UNSIGNED_INT))
          : e instanceof Int16Array
          ? ((o = rn.RGBA_INTEGER), (a = nn.SHORT))
          : e instanceof Uint16Array
          ? ((o = rn.RGBA_INTEGER), (a = nn.UNSIGNED_SHORT))
          : e instanceof Int8Array
          ? ((o = rn.RGBA), (a = nn.BYTE))
          : ((o = rn.RGBA), (a = nn.UNSIGNED_BYTE)),
        (n.internal = !0),
        new t(n, Object.assign({}, Wn, { type: a, format: o }, s))
      );
    }
    static addToCache(t, e) {
      e &&
        (t.textureCacheIds.includes(e) || t.textureCacheIds.push(e),
        Bn[e] && Bn[e],
        (Bn[e] = t));
    }
    static removeFromCache(t) {
      if ("string" == typeof t) {
        const e = Bn[t];
        if (e) {
          const r = e.textureCacheIds.indexOf(t);
          return r > -1 && e.textureCacheIds.splice(r, 1), delete Bn[t], e;
        }
      } else if (null == t ? void 0 : t.textureCacheIds) {
        for (let e = 0; e < t.textureCacheIds.length; ++e)
          delete Bn[t.textureCacheIds[e]];
        return (t.textureCacheIds.length = 0), t;
      }
      return null;
    }
  };
($n.defaultOptions = {
  mipmap: ln.POW2,
  anisotropicLevel: 0,
  scaleMode: an.LINEAR,
  wrapMode: hn.CLAMP,
  alphaMode: un.UNPACK,
  target: sn.TEXTURE_2D,
  format: rn.RGBA,
  type: nn.UNSIGNED_BYTE,
}),
  ($n._globalBatch = 0);
let Yn = $n;
class qn {
  constructor() {
    (this.texArray = null),
      (this.blend = 0),
      (this.type = en.TRIANGLES),
      (this.start = 0),
      (this.size = 0),
      (this.data = null);
  }
}
let Kn = 0;
class Zn {
  constructor(t, e = !0, r = !1) {
    (this.data = t || new Float32Array(1)),
      (this._glBuffers = {}),
      (this._updateID = 0),
      (this.index = r),
      (this.static = e),
      (this.id = Kn++),
      (this.disposeRunner = new Xn("disposeBuffer"));
  }
  update(t) {
    t instanceof Array && (t = new Float32Array(t)),
      (this.data = t || this.data),
      this._updateID++;
  }
  dispose() {
    this.disposeRunner.emit(this, !1);
  }
  destroy() {
    this.dispose(), (this.data = null);
  }
  set index(t) {
    this.type = t ? gn.ELEMENT_ARRAY_BUFFER : gn.ARRAY_BUFFER;
  }
  get index() {
    return this.type === gn.ELEMENT_ARRAY_BUFFER;
  }
  static from(t) {
    return t instanceof Array && (t = new Float32Array(t)), new Zn(t);
  }
}
class Qn {
  constructor(t, e = 0, r = !1, i = nn.FLOAT, s, n, o, a = 1) {
    (this.buffer = t),
      (this.size = e),
      (this.normalized = r),
      (this.type = i),
      (this.stride = s),
      (this.start = n),
      (this.instance = o),
      (this.divisor = a);
  }
  destroy() {
    this.buffer = null;
  }
  static from(t, e, r, i, s) {
    return new Qn(t, e, r, i, s);
  }
}
const Jn = {
    Float32Array: Float32Array,
    Uint32Array: Uint32Array,
    Int32Array: Int32Array,
    Uint8Array: Uint8Array,
  },
  to = { 5126: 4, 5123: 2, 5121: 1 };
let eo = 0;
const ro = {
  Float32Array: Float32Array,
  Uint32Array: Uint32Array,
  Int32Array: Int32Array,
  Uint8Array: Uint8Array,
  Uint16Array: Uint16Array,
};
class io {
  constructor(t = [], e = {}) {
    (this.buffers = t),
      (this.indexBuffer = null),
      (this.attributes = e),
      (this.glVertexArrayObjects = {}),
      (this.id = eo++),
      (this.instanced = !1),
      (this.instanceCount = 1),
      (this.disposeRunner = new Xn("disposeGeometry")),
      (this.refCount = 0);
  }
  addAttribute(t, e, r = 0, i = !1, s, n, o, a = !1) {
    if (!e)
      throw new Error("You must pass a buffer when creating an attribute");
    e instanceof Zn ||
      (e instanceof Array && (e = new Float32Array(e)), (e = new Zn(e)));
    const h = t.split("|");
    if (h.length > 1) {
      for (let t = 0; t < h.length; t++) this.addAttribute(h[t], e, r, i, s);
      return this;
    }
    let l = this.buffers.indexOf(e);
    return (
      -1 === l && (this.buffers.push(e), (l = this.buffers.length - 1)),
      (this.attributes[t] = new Qn(l, r, i, s, n, o, a)),
      (this.instanced = this.instanced || a),
      this
    );
  }
  getAttribute(t) {
    return this.attributes[t];
  }
  getBuffer(t) {
    return this.buffers[this.getAttribute(t).buffer];
  }
  addIndex(t) {
    return (
      t instanceof Zn ||
        (t instanceof Array && (t = new Uint16Array(t)), (t = new Zn(t))),
      (t.type = gn.ELEMENT_ARRAY_BUFFER),
      (this.indexBuffer = t),
      this.buffers.includes(t) || this.buffers.push(t),
      this
    );
  }
  getIndex() {
    return this.indexBuffer;
  }
  interleave() {
    if (
      1 === this.buffers.length ||
      (2 === this.buffers.length && this.indexBuffer)
    )
      return this;
    const t = [],
      e = [],
      r = new Zn();
    let i;
    for (i in this.attributes) {
      const r = this.attributes[i],
        s = this.buffers[r.buffer];
      t.push(s.data), e.push((r.size * to[r.type]) / 4), (r.buffer = 0);
    }
    for (
      r.data = (function (t, e) {
        let r = 0,
          i = 0;
        const s = {};
        for (let h = 0; h < t.length; h++) (i += e[h]), (r += t[h].length);
        const n = new ArrayBuffer(4 * r);
        let o = null,
          a = 0;
        for (let h = 0; h < t.length; h++) {
          const r = e[h],
            l = t[h],
            u = Z(l);
          s[u] || (s[u] = new Jn[u](n)), (o = s[u]);
          for (let t = 0; t < l.length; t++)
            o[((t / r) | 0) * i + a + (t % r)] = l[t];
          a += r;
        }
        return new Float32Array(n);
      })(t, e),
        i = 0;
      i < this.buffers.length;
      i++
    )
      this.buffers[i] !== this.indexBuffer && this.buffers[i].destroy();
    return (
      (this.buffers = [r]),
      this.indexBuffer && this.buffers.push(this.indexBuffer),
      this
    );
  }
  getSize() {
    for (const t in this.attributes) {
      const e = this.attributes[t];
      return this.buffers[e.buffer].data.length / (e.stride / 4 || e.size);
    }
    return 0;
  }
  dispose() {
    this.disposeRunner.emit(this, !1);
  }
  destroy() {
    this.dispose(),
      (this.buffers = null),
      (this.indexBuffer = null),
      (this.attributes = null);
  }
  clone() {
    const t = new io();
    for (let e = 0; e < this.buffers.length; e++)
      t.buffers[e] = new Zn(this.buffers[e].data.slice(0));
    for (const e in this.attributes) {
      const r = this.attributes[e];
      t.attributes[e] = new Qn(
        r.buffer,
        r.size,
        r.normalized,
        r.type,
        r.stride,
        r.start,
        r.instance
      );
    }
    return (
      this.indexBuffer &&
        ((t.indexBuffer = t.buffers[this.buffers.indexOf(this.indexBuffer)]),
        (t.indexBuffer.type = gn.ELEMENT_ARRAY_BUFFER)),
      t
    );
  }
  static merge(t) {
    const e = new io(),
      r = [],
      i = [],
      s = [];
    let n;
    for (let o = 0; o < t.length; o++) {
      n = t[o];
      for (let t = 0; t < n.buffers.length; t++)
        (i[t] = i[t] || 0), (i[t] += n.buffers[t].data.length), (s[t] = 0);
    }
    for (let o = 0; o < n.buffers.length; o++)
      (r[o] = new ro[Z(n.buffers[o].data)](i[o])),
        (e.buffers[o] = new Zn(r[o]));
    for (let o = 0; o < t.length; o++) {
      n = t[o];
      for (let t = 0; t < n.buffers.length; t++)
        r[t].set(n.buffers[t].data, s[t]), (s[t] += n.buffers[t].data.length);
    }
    if (((e.attributes = n.attributes), n.indexBuffer)) {
      (e.indexBuffer = e.buffers[n.buffers.indexOf(n.indexBuffer)]),
        (e.indexBuffer.type = gn.ELEMENT_ARRAY_BUFFER);
      let r = 0,
        i = 0,
        s = 0,
        o = 0;
      for (let t = 0; t < n.buffers.length; t++)
        if (n.buffers[t] !== n.indexBuffer) {
          o = t;
          break;
        }
      for (const t in n.attributes) {
        const e = n.attributes[t];
        (0 | e.buffer) === o && (i += (e.size * to[e.type]) / 4);
      }
      for (let n = 0; n < t.length; n++) {
        const a = t[n].indexBuffer.data;
        for (let t = 0; t < a.length; t++) e.indexBuffer.data[t + s] += r;
        (r += t[n].buffers[o].data.length / i), (s += a.length);
      }
    }
    return e;
  }
}
class so extends io {
  constructor(t = !1) {
    super(),
      (this._buffer = new Zn(null, t, !1)),
      (this._indexBuffer = new Zn(null, t, !0)),
      this.addAttribute("aVertexPosition", this._buffer, 2, !1, nn.FLOAT)
        .addAttribute("aTextureCoord", this._buffer, 2, !1, nn.FLOAT)
        .addAttribute("aColor", this._buffer, 4, !0, nn.UNSIGNED_BYTE)
        .addAttribute("aTextureId", this._buffer, 1, !0, nn.FLOAT)
        .addIndex(this._indexBuffer);
  }
}
const no = 2 * Math.PI,
  oo = 180 / Math.PI,
  ao = Math.PI / 180;
Hs = ((t) => (
  (t[(t.POLY = 0)] = "POLY"),
  (t[(t.RECT = 1)] = "RECT"),
  (t[(t.CIRC = 2)] = "CIRC"),
  (t[(t.ELIP = 3)] = "ELIP"),
  (t[(t.RREC = 4)] = "RREC"),
  t
))(Hs || {});
class ho {
  constructor(t = 0, e = 0) {
    (this.x = 0), (this.y = 0), (this.x = t), (this.y = e);
  }
  clone() {
    return new ho(this.x, this.y);
  }
  copyFrom(t) {
    return this.set(t.x, t.y), this;
  }
  copyTo(t) {
    return t.set(this.x, this.y), t;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y;
  }
  set(t = 0, e = t) {
    return (this.x = t), (this.y = e), this;
  }
}
ho.prototype.toString = function () {
  return `[@pixi/math:Point x=${this.x} y=${this.y}]`;
};
const lo = [new ho(), new ho(), new ho(), new ho()];
class uo {
  constructor(t = 0, e = 0, r = 0, i = 0) {
    (this.x = Number(t)),
      (this.y = Number(e)),
      (this.width = Number(r)),
      (this.height = Number(i)),
      (this.type = Hs.RECT);
  }
  get left() {
    return this.x;
  }
  get right() {
    return this.x + this.width;
  }
  get top() {
    return this.y;
  }
  get bottom() {
    return this.y + this.height;
  }
  static get EMPTY() {
    return new uo(0, 0, 0, 0);
  }
  clone() {
    return new uo(this.x, this.y, this.width, this.height);
  }
  copyFrom(t) {
    return (
      (this.x = t.x),
      (this.y = t.y),
      (this.width = t.width),
      (this.height = t.height),
      this
    );
  }
  copyTo(t) {
    return (
      (t.x = this.x),
      (t.y = this.y),
      (t.width = this.width),
      (t.height = this.height),
      t
    );
  }
  contains(t, e) {
    return (
      !(this.width <= 0 || this.height <= 0) &&
      t >= this.x &&
      t < this.x + this.width &&
      e >= this.y &&
      e < this.y + this.height
    );
  }
  intersects(t, e) {
    if (!e) {
      const e = this.x < t.x ? t.x : this.x;
      if ((this.right > t.right ? t.right : this.right) <= e) return !1;
      const r = this.y < t.y ? t.y : this.y;
      return (this.bottom > t.bottom ? t.bottom : this.bottom) > r;
    }
    const r = this.left,
      i = this.right,
      s = this.top,
      n = this.bottom;
    if (i <= r || n <= s) return !1;
    const o = lo[0].set(t.left, t.top),
      a = lo[1].set(t.left, t.bottom),
      h = lo[2].set(t.right, t.top),
      l = lo[3].set(t.right, t.bottom);
    if (h.x <= o.x || a.y <= o.y) return !1;
    const u = Math.sign(e.a * e.d - e.b * e.c);
    if (
      0 === u ||
      (e.apply(o, o),
      e.apply(a, a),
      e.apply(h, h),
      e.apply(l, l),
      Math.max(o.x, a.x, h.x, l.x) <= r ||
        Math.min(o.x, a.x, h.x, l.x) >= i ||
        Math.max(o.y, a.y, h.y, l.y) <= s ||
        Math.min(o.y, a.y, h.y, l.y) >= n)
    )
      return !1;
    const c = u * (a.y - o.y),
      d = u * (o.x - a.x),
      p = c * r + d * s,
      f = c * i + d * s,
      m = c * r + d * n,
      g = c * i + d * n;
    if (
      Math.max(p, f, m, g) <= c * o.x + d * o.y ||
      Math.min(p, f, m, g) >= c * l.x + d * l.y
    )
      return !1;
    const _ = u * (o.y - h.y),
      y = u * (h.x - o.x),
      v = _ * r + y * s,
      x = _ * i + y * s,
      b = _ * r + y * n,
      E = _ * i + y * n;
    return !(
      Math.max(v, x, b, E) <= _ * o.x + y * o.y ||
      Math.min(v, x, b, E) >= _ * l.x + y * l.y
    );
  }
  pad(t = 0, e = t) {
    return (
      (this.x -= t),
      (this.y -= e),
      (this.width += 2 * t),
      (this.height += 2 * e),
      this
    );
  }
  fit(t) {
    const e = Math.max(this.x, t.x),
      r = Math.min(this.x + this.width, t.x + t.width),
      i = Math.max(this.y, t.y),
      s = Math.min(this.y + this.height, t.y + t.height);
    return (
      (this.x = e),
      (this.width = Math.max(r - e, 0)),
      (this.y = i),
      (this.height = Math.max(s - i, 0)),
      this
    );
  }
  ceil(t = 1, e = 0.001) {
    const r = Math.ceil((this.x + this.width - e) * t) / t,
      i = Math.ceil((this.y + this.height - e) * t) / t;
    return (
      (this.x = Math.floor((this.x + e) * t) / t),
      (this.y = Math.floor((this.y + e) * t) / t),
      (this.width = r - this.x),
      (this.height = i - this.y),
      this
    );
  }
  enlarge(t) {
    const e = Math.min(this.x, t.x),
      r = Math.max(this.x + this.width, t.x + t.width),
      i = Math.min(this.y, t.y),
      s = Math.max(this.y + this.height, t.y + t.height);
    return (
      (this.x = e),
      (this.width = r - e),
      (this.y = i),
      (this.height = s - i),
      this
    );
  }
}
uo.prototype.toString = function () {
  return `[@pixi/math:Rectangle x=${this.x} y=${this.y} width=${this.width} height=${this.height}]`;
};
class co {
  constructor(t = 0, e = 0, r = 0) {
    (this.x = t), (this.y = e), (this.radius = r), (this.type = Hs.CIRC);
  }
  clone() {
    return new co(this.x, this.y, this.radius);
  }
  contains(t, e) {
    if (this.radius <= 0) return !1;
    const r = this.radius * this.radius;
    let i = this.x - t,
      s = this.y - e;
    return (i *= i), (s *= s), i + s <= r;
  }
  getBounds() {
    return new uo(
      this.x - this.radius,
      this.y - this.radius,
      2 * this.radius,
      2 * this.radius
    );
  }
}
co.prototype.toString = function () {
  return `[@pixi/math:Circle x=${this.x} y=${this.y} radius=${this.radius}]`;
};
class po {
  constructor(t = 0, e = 0, r = 0, i = 0) {
    (this.x = t),
      (this.y = e),
      (this.width = r),
      (this.height = i),
      (this.type = Hs.ELIP);
  }
  clone() {
    return new po(this.x, this.y, this.width, this.height);
  }
  contains(t, e) {
    if (this.width <= 0 || this.height <= 0) return !1;
    let r = (t - this.x) / this.width,
      i = (e - this.y) / this.height;
    return (r *= r), (i *= i), r + i <= 1;
  }
  getBounds() {
    return new uo(
      this.x - this.width,
      this.y - this.height,
      this.width,
      this.height
    );
  }
}
po.prototype.toString = function () {
  return `[@pixi/math:Ellipse x=${this.x} y=${this.y} width=${this.width} height=${this.height}]`;
};
class fo {
  constructor(...t) {
    let e = Array.isArray(t[0]) ? t[0] : t;
    if ("number" != typeof e[0]) {
      const t = [];
      for (let r = 0, i = e.length; r < i; r++) t.push(e[r].x, e[r].y);
      e = t;
    }
    (this.points = e), (this.type = Hs.POLY), (this.closeStroke = !0);
  }
  clone() {
    const t = this.points.slice(),
      e = new fo(t);
    return (e.closeStroke = this.closeStroke), e;
  }
  contains(t, e) {
    let r = !1;
    const i = this.points.length / 2;
    for (let s = 0, n = i - 1; s < i; n = s++) {
      const i = this.points[2 * s],
        o = this.points[2 * s + 1],
        a = this.points[2 * n],
        h = this.points[2 * n + 1];
      o > e != h > e && t < ((e - o) / (h - o)) * (a - i) + i && (r = !r);
    }
    return r;
  }
}
fo.prototype.toString = function () {
  return `[@pixi/math:PolygoncloseStroke=${
    this.closeStroke
  }points=${this.points.reduce((t, e) => `${t}, ${e}`, "")}]`;
};
class mo {
  constructor(t = 0, e = 0, r = 0, i = 0, s = 20) {
    (this.x = t),
      (this.y = e),
      (this.width = r),
      (this.height = i),
      (this.radius = s),
      (this.type = Hs.RREC);
  }
  clone() {
    return new mo(this.x, this.y, this.width, this.height, this.radius);
  }
  contains(t, e) {
    if (this.width <= 0 || this.height <= 0) return !1;
    if (
      t >= this.x &&
      t <= this.x + this.width &&
      e >= this.y &&
      e <= this.y + this.height
    ) {
      const r = Math.max(
        0,
        Math.min(this.radius, Math.min(this.width, this.height) / 2)
      );
      if (
        (e >= this.y + r && e <= this.y + this.height - r) ||
        (t >= this.x + r && t <= this.x + this.width - r)
      )
        return !0;
      let i = t - (this.x + r),
        s = e - (this.y + r);
      const n = r * r;
      if (
        i * i + s * s <= n ||
        ((i = t - (this.x + this.width - r)), i * i + s * s <= n) ||
        ((s = e - (this.y + this.height - r)), i * i + s * s <= n) ||
        ((i = t - (this.x + r)), i * i + s * s <= n)
      )
        return !0;
    }
    return !1;
  }
}
mo.prototype.toString = function () {
  return `[@pixi/math:RoundedRectangle x=${this.x} y=${this.y}width=${this.width} height=${this.height} radius=${this.radius}]`;
};
class go {
  constructor(t = 1, e = 0, r = 0, i = 1, s = 0, n = 0) {
    (this.array = null),
      (this.a = t),
      (this.b = e),
      (this.c = r),
      (this.d = i),
      (this.tx = s),
      (this.ty = n);
  }
  fromArray(t) {
    (this.a = t[0]),
      (this.b = t[1]),
      (this.c = t[3]),
      (this.d = t[4]),
      (this.tx = t[2]),
      (this.ty = t[5]);
  }
  set(t, e, r, i, s, n) {
    return (
      (this.a = t),
      (this.b = e),
      (this.c = r),
      (this.d = i),
      (this.tx = s),
      (this.ty = n),
      this
    );
  }
  toArray(t, e) {
    this.array || (this.array = new Float32Array(9));
    const r = e || this.array;
    return (
      t
        ? ((r[0] = this.a),
          (r[1] = this.b),
          (r[2] = 0),
          (r[3] = this.c),
          (r[4] = this.d),
          (r[5] = 0),
          (r[6] = this.tx),
          (r[7] = this.ty),
          (r[8] = 1))
        : ((r[0] = this.a),
          (r[1] = this.c),
          (r[2] = this.tx),
          (r[3] = this.b),
          (r[4] = this.d),
          (r[5] = this.ty),
          (r[6] = 0),
          (r[7] = 0),
          (r[8] = 1)),
      r
    );
  }
  apply(t, e) {
    e = e || new ho();
    const r = t.x,
      i = t.y;
    return (
      (e.x = this.a * r + this.c * i + this.tx),
      (e.y = this.b * r + this.d * i + this.ty),
      e
    );
  }
  applyInverse(t, e) {
    e = e || new ho();
    const r = 1 / (this.a * this.d + this.c * -this.b),
      i = t.x,
      s = t.y;
    return (
      (e.x =
        this.d * r * i +
        -this.c * r * s +
        (this.ty * this.c - this.tx * this.d) * r),
      (e.y =
        this.a * r * s +
        -this.b * r * i +
        (-this.ty * this.a + this.tx * this.b) * r),
      e
    );
  }
  translate(t, e) {
    return (this.tx += t), (this.ty += e), this;
  }
  scale(t, e) {
    return (
      (this.a *= t),
      (this.d *= e),
      (this.c *= t),
      (this.b *= e),
      (this.tx *= t),
      (this.ty *= e),
      this
    );
  }
  rotate(t) {
    const e = Math.cos(t),
      r = Math.sin(t),
      i = this.a,
      s = this.c,
      n = this.tx;
    return (
      (this.a = i * e - this.b * r),
      (this.b = i * r + this.b * e),
      (this.c = s * e - this.d * r),
      (this.d = s * r + this.d * e),
      (this.tx = n * e - this.ty * r),
      (this.ty = n * r + this.ty * e),
      this
    );
  }
  append(t) {
    const e = this.a,
      r = this.b,
      i = this.c,
      s = this.d;
    return (
      (this.a = t.a * e + t.b * i),
      (this.b = t.a * r + t.b * s),
      (this.c = t.c * e + t.d * i),
      (this.d = t.c * r + t.d * s),
      (this.tx = t.tx * e + t.ty * i + this.tx),
      (this.ty = t.tx * r + t.ty * s + this.ty),
      this
    );
  }
  setTransform(t, e, r, i, s, n, o, a, h) {
    return (
      (this.a = Math.cos(o + h) * s),
      (this.b = Math.sin(o + h) * s),
      (this.c = -Math.sin(o - a) * n),
      (this.d = Math.cos(o - a) * n),
      (this.tx = t - (r * this.a + i * this.c)),
      (this.ty = e - (r * this.b + i * this.d)),
      this
    );
  }
  prepend(t) {
    const e = this.tx;
    if (1 !== t.a || 0 !== t.b || 0 !== t.c || 1 !== t.d) {
      const e = this.a,
        r = this.c;
      (this.a = e * t.a + this.b * t.c),
        (this.b = e * t.b + this.b * t.d),
        (this.c = r * t.a + this.d * t.c),
        (this.d = r * t.b + this.d * t.d);
    }
    return (
      (this.tx = e * t.a + this.ty * t.c + t.tx),
      (this.ty = e * t.b + this.ty * t.d + t.ty),
      this
    );
  }
  decompose(t) {
    const e = this.a,
      r = this.b,
      i = this.c,
      s = this.d,
      n = t.pivot,
      o = -Math.atan2(-i, s),
      a = Math.atan2(r, e),
      h = Math.abs(o + a);
    return (
      h < 1e-5 || Math.abs(no - h) < 1e-5
        ? ((t.rotation = a), (t.skew.x = t.skew.y = 0))
        : ((t.rotation = 0), (t.skew.x = o), (t.skew.y = a)),
      (t.scale.x = Math.sqrt(e * e + r * r)),
      (t.scale.y = Math.sqrt(i * i + s * s)),
      (t.position.x = this.tx + (n.x * e + n.y * i)),
      (t.position.y = this.ty + (n.x * r + n.y * s)),
      t
    );
  }
  invert() {
    const t = this.a,
      e = this.b,
      r = this.c,
      i = this.d,
      s = this.tx,
      n = t * i - e * r;
    return (
      (this.a = i / n),
      (this.b = -e / n),
      (this.c = -r / n),
      (this.d = t / n),
      (this.tx = (r * this.ty - i * s) / n),
      (this.ty = -(t * this.ty - e * s) / n),
      this
    );
  }
  identity() {
    return (
      (this.a = 1),
      (this.b = 0),
      (this.c = 0),
      (this.d = 1),
      (this.tx = 0),
      (this.ty = 0),
      this
    );
  }
  clone() {
    const t = new go();
    return (
      (t.a = this.a),
      (t.b = this.b),
      (t.c = this.c),
      (t.d = this.d),
      (t.tx = this.tx),
      (t.ty = this.ty),
      t
    );
  }
  copyTo(t) {
    return (
      (t.a = this.a),
      (t.b = this.b),
      (t.c = this.c),
      (t.d = this.d),
      (t.tx = this.tx),
      (t.ty = this.ty),
      t
    );
  }
  copyFrom(t) {
    return (
      (this.a = t.a),
      (this.b = t.b),
      (this.c = t.c),
      (this.d = t.d),
      (this.tx = t.tx),
      (this.ty = t.ty),
      this
    );
  }
  static get IDENTITY() {
    return new go();
  }
  static get TEMP_MATRIX() {
    return new go();
  }
}
go.prototype.toString = function () {
  return `[@pixi/math:Matrix a=${this.a} b=${this.b} c=${this.c} d=${this.d} tx=${this.tx} ty=${this.ty}]`;
};
const _o = [1, 1, 0, -1, -1, -1, 0, 1, 1, 1, 0, -1, -1, -1, 0, 1],
  yo = [0, 1, 1, 1, 0, -1, -1, -1, 0, 1, 1, 1, 0, -1, -1, -1],
  vo = [0, -1, -1, -1, 0, 1, 1, 1, 0, 1, 1, 1, 0, -1, -1, -1],
  xo = [1, 1, 0, -1, -1, -1, 0, 1, -1, -1, 0, 1, 1, 1, 0, -1],
  bo = [],
  Eo = [],
  To = Math.sign;
!(function () {
  for (let t = 0; t < 16; t++) {
    const e = [];
    bo.push(e);
    for (let r = 0; r < 16; r++) {
      const i = To(_o[t] * _o[r] + vo[t] * yo[r]),
        s = To(yo[t] * _o[r] + xo[t] * yo[r]),
        n = To(_o[t] * vo[r] + vo[t] * xo[r]),
        o = To(yo[t] * vo[r] + xo[t] * xo[r]);
      for (let t = 0; t < 16; t++)
        if (_o[t] === i && yo[t] === s && vo[t] === n && xo[t] === o) {
          e.push(t);
          break;
        }
    }
  }
  for (let t = 0; t < 16; t++) {
    const e = new go();
    e.set(_o[t], yo[t], vo[t], xo[t], 0, 0), Eo.push(e);
  }
})();
const Ao = {
  E: 0,
  SE: 1,
  S: 2,
  SW: 3,
  W: 4,
  NW: 5,
  N: 6,
  NE: 7,
  MIRROR_VERTICAL: 8,
  MAIN_DIAGONAL: 10,
  MIRROR_HORIZONTAL: 12,
  REVERSE_DIAGONAL: 14,
  uX: (t) => _o[t],
  uY: (t) => yo[t],
  vX: (t) => vo[t],
  vY: (t) => xo[t],
  inv: (t) => (8 & t ? 15 & t : 7 & -t),
  add: (t, e) => bo[t][e],
  sub: (t, e) => bo[t][Ao.inv(e)],
  rotate180: (t) => 4 ^ t,
  isVertical: (t) => 2 == (3 & t),
  byDirection: (t, e) =>
    2 * Math.abs(t) <= Math.abs(e)
      ? e >= 0
        ? Ao.S
        : Ao.N
      : 2 * Math.abs(e) <= Math.abs(t)
      ? t > 0
        ? Ao.E
        : Ao.W
      : e > 0
      ? t > 0
        ? Ao.SE
        : Ao.SW
      : t > 0
      ? Ao.NE
      : Ao.NW,
  matrixAppendRotationInv: (t, e, r = 0, i = 0) => {
    const s = Eo[Ao.inv(e)];
    (s.tx = r), (s.ty = i), t.append(s);
  },
};
class wo {
  constructor(t, e, r = 0, i = 0) {
    (this._x = r), (this._y = i), (this.cb = t), (this.scope = e);
  }
  clone(t = this.cb, e = this.scope) {
    return new wo(t, e, this._x, this._y);
  }
  set(t = 0, e = t) {
    return (
      (this._x !== t || this._y !== e) &&
        ((this._x = t), (this._y = e), this.cb.call(this.scope)),
      this
    );
  }
  copyFrom(t) {
    return (
      (this._x !== t.x || this._y !== t.y) &&
        ((this._x = t.x), (this._y = t.y), this.cb.call(this.scope)),
      this
    );
  }
  copyTo(t) {
    return t.set(this._x, this._y), t;
  }
  equals(t) {
    return t.x === this._x && t.y === this._y;
  }
  get x() {
    return this._x;
  }
  set x(t) {
    this._x !== t && ((this._x = t), this.cb.call(this.scope));
  }
  get y() {
    return this._y;
  }
  set y(t) {
    this._y !== t && ((this._y = t), this.cb.call(this.scope));
  }
}
wo.prototype.toString = function () {
  return `[@pixi/math:ObservablePoint x=${this.x} y=${this.y} scope=${this.scope}]`;
};
const So = class {
  constructor() {
    (this.worldTransform = new go()),
      (this.localTransform = new go()),
      (this.position = new wo(this.onChange, this, 0, 0)),
      (this.scale = new wo(this.onChange, this, 1, 1)),
      (this.pivot = new wo(this.onChange, this, 0, 0)),
      (this.skew = new wo(this.updateSkew, this, 0, 0)),
      (this._rotation = 0),
      (this._cx = 1),
      (this._sx = 0),
      (this._cy = 0),
      (this._sy = 1),
      (this._localID = 0),
      (this._currentLocalID = 0),
      (this._worldID = 0),
      (this._parentID = 0);
  }
  onChange() {
    this._localID++;
  }
  updateSkew() {
    (this._cx = Math.cos(this._rotation + this.skew.y)),
      (this._sx = Math.sin(this._rotation + this.skew.y)),
      (this._cy = -Math.sin(this._rotation - this.skew.x)),
      (this._sy = Math.cos(this._rotation - this.skew.x)),
      this._localID++;
  }
  updateLocalTransform() {
    const t = this.localTransform;
    this._localID !== this._currentLocalID &&
      ((t.a = this._cx * this.scale.x),
      (t.b = this._sx * this.scale.x),
      (t.c = this._cy * this.scale.y),
      (t.d = this._sy * this.scale.y),
      (t.tx = this.position.x - (this.pivot.x * t.a + this.pivot.y * t.c)),
      (t.ty = this.position.y - (this.pivot.x * t.b + this.pivot.y * t.d)),
      (this._currentLocalID = this._localID),
      (this._parentID = -1));
  }
  updateTransform(t) {
    const e = this.localTransform;
    if (
      (this._localID !== this._currentLocalID &&
        ((e.a = this._cx * this.scale.x),
        (e.b = this._sx * this.scale.x),
        (e.c = this._cy * this.scale.y),
        (e.d = this._sy * this.scale.y),
        (e.tx = this.position.x - (this.pivot.x * e.a + this.pivot.y * e.c)),
        (e.ty = this.position.y - (this.pivot.x * e.b + this.pivot.y * e.d)),
        (this._currentLocalID = this._localID),
        (this._parentID = -1)),
      this._parentID !== t._worldID)
    ) {
      const r = t.worldTransform,
        i = this.worldTransform;
      (i.a = e.a * r.a + e.b * r.c),
        (i.b = e.a * r.b + e.b * r.d),
        (i.c = e.c * r.a + e.d * r.c),
        (i.d = e.c * r.b + e.d * r.d),
        (i.tx = e.tx * r.a + e.ty * r.c + r.tx),
        (i.ty = e.tx * r.b + e.ty * r.d + r.ty),
        (this._parentID = t._worldID),
        this._worldID++;
    }
  }
  setFromMatrix(t) {
    t.decompose(this), this._localID++;
  }
  get rotation() {
    return this._rotation;
  }
  set rotation(t) {
    this._rotation !== t && ((this._rotation = t), this.updateSkew());
  }
};
So.IDENTITY = new So();
let Ro = So;
Ro.prototype.toString = function () {
  return `[@pixi/math:Transform position=(${this.position.x}, ${this.position.y}) rotation=${this.rotation} scale=(${this.scale.x}, ${this.scale.y}) skew=(${this.skew.x}, ${this.skew.y}) ]`;
};
const Io = [
    {
      test: (t) => "float" === t.type && 1 === t.size && !t.isArray,
      code: (t) =>
        `\n            if(uv["${t}"] !== ud["${t}"].value)\n            {\n                ud["${t}"].value = uv["${t}"]\n                gl.uniform1f(ud["${t}"].location, uv["${t}"])\n            }\n            `,
    },
    {
      test: (t, e) =>
        !(
          ("sampler2D" !== t.type &&
            "samplerCube" !== t.type &&
            "sampler2DArray" !== t.type) ||
          1 !== t.size ||
          t.isArray ||
          (null != e && void 0 === e.castToBaseTexture)
        ),
      code: (t) =>
        `t = syncData.textureCount++;\n\n            renderer.texture.bind(uv["${t}"], t);\n\n            if(ud["${t}"].value !== t)\n            {\n                ud["${t}"].value = t;\n                gl.uniform1i(ud["${t}"].location, t);\n; // eslint-disable-line max-len\n            }`,
    },
    {
      test: (t, e) =>
        "mat3" === t.type && 1 === t.size && !t.isArray && void 0 !== e.a,
      code: (t) =>
        `\n            gl.uniformMatrix3fv(ud["${t}"].location, false, uv["${t}"].toArray(true));\n            `,
      codeUbo: (t) =>
        `\n                var ${t}_matrix = uv.${t}.toArray(true);\n\n                data[offset] = ${t}_matrix[0];\n                data[offset+1] = ${t}_matrix[1];\n                data[offset+2] = ${t}_matrix[2];\n        \n                data[offset + 4] = ${t}_matrix[3];\n                data[offset + 5] = ${t}_matrix[4];\n                data[offset + 6] = ${t}_matrix[5];\n        \n                data[offset + 8] = ${t}_matrix[6];\n                data[offset + 9] = ${t}_matrix[7];\n                data[offset + 10] = ${t}_matrix[8];\n            `,
    },
    {
      test: (t, e) =>
        "vec2" === t.type && 1 === t.size && !t.isArray && void 0 !== e.x,
      code: (t) =>
        `\n                cv = ud["${t}"].value;\n                v = uv["${t}"];\n\n                if(cv[0] !== v.x || cv[1] !== v.y)\n                {\n                    cv[0] = v.x;\n                    cv[1] = v.y;\n                    gl.uniform2f(ud["${t}"].location, v.x, v.y);\n                }`,
      codeUbo: (t) =>
        `\n                v = uv.${t};\n\n                data[offset] = v.x;\n                data[offset+1] = v.y;\n            `,
    },
    {
      test: (t) => "vec2" === t.type && 1 === t.size && !t.isArray,
      code: (t) =>
        `\n                cv = ud["${t}"].value;\n                v = uv["${t}"];\n\n                if(cv[0] !== v[0] || cv[1] !== v[1])\n                {\n                    cv[0] = v[0];\n                    cv[1] = v[1];\n                    gl.uniform2f(ud["${t}"].location, v[0], v[1]);\n                }\n            `,
    },
    {
      test: (t, e) =>
        "vec4" === t.type && 1 === t.size && !t.isArray && void 0 !== e.width,
      code: (t) =>
        `\n                cv = ud["${t}"].value;\n                v = uv["${t}"];\n\n                if(cv[0] !== v.x || cv[1] !== v.y || cv[2] !== v.width || cv[3] !== v.height)\n                {\n                    cv[0] = v.x;\n                    cv[1] = v.y;\n                    cv[2] = v.width;\n                    cv[3] = v.height;\n                    gl.uniform4f(ud["${t}"].location, v.x, v.y, v.width, v.height)\n                }`,
      codeUbo: (t) =>
        `\n                    v = uv.${t};\n\n                    data[offset] = v.x;\n                    data[offset+1] = v.y;\n                    data[offset+2] = v.width;\n                    data[offset+3] = v.height;\n                `,
    },
    {
      test: (t, e) =>
        "vec4" === t.type && 1 === t.size && !t.isArray && void 0 !== e.red,
      code: (t) =>
        `\n                cv = ud["${t}"].value;\n                v = uv["${t}"];\n\n                if(cv[0] !== v.red || cv[1] !== v.green || cv[2] !== v.blue || cv[3] !== v.alpha)\n                {\n                    cv[0] = v.red;\n                    cv[1] = v.green;\n                    cv[2] = v.blue;\n                    cv[3] = v.alpha;\n                    gl.uniform4f(ud["${t}"].location, v.red, v.green, v.blue, v.alpha)\n                }`,
      codeUbo: (t) =>
        `\n                    v = uv.${t};\n\n                    data[offset] = v.red;\n                    data[offset+1] = v.green;\n                    data[offset+2] = v.blue;\n                    data[offset+3] = v.alpha;\n                `,
    },
    {
      test: (t, e) =>
        "vec3" === t.type && 1 === t.size && !t.isArray && void 0 !== e.red,
      code: (t) =>
        `\n                cv = ud["${t}"].value;\n                v = uv["${t}"];\n\n                if(cv[0] !== v.red || cv[1] !== v.green || cv[2] !== v.blue || cv[3] !== v.a)\n                {\n                    cv[0] = v.red;\n                    cv[1] = v.green;\n                    cv[2] = v.blue;\n    \n                    gl.uniform3f(ud["${t}"].location, v.red, v.green, v.blue)\n                }`,
      codeUbo: (t) =>
        `\n                    v = uv.${t};\n\n                    data[offset] = v.red;\n                    data[offset+1] = v.green;\n                    data[offset+2] = v.blue;\n                `,
    },
    {
      test: (t) => "vec4" === t.type && 1 === t.size && !t.isArray,
      code: (t) =>
        `\n                cv = ud["${t}"].value;\n                v = uv["${t}"];\n\n                if(cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n                {\n                    cv[0] = v[0];\n                    cv[1] = v[1];\n                    cv[2] = v[2];\n                    cv[3] = v[3];\n\n                    gl.uniform4f(ud["${t}"].location, v[0], v[1], v[2], v[3])\n                }`,
    },
  ],
  Co = {
    float:
      "\n    if (cv !== v)\n    {\n        cu.value = v;\n        gl.uniform1f(location, v);\n    }",
    vec2: "\n    if (cv[0] !== v[0] || cv[1] !== v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2f(location, v[0], v[1])\n    }",
    vec3: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3f(location, v[0], v[1], v[2])\n    }",
    vec4: "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4f(location, v[0], v[1], v[2], v[3]);\n    }",
    int: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
    ivec2:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2i(location, v[0], v[1]);\n    }",
    ivec3:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3i(location, v[0], v[1], v[2]);\n    }",
    ivec4:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4i(location, v[0], v[1], v[2], v[3]);\n    }",
    uint: "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1ui(location, v);\n    }",
    uvec2:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2ui(location, v[0], v[1]);\n    }",
    uvec3:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3ui(location, v[0], v[1], v[2]);\n    }",
    uvec4:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4ui(location, v[0], v[1], v[2], v[3]);\n    }",
    bool: "\n    if (cv !== v)\n    {\n        cu.value = v;\n        gl.uniform1i(location, v);\n    }",
    bvec2:
      "\n    if (cv[0] != v[0] || cv[1] != v[1])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n\n        gl.uniform2i(location, v[0], v[1]);\n    }",
    bvec3:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n\n        gl.uniform3i(location, v[0], v[1], v[2]);\n    }",
    bvec4:
      "\n    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])\n    {\n        cv[0] = v[0];\n        cv[1] = v[1];\n        cv[2] = v[2];\n        cv[3] = v[3];\n\n        gl.uniform4i(location, v[0], v[1], v[2], v[3]);\n    }",
    mat2: "gl.uniformMatrix2fv(location, false, v)",
    mat3: "gl.uniformMatrix3fv(location, false, v)",
    mat4: "gl.uniformMatrix4fv(location, false, v)",
    sampler2D:
      "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
    samplerCube:
      "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
    sampler2DArray:
      "\n    if (cv !== v)\n    {\n        cu.value = v;\n\n        gl.uniform1i(location, v);\n    }",
  },
  Po = {
    float: "gl.uniform1fv(location, v)",
    vec2: "gl.uniform2fv(location, v)",
    vec3: "gl.uniform3fv(location, v)",
    vec4: "gl.uniform4fv(location, v)",
    mat4: "gl.uniformMatrix4fv(location, false, v)",
    mat3: "gl.uniformMatrix3fv(location, false, v)",
    mat2: "gl.uniformMatrix2fv(location, false, v)",
    int: "gl.uniform1iv(location, v)",
    ivec2: "gl.uniform2iv(location, v)",
    ivec3: "gl.uniform3iv(location, v)",
    ivec4: "gl.uniform4iv(location, v)",
    uint: "gl.uniform1uiv(location, v)",
    uvec2: "gl.uniform2uiv(location, v)",
    uvec3: "gl.uniform3uiv(location, v)",
    uvec4: "gl.uniform4uiv(location, v)",
    bool: "gl.uniform1iv(location, v)",
    bvec2: "gl.uniform2iv(location, v)",
    bvec3: "gl.uniform3iv(location, v)",
    bvec4: "gl.uniform4iv(location, v)",
    sampler2D: "gl.uniform1iv(location, v)",
    samplerCube: "gl.uniform1iv(location, v)",
    sampler2DArray: "gl.uniform1iv(location, v)",
  },
  Mo = {};
let Do,
  Oo = Mo;
const Bo = {
  float: 1,
  vec2: 2,
  vec3: 3,
  vec4: 4,
  int: 1,
  ivec2: 2,
  ivec3: 3,
  ivec4: 4,
  uint: 1,
  uvec2: 2,
  uvec3: 3,
  uvec4: 4,
  bool: 1,
  bvec2: 2,
  bvec3: 3,
  bvec4: 4,
  mat2: 4,
  mat3: 9,
  mat4: 16,
  sampler2D: 1,
};
let No = null;
const Fo = {
  FLOAT: "float",
  FLOAT_VEC2: "vec2",
  FLOAT_VEC3: "vec3",
  FLOAT_VEC4: "vec4",
  INT: "int",
  INT_VEC2: "ivec2",
  INT_VEC3: "ivec3",
  INT_VEC4: "ivec4",
  UNSIGNED_INT: "uint",
  UNSIGNED_INT_VEC2: "uvec2",
  UNSIGNED_INT_VEC3: "uvec3",
  UNSIGNED_INT_VEC4: "uvec4",
  BOOL: "bool",
  BOOL_VEC2: "bvec2",
  BOOL_VEC3: "bvec3",
  BOOL_VEC4: "bvec4",
  FLOAT_MAT2: "mat2",
  FLOAT_MAT3: "mat3",
  FLOAT_MAT4: "mat4",
  SAMPLER_2D: "sampler2D",
  INT_SAMPLER_2D: "sampler2D",
  UNSIGNED_INT_SAMPLER_2D: "sampler2D",
  SAMPLER_CUBE: "samplerCube",
  INT_SAMPLER_CUBE: "samplerCube",
  UNSIGNED_INT_SAMPLER_CUBE: "samplerCube",
  SAMPLER_2D_ARRAY: "sampler2DArray",
  INT_SAMPLER_2D_ARRAY: "sampler2DArray",
  UNSIGNED_INT_SAMPLER_2D_ARRAY: "sampler2DArray",
};
let Lo,
  ko = 0;
const Uo = {},
  Go = class t {
    constructor(e, r, i = "pixi-shader", s = {}) {
      (this.extra = {}),
        (this.id = ko++),
        (this.vertexSrc = e || t.defaultVertexSrc),
        (this.fragmentSrc = r || t.defaultFragmentSrc),
        (this.vertexSrc = this.vertexSrc.trim()),
        (this.fragmentSrc = this.fragmentSrc.trim()),
        (this.extra = s),
        "#version" !== this.vertexSrc.substring(0, 8) &&
          ((i = i.replace(/\s+/g, "-")),
          Uo[i] ? (Uo[i]++, (i += `-${Uo[i]}`)) : (Uo[i] = 1),
          (this.vertexSrc = `#define SHADER_NAME ${i}\n${this.vertexSrc}`),
          (this.fragmentSrc = `#define SHADER_NAME ${i}\n${this.fragmentSrc}`),
          (this.vertexSrc = mt(
            this.vertexSrc,
            t.defaultVertexPrecision,
            pn.HIGH
          )),
          (this.fragmentSrc = mt(
            this.fragmentSrc,
            t.defaultFragmentPrecision,
            (function () {
              if (!Do) {
                Do = pn.MEDIUM;
                const t = (function () {
                  if (Oo === Mo || (null == Oo ? void 0 : Oo.isContextLost())) {
                    const t = _n.ADAPTER.createCanvas();
                    let e;
                    _n.PREFER_ENV >= Zs.WEBGL2 &&
                      (e = t.getContext("webgl2", {})),
                      e ||
                        ((e =
                          t.getContext("webgl", {}) ||
                          t.getContext("experimental-webgl", {})),
                        e ? e.getExtension("WEBGL_draw_buffers") : (e = null)),
                      (Oo = e);
                  }
                  return Oo;
                })();
                t &&
                  t.getShaderPrecisionFormat &&
                  (Do = t.getShaderPrecisionFormat(
                    t.FRAGMENT_SHADER,
                    t.HIGH_FLOAT
                  ).precision
                    ? pn.HIGH
                    : pn.MEDIUM);
              }
              return Do;
            })()
          ))),
        (this.glPrograms = {}),
        (this.syncUniforms = null);
    }
    static get defaultVertexSrc() {
      return "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nvoid main(void){\n   gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n   vTextureCoord = aTextureCoord;\n}\n";
    }
    static get defaultFragmentSrc() {
      return "varying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\n\nvoid main(void){\n   gl_FragColor *= texture2D(uSampler, vTextureCoord);\n}";
    }
    static from(e, r, i) {
      const s = e + r;
      let n = Dn[s];
      return n || (Dn[s] = n = new t(e, r, i)), n;
    }
  };
(Go.defaultVertexPrecision = pn.HIGH),
  (Go.defaultFragmentPrecision = yn.apple.device ? pn.HIGH : pn.MEDIUM);
let Ho = Go,
  jo = 0;
class Xo {
  constructor(t, e, r) {
    (this.group = !0),
      (this.syncUniforms = {}),
      (this.dirtyId = 0),
      (this.id = jo++),
      (this.static = !!e),
      (this.ubo = !!r),
      t instanceof Zn
        ? ((this.buffer = t),
          (this.buffer.type = gn.UNIFORM_BUFFER),
          (this.autoManage = !1),
          (this.ubo = !0))
        : ((this.uniforms = t),
          this.ubo &&
            ((this.buffer = new Zn(new Float32Array(1))),
            (this.buffer.type = gn.UNIFORM_BUFFER),
            (this.autoManage = !0)));
  }
  update() {
    this.dirtyId++, !this.autoManage && this.buffer && this.buffer.update();
  }
  add(t, e, r) {
    if (this.ubo)
      throw new Error(
        "[UniformGroup] uniform groups in ubo mode cannot be modified, or have uniform groups nested in them"
      );
    this.uniforms[t] = new Xo(e, r);
  }
  static from(t, e, r) {
    return new Xo(t, e, r);
  }
  static uboFrom(t, e) {
    return new Xo(t, e ?? !0, !0);
  }
}
class Vo {
  constructor(t, e) {
    (this.uniformBindCount = 0),
      (this.program = t),
      (this.uniformGroup = e ? (e instanceof Xo ? e : new Xo(e)) : new Xo({})),
      (this.disposeRunner = new Xn("disposeShader"));
  }
  checkUniformExists(t, e) {
    if (e.uniforms[t]) return !0;
    for (const r in e.uniforms) {
      const i = e.uniforms[r];
      if (!0 === i.group && this.checkUniformExists(t, i)) return !0;
    }
    return !1;
  }
  destroy() {
    (this.uniformGroup = null),
      this.disposeRunner.emit(this),
      this.disposeRunner.destroy();
  }
  get uniforms() {
    return this.uniformGroup.uniforms;
  }
  static from(t, e, r) {
    const i = Ho.from(t, e);
    return new Vo(i, r);
  }
}
class zo {
  constructor(t, e) {
    if (
      ((this.vertexSrc = t),
      (this.fragTemplate = e),
      (this.programCache = {}),
      (this.defaultGroupCache = {}),
      !e.includes("%count%"))
    )
      throw new Error('Fragment template must contain "%count%".');
    if (!e.includes("%forloop%"))
      throw new Error('Fragment template must contain "%forloop%".');
  }
  generateShader(t) {
    if (!this.programCache[t]) {
      const e = new Int32Array(t);
      for (let i = 0; i < t; i++) e[i] = i;
      this.defaultGroupCache[t] = Xo.from({ uSamplers: e }, !0);
      let r = this.fragTemplate;
      (r = r.replace(/%count%/gi, `${t}`)),
        (r = r.replace(/%forloop%/gi, this.generateSampleSrc(t))),
        (this.programCache[t] = new Ho(this.vertexSrc, r));
    }
    const e = {
      tint: new Float32Array([1, 1, 1, 1]),
      translationMatrix: new go(),
      default: this.defaultGroupCache[t],
    };
    return new Vo(this.programCache[t], e);
  }
  generateSampleSrc(t) {
    let e = "";
    (e += "\n"), (e += "\n");
    for (let r = 0; r < t; r++)
      r > 0 && (e += "\nelse "),
        r < t - 1 && (e += `if(vTextureId < ${r}.5)`),
        (e += "\n{"),
        (e += `\n\tcolor = texture2D(uSamplers[${r}], vTextureCoord);`),
        (e += "\n}");
    return (e += "\n"), (e += "\n"), e;
  }
}
class Wo {
  constructor() {
    (this.elements = []), (this.ids = []), (this.count = 0);
  }
  clear() {
    for (let t = 0; t < this.count; t++) this.elements[t] = null;
    this.count = 0;
  }
}
class $o {
  constructor(t) {
    this.renderer = t;
  }
  flush() {}
  destroy() {
    this.renderer = null;
  }
  start() {}
  stop() {
    this.flush();
  }
  render(t) {}
}
const Yo = class t extends $o {
  constructor(e) {
    super(e),
      this.setShaderGenerator(),
      (this.geometryClass = so),
      (this.vertexSize = 6),
      (this.state = Hn.for2d()),
      (this.size = 4 * t.defaultBatchSize),
      (this._vertexCount = 0),
      (this._indexCount = 0),
      (this._bufferedElements = []),
      (this._bufferedTextures = []),
      (this._bufferSize = 0),
      (this._shader = null),
      (this._packedGeometries = []),
      (this._packedGeometryPoolSize = 2),
      (this._flushId = 0),
      (this._aBuffers = {}),
      (this._iBuffers = {}),
      (this.maxTextures = 1),
      this.renderer.on("prerender", this.onPrerender, this),
      e.runners.contextChange.add(this),
      (this._dcIndex = 0),
      (this._aIndex = 0),
      (this._iIndex = 0),
      (this._attributeBuffer = null),
      (this._indexBuffer = null),
      (this._tempBoundTextures = []);
  }
  static get defaultMaxTextures() {
    return (
      (this._defaultMaxTextures =
        this._defaultMaxTextures ??
        (function (t) {
          let e = !0;
          const r = _n.ADAPTER.getNavigator();
          if (yn.tablet || yn.phone) {
            if (yn.apple.device) {
              const t = r.userAgent.match(/OS (\d+)_(\d+)?/);
              t && parseInt(t[1], 10) < 11 && (e = !1);
            }
            if (yn.android.device) {
              const t = r.userAgent.match(/Android\s([0-9.]*)/);
              t && parseInt(t[1], 10) < 7 && (e = !1);
            }
          }
          return e ? 32 : 4;
        })()),
      this._defaultMaxTextures
    );
  }
  static set defaultMaxTextures(t) {
    this._defaultMaxTextures = t;
  }
  static get canUploadSameBuffer() {
    return (
      (this._canUploadSameBuffer =
        this._canUploadSameBuffer ?? !yn.apple.device),
      this._canUploadSameBuffer
    );
  }
  static set canUploadSameBuffer(t) {
    this._canUploadSameBuffer = t;
  }
  get MAX_TEXTURES() {
    return (
      W(0, "BatchRenderer#MAX_TEXTURES renamed to BatchRenderer#maxTextures"),
      this.maxTextures
    );
  }
  static get defaultVertexSrc() {
    return "precision highp float;\nattribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\nattribute vec4 aColor;\nattribute float aTextureId;\n\nuniform mat3 projectionMatrix;\nuniform mat3 translationMatrix;\nuniform vec4 tint;\n\nvarying vec2 vTextureCoord;\nvarying vec4 vColor;\nvarying float vTextureId;\n\nvoid main(void){\n    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = aTextureCoord;\n    vTextureId = aTextureId;\n    vColor = aColor * tint;\n}\n";
  }
  static get defaultFragmentTemplate() {
    return "varying vec2 vTextureCoord;\nvarying vec4 vColor;\nvarying float vTextureId;\nuniform sampler2D uSamplers[%count%];\n\nvoid main(void){\n    vec4 color;\n    %forloop%\n    gl_FragColor = color * vColor;\n}\n";
  }
  setShaderGenerator({
    vertex: e = t.defaultVertexSrc,
    fragment: r = t.defaultFragmentTemplate,
  } = {}) {
    this.shaderGenerator = new zo(e, r);
  }
  contextChange() {
    const e = this.renderer.gl;
    _n.PREFER_ENV === Zs.WEBGL_LEGACY
      ? (this.maxTextures = 1)
      : ((this.maxTextures = Math.min(
          e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),
          t.defaultMaxTextures
        )),
        (this.maxTextures = (function (t, e) {
          if (0 === t)
            throw new Error(
              "Invalid value of `0` passed to `checkMaxIfStatementsInShader`"
            );
          const r = e.createShader(e.FRAGMENT_SHADER);
          for (;;) {
            const i = Gn.replace(/%forloop%/gi, at(t));
            if (
              (e.shaderSource(r, i),
              e.compileShader(r),
              e.getShaderParameter(r, e.COMPILE_STATUS))
            )
              break;
            t = (t / 2) | 0;
          }
          return t;
        })(this.maxTextures, e))),
      (this._shader = this.shaderGenerator.generateShader(this.maxTextures));
    for (let t = 0; t < this._packedGeometryPoolSize; t++)
      this._packedGeometries[t] = new this.geometryClass();
    this.initFlushBuffers();
  }
  initFlushBuffers() {
    const { _drawCallPool: e, _textureArrayPool: r } = t,
      i = this.size / 4,
      s = Math.floor(i / this.maxTextures) + 1;
    for (; e.length < i; ) e.push(new qn());
    for (; r.length < s; ) r.push(new Wo());
    for (let t = 0; t < this.maxTextures; t++)
      this._tempBoundTextures[t] = null;
  }
  onPrerender() {
    this._flushId = 0;
  }
  render(t) {
    t._texture.valid &&
      (this._vertexCount + t.vertexData.length / 2 > this.size && this.flush(),
      (this._vertexCount += t.vertexData.length / 2),
      (this._indexCount += t.indices.length),
      (this._bufferedTextures[this._bufferSize] = t._texture.baseTexture),
      (this._bufferedElements[this._bufferSize++] = t));
  }
  buildTexturesAndDrawCalls() {
    const { _bufferedTextures: e, maxTextures: r } = this,
      i = t._textureArrayPool,
      s = this.renderer.batch,
      n = this._tempBoundTextures,
      o = this.renderer.textureGC.count;
    let a = ++Yn._globalBatch,
      h = 0,
      l = i[0],
      u = 0;
    s.copyBoundTextures(n, r);
    for (let t = 0; t < this._bufferSize; ++t) {
      const c = e[t];
      (e[t] = null),
        c._batchEnabled !== a &&
          (l.count >= r &&
            (s.boundArray(l, n, a, r),
            this.buildDrawCalls(l, u, t),
            (u = t),
            (l = i[++h]),
            ++a),
          (c._batchEnabled = a),
          (c.touched = o),
          (l.elements[l.count++] = c));
    }
    l.count > 0 &&
      (s.boundArray(l, n, a, r),
      this.buildDrawCalls(l, u, this._bufferSize),
      ++h,
      ++a);
    for (let t = 0; t < n.length; t++) n[t] = null;
    Yn._globalBatch = a;
  }
  buildDrawCalls(e, r, i) {
    const {
        _bufferedElements: s,
        _attributeBuffer: n,
        _indexBuffer: o,
        vertexSize: a,
      } = this,
      h = t._drawCallPool;
    let l = this._dcIndex,
      u = this._aIndex,
      c = this._iIndex,
      d = h[l];
    (d.start = this._iIndex), (d.texArray = e);
    for (let t = r; t < i; ++t) {
      const i = s[t],
        p = i._texture.baseTexture,
        f = In[p.alphaMode ? 1 : 0][i.blendMode];
      (s[t] = null),
        r < t &&
          d.blend !== f &&
          ((d.size = c - d.start),
          (r = t),
          (d = h[++l]),
          (d.texArray = e),
          (d.start = c)),
        this.packInterleavedGeometry(i, n, o, u, c),
        (u += (i.vertexData.length / 2) * a),
        (c += i.indices.length),
        (d.blend = f);
    }
    r < i && ((d.size = c - d.start), ++l),
      (this._dcIndex = l),
      (this._aIndex = u),
      (this._iIndex = c);
  }
  bindAndClearTexArray(t) {
    const e = this.renderer.texture;
    for (let r = 0; r < t.count; r++)
      e.bind(t.elements[r], t.ids[r]), (t.elements[r] = null);
    t.count = 0;
  }
  updateGeometry() {
    const { _packedGeometries: e, _attributeBuffer: r, _indexBuffer: i } = this;
    t.canUploadSameBuffer
      ? (e[this._flushId]._buffer.update(r.rawBinaryData),
        e[this._flushId]._indexBuffer.update(i),
        this.renderer.geometry.updateBuffers())
      : (this._packedGeometryPoolSize <= this._flushId &&
          (this._packedGeometryPoolSize++,
          (e[this._flushId] = new this.geometryClass())),
        e[this._flushId]._buffer.update(r.rawBinaryData),
        e[this._flushId]._indexBuffer.update(i),
        this.renderer.geometry.bind(e[this._flushId]),
        this.renderer.geometry.updateBuffers(),
        this._flushId++);
  }
  drawBatches() {
    const e = this._dcIndex,
      { gl: r, state: i } = this.renderer,
      s = t._drawCallPool;
    let n = null;
    for (let t = 0; t < e; t++) {
      const { texArray: e, type: o, size: a, start: h, blend: l } = s[t];
      n !== e && ((n = e), this.bindAndClearTexArray(e)),
        (this.state.blendMode = l),
        i.set(this.state),
        r.drawElements(o, a, r.UNSIGNED_SHORT, 2 * h);
    }
  }
  flush() {
    0 !== this._vertexCount &&
      ((this._attributeBuffer = this.getAttributeBuffer(this._vertexCount)),
      (this._indexBuffer = this.getIndexBuffer(this._indexCount)),
      (this._aIndex = 0),
      (this._iIndex = 0),
      (this._dcIndex = 0),
      this.buildTexturesAndDrawCalls(),
      this.updateGeometry(),
      this.drawBatches(),
      (this._bufferSize = 0),
      (this._vertexCount = 0),
      (this._indexCount = 0));
  }
  start() {
    this.renderer.state.set(this.state),
      this.renderer.texture.ensureSamplerType(this.maxTextures),
      this.renderer.shader.bind(this._shader),
      t.canUploadSameBuffer &&
        this.renderer.geometry.bind(this._packedGeometries[this._flushId]);
  }
  stop() {
    this.flush();
  }
  destroy() {
    for (let t = 0; t < this._packedGeometryPoolSize; t++)
      this._packedGeometries[t] && this._packedGeometries[t].destroy();
    this.renderer.off("prerender", this.onPrerender, this),
      (this._aBuffers = null),
      (this._iBuffers = null),
      (this._packedGeometries = null),
      (this._attributeBuffer = null),
      (this._indexBuffer = null),
      this._shader && (this._shader.destroy(), (this._shader = null)),
      super.destroy();
  }
  getAttributeBuffer(t) {
    const e = Q(Math.ceil(t / 8)),
      r = tt(e),
      i = 8 * e;
    this._aBuffers.length <= r && (this._iBuffers.length = r + 1);
    let s = this._aBuffers[i];
    return s || (this._aBuffers[i] = s = new Un(i * this.vertexSize * 4)), s;
  }
  getIndexBuffer(t) {
    const e = Q(Math.ceil(t / 12)),
      r = tt(e),
      i = 12 * e;
    this._iBuffers.length <= r && (this._iBuffers.length = r + 1);
    let s = this._iBuffers[r];
    return s || (this._iBuffers[r] = s = new Uint16Array(i)), s;
  }
  packInterleavedGeometry(t, e, r, i, s) {
    const { uint32View: n, float32View: o } = e,
      a = i / this.vertexSize,
      h = t.uvs,
      l = t.indices,
      u = t.vertexData,
      c = t._texture.baseTexture._batchLocation,
      d = Math.min(t.worldAlpha, 1),
      p = Rn.shared
        .setValue(t._tintRGB)
        .toPremultiplied(d, t._texture.baseTexture.alphaMode > 0);
    for (let f = 0; f < u.length; f += 2)
      (o[i++] = u[f]),
        (o[i++] = u[f + 1]),
        (o[i++] = h[f]),
        (o[i++] = h[f + 1]),
        (n[i++] = p),
        (o[i++] = c);
    for (let f = 0; f < l.length; f++) r[s++] = a + l[f];
  }
};
(Yo.defaultBatchSize = 4096),
  (Yo.extension = { name: "batch", type: Gs.RendererPlugin }),
  (Yo._drawCallPool = []),
  (Yo._textureArrayPool = []);
let qo = Yo;
kn.add(qo);
const Ko = class t extends Vo {
  constructor(e, r, i) {
    super(Ho.from(e || t.defaultVertexSrc, r || t.defaultFragmentSrc), i),
      (this.padding = 0),
      (this.resolution = t.defaultResolution),
      (this.multisample = t.defaultMultisample),
      (this.enabled = !0),
      (this.autoFit = !0),
      (this.state = new Hn());
  }
  apply(t, e, r, i, s) {
    t.applyFilter(this, e, r, i);
  }
  get blendMode() {
    return this.state.blendMode;
  }
  set blendMode(t) {
    this.state.blendMode = t;
  }
  get resolution() {
    return this._resolution;
  }
  set resolution(t) {
    this._resolution = t;
  }
  static get defaultVertexSrc() {
    return "attribute vec2 aVertexPosition;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nuniform vec4 inputSize;\nuniform vec4 outputFrame;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aVertexPosition * (outputFrame.zw * inputSize.zw);\n}\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n}\n";
  }
  static get defaultFragmentSrc() {
    return "varying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\n\nvoid main(void){\n   gl_FragColor = texture2D(uSampler, vTextureCoord);\n}\n";
  }
};
(Ko.defaultResolution = 1), (Ko.defaultMultisample = mn.NONE);
let Zo = Ko;
class Qo {
  constructor() {
    (this.clearBeforeRender = !0),
      (this._backgroundColor = new Rn(0)),
      (this.alpha = 1);
  }
  init(t) {
    this.clearBeforeRender = t.clearBeforeRender;
    const { backgroundColor: e, background: r, backgroundAlpha: i } = t,
      s = r ?? e;
    void 0 !== s && (this.color = s), (this.alpha = i);
  }
  get color() {
    return this._backgroundColor.value;
  }
  set color(t) {
    this._backgroundColor.setValue(t);
  }
  get alpha() {
    return this._backgroundColor.alpha;
  }
  set alpha(t) {
    this._backgroundColor.setAlpha(t);
  }
  get backgroundColor() {
    return this._backgroundColor;
  }
  destroy() {}
}
(Qo.defaultOptions = {
  backgroundAlpha: 1,
  backgroundColor: 0,
  clearBeforeRender: !0,
}),
  (Qo.extension = {
    type: [Gs.RendererSystem, Gs.CanvasRendererSystem],
    name: "background",
  }),
  kn.add(Qo);
class Jo {
  constructor(t) {
    (this.renderer = t),
      (this.emptyRenderer = new $o(t)),
      (this.currentRenderer = this.emptyRenderer);
  }
  setObjectRenderer(t) {
    this.currentRenderer !== t &&
      (this.currentRenderer.stop(),
      (this.currentRenderer = t),
      this.currentRenderer.start());
  }
  flush() {
    this.setObjectRenderer(this.emptyRenderer);
  }
  reset() {
    this.setObjectRenderer(this.emptyRenderer);
  }
  copyBoundTextures(t, e) {
    const { boundTextures: r } = this.renderer.texture;
    for (let i = e - 1; i >= 0; --i)
      (t[i] = r[i] || null), t[i] && (t[i]._batchLocation = i);
  }
  boundArray(t, e, r, i) {
    const { elements: s, ids: n, count: o } = t;
    let a = 0;
    for (let h = 0; h < o; h++) {
      const t = s[h],
        o = t._batchLocation;
      if (o >= 0 && o < i && e[o] === t) n[h] = o;
      else
        for (; a < i; ) {
          const i = e[a];
          if (!i || i._batchEnabled !== r || i._batchLocation !== a) {
            (n[h] = a), (t._batchLocation = a), (e[a] = t);
            break;
          }
          a++;
        }
    }
  }
  destroy() {
    this.renderer = null;
  }
}
(Jo.extension = { type: Gs.RendererSystem, name: "batch" }), kn.add(Jo);
let ta = 0;
class ea {
  constructor(t) {
    (this.renderer = t),
      (this.webGLVersion = 1),
      (this.extensions = {}),
      (this.supports = { uint32Indices: !1 }),
      (this.handleContextLost = this.handleContextLost.bind(this)),
      (this.handleContextRestored = this.handleContextRestored.bind(this));
  }
  get isLost() {
    return !this.gl || this.gl.isContextLost();
  }
  contextChange(t) {
    (this.gl = t), (this.renderer.gl = t), (this.renderer.CONTEXT_UID = ta++);
  }
  init(t) {
    if (t.context) this.initFromContext(t.context);
    else {
      const e = this.renderer.background.alpha < 1,
        r = t.premultipliedAlpha;
      (this.preserveDrawingBuffer = t.preserveDrawingBuffer),
        (this.useContextAlpha = t.useContextAlpha),
        (this.powerPreference = t.powerPreference),
        this.initFromOptions({
          alpha: e,
          premultipliedAlpha: r,
          antialias: t.antialias,
          stencil: !0,
          preserveDrawingBuffer: t.preserveDrawingBuffer,
          powerPreference: t.powerPreference,
        });
    }
  }
  initFromContext(t) {
    (this.gl = t),
      this.validateContext(t),
      (this.renderer.gl = t),
      (this.renderer.CONTEXT_UID = ta++),
      this.renderer.runners.contextChange.emit(t);
    const e = this.renderer.view;
    void 0 !== e.addEventListener &&
      (e.addEventListener("webglcontextlost", this.handleContextLost, !1),
      e.addEventListener(
        "webglcontextrestored",
        this.handleContextRestored,
        !1
      ));
  }
  initFromOptions(t) {
    const e = this.createContext(this.renderer.view, t);
    this.initFromContext(e);
  }
  createContext(t, e) {
    let r;
    if ((_n.PREFER_ENV >= Zs.WEBGL2 && (r = t.getContext("webgl2", e)), r))
      this.webGLVersion = 2;
    else if (
      ((this.webGLVersion = 1),
      (r = t.getContext("webgl", e) || t.getContext("experimental-webgl", e)),
      !r)
    )
      throw new Error(
        "This browser does not support WebGL. Try using the canvas renderer"
      );
    return (this.gl = r), this.getExtensions(), this.gl;
  }
  getExtensions() {
    const { gl: t } = this,
      e = {
        loseContext: t.getExtension("WEBGL_lose_context"),
        anisotropicFiltering: t.getExtension("EXT_texture_filter_anisotropic"),
        floatTextureLinear: t.getExtension("OES_texture_float_linear"),
        s3tc: t.getExtension("WEBGL_compressed_texture_s3tc"),
        s3tc_sRGB: t.getExtension("WEBGL_compressed_texture_s3tc_srgb"),
        etc: t.getExtension("WEBGL_compressed_texture_etc"),
        etc1: t.getExtension("WEBGL_compressed_texture_etc1"),
        pvrtc:
          t.getExtension("WEBGL_compressed_texture_pvrtc") ||
          t.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
        atc: t.getExtension("WEBGL_compressed_texture_atc"),
        astc: t.getExtension("WEBGL_compressed_texture_astc"),
      };
    1 === this.webGLVersion
      ? Object.assign(this.extensions, e, {
          drawBuffers: t.getExtension("WEBGL_draw_buffers"),
          depthTexture: t.getExtension("WEBGL_depth_texture"),
          vertexArrayObject:
            t.getExtension("OES_vertex_array_object") ||
            t.getExtension("MOZ_OES_vertex_array_object") ||
            t.getExtension("WEBKIT_OES_vertex_array_object"),
          uint32ElementIndex: t.getExtension("OES_element_index_uint"),
          floatTexture: t.getExtension("OES_texture_float"),
          floatTextureLinear: t.getExtension("OES_texture_float_linear"),
          textureHalfFloat: t.getExtension("OES_texture_half_float"),
          textureHalfFloatLinear: t.getExtension(
            "OES_texture_half_float_linear"
          ),
        })
      : 2 === this.webGLVersion &&
        Object.assign(this.extensions, e, {
          colorBufferFloat: t.getExtension("EXT_color_buffer_float"),
        });
  }
  handleContextLost(t) {
    t.preventDefault(),
      setTimeout(() => {
        this.gl.isContextLost() &&
          this.extensions.loseContext &&
          this.extensions.loseContext.restoreContext();
      }, 0);
  }
  handleContextRestored() {
    this.renderer.runners.contextChange.emit(this.gl);
  }
  destroy() {
    const t = this.renderer.view;
    (this.renderer = null),
      void 0 !== t.removeEventListener &&
        (t.removeEventListener("webglcontextlost", this.handleContextLost),
        t.removeEventListener(
          "webglcontextrestored",
          this.handleContextRestored
        )),
      this.gl.useProgram(null),
      this.extensions.loseContext && this.extensions.loseContext.loseContext();
  }
  postrender() {
    this.renderer.objectRenderer.renderingToScreen && this.gl.flush();
  }
  validateContext(t) {
    const e = t.getContextAttributes(),
      r =
        "WebGL2RenderingContext" in globalThis &&
        t instanceof globalThis.WebGL2RenderingContext;
    r && (this.webGLVersion = 2), e && e.stencil;
    const i = r || !!t.getExtension("OES_element_index_uint");
    this.supports.uint32Indices = i;
  }
}
(ea.defaultOptions = {
  context: null,
  antialias: !1,
  premultipliedAlpha: !0,
  preserveDrawingBuffer: !1,
  powerPreference: "default",
}),
  (ea.extension = { type: Gs.RendererSystem, name: "context" }),
  kn.add(ea);
class ra {
  constructor(t, e) {
    if (
      ((this.width = Math.round(t)),
      (this.height = Math.round(e)),
      !this.width || !this.height)
    )
      throw new Error("Framebuffer width or height is zero");
    (this.stencil = !1),
      (this.depth = !1),
      (this.dirtyId = 0),
      (this.dirtyFormat = 0),
      (this.dirtySize = 0),
      (this.depthTexture = null),
      (this.colorTextures = []),
      (this.glFramebuffers = {}),
      (this.disposeRunner = new Xn("disposeFramebuffer")),
      (this.multisample = mn.NONE);
  }
  get colorTexture() {
    return this.colorTextures[0];
  }
  addColorTexture(t = 0, e) {
    return (
      (this.colorTextures[t] =
        e ||
        new Yn(null, {
          scaleMode: an.NEAREST,
          resolution: 1,
          mipmap: ln.OFF,
          width: this.width,
          height: this.height,
        })),
      this.dirtyId++,
      this.dirtyFormat++,
      this
    );
  }
  addDepthTexture(t) {
    return (
      (this.depthTexture =
        t ||
        new Yn(null, {
          scaleMode: an.NEAREST,
          resolution: 1,
          width: this.width,
          height: this.height,
          mipmap: ln.OFF,
          format: rn.DEPTH_COMPONENT,
          type: nn.UNSIGNED_SHORT,
        })),
      this.dirtyId++,
      this.dirtyFormat++,
      this
    );
  }
  enableDepth() {
    return (this.depth = !0), this.dirtyId++, this.dirtyFormat++, this;
  }
  enableStencil() {
    return (this.stencil = !0), this.dirtyId++, this.dirtyFormat++, this;
  }
  resize(t, e) {
    if (((t = Math.round(t)), (e = Math.round(e)), !t || !e))
      throw new Error("Framebuffer width and height must not be zero");
    if (t !== this.width || e !== this.height) {
      (this.width = t), (this.height = e), this.dirtyId++, this.dirtySize++;
      for (let r = 0; r < this.colorTextures.length; r++) {
        const i = this.colorTextures[r],
          s = i.resolution;
        i.setSize(t / s, e / s);
      }
      if (this.depthTexture) {
        const r = this.depthTexture.resolution;
        this.depthTexture.setSize(t / r, e / r);
      }
    }
  }
  dispose() {
    this.disposeRunner.emit(this, !1);
  }
  destroyDepthTexture() {
    this.depthTexture &&
      (this.depthTexture.destroy(),
      (this.depthTexture = null),
      ++this.dirtyId,
      ++this.dirtyFormat);
  }
}
class ia extends Yn {
  constructor(t = {}) {
    "number" == typeof t &&
      (t = {
        width: arguments[0],
        height: arguments[1],
        scaleMode: arguments[2],
        resolution: arguments[3],
      }),
      (t.width = t.width ?? 100),
      (t.height = t.height ?? 100),
      t.multisample ?? (t.multisample = mn.NONE),
      super(null, t),
      (this.mipmap = ln.OFF),
      (this.valid = !0),
      (this._clear = new Rn([0, 0, 0, 0])),
      (this.framebuffer = new ra(
        this.realWidth,
        this.realHeight
      ).addColorTexture(0, this)),
      (this.framebuffer.multisample = t.multisample),
      (this.maskStack = []),
      (this.filterStack = [{}]);
  }
  set clearColor(t) {
    this._clear.setValue(t);
  }
  get clearColor() {
    return this._clear.value;
  }
  get clear() {
    return this._clear;
  }
  get multisample() {
    return this.framebuffer.multisample;
  }
  set multisample(t) {
    this.framebuffer.multisample = t;
  }
  resize(t, e) {
    this.framebuffer.resize(t * this.resolution, e * this.resolution),
      this.setRealSize(this.framebuffer.width, this.framebuffer.height);
  }
  dispose() {
    this.framebuffer.dispose(), super.dispose();
  }
  destroy() {
    super.destroy(),
      this.framebuffer.destroyDepthTexture(),
      (this.framebuffer = null);
  }
}
class sa extends Vn {
  constructor(t) {
    const e = t;
    super(
      e.naturalWidth || e.videoWidth || e.width,
      e.naturalHeight || e.videoHeight || e.height
    ),
      (this.source = t),
      (this.noSubImage = !1);
  }
  static crossOrigin(t, e, r) {
    void 0 !== r || e.startsWith("data:")
      ? !1 !== r && (t.crossOrigin = "string" == typeof r ? r : "anonymous")
      : (t.crossOrigin = (function (t, e = globalThis.location) {
          if (t.startsWith("data:")) return "";
          e = e || globalThis.location;
          const r = new URL(t, document.baseURI);
          return r.hostname !== e.hostname ||
            r.port !== e.port ||
            r.protocol !== e.protocol
            ? "anonymous"
            : "";
        })(e));
  }
  upload(t, e, r, i) {
    const s = t.gl,
      n = e.realWidth,
      o = e.realHeight;
    if (
      ((i = i || this.source),
      typeof HTMLImageElement < "u" && i instanceof HTMLImageElement)
    ) {
      if (!i.complete || 0 === i.naturalWidth) return !1;
    } else if (
      typeof HTMLVideoElement < "u" &&
      i instanceof HTMLVideoElement &&
      i.readyState <= 1
    )
      return !1;
    return (
      s.pixelStorei(
        s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,
        e.alphaMode === un.UNPACK
      ),
      this.noSubImage ||
      e.target !== s.TEXTURE_2D ||
      r.width !== n ||
      r.height !== o
        ? ((r.width = n),
          (r.height = o),
          s.texImage2D(e.target, 0, r.internalFormat, e.format, r.type, i))
        : s.texSubImage2D(s.TEXTURE_2D, 0, 0, 0, e.format, r.type, i),
      !0
    );
  }
  update() {
    if (this.destroyed) return;
    const t = this.source,
      e = t.naturalWidth || t.videoWidth || t.width,
      r = t.naturalHeight || t.videoHeight || t.height;
    this.resize(e, r), super.update();
  }
  dispose() {
    this.source = null;
  }
}
class na extends sa {
  constructor(t, e) {
    if (((e = e || {}), "string" == typeof t)) {
      const r = new Image();
      sa.crossOrigin(r, t, e.crossorigin), (r.src = t), (t = r);
    }
    super(t),
      !t.complete &&
        this._width &&
        this._height &&
        ((this._width = 0), (this._height = 0)),
      (this.url = t.src),
      (this._process = null),
      (this.preserveBitmap = !1),
      (this.createBitmap =
        (e.createBitmap ?? _n.CREATE_IMAGE_BITMAP) &&
        !!globalThis.createImageBitmap),
      (this.alphaMode = "number" == typeof e.alphaMode ? e.alphaMode : null),
      (this.bitmap = null),
      (this._load = null),
      !1 !== e.autoLoad && this.load();
  }
  load(t) {
    return (
      this._load ||
        (void 0 !== t && (this.createBitmap = t),
        (this._load = new Promise((t, e) => {
          const r = this.source;
          this.url = r.src;
          const i = () => {
            this.destroyed ||
              ((r.onload = null),
              (r.onerror = null),
              this.update(),
              (this._load = null),
              this.createBitmap ? t(this.process()) : t(this));
          };
          r.complete && r.src
            ? i()
            : ((r.onload = i),
              (r.onerror = (t) => {
                e(t), this.onError.emit(t);
              }));
        }))),
      this._load
    );
  }
  process() {
    const t = this.source;
    if (null !== this._process) return this._process;
    if (null !== this.bitmap || !globalThis.createImageBitmap)
      return Promise.resolve(this);
    const e = globalThis.createImageBitmap,
      r = !t.crossOrigin || "anonymous" === t.crossOrigin;
    return (
      (this._process = fetch(t.src, { mode: r ? "cors" : "no-cors" })
        .then((t) => t.blob())
        .then((r) =>
          e(r, 0, 0, t.width, t.height, {
            premultiplyAlpha:
              null === this.alphaMode || this.alphaMode === un.UNPACK
                ? "premultiply"
                : "none",
          })
        )
        .then((t) =>
          this.destroyed
            ? Promise.reject()
            : ((this.bitmap = t),
              this.update(),
              (this._process = null),
              Promise.resolve(this))
        )),
      this._process
    );
  }
  upload(t, e, r) {
    if (
      ("number" == typeof this.alphaMode && (e.alphaMode = this.alphaMode),
      !this.createBitmap)
    )
      return super.upload(t, e, r);
    if (!this.bitmap && (this.process(), !this.bitmap)) return !1;
    if ((super.upload(t, e, r, this.bitmap), !this.preserveBitmap)) {
      let t = !0;
      const i = e._glTextures;
      for (const s in i) {
        const n = i[s];
        if (n !== r && n.dirtyId !== e.dirtyId) {
          t = !1;
          break;
        }
      }
      t && (this.bitmap.close && this.bitmap.close(), (this.bitmap = null));
    }
    return !0;
  }
  dispose() {
    (this.source.onload = null),
      (this.source.onerror = null),
      super.dispose(),
      this.bitmap && (this.bitmap.close(), (this.bitmap = null)),
      (this._process = null),
      (this._load = null);
  }
  static test(t) {
    return (
      typeof HTMLImageElement < "u" &&
      ("string" == typeof t || t instanceof HTMLImageElement)
    );
  }
}
class oa {
  constructor() {
    (this.x0 = 0),
      (this.y0 = 0),
      (this.x1 = 1),
      (this.y1 = 0),
      (this.x2 = 1),
      (this.y2 = 1),
      (this.x3 = 0),
      (this.y3 = 1),
      (this.uvsFloat32 = new Float32Array(8));
  }
  set(t, e, r) {
    const i = e.width,
      s = e.height;
    if (r) {
      const e = t.width / 2 / i,
        n = t.height / 2 / s,
        o = t.x / i + e,
        a = t.y / s + n;
      (r = Ao.add(r, Ao.NW)),
        (this.x0 = o + e * Ao.uX(r)),
        (this.y0 = a + n * Ao.uY(r)),
        (r = Ao.add(r, 2)),
        (this.x1 = o + e * Ao.uX(r)),
        (this.y1 = a + n * Ao.uY(r)),
        (r = Ao.add(r, 2)),
        (this.x2 = o + e * Ao.uX(r)),
        (this.y2 = a + n * Ao.uY(r)),
        (r = Ao.add(r, 2)),
        (this.x3 = o + e * Ao.uX(r)),
        (this.y3 = a + n * Ao.uY(r));
    } else
      (this.x0 = t.x / i),
        (this.y0 = t.y / s),
        (this.x1 = (t.x + t.width) / i),
        (this.y1 = t.y / s),
        (this.x2 = (t.x + t.width) / i),
        (this.y2 = (t.y + t.height) / s),
        (this.x3 = t.x / i),
        (this.y3 = (t.y + t.height) / s);
    (this.uvsFloat32[0] = this.x0),
      (this.uvsFloat32[1] = this.y0),
      (this.uvsFloat32[2] = this.x1),
      (this.uvsFloat32[3] = this.y1),
      (this.uvsFloat32[4] = this.x2),
      (this.uvsFloat32[5] = this.y2),
      (this.uvsFloat32[6] = this.x3),
      (this.uvsFloat32[7] = this.y3);
  }
}
oa.prototype.toString = function () {
  return `[@pixi/core:TextureUvs x0=${this.x0} y0=${this.y0} x1=${this.x1} y1=${this.y1} x2=${this.x2} y2=${this.y2} x3=${this.x3} y3=${this.y3}]`;
};
const aa = new oa();
class ha extends vn {
  constructor(t, e, r, i, s, n, o) {
    if (
      (super(),
      (this.noFrame = !1),
      e || ((this.noFrame = !0), (e = new uo(0, 0, 1, 1))),
      t instanceof ha && (t = t.baseTexture),
      (this.baseTexture = t),
      (this._frame = e),
      (this.trim = i),
      (this.valid = !1),
      (this.destroyed = !1),
      (this._uvs = aa),
      (this.uvMatrix = null),
      (this.orig = r || e),
      (this._rotate = Number(s || 0)),
      !0 === s)
    )
      this._rotate = 2;
    else if (this._rotate % 2 != 0)
      throw new Error(
        "attempt to use diamond-shaped UVs. If you are sure, set rotation manually"
      );
    (this.defaultAnchor = n ? new ho(n.x, n.y) : new ho(0, 0)),
      (this.defaultBorders = o),
      (this._updateID = 0),
      (this.textureCacheIds = []),
      t.valid
        ? this.noFrame
          ? t.valid && this.onBaseTextureUpdated(t)
          : (this.frame = e)
        : t.once("loaded", this.onBaseTextureUpdated, this),
      this.noFrame && t.on("update", this.onBaseTextureUpdated, this);
  }
  update() {
    this.baseTexture.resource && this.baseTexture.resource.update();
  }
  onBaseTextureUpdated(t) {
    if (this.noFrame) {
      if (!this.baseTexture.valid) return;
      (this._frame.width = t.width),
        (this._frame.height = t.height),
        (this.valid = !0),
        this.updateUvs();
    } else this.frame = this._frame;
    this.emit("update", this);
  }
  destroy(t) {
    if (this.baseTexture) {
      if (t) {
        const { resource: t } = this.baseTexture;
        (null == t ? void 0 : t.url) && On[t.url] && ha.removeFromCache(t.url),
          this.baseTexture.destroy();
      }
      this.baseTexture.off("loaded", this.onBaseTextureUpdated, this),
        this.baseTexture.off("update", this.onBaseTextureUpdated, this),
        (this.baseTexture = null);
    }
    (this._frame = null),
      (this._uvs = null),
      (this.trim = null),
      (this.orig = null),
      (this.valid = !1),
      ha.removeFromCache(this),
      (this.textureCacheIds = null),
      (this.destroyed = !0),
      this.emit("destroyed", this),
      this.removeAllListeners();
  }
  clone() {
    var t;
    const e = this._frame.clone(),
      r = this._frame === this.orig ? e : this.orig.clone(),
      i = new ha(
        this.baseTexture,
        !this.noFrame && e,
        r,
        null == (t = this.trim) ? void 0 : t.clone(),
        this.rotate,
        this.defaultAnchor,
        this.defaultBorders
      );
    return this.noFrame && (i._frame = e), i;
  }
  updateUvs() {
    this._uvs === aa && (this._uvs = new oa()),
      this._uvs.set(this._frame, this.baseTexture, this.rotate),
      this._updateID++;
  }
  static from(t, e = {}, r = _n.STRICT_TEXTURE_CACHE) {
    const i = "string" == typeof t;
    let s = null;
    if (i) s = t;
    else if (t instanceof Yn) {
      if (!t.cacheId) {
        const r = (null == e ? void 0 : e.pixiIdPrefix) || "pixiid";
        (t.cacheId = `${r}-${it()}`), Yn.addToCache(t, t.cacheId);
      }
      s = t.cacheId;
    } else {
      if (!t._pixiId) {
        const r = (null == e ? void 0 : e.pixiIdPrefix) || "pixiid";
        t._pixiId = `${r}_${it()}`;
      }
      s = t._pixiId;
    }
    let n = On[s];
    if (i && r && !n)
      throw new Error(`The cacheId "${s}" does not exist in TextureCache.`);
    return (
      n || t instanceof Yn
        ? !n && t instanceof Yn && ((n = new ha(t)), ha.addToCache(n, s))
        : (e.resolution || (e.resolution = ot(t)),
          (n = new ha(new Yn(t, e))),
          (n.baseTexture.cacheId = s),
          Yn.addToCache(n.baseTexture, s),
          ha.addToCache(n, s)),
      n
    );
  }
  static fromURL(t, e) {
    const r = Object.assign(
        { autoLoad: !1 },
        null == e ? void 0 : e.resourceOptions
      ),
      i = ha.from(t, Object.assign({ resourceOptions: r }, e), !1),
      s = i.baseTexture.resource;
    return i.baseTexture.valid
      ? Promise.resolve(i)
      : s.load().then(() => Promise.resolve(i));
  }
  static fromBuffer(t, e, r, i) {
    return new ha(Yn.fromBuffer(t, e, r, i));
  }
  static fromLoader(t, e, r, i) {
    const s = new Yn(
        t,
        Object.assign(
          { scaleMode: Yn.defaultOptions.scaleMode, resolution: ot(e) },
          i
        )
      ),
      { resource: n } = s;
    n instanceof na && (n.url = e);
    const o = new ha(s);
    return (
      r || (r = e),
      Yn.addToCache(o.baseTexture, r),
      ha.addToCache(o, r),
      r !== e && (Yn.addToCache(o.baseTexture, e), ha.addToCache(o, e)),
      o.baseTexture.valid
        ? Promise.resolve(o)
        : new Promise((t) => {
            o.baseTexture.once("loaded", () => t(o));
          })
    );
  }
  static addToCache(t, e) {
    e &&
      (t.textureCacheIds.includes(e) || t.textureCacheIds.push(e),
      On[e] && On[e],
      (On[e] = t));
  }
  static removeFromCache(t) {
    if ("string" == typeof t) {
      const e = On[t];
      if (e) {
        const r = e.textureCacheIds.indexOf(t);
        return r > -1 && e.textureCacheIds.splice(r, 1), delete On[t], e;
      }
    } else if (null == t ? void 0 : t.textureCacheIds) {
      for (let e = 0; e < t.textureCacheIds.length; ++e)
        On[t.textureCacheIds[e]] === t && delete On[t.textureCacheIds[e]];
      return (t.textureCacheIds.length = 0), t;
    }
    return null;
  }
  get resolution() {
    return this.baseTexture.resolution;
  }
  get frame() {
    return this._frame;
  }
  set frame(t) {
    (this._frame = t), (this.noFrame = !1);
    const { x: e, y: r, width: i, height: s } = t,
      n = e + i > this.baseTexture.width,
      o = r + s > this.baseTexture.height;
    if (n || o) {
      const t = n && o ? "and" : "or",
        a = `X: ${e} + ${i} = ${e + i} > ${this.baseTexture.width}`,
        h = `Y: ${r} + ${s} = ${r + s} > ${this.baseTexture.height}`;
      throw new Error(
        `Texture Error: frame does not fit inside the base Texture dimensions: ${a} ${t} ${h}`
      );
    }
    (this.valid = i && s && this.baseTexture.valid),
      !this.trim && !this.rotate && (this.orig = t),
      this.valid && this.updateUvs();
  }
  get rotate() {
    return this._rotate;
  }
  set rotate(t) {
    (this._rotate = t), this.valid && this.updateUvs();
  }
  get width() {
    return this.orig.width;
  }
  get height() {
    return this.orig.height;
  }
  castToBaseTexture() {
    return this.baseTexture;
  }
  static get EMPTY() {
    return (
      ha._EMPTY ||
        ((ha._EMPTY = new ha(new Yn())),
        gt(ha._EMPTY),
        gt(ha._EMPTY.baseTexture)),
      ha._EMPTY
    );
  }
  static get WHITE() {
    if (!ha._WHITE) {
      const t = _n.ADAPTER.createCanvas(16, 16),
        e = t.getContext("2d");
      (t.width = 16),
        (t.height = 16),
        (e.fillStyle = "white"),
        e.fillRect(0, 0, 16, 16),
        (ha._WHITE = new ha(Yn.from(t))),
        gt(ha._WHITE),
        gt(ha._WHITE.baseTexture);
    }
    return ha._WHITE;
  }
}
class la extends ha {
  constructor(t, e) {
    super(t, e),
      (this.valid = !0),
      (this.filterFrame = null),
      (this.filterPoolKey = null),
      this.updateUvs();
  }
  get framebuffer() {
    return this.baseTexture.framebuffer;
  }
  get multisample() {
    return this.framebuffer.multisample;
  }
  set multisample(t) {
    this.framebuffer.multisample = t;
  }
  resize(t, e, r = !0) {
    const i = this.baseTexture.resolution,
      s = Math.round(t * i) / i,
      n = Math.round(e * i) / i;
    (this.valid = s > 0 && n > 0),
      (this._frame.width = this.orig.width = s),
      (this._frame.height = this.orig.height = n),
      r && this.baseTexture.resize(s, n),
      this.updateUvs();
  }
  setResolution(t) {
    const { baseTexture: e } = this;
    e.resolution !== t &&
      (e.setResolution(t), this.resize(e.width, e.height, !1));
  }
  static create(t) {
    return new la(new ia(t));
  }
}
class ua {
  constructor(t) {
    (this.texturePool = {}),
      (this.textureOptions = t || {}),
      (this.enableFullScreen = !1),
      (this._pixelsWidth = 0),
      (this._pixelsHeight = 0);
  }
  createTexture(t, e, r = mn.NONE) {
    const i = new ia(
      Object.assign(
        { width: t, height: e, resolution: 1, multisample: r },
        this.textureOptions
      )
    );
    return new la(i);
  }
  getOptimalTexture(t, e, r = 1, i = mn.NONE) {
    let s;
    (t = Math.max(Math.ceil(t * r - 1e-6), 1)),
      (e = Math.max(Math.ceil(e * r - 1e-6), 1)),
      this.enableFullScreen &&
      t === this._pixelsWidth &&
      e === this._pixelsHeight
        ? (s = i > 1 ? -i : -1)
        : ((s = (((65535 & (t = Q(t))) << 16) | (65535 & (e = Q(e)))) >>> 0),
          i > 1 && (s += 4294967296 * i)),
      this.texturePool[s] || (this.texturePool[s] = []);
    let n = this.texturePool[s].pop();
    return (
      n || (n = this.createTexture(t, e, i)),
      (n.filterPoolKey = s),
      n.setResolution(r),
      n
    );
  }
  getFilterTexture(t, e, r) {
    const i = this.getOptimalTexture(
      t.width,
      t.height,
      e || t.resolution,
      r || mn.NONE
    );
    return (i.filterFrame = t.filterFrame), i;
  }
  returnTexture(t) {
    const e = t.filterPoolKey;
    (t.filterFrame = null), this.texturePool[e].push(t);
  }
  returnFilterTexture(t) {
    this.returnTexture(t);
  }
  clear(t) {
    if ((t = !1 !== t))
      for (const e in this.texturePool) {
        const t = this.texturePool[e];
        if (t) for (let e = 0; e < t.length; e++) t[e].destroy(!0);
      }
    this.texturePool = {};
  }
  setScreenSize(t) {
    if (t.width !== this._pixelsWidth || t.height !== this._pixelsHeight) {
      this.enableFullScreen = t.width > 0 && t.height > 0;
      for (const t in this.texturePool) {
        if (!(Number(t) < 0)) continue;
        const e = this.texturePool[t];
        if (e) for (let t = 0; t < e.length; t++) e[t].destroy(!0);
        this.texturePool[t] = [];
      }
      (this._pixelsWidth = t.width), (this._pixelsHeight = t.height);
    }
  }
}
ua.SCREEN_KEY = -1;
class ca extends io {
  constructor() {
    super(),
      this.addAttribute(
        "aVertexPosition",
        new Float32Array([0, 0, 1, 0, 1, 1, 0, 1])
      ).addIndex([0, 1, 3, 2]);
  }
}
class da extends io {
  constructor() {
    super(),
      (this.vertices = new Float32Array([-1, -1, 1, -1, 1, 1, -1, 1])),
      (this.uvs = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1])),
      (this.vertexBuffer = new Zn(this.vertices)),
      (this.uvBuffer = new Zn(this.uvs)),
      this.addAttribute("aVertexPosition", this.vertexBuffer)
        .addAttribute("aTextureCoord", this.uvBuffer)
        .addIndex([0, 1, 2, 0, 2, 3]);
  }
  map(t, e) {
    let r = 0,
      i = 0;
    return (
      (this.uvs[0] = r),
      (this.uvs[1] = i),
      (this.uvs[2] = r + e.width / t.width),
      (this.uvs[3] = i),
      (this.uvs[4] = r + e.width / t.width),
      (this.uvs[5] = i + e.height / t.height),
      (this.uvs[6] = r),
      (this.uvs[7] = i + e.height / t.height),
      (r = e.x),
      (i = e.y),
      (this.vertices[0] = r),
      (this.vertices[1] = i),
      (this.vertices[2] = r + e.width),
      (this.vertices[3] = i),
      (this.vertices[4] = r + e.width),
      (this.vertices[5] = i + e.height),
      (this.vertices[6] = r),
      (this.vertices[7] = i + e.height),
      this.invalidate(),
      this
    );
  }
  invalidate() {
    return this.vertexBuffer._updateID++, this.uvBuffer._updateID++, this;
  }
}
class pa {
  constructor() {
    (this.renderTexture = null),
      (this.target = null),
      (this.legacy = !1),
      (this.resolution = 1),
      (this.multisample = mn.NONE),
      (this.sourceFrame = new uo()),
      (this.destinationFrame = new uo()),
      (this.bindingSourceFrame = new uo()),
      (this.bindingDestinationFrame = new uo()),
      (this.filters = []),
      (this.transform = null);
  }
  clear() {
    (this.target = null), (this.filters = null), (this.renderTexture = null);
  }
}
const fa = [new ho(), new ho(), new ho(), new ho()],
  ma = new go();
class ga {
  constructor(t) {
    (this.renderer = t),
      (this.defaultFilterStack = [{}]),
      (this.texturePool = new ua()),
      (this.statePool = []),
      (this.quad = new ca()),
      (this.quadUv = new da()),
      (this.tempRect = new uo()),
      (this.activeState = {}),
      (this.globalUniforms = new Xo(
        {
          outputFrame: new uo(),
          inputSize: new Float32Array(4),
          inputPixel: new Float32Array(4),
          inputClamp: new Float32Array(4),
          resolution: 1,
          filterArea: new Float32Array(4),
          filterClamp: new Float32Array(4),
        },
        !0
      )),
      (this.forceClear = !1),
      (this.useMaxPadding = !1);
  }
  init() {
    this.texturePool.setScreenSize(this.renderer.view);
  }
  push(t, e) {
    const r = this.renderer,
      i = this.defaultFilterStack,
      s = this.statePool.pop() || new pa(),
      n = r.renderTexture;
    let o, a;
    if (n.current) {
      const t = n.current;
      (o = t.resolution), (a = t.multisample);
    } else (o = r.resolution), (a = r.multisample);
    let h = e[0].resolution || o,
      l = e[0].multisample ?? a,
      u = e[0].padding,
      c = e[0].autoFit,
      d = e[0].legacy ?? !0;
    for (let m = 1; m < e.length; m++) {
      const t = e[m];
      (h = Math.min(h, t.resolution || o)),
        (l = Math.min(l, t.multisample ?? a)),
        (u = this.useMaxPadding ? Math.max(u, t.padding) : u + t.padding),
        (c = c && t.autoFit),
        (d = d || (t.legacy ?? !0));
    }
    1 === i.length && (this.defaultFilterStack[0].renderTexture = n.current),
      i.push(s),
      (s.resolution = h),
      (s.multisample = l),
      (s.legacy = d),
      (s.target = t),
      s.sourceFrame.copyFrom(t.filterArea || t.getBounds(!0)),
      s.sourceFrame.pad(u);
    const p = this.tempRect.copyFrom(n.sourceFrame);
    r.projection.transform &&
      this.transformAABB(ma.copyFrom(r.projection.transform).invert(), p),
      c
        ? (s.sourceFrame.fit(p),
          (s.sourceFrame.width <= 0 || s.sourceFrame.height <= 0) &&
            ((s.sourceFrame.width = 0), (s.sourceFrame.height = 0)))
        : s.sourceFrame.intersects(p) ||
          ((s.sourceFrame.width = 0), (s.sourceFrame.height = 0)),
      this.roundFrame(
        s.sourceFrame,
        n.current ? n.current.resolution : r.resolution,
        n.sourceFrame,
        n.destinationFrame,
        r.projection.transform
      ),
      (s.renderTexture = this.getOptimalFilterTexture(
        s.sourceFrame.width,
        s.sourceFrame.height,
        h,
        l
      )),
      (s.filters = e),
      (s.destinationFrame.width = s.renderTexture.width),
      (s.destinationFrame.height = s.renderTexture.height);
    const f = this.tempRect;
    (f.x = 0),
      (f.y = 0),
      (f.width = s.sourceFrame.width),
      (f.height = s.sourceFrame.height),
      (s.renderTexture.filterFrame = s.sourceFrame),
      s.bindingSourceFrame.copyFrom(n.sourceFrame),
      s.bindingDestinationFrame.copyFrom(n.destinationFrame),
      (s.transform = r.projection.transform),
      (r.projection.transform = null),
      n.bind(s.renderTexture, s.sourceFrame, f),
      r.framebuffer.clear(0, 0, 0, 0);
  }
  pop() {
    const t = this.defaultFilterStack,
      e = t.pop(),
      r = e.filters;
    this.activeState = e;
    const i = this.globalUniforms.uniforms;
    (i.outputFrame = e.sourceFrame), (i.resolution = e.resolution);
    const s = i.inputSize,
      n = i.inputPixel,
      o = i.inputClamp;
    if (
      ((s[0] = e.destinationFrame.width),
      (s[1] = e.destinationFrame.height),
      (s[2] = 1 / s[0]),
      (s[3] = 1 / s[1]),
      (n[0] = Math.round(s[0] * e.resolution)),
      (n[1] = Math.round(s[1] * e.resolution)),
      (n[2] = 1 / n[0]),
      (n[3] = 1 / n[1]),
      (o[0] = 0.5 * n[2]),
      (o[1] = 0.5 * n[3]),
      (o[2] = e.sourceFrame.width * s[2] - 0.5 * n[2]),
      (o[3] = e.sourceFrame.height * s[3] - 0.5 * n[3]),
      e.legacy)
    ) {
      const t = i.filterArea;
      (t[0] = e.destinationFrame.width),
        (t[1] = e.destinationFrame.height),
        (t[2] = e.sourceFrame.x),
        (t[3] = e.sourceFrame.y),
        (i.filterClamp = i.inputClamp);
    }
    this.globalUniforms.update();
    const a = t[t.length - 1];
    if ((this.renderer.framebuffer.blit(), 1 === r.length))
      r[0].apply(this, e.renderTexture, a.renderTexture, cn.BLEND, e),
        this.returnFilterTexture(e.renderTexture);
    else {
      let t = e.renderTexture,
        i = this.getOptimalFilterTexture(t.width, t.height, e.resolution);
      i.filterFrame = t.filterFrame;
      let s = 0;
      for (s = 0; s < r.length - 1; ++s) {
        1 === s &&
          e.multisample > 1 &&
          ((i = this.getOptimalFilterTexture(t.width, t.height, e.resolution)),
          (i.filterFrame = t.filterFrame)),
          r[s].apply(this, t, i, cn.CLEAR, e);
        const n = t;
        (t = i), (i = n);
      }
      r[s].apply(this, t, a.renderTexture, cn.BLEND, e),
        s > 1 && e.multisample > 1 && this.returnFilterTexture(e.renderTexture),
        this.returnFilterTexture(t),
        this.returnFilterTexture(i);
    }
    e.clear(), this.statePool.push(e);
  }
  bindAndClear(t, e = cn.CLEAR) {
    const { renderTexture: r, state: i } = this.renderer;
    if (
      (t ===
      this.defaultFilterStack[this.defaultFilterStack.length - 1].renderTexture
        ? (this.renderer.projection.transform = this.activeState.transform)
        : (this.renderer.projection.transform = null),
      null == t ? void 0 : t.filterFrame)
    ) {
      const e = this.tempRect;
      (e.x = 0),
        (e.y = 0),
        (e.width = t.filterFrame.width),
        (e.height = t.filterFrame.height),
        r.bind(t, t.filterFrame, e);
    } else
      t !==
      this.defaultFilterStack[this.defaultFilterStack.length - 1].renderTexture
        ? r.bind(t)
        : this.renderer.renderTexture.bind(
            t,
            this.activeState.bindingSourceFrame,
            this.activeState.bindingDestinationFrame
          );
    const s = 1 & i.stateId || this.forceClear;
    (e === cn.CLEAR || (e === cn.BLIT && s)) &&
      this.renderer.framebuffer.clear(0, 0, 0, 0);
  }
  applyFilter(t, e, r, i) {
    const s = this.renderer;
    s.state.set(t.state),
      this.bindAndClear(r, i),
      (t.uniforms.uSampler = e),
      (t.uniforms.filterGlobals = this.globalUniforms),
      s.shader.bind(t),
      (t.legacy = !!t.program.attributeData.aTextureCoord),
      t.legacy
        ? (this.quadUv.map(e._frame, e.filterFrame),
          s.geometry.bind(this.quadUv),
          s.geometry.draw(en.TRIANGLES))
        : (s.geometry.bind(this.quad), s.geometry.draw(en.TRIANGLE_STRIP));
  }
  calculateSpriteMatrix(t, e) {
    const { sourceFrame: r, destinationFrame: i } = this.activeState,
      { orig: s } = e._texture,
      n = t.set(i.width, 0, 0, i.height, r.x, r.y),
      o = e.worldTransform.copyTo(go.TEMP_MATRIX);
    return (
      o.invert(),
      n.prepend(o),
      n.scale(1 / s.width, 1 / s.height),
      n.translate(e.anchor.x, e.anchor.y),
      n
    );
  }
  destroy() {
    (this.renderer = null), this.texturePool.clear(!1);
  }
  getOptimalFilterTexture(t, e, r = 1, i = mn.NONE) {
    return this.texturePool.getOptimalTexture(t, e, r, i);
  }
  getFilterTexture(t, e, r) {
    if ("number" == typeof t) {
      const r = t;
      (t = e), (e = r);
    }
    t = t || this.activeState.renderTexture;
    const i = this.texturePool.getOptimalTexture(
      t.width,
      t.height,
      e || t.resolution,
      r || mn.NONE
    );
    return (i.filterFrame = t.filterFrame), i;
  }
  returnFilterTexture(t) {
    this.texturePool.returnTexture(t);
  }
  emptyPool() {
    this.texturePool.clear(!0);
  }
  resize() {
    this.texturePool.setScreenSize(this.renderer.view);
  }
  transformAABB(t, e) {
    const r = fa[0],
      i = fa[1],
      s = fa[2],
      n = fa[3];
    r.set(e.left, e.top),
      i.set(e.left, e.bottom),
      s.set(e.right, e.top),
      n.set(e.right, e.bottom),
      t.apply(r, r),
      t.apply(i, i),
      t.apply(s, s),
      t.apply(n, n);
    const o = Math.min(r.x, i.x, s.x, n.x),
      a = Math.min(r.y, i.y, s.y, n.y),
      h = Math.max(r.x, i.x, s.x, n.x),
      l = Math.max(r.y, i.y, s.y, n.y);
    (e.x = o), (e.y = a), (e.width = h - o), (e.height = l - a);
  }
  roundFrame(t, e, r, i, s) {
    if (!(t.width <= 0 || t.height <= 0 || r.width <= 0 || r.height <= 0)) {
      if (s) {
        const { a: t, b: e, c: r, d: i } = s;
        if (
          (Math.abs(e) > 1e-4 || Math.abs(r) > 1e-4) &&
          (Math.abs(t) > 1e-4 || Math.abs(i) > 1e-4)
        )
          return;
      }
      (s = s ? ma.copyFrom(s) : ma.identity())
        .translate(-r.x, -r.y)
        .scale(i.width / r.width, i.height / r.height)
        .translate(i.x, i.y),
        this.transformAABB(s, t),
        t.ceil(e),
        this.transformAABB(s.invert(), t);
    }
  }
}
(ga.extension = { type: Gs.RendererSystem, name: "filter" }), kn.add(ga);
class _a {
  constructor(t) {
    (this.framebuffer = t),
      (this.stencil = null),
      (this.dirtyId = -1),
      (this.dirtyFormat = -1),
      (this.dirtySize = -1),
      (this.multisample = mn.NONE),
      (this.msaaBuffer = null),
      (this.blitFramebuffer = null),
      (this.mipLevel = 0);
  }
}
const ya = new uo();
class va {
  constructor(t) {
    (this.renderer = t),
      (this.managedFramebuffers = []),
      (this.unknownFramebuffer = new ra(10, 10)),
      (this.msaaSamples = null);
  }
  contextChange() {
    this.disposeAll(!0);
    const t = (this.gl = this.renderer.gl);
    if (
      ((this.CONTEXT_UID = this.renderer.CONTEXT_UID),
      (this.current = this.unknownFramebuffer),
      (this.viewport = new uo()),
      (this.hasMRT = !0),
      (this.writeDepthTexture = !0),
      1 === this.renderer.context.webGLVersion)
    ) {
      let e = this.renderer.context.extensions.drawBuffers,
        r = this.renderer.context.extensions.depthTexture;
      _n.PREFER_ENV === Zs.WEBGL_LEGACY && ((e = null), (r = null)),
        e
          ? (t.drawBuffers = (t) => e.drawBuffersWEBGL(t))
          : ((this.hasMRT = !1), (t.drawBuffers = () => {})),
        r || (this.writeDepthTexture = !1);
    } else
      this.msaaSamples = t.getInternalformatParameter(
        t.RENDERBUFFER,
        t.RGBA8,
        t.SAMPLES
      );
  }
  bind(t, e, r = 0) {
    const { gl: i } = this;
    if (t) {
      const s = t.glFramebuffers[this.CONTEXT_UID] || this.initFramebuffer(t);
      this.current !== t &&
        ((this.current = t), i.bindFramebuffer(i.FRAMEBUFFER, s.framebuffer)),
        s.mipLevel !== r && (t.dirtyId++, t.dirtyFormat++, (s.mipLevel = r)),
        s.dirtyId !== t.dirtyId &&
          ((s.dirtyId = t.dirtyId),
          s.dirtyFormat !== t.dirtyFormat
            ? ((s.dirtyFormat = t.dirtyFormat),
              (s.dirtySize = t.dirtySize),
              this.updateFramebuffer(t, r))
            : s.dirtySize !== t.dirtySize &&
              ((s.dirtySize = t.dirtySize), this.resizeFramebuffer(t)));
      for (let e = 0; e < t.colorTextures.length; e++) {
        const r = t.colorTextures[e];
        this.renderer.texture.unbind(r.parentTextureArray || r);
      }
      if ((t.depthTexture && this.renderer.texture.unbind(t.depthTexture), e)) {
        const t = e.width >> r,
          i = e.height >> r,
          s = t / e.width;
        this.setViewport(e.x * s, e.y * s, t, i);
      } else {
        const e = t.width >> r,
          i = t.height >> r;
        this.setViewport(0, 0, e, i);
      }
    } else
      this.current &&
        ((this.current = null), i.bindFramebuffer(i.FRAMEBUFFER, null)),
        e
          ? this.setViewport(e.x, e.y, e.width, e.height)
          : this.setViewport(0, 0, this.renderer.width, this.renderer.height);
  }
  setViewport(t, e, r, i) {
    const s = this.viewport;
    (t = Math.round(t)),
      (e = Math.round(e)),
      (r = Math.round(r)),
      (i = Math.round(i)),
      (s.width !== r || s.height !== i || s.x !== t || s.y !== e) &&
        ((s.x = t),
        (s.y = e),
        (s.width = r),
        (s.height = i),
        this.gl.viewport(t, e, r, i));
  }
  get size() {
    return this.current
      ? { x: 0, y: 0, width: this.current.width, height: this.current.height }
      : {
          x: 0,
          y: 0,
          width: this.renderer.width,
          height: this.renderer.height,
        };
  }
  clear(t, e, r, i, s = Js.COLOR | Js.DEPTH) {
    const { gl: n } = this;
    n.clearColor(t, e, r, i), n.clear(s);
  }
  initFramebuffer(t) {
    const { gl: e } = this,
      r = new _a(e.createFramebuffer());
    return (
      (r.multisample = this.detectSamples(t.multisample)),
      (t.glFramebuffers[this.CONTEXT_UID] = r),
      this.managedFramebuffers.push(t),
      t.disposeRunner.add(this),
      r
    );
  }
  resizeFramebuffer(t) {
    const { gl: e } = this,
      r = t.glFramebuffers[this.CONTEXT_UID];
    if (r.stencil) {
      let i;
      e.bindRenderbuffer(e.RENDERBUFFER, r.stencil),
        (i =
          1 === this.renderer.context.webGLVersion
            ? e.DEPTH_STENCIL
            : t.depth && t.stencil
            ? e.DEPTH24_STENCIL8
            : t.depth
            ? e.DEPTH_COMPONENT24
            : e.STENCIL_INDEX8),
        r.msaaBuffer
          ? e.renderbufferStorageMultisample(
              e.RENDERBUFFER,
              r.multisample,
              i,
              t.width,
              t.height
            )
          : e.renderbufferStorage(e.RENDERBUFFER, i, t.width, t.height);
    }
    const i = t.colorTextures;
    let s = i.length;
    e.drawBuffers || (s = Math.min(s, 1));
    for (let n = 0; n < s; n++) {
      const s = i[n],
        o = s.parentTextureArray || s;
      this.renderer.texture.bind(o, 0),
        0 === n &&
          r.msaaBuffer &&
          (e.bindRenderbuffer(e.RENDERBUFFER, r.msaaBuffer),
          e.renderbufferStorageMultisample(
            e.RENDERBUFFER,
            r.multisample,
            o._glTextures[this.CONTEXT_UID].internalFormat,
            t.width,
            t.height
          ));
    }
    t.depthTexture &&
      this.writeDepthTexture &&
      this.renderer.texture.bind(t.depthTexture, 0);
  }
  updateFramebuffer(t, e) {
    const { gl: r } = this,
      i = t.glFramebuffers[this.CONTEXT_UID],
      s = t.colorTextures;
    let n = s.length;
    r.drawBuffers || (n = Math.min(n, 1)),
      i.multisample > 1 && this.canMultisampleFramebuffer(t)
        ? (i.msaaBuffer = i.msaaBuffer || r.createRenderbuffer())
        : i.msaaBuffer &&
          (r.deleteRenderbuffer(i.msaaBuffer),
          (i.msaaBuffer = null),
          i.blitFramebuffer &&
            (i.blitFramebuffer.dispose(), (i.blitFramebuffer = null)));
    const o = [];
    for (let a = 0; a < n; a++) {
      const n = s[a],
        h = n.parentTextureArray || n;
      this.renderer.texture.bind(h, 0),
        0 === a && i.msaaBuffer
          ? (r.bindRenderbuffer(r.RENDERBUFFER, i.msaaBuffer),
            r.renderbufferStorageMultisample(
              r.RENDERBUFFER,
              i.multisample,
              h._glTextures[this.CONTEXT_UID].internalFormat,
              t.width,
              t.height
            ),
            r.framebufferRenderbuffer(
              r.FRAMEBUFFER,
              r.COLOR_ATTACHMENT0,
              r.RENDERBUFFER,
              i.msaaBuffer
            ))
          : (r.framebufferTexture2D(
              r.FRAMEBUFFER,
              r.COLOR_ATTACHMENT0 + a,
              n.target,
              h._glTextures[this.CONTEXT_UID].texture,
              e
            ),
            o.push(r.COLOR_ATTACHMENT0 + a));
    }
    if (
      (o.length > 1 && r.drawBuffers(o),
      t.depthTexture && this.writeDepthTexture)
    ) {
      const i = t.depthTexture;
      this.renderer.texture.bind(i, 0),
        r.framebufferTexture2D(
          r.FRAMEBUFFER,
          r.DEPTH_ATTACHMENT,
          r.TEXTURE_2D,
          i._glTextures[this.CONTEXT_UID].texture,
          e
        );
    }
    if ((!t.stencil && !t.depth) || (t.depthTexture && this.writeDepthTexture))
      i.stencil && (r.deleteRenderbuffer(i.stencil), (i.stencil = null));
    else {
      let e, s;
      (i.stencil = i.stencil || r.createRenderbuffer()),
        1 === this.renderer.context.webGLVersion
          ? ((e = r.DEPTH_STENCIL_ATTACHMENT), (s = r.DEPTH_STENCIL))
          : t.depth && t.stencil
          ? ((e = r.DEPTH_STENCIL_ATTACHMENT), (s = r.DEPTH24_STENCIL8))
          : t.depth
          ? ((e = r.DEPTH_ATTACHMENT), (s = r.DEPTH_COMPONENT24))
          : ((e = r.STENCIL_ATTACHMENT), (s = r.STENCIL_INDEX8)),
        r.bindRenderbuffer(r.RENDERBUFFER, i.stencil),
        i.msaaBuffer
          ? r.renderbufferStorageMultisample(
              r.RENDERBUFFER,
              i.multisample,
              s,
              t.width,
              t.height
            )
          : r.renderbufferStorage(r.RENDERBUFFER, s, t.width, t.height),
        r.framebufferRenderbuffer(r.FRAMEBUFFER, e, r.RENDERBUFFER, i.stencil);
    }
  }
  canMultisampleFramebuffer(t) {
    return (
      1 !== this.renderer.context.webGLVersion &&
      t.colorTextures.length <= 1 &&
      !t.depthTexture
    );
  }
  detectSamples(t) {
    const { msaaSamples: e } = this;
    let r = mn.NONE;
    if (t <= 1 || null === e) return r;
    for (let i = 0; i < e.length; i++)
      if (e[i] <= t) {
        r = e[i];
        break;
      }
    return 1 === r && (r = mn.NONE), r;
  }
  blit(t, e, r) {
    const { current: i, renderer: s, gl: n, CONTEXT_UID: o } = this;
    if (2 !== s.context.webGLVersion || !i) return;
    const a = i.glFramebuffers[o];
    if (!a) return;
    if (!t) {
      if (!a.msaaBuffer) return;
      const e = i.colorTextures[0];
      if (!e) return;
      a.blitFramebuffer ||
        ((a.blitFramebuffer = new ra(i.width, i.height)),
        a.blitFramebuffer.addColorTexture(0, e)),
        (t = a.blitFramebuffer).colorTextures[0] !== e &&
          ((t.colorTextures[0] = e), t.dirtyId++, t.dirtyFormat++),
        (t.width !== i.width || t.height !== i.height) &&
          ((t.width = i.width),
          (t.height = i.height),
          t.dirtyId++,
          t.dirtySize++);
    }
    e || (((e = ya).width = i.width), (e.height = i.height)), r || (r = e);
    const h = e.width === r.width && e.height === r.height;
    this.bind(t),
      n.bindFramebuffer(n.READ_FRAMEBUFFER, a.framebuffer),
      n.blitFramebuffer(
        e.left,
        e.top,
        e.right,
        e.bottom,
        r.left,
        r.top,
        r.right,
        r.bottom,
        n.COLOR_BUFFER_BIT,
        h ? n.NEAREST : n.LINEAR
      ),
      n.bindFramebuffer(
        n.READ_FRAMEBUFFER,
        t.glFramebuffers[this.CONTEXT_UID].framebuffer
      );
  }
  disposeFramebuffer(t, e) {
    const r = t.glFramebuffers[this.CONTEXT_UID],
      i = this.gl;
    if (!r) return;
    delete t.glFramebuffers[this.CONTEXT_UID];
    const s = this.managedFramebuffers.indexOf(t);
    s >= 0 && this.managedFramebuffers.splice(s, 1),
      t.disposeRunner.remove(this),
      e ||
        (i.deleteFramebuffer(r.framebuffer),
        r.msaaBuffer && i.deleteRenderbuffer(r.msaaBuffer),
        r.stencil && i.deleteRenderbuffer(r.stencil)),
      r.blitFramebuffer && this.disposeFramebuffer(r.blitFramebuffer, e);
  }
  disposeAll(t) {
    const e = this.managedFramebuffers;
    this.managedFramebuffers = [];
    for (let r = 0; r < e.length; r++) this.disposeFramebuffer(e[r], t);
  }
  forceStencil() {
    const t = this.current;
    if (!t) return;
    const e = t.glFramebuffers[this.CONTEXT_UID];
    if (!e || (e.stencil && t.stencil)) return;
    t.stencil = !0;
    const r = t.width,
      i = t.height,
      s = this.gl,
      n = (e.stencil = s.createRenderbuffer());
    let o, a;
    s.bindRenderbuffer(s.RENDERBUFFER, n),
      1 === this.renderer.context.webGLVersion
        ? ((o = s.DEPTH_STENCIL_ATTACHMENT), (a = s.DEPTH_STENCIL))
        : t.depth
        ? ((o = s.DEPTH_STENCIL_ATTACHMENT), (a = s.DEPTH24_STENCIL8))
        : ((o = s.STENCIL_ATTACHMENT), (a = s.STENCIL_INDEX8)),
      e.msaaBuffer
        ? s.renderbufferStorageMultisample(
            s.RENDERBUFFER,
            e.multisample,
            a,
            r,
            i
          )
        : s.renderbufferStorage(s.RENDERBUFFER, a, r, i),
      s.framebufferRenderbuffer(s.FRAMEBUFFER, o, s.RENDERBUFFER, n);
  }
  reset() {
    (this.current = this.unknownFramebuffer), (this.viewport = new uo());
  }
  destroy() {
    this.renderer = null;
  }
}
(va.extension = { type: Gs.RendererSystem, name: "framebuffer" }), kn.add(va);
const xa = { 5126: 4, 5123: 2, 5121: 1 };
class ba {
  constructor(t) {
    (this.renderer = t),
      (this._activeGeometry = null),
      (this._activeVao = null),
      (this.hasVao = !0),
      (this.hasInstance = !0),
      (this.canUseUInt32ElementIndex = !1),
      (this.managedGeometries = {});
  }
  contextChange() {
    this.disposeAll(!0);
    const t = (this.gl = this.renderer.gl),
      e = this.renderer.context;
    if (
      ((this.CONTEXT_UID = this.renderer.CONTEXT_UID), 2 !== e.webGLVersion)
    ) {
      let e = this.renderer.context.extensions.vertexArrayObject;
      _n.PREFER_ENV === Zs.WEBGL_LEGACY && (e = null),
        e
          ? ((t.createVertexArray = () => e.createVertexArrayOES()),
            (t.bindVertexArray = (t) => e.bindVertexArrayOES(t)),
            (t.deleteVertexArray = (t) => e.deleteVertexArrayOES(t)))
          : ((this.hasVao = !1),
            (t.createVertexArray = () => null),
            (t.bindVertexArray = () => null),
            (t.deleteVertexArray = () => null));
    }
    if (2 !== e.webGLVersion) {
      const e = t.getExtension("ANGLE_instanced_arrays");
      e
        ? ((t.vertexAttribDivisor = (t, r) => e.vertexAttribDivisorANGLE(t, r)),
          (t.drawElementsInstanced = (t, r, i, s, n) =>
            e.drawElementsInstancedANGLE(t, r, i, s, n)),
          (t.drawArraysInstanced = (t, r, i, s) =>
            e.drawArraysInstancedANGLE(t, r, i, s)))
        : (this.hasInstance = !1);
    }
    this.canUseUInt32ElementIndex =
      2 === e.webGLVersion || !!e.extensions.uint32ElementIndex;
  }
  bind(t, e) {
    e = e || this.renderer.shader.shader;
    const { gl: r } = this;
    let i = t.glVertexArrayObjects[this.CONTEXT_UID],
      s = !1;
    i ||
      ((this.managedGeometries[t.id] = t),
      t.disposeRunner.add(this),
      (t.glVertexArrayObjects[this.CONTEXT_UID] = i = {}),
      (s = !0));
    const n = i[e.program.id] || this.initGeometryVao(t, e, s);
    (this._activeGeometry = t),
      this._activeVao !== n &&
        ((this._activeVao = n),
        this.hasVao ? r.bindVertexArray(n) : this.activateVao(t, e.program)),
      this.updateBuffers();
  }
  reset() {
    this.unbind();
  }
  updateBuffers() {
    const t = this._activeGeometry,
      e = this.renderer.buffer;
    for (let r = 0; r < t.buffers.length; r++) {
      const i = t.buffers[r];
      e.update(i);
    }
  }
  checkCompatibility(t, e) {
    const r = t.attributes,
      i = e.attributeData;
    for (const s in i)
      if (!r[s])
        throw new Error(
          `shader and geometry incompatible, geometry missing the "${s}" attribute`
        );
  }
  getSignature(t, e) {
    const r = t.attributes,
      i = e.attributeData,
      s = ["g", t.id];
    for (const n in r) i[n] && s.push(n, i[n].location);
    return s.join("-");
  }
  initGeometryVao(t, e, r = !0) {
    const i = this.gl,
      s = this.CONTEXT_UID,
      n = this.renderer.buffer,
      o = e.program;
    o.glPrograms[s] || this.renderer.shader.generateProgram(e),
      this.checkCompatibility(t, o);
    const a = this.getSignature(t, o),
      h = t.glVertexArrayObjects[this.CONTEXT_UID];
    let l = h[a];
    if (l) return (h[o.id] = l), l;
    const u = t.buffers,
      c = t.attributes,
      d = {},
      p = {};
    for (const f in u) (d[f] = 0), (p[f] = 0);
    for (const f in c)
      !c[f].size && o.attributeData[f]
        ? (c[f].size = o.attributeData[f].size)
        : c[f].size,
        (d[c[f].buffer] += c[f].size * xa[c[f].type]);
    for (const f in c) {
      const t = c[f],
        e = t.size;
      void 0 === t.stride &&
        (d[t.buffer] === e * xa[t.type]
          ? (t.stride = 0)
          : (t.stride = d[t.buffer])),
        void 0 === t.start &&
          ((t.start = p[t.buffer]), (p[t.buffer] += e * xa[t.type]));
    }
    (l = i.createVertexArray()), i.bindVertexArray(l);
    for (let f = 0; f < u.length; f++) {
      const t = u[f];
      n.bind(t), r && t._glBuffers[s].refCount++;
    }
    return (
      this.activateVao(t, o),
      (h[o.id] = l),
      (h[a] = l),
      i.bindVertexArray(null),
      n.unbind(gn.ARRAY_BUFFER),
      l
    );
  }
  disposeGeometry(t, e) {
    var r;
    if (!this.managedGeometries[t.id]) return;
    delete this.managedGeometries[t.id];
    const i = t.glVertexArrayObjects[this.CONTEXT_UID],
      s = this.gl,
      n = t.buffers,
      o = null == (r = this.renderer) ? void 0 : r.buffer;
    if ((t.disposeRunner.remove(this), i)) {
      if (o)
        for (let t = 0; t < n.length; t++) {
          const r = n[t]._glBuffers[this.CONTEXT_UID];
          r && (r.refCount--, 0 === r.refCount && !e && o.dispose(n[t], e));
        }
      if (!e)
        for (const t in i)
          if ("g" === t[0]) {
            const e = i[t];
            this._activeVao === e && this.unbind(), s.deleteVertexArray(e);
          }
      delete t.glVertexArrayObjects[this.CONTEXT_UID];
    }
  }
  disposeAll(t) {
    const e = Object.keys(this.managedGeometries);
    for (let r = 0; r < e.length; r++)
      this.disposeGeometry(this.managedGeometries[e[r]], t);
  }
  activateVao(t, e) {
    const r = this.gl,
      i = this.CONTEXT_UID,
      s = this.renderer.buffer,
      n = t.buffers,
      o = t.attributes;
    t.indexBuffer && s.bind(t.indexBuffer);
    let a = null;
    for (const h in o) {
      const t = o[h],
        l = n[t.buffer],
        u = l._glBuffers[i];
      if (e.attributeData[h]) {
        a !== u && (s.bind(l), (a = u));
        const i = e.attributeData[h].location;
        if (
          (r.enableVertexAttribArray(i),
          r.vertexAttribPointer(
            i,
            t.size,
            t.type || r.FLOAT,
            t.normalized,
            t.stride,
            t.start
          ),
          t.instance)
        ) {
          if (!this.hasInstance)
            throw new Error(
              "geometry error, GPU Instancing is not supported on this device"
            );
          r.vertexAttribDivisor(i, t.divisor);
        }
      }
    }
  }
  draw(t, e, r, i) {
    const { gl: s } = this,
      n = this._activeGeometry;
    if (n.indexBuffer) {
      const o = n.indexBuffer.data.BYTES_PER_ELEMENT,
        a = 2 === o ? s.UNSIGNED_SHORT : s.UNSIGNED_INT;
      (2 === o || (4 === o && this.canUseUInt32ElementIndex)) &&
        (n.instanced
          ? s.drawElementsInstanced(
              t,
              e || n.indexBuffer.data.length,
              a,
              (r || 0) * o,
              i || 1
            )
          : s.drawElements(t, e || n.indexBuffer.data.length, a, (r || 0) * o));
    } else
      n.instanced
        ? s.drawArraysInstanced(t, r, e || n.getSize(), i || 1)
        : s.drawArrays(t, r, e || n.getSize());
    return this;
  }
  unbind() {
    this.gl.bindVertexArray(null),
      (this._activeVao = null),
      (this._activeGeometry = null);
  }
  destroy() {
    this.renderer = null;
  }
}
(ba.extension = { type: Gs.RendererSystem, name: "geometry" }), kn.add(ba);
const Ea = new go();
class Ta {
  constructor(t, e) {
    (this._texture = t),
      (this.mapCoord = new go()),
      (this.uClampFrame = new Float32Array(4)),
      (this.uClampOffset = new Float32Array(2)),
      (this._textureID = -1),
      (this._updateID = 0),
      (this.clampOffset = 0),
      (this.clampMargin = typeof e > "u" ? 0.5 : e),
      (this.isSimple = !1);
  }
  get texture() {
    return this._texture;
  }
  set texture(t) {
    (this._texture = t), (this._textureID = -1);
  }
  multiplyUvs(t, e) {
    void 0 === e && (e = t);
    const r = this.mapCoord;
    for (let i = 0; i < t.length; i += 2) {
      const s = t[i],
        n = t[i + 1];
      (e[i] = s * r.a + n * r.c + r.tx), (e[i + 1] = s * r.b + n * r.d + r.ty);
    }
    return e;
  }
  update(t) {
    const e = this._texture;
    if (!e || !e.valid || (!t && this._textureID === e._updateID)) return !1;
    (this._textureID = e._updateID), this._updateID++;
    const r = e._uvs;
    this.mapCoord.set(
      r.x1 - r.x0,
      r.y1 - r.y0,
      r.x3 - r.x0,
      r.y3 - r.y0,
      r.x0,
      r.y0
    );
    const i = e.orig,
      s = e.trim;
    s &&
      (Ea.set(
        i.width / s.width,
        0,
        0,
        i.height / s.height,
        -s.x / s.width,
        -s.y / s.height
      ),
      this.mapCoord.append(Ea));
    const n = e.baseTexture,
      o = this.uClampFrame,
      a = this.clampMargin / n.resolution,
      h = this.clampOffset;
    return (
      (o[0] = (e._frame.x + a + h) / n.width),
      (o[1] = (e._frame.y + a + h) / n.height),
      (o[2] = (e._frame.x + e._frame.width - a + h) / n.width),
      (o[3] = (e._frame.y + e._frame.height - a + h) / n.height),
      (this.uClampOffset[0] = h / n.realWidth),
      (this.uClampOffset[1] = h / n.realHeight),
      (this.isSimple =
        e._frame.width === n.width &&
        e._frame.height === n.height &&
        0 === e.rotate),
      !0
    );
  }
}
class Aa extends Zo {
  constructor(t, e, r) {
    let i = null;
    "string" != typeof t &&
      void 0 === e &&
      void 0 === r &&
      ((i = t), (t = void 0), (e = void 0), (r = void 0)),
      super(
        t ||
          "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\nuniform mat3 otherMatrix;\n\nvarying vec2 vMaskCoord;\nvarying vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = aTextureCoord;\n    vMaskCoord = ( otherMatrix * vec3( aTextureCoord, 1.0)  ).xy;\n}\n",
        e ||
          "varying vec2 vMaskCoord;\nvarying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\nuniform sampler2D mask;\nuniform float alpha;\nuniform float npmAlpha;\nuniform vec4 maskClamp;\n\nvoid main(void)\n{\n    float clip = step(3.5,\n        step(maskClamp.x, vMaskCoord.x) +\n        step(maskClamp.y, vMaskCoord.y) +\n        step(vMaskCoord.x, maskClamp.z) +\n        step(vMaskCoord.y, maskClamp.w));\n\n    vec4 original = texture2D(uSampler, vTextureCoord);\n    vec4 masky = texture2D(mask, vMaskCoord);\n    float alphaMul = 1.0 - npmAlpha * (1.0 - masky.a);\n\n    original *= (alphaMul * masky.r * alpha * clip);\n\n    gl_FragColor = original;\n}\n",
        r
      ),
      (this.maskSprite = i),
      (this.maskMatrix = new go());
  }
  get maskSprite() {
    return this._maskSprite;
  }
  set maskSprite(t) {
    (this._maskSprite = t),
      this._maskSprite && (this._maskSprite.renderable = !1);
  }
  apply(t, e, r, i) {
    const s = this._maskSprite,
      n = s._texture;
    n.valid &&
      (n.uvMatrix || (n.uvMatrix = new Ta(n, 0)),
      n.uvMatrix.update(),
      (this.uniforms.npmAlpha = n.baseTexture.alphaMode ? 0 : 1),
      (this.uniforms.mask = n),
      (this.uniforms.otherMatrix = t
        .calculateSpriteMatrix(this.maskMatrix, s)
        .prepend(n.uvMatrix.mapCoord)),
      (this.uniforms.alpha = s.worldAlpha),
      (this.uniforms.maskClamp = n.uvMatrix.uClampFrame),
      t.applyFilter(this, e, r, i));
  }
}
class wa {
  constructor(t = null) {
    (this.type = fn.NONE),
      (this.autoDetect = !0),
      (this.maskObject = t || null),
      (this.pooled = !1),
      (this.isMaskData = !0),
      (this.resolution = null),
      (this.multisample = Zo.defaultMultisample),
      (this.enabled = !0),
      (this.colorMask = 15),
      (this._filters = null),
      (this._stencilCounter = 0),
      (this._scissorCounter = 0),
      (this._scissorRect = null),
      (this._scissorRectLocal = null),
      (this._colorMask = 15),
      (this._target = null);
  }
  get filter() {
    return this._filters ? this._filters[0] : null;
  }
  set filter(t) {
    t
      ? this._filters
        ? (this._filters[0] = t)
        : (this._filters = [t])
      : (this._filters = null);
  }
  reset() {
    this.pooled &&
      ((this.maskObject = null), (this.type = fn.NONE), (this.autoDetect = !0)),
      (this._target = null),
      (this._scissorRectLocal = null);
  }
  copyCountersOrReset(t) {
    t
      ? ((this._stencilCounter = t._stencilCounter),
        (this._scissorCounter = t._scissorCounter),
        (this._scissorRect = t._scissorRect))
      : ((this._stencilCounter = 0),
        (this._scissorCounter = 0),
        (this._scissorRect = null));
  }
}
class Sa {
  constructor(t) {
    (this.renderer = t),
      (this.enableScissor = !0),
      (this.alphaMaskPool = []),
      (this.maskDataPool = []),
      (this.maskStack = []),
      (this.alphaMaskIndex = 0);
  }
  setMaskStack(t) {
    (this.maskStack = t),
      this.renderer.scissor.setMaskStack(t),
      this.renderer.stencil.setMaskStack(t);
  }
  push(t, e) {
    let r = e;
    if (!r.isMaskData) {
      const t = this.maskDataPool.pop() || new wa();
      (t.pooled = !0), (t.maskObject = e), (r = t);
    }
    const i =
      0 !== this.maskStack.length
        ? this.maskStack[this.maskStack.length - 1]
        : null;
    if (
      (r.copyCountersOrReset(i),
      (r._colorMask = i ? i._colorMask : 15),
      r.autoDetect && this.detect(r),
      (r._target = t),
      r.type !== fn.SPRITE && this.maskStack.push(r),
      r.enabled)
    )
      switch (r.type) {
        case fn.SCISSOR:
          this.renderer.scissor.push(r);
          break;
        case fn.STENCIL:
          this.renderer.stencil.push(r);
          break;
        case fn.SPRITE:
          r.copyCountersOrReset(null), this.pushSpriteMask(r);
          break;
        case fn.COLOR:
          this.pushColorMask(r);
      }
    r.type === fn.SPRITE && this.maskStack.push(r);
  }
  pop(t) {
    const e = this.maskStack.pop();
    if (e && e._target === t) {
      if (e.enabled)
        switch (e.type) {
          case fn.SCISSOR:
            this.renderer.scissor.pop(e);
            break;
          case fn.STENCIL:
            this.renderer.stencil.pop(e.maskObject);
            break;
          case fn.SPRITE:
            this.popSpriteMask(e);
            break;
          case fn.COLOR:
            this.popColorMask(e);
        }
      if (
        (e.reset(),
        e.pooled && this.maskDataPool.push(e),
        0 !== this.maskStack.length)
      ) {
        const t = this.maskStack[this.maskStack.length - 1];
        t.type === fn.SPRITE &&
          t._filters &&
          (t._filters[0].maskSprite = t.maskObject);
      }
    }
  }
  detect(t) {
    const e = t.maskObject;
    e
      ? e.isSprite
        ? (t.type = fn.SPRITE)
        : this.enableScissor && this.renderer.scissor.testScissor(t)
        ? (t.type = fn.SCISSOR)
        : (t.type = fn.STENCIL)
      : (t.type = fn.COLOR);
  }
  pushSpriteMask(t) {
    const { maskObject: e } = t,
      r = t._target;
    let i = t._filters;
    i ||
      ((i = this.alphaMaskPool[this.alphaMaskIndex]),
      i || (i = this.alphaMaskPool[this.alphaMaskIndex] = [new Aa()])),
      (i[0].resolution = t.resolution),
      (i[0].multisample = t.multisample),
      (i[0].maskSprite = e);
    const s = r.filterArea;
    (r.filterArea = e.getBounds(!0)),
      this.renderer.filter.push(r, i),
      (r.filterArea = s),
      t._filters || this.alphaMaskIndex++;
  }
  popSpriteMask(t) {
    this.renderer.filter.pop(),
      t._filters
        ? (t._filters[0].maskSprite = null)
        : (this.alphaMaskIndex--,
          (this.alphaMaskPool[this.alphaMaskIndex][0].maskSprite = null));
  }
  pushColorMask(t) {
    const e = t._colorMask,
      r = (t._colorMask = e & t.colorMask);
    r !== e &&
      this.renderer.gl.colorMask(
        0 != (1 & r),
        0 != (2 & r),
        0 != (4 & r),
        0 != (8 & r)
      );
  }
  popColorMask(t) {
    const e = t._colorMask,
      r =
        this.maskStack.length > 0
          ? this.maskStack[this.maskStack.length - 1]._colorMask
          : 15;
    r !== e &&
      this.renderer.gl.colorMask(
        0 != (1 & r),
        0 != (2 & r),
        0 != (4 & r),
        0 != (8 & r)
      );
  }
  destroy() {
    this.renderer = null;
  }
}
(Sa.extension = { type: Gs.RendererSystem, name: "mask" }), kn.add(Sa);
class Ra {
  constructor(t) {
    (this.renderer = t), (this.maskStack = []), (this.glConst = 0);
  }
  getStackLength() {
    return this.maskStack.length;
  }
  setMaskStack(t) {
    const { gl: e } = this.renderer,
      r = this.getStackLength();
    this.maskStack = t;
    const i = this.getStackLength();
    i !== r &&
      (0 === i
        ? e.disable(this.glConst)
        : (e.enable(this.glConst), this._useCurrent()));
  }
  _useCurrent() {}
  destroy() {
    (this.renderer = null), (this.maskStack = null);
  }
}
const Ia = new go(),
  Ca = [],
  Pa = class t extends Ra {
    constructor(t) {
      super(t),
        (this.glConst = _n.ADAPTER.getWebGLRenderingContext().SCISSOR_TEST);
    }
    getStackLength() {
      const t = this.maskStack[this.maskStack.length - 1];
      return t ? t._scissorCounter : 0;
    }
    calcScissorRect(t) {
      if (t._scissorRectLocal) return;
      const e = t._scissorRect,
        { maskObject: r } = t,
        { renderer: i } = this,
        s = i.renderTexture,
        n = r.getBounds(!0, Ca.pop() ?? new uo());
      this.roundFrameToPixels(
        n,
        s.current ? s.current.resolution : i.resolution,
        s.sourceFrame,
        s.destinationFrame,
        i.projection.transform
      ),
        e && n.fit(e),
        (t._scissorRectLocal = n);
    }
    static isMatrixRotated(t) {
      if (!t) return !1;
      const { a: e, b: r, c: i, d: s } = t;
      return (
        (Math.abs(r) > 1e-4 || Math.abs(i) > 1e-4) &&
        (Math.abs(e) > 1e-4 || Math.abs(s) > 1e-4)
      );
    }
    testScissor(e) {
      const { maskObject: r } = e;
      if (
        !r.isFastRect ||
        !r.isFastRect() ||
        t.isMatrixRotated(r.worldTransform) ||
        t.isMatrixRotated(this.renderer.projection.transform)
      )
        return !1;
      this.calcScissorRect(e);
      const i = e._scissorRectLocal;
      return i.width > 0 && i.height > 0;
    }
    roundFrameToPixels(e, r, i, s, n) {
      t.isMatrixRotated(n) ||
        ((n = n ? Ia.copyFrom(n) : Ia.identity())
          .translate(-i.x, -i.y)
          .scale(s.width / i.width, s.height / i.height)
          .translate(s.x, s.y),
        this.renderer.filter.transformAABB(n, e),
        e.fit(s),
        (e.x = Math.round(e.x * r)),
        (e.y = Math.round(e.y * r)),
        (e.width = Math.round(e.width * r)),
        (e.height = Math.round(e.height * r)));
    }
    push(t) {
      t._scissorRectLocal || this.calcScissorRect(t);
      const { gl: e } = this.renderer;
      t._scissorRect || e.enable(e.SCISSOR_TEST),
        t._scissorCounter++,
        (t._scissorRect = t._scissorRectLocal),
        this._useCurrent();
    }
    pop(t) {
      const { gl: e } = this.renderer;
      t && Ca.push(t._scissorRectLocal),
        this.getStackLength() > 0
          ? this._useCurrent()
          : e.disable(e.SCISSOR_TEST);
    }
    _useCurrent() {
      const t = this.maskStack[this.maskStack.length - 1]._scissorRect;
      let e;
      (e = this.renderer.renderTexture.current
        ? t.y
        : this.renderer.height - t.height - t.y),
        this.renderer.gl.scissor(t.x, e, t.width, t.height);
    }
  };
Pa.extension = { type: Gs.RendererSystem, name: "scissor" };
let Ma = Pa;
kn.add(Ma);
class Da extends Ra {
  constructor(t) {
    super(t),
      (this.glConst = _n.ADAPTER.getWebGLRenderingContext().STENCIL_TEST);
  }
  getStackLength() {
    const t = this.maskStack[this.maskStack.length - 1];
    return t ? t._stencilCounter : 0;
  }
  push(t) {
    const e = t.maskObject,
      { gl: r } = this.renderer,
      i = t._stencilCounter;
    0 === i &&
      (this.renderer.framebuffer.forceStencil(),
      r.clearStencil(0),
      r.clear(r.STENCIL_BUFFER_BIT),
      r.enable(r.STENCIL_TEST)),
      t._stencilCounter++;
    const s = t._colorMask;
    0 !== s && ((t._colorMask = 0), r.colorMask(!1, !1, !1, !1)),
      r.stencilFunc(r.EQUAL, i, 4294967295),
      r.stencilOp(r.KEEP, r.KEEP, r.INCR),
      (e.renderable = !0),
      e.render(this.renderer),
      this.renderer.batch.flush(),
      (e.renderable = !1),
      0 !== s &&
        ((t._colorMask = s),
        r.colorMask(0 != (1 & s), 0 != (2 & s), 0 != (4 & s), 0 != (8 & s))),
      this._useCurrent();
  }
  pop(t) {
    const e = this.renderer.gl;
    if (0 === this.getStackLength()) e.disable(e.STENCIL_TEST);
    else {
      const r =
          0 !== this.maskStack.length
            ? this.maskStack[this.maskStack.length - 1]
            : null,
        i = r ? r._colorMask : 15;
      0 !== i && ((r._colorMask = 0), e.colorMask(!1, !1, !1, !1)),
        e.stencilOp(e.KEEP, e.KEEP, e.DECR),
        (t.renderable = !0),
        t.render(this.renderer),
        this.renderer.batch.flush(),
        (t.renderable = !1),
        0 !== i &&
          ((r._colorMask = i),
          e.colorMask(0 != (1 & i), 0 != (2 & i), 0 != (4 & i), 0 != (8 & i))),
        this._useCurrent();
    }
  }
  _useCurrent() {
    const t = this.renderer.gl;
    t.stencilFunc(t.EQUAL, this.getStackLength(), 4294967295),
      t.stencilOp(t.KEEP, t.KEEP, t.KEEP);
  }
}
(Da.extension = { type: Gs.RendererSystem, name: "stencil" }), kn.add(Da);
class Oa {
  constructor(t) {
    (this.renderer = t),
      (this.plugins = {}),
      Object.defineProperties(this.plugins, {
        extract: {
          enumerable: !1,
          get: () => (
            W(0, "renderer.plugins.extract has moved to renderer.extract"),
            t.extract
          ),
        },
        prepare: {
          enumerable: !1,
          get: () => (
            W(0, "renderer.plugins.prepare has moved to renderer.prepare"),
            t.prepare
          ),
        },
        interaction: {
          enumerable: !1,
          get: () => (
            W(
              0,
              "renderer.plugins.interaction has been deprecated, use renderer.events"
            ),
            t.events
          ),
        },
      });
  }
  init() {
    const t = this.rendererPlugins;
    for (const e in t) this.plugins[e] = new t[e](this.renderer);
  }
  destroy() {
    for (const t in this.plugins)
      this.plugins[t].destroy(), (this.plugins[t] = null);
  }
}
(Oa.extension = {
  type: [Gs.RendererSystem, Gs.CanvasRendererSystem],
  name: "_plugin",
}),
  kn.add(Oa);
class Ba {
  constructor(t) {
    (this.renderer = t),
      (this.destinationFrame = null),
      (this.sourceFrame = null),
      (this.defaultFrame = null),
      (this.projectionMatrix = new go()),
      (this.transform = null);
  }
  update(t, e, r, i) {
    (this.destinationFrame = t || this.destinationFrame || this.defaultFrame),
      (this.sourceFrame = e || this.sourceFrame || t),
      this.calculateProjection(this.destinationFrame, this.sourceFrame, r, i),
      this.transform && this.projectionMatrix.append(this.transform);
    const s = this.renderer;
    (s.globalUniforms.uniforms.projectionMatrix = this.projectionMatrix),
      s.globalUniforms.update(),
      s.shader.shader &&
        s.shader.syncUniformGroup(s.shader.shader.uniforms.globals);
  }
  calculateProjection(t, e, r, i) {
    const s = this.projectionMatrix,
      n = i ? -1 : 1;
    s.identity(),
      (s.a = (1 / e.width) * 2),
      (s.d = n * ((1 / e.height) * 2)),
      (s.tx = -1 - e.x * s.a),
      (s.ty = -n - e.y * s.d);
  }
  setTransform(t) {}
  destroy() {
    this.renderer = null;
  }
}
(Ba.extension = { type: Gs.RendererSystem, name: "projection" }), kn.add(Ba);
const Na = new Ro(),
  Fa = new uo();
class La {
  constructor(t) {
    (this.renderer = t), (this._tempMatrix = new go());
  }
  generateTexture(t, e) {
    const { region: r, ...i } = e || {},
      s = (null == r ? void 0 : r.copyTo(Fa)) || t.getLocalBounds(Fa, !0),
      n = i.resolution || this.renderer.resolution;
    (s.width = Math.max(s.width, 1 / n)),
      (s.height = Math.max(s.height, 1 / n)),
      (i.width = s.width),
      (i.height = s.height),
      (i.resolution = n),
      i.multisample ?? (i.multisample = this.renderer.multisample);
    const o = la.create(i);
    (this._tempMatrix.tx = -s.x), (this._tempMatrix.ty = -s.y);
    const a = t.transform;
    return (
      (t.transform = Na),
      this.renderer.render(t, {
        renderTexture: o,
        transform: this._tempMatrix,
        skipUpdateTransform: !!t.parent,
        blit: !0,
      }),
      (t.transform = a),
      o
    );
  }
  destroy() {}
}
(La.extension = {
  type: [Gs.RendererSystem, Gs.CanvasRendererSystem],
  name: "textureGenerator",
}),
  kn.add(La);
const ka = new uo(),
  Ua = new uo();
class Ga {
  constructor(t) {
    (this.renderer = t),
      (this.defaultMaskStack = []),
      (this.current = null),
      (this.sourceFrame = new uo()),
      (this.destinationFrame = new uo()),
      (this.viewportFrame = new uo());
  }
  contextChange() {
    var t;
    const e =
      null == (t = this.renderer) ? void 0 : t.gl.getContextAttributes();
    this._rendererPremultipliedAlpha = !!(e && e.alpha && e.premultipliedAlpha);
  }
  bind(t = null, e, r) {
    const i = this.renderer;
    let s, n, o;
    (this.current = t),
      t
        ? ((s = t.baseTexture),
          (o = s.resolution),
          e ||
            ((ka.width = t.frame.width),
            (ka.height = t.frame.height),
            (e = ka)),
          r ||
            ((Ua.x = t.frame.x),
            (Ua.y = t.frame.y),
            (Ua.width = e.width),
            (Ua.height = e.height),
            (r = Ua)),
          (n = s.framebuffer))
        : ((o = i.resolution),
          e ||
            ((ka.width = i._view.screen.width),
            (ka.height = i._view.screen.height),
            (e = ka)),
          r || (((r = ka).width = e.width), (r.height = e.height)));
    const a = this.viewportFrame;
    (a.x = r.x * o),
      (a.y = r.y * o),
      (a.width = r.width * o),
      (a.height = r.height * o),
      t || (a.y = i.view.height - (a.y + a.height)),
      a.ceil(),
      this.renderer.framebuffer.bind(n, a),
      this.renderer.projection.update(r, e, o, !n),
      t
        ? this.renderer.mask.setMaskStack(s.maskStack)
        : this.renderer.mask.setMaskStack(this.defaultMaskStack),
      this.sourceFrame.copyFrom(e),
      this.destinationFrame.copyFrom(r);
  }
  clear(t, e) {
    const r = this.current
        ? this.current.baseTexture.clear
        : this.renderer.background.backgroundColor,
      i = Rn.shared.setValue(t || r);
    ((this.current && this.current.baseTexture.alphaMode > 0) ||
      (!this.current && this._rendererPremultipliedAlpha)) &&
      i.premultiply(i.alpha);
    const s = this.destinationFrame,
      n = this.current ? this.current.baseTexture : this.renderer._view.screen,
      o = s.width !== n.width || s.height !== n.height;
    if (o) {
      let { x: t, y: e, width: r, height: i } = this.viewportFrame;
      (t = Math.round(t)),
        (e = Math.round(e)),
        (r = Math.round(r)),
        (i = Math.round(i)),
        this.renderer.gl.enable(this.renderer.gl.SCISSOR_TEST),
        this.renderer.gl.scissor(t, e, r, i);
    }
    this.renderer.framebuffer.clear(i.red, i.green, i.blue, i.alpha, e),
      o && this.renderer.scissor.pop();
  }
  resize() {
    this.bind(null);
  }
  reset() {
    this.bind(null);
  }
  destroy() {
    this.renderer = null;
  }
}
(Ga.extension = { type: Gs.RendererSystem, name: "renderTexture" }), kn.add(Ga);
class Ha {
  constructor(t, e) {
    (this.program = t),
      (this.uniformData = e),
      (this.uniformGroups = {}),
      (this.uniformDirtyGroups = {}),
      (this.uniformBufferBindings = {});
  }
  destroy() {
    (this.uniformData = null),
      (this.uniformGroups = null),
      (this.uniformDirtyGroups = null),
      (this.uniformBufferBindings = null),
      (this.program = null);
  }
}
const ja = {
    float: "\n        data[offset] = v;\n    ",
    vec2: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n    ",
    vec3: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n        data[offset+2] = v[2];\n\n    ",
    vec4: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n        data[offset+2] = v[2];\n        data[offset+3] = v[3];\n    ",
    mat2: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n\n        data[offset+4] = v[2];\n        data[offset+5] = v[3];\n    ",
    mat3: "\n        data[offset] = v[0];\n        data[offset+1] = v[1];\n        data[offset+2] = v[2];\n\n        data[offset + 4] = v[3];\n        data[offset + 5] = v[4];\n        data[offset + 6] = v[5];\n\n        data[offset + 8] = v[6];\n        data[offset + 9] = v[7];\n        data[offset + 10] = v[8];\n    ",
    mat4: "\n        for(var i = 0; i < 16; i++)\n        {\n            data[offset + i] = v[i];\n        }\n    ",
  },
  Xa = {
    float: 4,
    vec2: 8,
    vec3: 12,
    vec4: 16,
    int: 4,
    ivec2: 8,
    ivec3: 12,
    ivec4: 16,
    uint: 4,
    uvec2: 8,
    uvec3: 12,
    uvec4: 16,
    bool: 4,
    bvec2: 8,
    bvec3: 12,
    bvec4: 16,
    mat2: 32,
    mat3: 48,
    mat4: 64,
  };
let Va = 0;
const za = { textureCount: 0, uboCount: 0 };
class Wa {
  constructor(t) {
    (this.destroyed = !1),
      (this.renderer = t),
      this.systemCheck(),
      (this.gl = null),
      (this.shader = null),
      (this.program = null),
      (this.cache = {}),
      (this._uboCache = {}),
      (this.id = Va++);
  }
  systemCheck() {
    if (
      !(function () {
        if ("boolean" == typeof Lo) return Lo;
        try {
          Lo =
            !0 ===
            new Function(
              "param1",
              "param2",
              "param3",
              "return param1[param2] === param3;"
            )({ a: "b" }, "a", "b");
        } catch {
          Lo = !1;
        }
        return Lo;
      })()
    )
      throw new Error(
        "Current environment does not allow unsafe-eval, please use @pixi/unsafe-eval module to enable support."
      );
  }
  contextChange(t) {
    (this.gl = t), this.reset();
  }
  bind(t, e) {
    t.disposeRunner.add(this),
      (t.uniforms.globals = this.renderer.globalUniforms);
    const r = t.program,
      i = r.glPrograms[this.renderer.CONTEXT_UID] || this.generateProgram(t);
    return (
      (this.shader = t),
      this.program !== r && ((this.program = r), this.gl.useProgram(i.program)),
      e ||
        ((za.textureCount = 0),
        (za.uboCount = 0),
        this.syncUniformGroup(t.uniformGroup, za)),
      i
    );
  }
  setUniforms(t) {
    const e = this.shader.program,
      r = e.glPrograms[this.renderer.CONTEXT_UID];
    e.syncUniforms(r.uniformData, t, this.renderer);
  }
  syncUniformGroup(t, e) {
    const r = this.getGlProgram();
    (!t.static || t.dirtyId !== r.uniformDirtyGroups[t.id]) &&
      ((r.uniformDirtyGroups[t.id] = t.dirtyId), this.syncUniforms(t, r, e));
  }
  syncUniforms(t, e, r) {
    (t.syncUniforms[this.shader.program.id] || this.createSyncGroups(t))(
      e.uniformData,
      t.uniforms,
      this.renderer,
      r
    );
  }
  createSyncGroups(t) {
    const e = this.getSignature(t, this.shader.program.uniformData, "u");
    return (
      this.cache[e] ||
        (this.cache[e] = (function (t, e) {
          var r;
          const i = [
            "\n        var v = null;\n        var cv = null;\n        var cu = null;\n        var t = 0;\n        var gl = renderer.gl;\n    ",
          ];
          for (const s in t.uniforms) {
            const n = e[s];
            if (!n) {
              !0 === (null == (r = t.uniforms[s]) ? void 0 : r.group) &&
                (t.uniforms[s].ubo
                  ? i.push(
                      `\n                        renderer.shader.syncUniformBufferGroup(uv.${s}, '${s}');\n                    `
                    )
                  : i.push(
                      `\n                        renderer.shader.syncUniformGroup(uv.${s}, syncData);\n                    `
                    ));
              continue;
            }
            const o = t.uniforms[s];
            let a = !1;
            for (let t = 0; t < Io.length; t++)
              if (Io[t].test(n, o)) {
                i.push(Io[t].code(s, o)), (a = !0);
                break;
              }
            if (!a) {
              const t = (1 !== n.size || n.isArray ? Po : Co)[n.type].replace(
                "location",
                `ud["${s}"].location`
              );
              i.push(
                `\n            cu = ud["${s}"];\n            cv = cu.value;\n            v = uv["${s}"];\n            ${t};`
              );
            }
          }
          return new Function("ud", "uv", "renderer", "syncData", i.join("\n"));
        })(t, this.shader.program.uniformData)),
      (t.syncUniforms[this.shader.program.id] = this.cache[e]),
      t.syncUniforms[this.shader.program.id]
    );
  }
  syncUniformBufferGroup(t, e) {
    const r = this.getGlProgram();
    if (!t.static || 0 !== t.dirtyId || !r.uniformGroups[t.id]) {
      t.dirtyId = 0;
      const i = r.uniformGroups[t.id] || this.createSyncBufferGroup(t, r, e);
      t.buffer.update(),
        i(r.uniformData, t.uniforms, this.renderer, za, t.buffer);
    }
    this.renderer.buffer.bindBufferBase(t.buffer, r.uniformBufferBindings[e]);
  }
  createSyncBufferGroup(t, e, r) {
    const { gl: i } = this.renderer;
    this.renderer.buffer.bind(t.buffer);
    const s = this.gl.getUniformBlockIndex(e.program, r);
    (e.uniformBufferBindings[r] = this.shader.uniformBindCount),
      i.uniformBlockBinding(e.program, s, this.shader.uniformBindCount),
      this.shader.uniformBindCount++;
    const n = this.getSignature(t, this.shader.program.uniformData, "ubo");
    let o = this._uboCache[n];
    if (
      (o ||
        (o = this._uboCache[n] =
          (function (t, e) {
            if (!t.autoManage) return { size: 0, syncFunc: _t };
            const r = (function (t, e) {
                const r = [];
                for (const i in t) e[i] && r.push(e[i]);
                return r.sort((t, e) => t.index - e.index), r;
              })(t.uniforms, e),
              { uboElements: i, size: s } = (function (t) {
                const e = t.map((t) => ({
                  data: t,
                  offset: 0,
                  dataLen: 0,
                  dirty: 0,
                }));
                let r = 0,
                  i = 0,
                  s = 0;
                for (let n = 0; n < e.length; n++) {
                  const t = e[n];
                  if (
                    ((r = Xa[t.data.type]),
                    t.data.size > 1 && (r = Math.max(r, 16) * t.data.size),
                    (t.dataLen = r),
                    i % r != 0 && i < 16)
                  ) {
                    const t = (i % r) % 16;
                    (i += t), (s += t);
                  }
                  i + r > 16
                    ? ((s = 16 * Math.ceil(s / 16)),
                      (t.offset = s),
                      (s += r),
                      (i = r))
                    : ((t.offset = s), (i += r), (s += r));
                }
                return (
                  (s = 16 * Math.ceil(s / 16)), { uboElements: e, size: s }
                );
              })(r),
              n = [
                "\n    var v = null;\n    var v2 = null;\n    var cv = null;\n    var t = 0;\n    var gl = renderer.gl\n    var index = 0;\n    var data = buffer.data;\n    ",
              ];
            for (let o = 0; o < i.length; o++) {
              const e = i[o],
                r = t.uniforms[e.data.name],
                s = e.data.name;
              let a = !1;
              for (let t = 0; t < Io.length; t++) {
                const i = Io[t];
                if (i.codeUbo && i.test(e.data, r)) {
                  n.push(
                    `offset = ${e.offset / 4};`,
                    Io[t].codeUbo(e.data.name, r)
                  ),
                    (a = !0);
                  break;
                }
              }
              if (!a)
                if (e.data.size > 1) {
                  const t = pt(e.data.type),
                    r = Math.max(Xa[e.data.type] / 16, 1),
                    i = t / r,
                    o = (4 - (i % 4)) % 4;
                  n.push(
                    `\n                cv = ud.${s}.value;\n                v = uv.${s};\n                offset = ${
                      e.offset / 4
                    };\n\n                t = 0;\n\n                for(var i=0; i < ${
                      e.data.size * r
                    }; i++)\n                {\n                    for(var j = 0; j < ${i}; j++)\n                    {\n                        data[offset++] = v[t++];\n                    }\n                    offset += ${o};\n                }\n\n                `
                  );
                } else {
                  const t = ja[e.data.type];
                  n.push(
                    `\n                cv = ud.${s}.value;\n                v = uv.${s};\n                offset = ${
                      e.offset / 4
                    };\n                ${t};\n                `
                  );
                }
            }
            return (
              n.push("\n       renderer.buffer.update(buffer);\n    "),
              {
                size: s,
                syncFunc: new Function(
                  "ud",
                  "uv",
                  "renderer",
                  "syncData",
                  "buffer",
                  n.join("\n")
                ),
              }
            );
          })(t, this.shader.program.uniformData)),
      t.autoManage)
    ) {
      const e = new Float32Array(o.size / 4);
      t.buffer.update(e);
    }
    return (e.uniformGroups[t.id] = o.syncFunc), e.uniformGroups[t.id];
  }
  getSignature(t, e, r) {
    const i = t.uniforms,
      s = [`${r}-`];
    for (const n in i) s.push(n), e[n] && s.push(e[n].type);
    return s.join("-");
  }
  getGlProgram() {
    return this.shader
      ? this.shader.program.glPrograms[this.renderer.CONTEXT_UID]
      : null;
  }
  generateProgram(t) {
    const e = this.gl,
      r = t.program,
      i = (function (t, e) {
        var r;
        const i = lt(t, t.VERTEX_SHADER, e.vertexSrc),
          s = lt(t, t.FRAGMENT_SHADER, e.fragmentSrc),
          n = t.createProgram();
        t.attachShader(n, i), t.attachShader(n, s);
        const o = null == (r = e.extra) ? void 0 : r.transformFeedbackVaryings;
        if (
          (o &&
            ("function" != typeof t.transformFeedbackVaryings ||
              t.transformFeedbackVaryings(
                n,
                o.names,
                "separate" === o.bufferMode
                  ? t.SEPARATE_ATTRIBS
                  : t.INTERLEAVED_ATTRIBS
              )),
          t.linkProgram(n),
          t.getProgramParameter(n, t.LINK_STATUS) ||
            (function (t, e, r, i) {
              t.getProgramParameter(e, t.LINK_STATUS) ||
                (t.getShaderParameter(r, t.COMPILE_STATUS) || dt(t, r),
                t.getShaderParameter(i, t.COMPILE_STATUS) || dt(t, i),
                t.getProgramInfoLog(e));
            })(t, n, i, s),
          (e.attributeData = (function (t, e) {
            const r = {},
              i = e.getProgramParameter(t, e.ACTIVE_ATTRIBUTES);
            for (let s = 0; s < i; s++) {
              const i = e.getActiveAttrib(t, s);
              if (i.name.startsWith("gl_")) continue;
              const n = ft(e, i.type),
                o = {
                  type: n,
                  name: i.name,
                  size: pt(n),
                  location: e.getAttribLocation(t, i.name),
                };
              r[i.name] = o;
            }
            return r;
          })(n, t)),
          (e.uniformData = (function (t, e) {
            const r = {},
              i = e.getProgramParameter(t, e.ACTIVE_UNIFORMS);
            for (let s = 0; s < i; s++) {
              const i = e.getActiveUniform(t, s),
                n = i.name.replace(/\[.*?\]$/, ""),
                o = !!i.name.match(/\[.*?\]$/),
                a = ft(e, i.type);
              r[n] = {
                name: n,
                index: s,
                type: a,
                size: i.size,
                isArray: o,
                value: ct(a, i.size),
              };
            }
            return r;
          })(n, t)),
          !/^[ \t]*#[ \t]*version[ \t]+300[ \t]+es[ \t]*$/m.test(e.vertexSrc))
        ) {
          const r = Object.keys(e.attributeData);
          r.sort((t, e) => (t > e ? 1 : -1));
          for (let i = 0; i < r.length; i++)
            (e.attributeData[r[i]].location = i),
              t.bindAttribLocation(n, i, r[i]);
          t.linkProgram(n);
        }
        t.deleteShader(i), t.deleteShader(s);
        const a = {};
        for (const h in e.uniformData) {
          const r = e.uniformData[h];
          a[h] = {
            location: t.getUniformLocation(n, h),
            value: ct(r.type, r.size),
          };
        }
        return new Ha(n, a);
      })(e, r);
    return (r.glPrograms[this.renderer.CONTEXT_UID] = i), i;
  }
  reset() {
    (this.program = null), (this.shader = null);
  }
  disposeShader(t) {
    this.shader === t && (this.shader = null);
  }
  destroy() {
    (this.renderer = null), (this.destroyed = !0);
  }
}
(Wa.extension = { type: Gs.RendererSystem, name: "shader" }), kn.add(Wa);
class $a {
  constructor(t) {
    this.renderer = t;
  }
  run(t) {
    const { renderer: e } = this;
    e.runners.init.emit(e.options),
      t.hello,
      e.resize(e.screen.width, e.screen.height);
  }
  destroy() {}
}
($a.defaultOptions = { hello: !1 }),
  ($a.extension = {
    type: [Gs.RendererSystem, Gs.CanvasRendererSystem],
    name: "startup",
  }),
  kn.add($a);
const Ya = class t {
  constructor() {
    (this.gl = null),
      (this.stateId = 0),
      (this.polygonOffset = 0),
      (this.blendMode = tn.NONE),
      (this._blendEq = !1),
      (this.map = []),
      (this.map[0] = this.setBlend),
      (this.map[1] = this.setOffset),
      (this.map[2] = this.setCullFace),
      (this.map[3] = this.setDepthTest),
      (this.map[4] = this.setFrontFace),
      (this.map[5] = this.setDepthMask),
      (this.checks = []),
      (this.defaultState = new Hn()),
      (this.defaultState.blend = !0);
  }
  contextChange(t) {
    (this.gl = t),
      (this.blendModes = (function (t, e = []) {
        return (
          (e[tn.NORMAL] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.ADD] = [t.ONE, t.ONE]),
          (e[tn.MULTIPLY] = [
            t.DST_COLOR,
            t.ONE_MINUS_SRC_ALPHA,
            t.ONE,
            t.ONE_MINUS_SRC_ALPHA,
          ]),
          (e[tn.SCREEN] = [
            t.ONE,
            t.ONE_MINUS_SRC_COLOR,
            t.ONE,
            t.ONE_MINUS_SRC_ALPHA,
          ]),
          (e[tn.OVERLAY] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.DARKEN] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.LIGHTEN] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.COLOR_DODGE] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.COLOR_BURN] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.HARD_LIGHT] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.SOFT_LIGHT] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.DIFFERENCE] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.EXCLUSION] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.HUE] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.SATURATION] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.COLOR] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.LUMINOSITY] = [t.ONE, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.NONE] = [0, 0]),
          (e[tn.NORMAL_NPM] = [
            t.SRC_ALPHA,
            t.ONE_MINUS_SRC_ALPHA,
            t.ONE,
            t.ONE_MINUS_SRC_ALPHA,
          ]),
          (e[tn.ADD_NPM] = [t.SRC_ALPHA, t.ONE, t.ONE, t.ONE]),
          (e[tn.SCREEN_NPM] = [
            t.SRC_ALPHA,
            t.ONE_MINUS_SRC_COLOR,
            t.ONE,
            t.ONE_MINUS_SRC_ALPHA,
          ]),
          (e[tn.SRC_IN] = [t.DST_ALPHA, t.ZERO]),
          (e[tn.SRC_OUT] = [t.ONE_MINUS_DST_ALPHA, t.ZERO]),
          (e[tn.SRC_ATOP] = [t.DST_ALPHA, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.DST_OVER] = [t.ONE_MINUS_DST_ALPHA, t.ONE]),
          (e[tn.DST_IN] = [t.ZERO, t.SRC_ALPHA]),
          (e[tn.DST_OUT] = [t.ZERO, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.DST_ATOP] = [t.ONE_MINUS_DST_ALPHA, t.SRC_ALPHA]),
          (e[tn.XOR] = [t.ONE_MINUS_DST_ALPHA, t.ONE_MINUS_SRC_ALPHA]),
          (e[tn.SUBTRACT] = [
            t.ONE,
            t.ONE,
            t.ONE,
            t.ONE,
            t.FUNC_REVERSE_SUBTRACT,
            t.FUNC_ADD,
          ]),
          e
        );
      })(t)),
      this.set(this.defaultState),
      this.reset();
  }
  set(t) {
    if (((t = t || this.defaultState), this.stateId !== t.data)) {
      let e = this.stateId ^ t.data,
        r = 0;
      for (; e; )
        1 & e && this.map[r].call(this, !!(t.data & (1 << r))), (e >>= 1), r++;
      this.stateId = t.data;
    }
    for (let e = 0; e < this.checks.length; e++) this.checks[e](this, t);
  }
  forceState(t) {
    t = t || this.defaultState;
    for (let e = 0; e < this.map.length; e++)
      this.map[e].call(this, !!(t.data & (1 << e)));
    for (let e = 0; e < this.checks.length; e++) this.checks[e](this, t);
    this.stateId = t.data;
  }
  setBlend(e) {
    this.updateCheck(t.checkBlendMode, e),
      this.gl[e ? "enable" : "disable"](this.gl.BLEND);
  }
  setOffset(e) {
    this.updateCheck(t.checkPolygonOffset, e),
      this.gl[e ? "enable" : "disable"](this.gl.POLYGON_OFFSET_FILL);
  }
  setDepthTest(t) {
    this.gl[t ? "enable" : "disable"](this.gl.DEPTH_TEST);
  }
  setDepthMask(t) {
    this.gl.depthMask(t);
  }
  setCullFace(t) {
    this.gl[t ? "enable" : "disable"](this.gl.CULL_FACE);
  }
  setFrontFace(t) {
    this.gl.frontFace(this.gl[t ? "CW" : "CCW"]);
  }
  setBlendMode(t) {
    if (t === this.blendMode) return;
    this.blendMode = t;
    const e = this.blendModes[t],
      r = this.gl;
    2 === e.length
      ? r.blendFunc(e[0], e[1])
      : r.blendFuncSeparate(e[0], e[1], e[2], e[3]),
      6 === e.length
        ? ((this._blendEq = !0), r.blendEquationSeparate(e[4], e[5]))
        : this._blendEq &&
          ((this._blendEq = !1),
          r.blendEquationSeparate(r.FUNC_ADD, r.FUNC_ADD));
  }
  setPolygonOffset(t, e) {
    this.gl.polygonOffset(t, e);
  }
  reset() {
    this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, !1),
      this.forceState(this.defaultState),
      (this._blendEq = !0),
      (this.blendMode = -1),
      this.setBlendMode(0);
  }
  updateCheck(t, e) {
    const r = this.checks.indexOf(t);
    e && -1 === r
      ? this.checks.push(t)
      : !e && -1 !== r && this.checks.splice(r, 1);
  }
  static checkBlendMode(t, e) {
    t.setBlendMode(e.blendMode);
  }
  static checkPolygonOffset(t, e) {
    t.setPolygonOffset(1, e.polygonOffset);
  }
  destroy() {
    this.gl = null;
  }
};
Ya.extension = { type: Gs.RendererSystem, name: "state" };
let qa = Ya;
kn.add(qa);
class Ka extends vn {
  constructor() {
    super(...arguments), (this.runners = {}), (this._systemsHash = {});
  }
  setup(t) {
    this.addRunners(...t.runners);
    const e = (t.priority ?? []).filter((e) => t.systems[e]),
      r = [...e, ...Object.keys(t.systems).filter((t) => !e.includes(t))];
    for (const i of r) this.addSystem(t.systems[i], i);
  }
  addRunners(...t) {
    t.forEach((t) => {
      this.runners[t] = new Xn(t);
    });
  }
  addSystem(t, e) {
    const r = new t(this);
    if (this[e]) throw new Error(`Whoops! The name "${e}" is already in use`);
    (this[e] = r), (this._systemsHash[e] = r);
    for (const i in this.runners) this.runners[i].add(r);
    return this;
  }
  emitWithCustomOptions(t, e) {
    const r = Object.keys(this._systemsHash);
    t.items.forEach((i) => {
      const s = r.find((t) => this._systemsHash[t] === i);
      i[t.name](e[s]);
    });
  }
  destroy() {
    Object.values(this.runners).forEach((t) => {
      t.destroy();
    }),
      (this._systemsHash = {});
  }
}
const Za = class t {
  constructor(e) {
    (this.renderer = e),
      (this.count = 0),
      (this.checkCount = 0),
      (this.maxIdle = t.defaultMaxIdle),
      (this.checkCountMax = t.defaultCheckCountMax),
      (this.mode = t.defaultMode);
  }
  postrender() {
    this.renderer.objectRenderer.renderingToScreen &&
      (this.count++,
      this.mode !== dn.MANUAL &&
        (this.checkCount++,
        this.checkCount > this.checkCountMax &&
          ((this.checkCount = 0), this.run())));
  }
  run() {
    const t = this.renderer.texture,
      e = t.managedTextures;
    let r = !1;
    for (let i = 0; i < e.length; i++) {
      const s = e[i];
      s.resource &&
        this.count - s.touched > this.maxIdle &&
        (t.destroyTexture(s, !0), (e[i] = null), (r = !0));
    }
    if (r) {
      let t = 0;
      for (let r = 0; r < e.length; r++) null !== e[r] && (e[t++] = e[r]);
      e.length = t;
    }
  }
  unload(t) {
    const e = this.renderer.texture,
      r = t._texture;
    r && !r.framebuffer && e.destroyTexture(r);
    for (let i = t.children.length - 1; i >= 0; i--) this.unload(t.children[i]);
  }
  destroy() {
    this.renderer = null;
  }
};
(Za.defaultMode = dn.AUTO),
  (Za.defaultMaxIdle = 3600),
  (Za.defaultCheckCountMax = 600),
  (Za.extension = { type: Gs.RendererSystem, name: "textureGC" });
let Qa = Za;
kn.add(Qa);
class Ja {
  constructor(t) {
    (this.texture = t),
      (this.width = -1),
      (this.height = -1),
      (this.dirtyId = -1),
      (this.dirtyStyleId = -1),
      (this.mipmap = !1),
      (this.wrapMode = 33071),
      (this.type = nn.UNSIGNED_BYTE),
      (this.internalFormat = rn.RGBA),
      (this.samplerType = 0);
  }
}
class th {
  constructor(t) {
    (this.renderer = t),
      (this.boundTextures = []),
      (this.currentLocation = -1),
      (this.managedTextures = []),
      (this._unknownBoundTextures = !1),
      (this.unknownTexture = new Yn()),
      (this.hasIntegerTextures = !1);
  }
  contextChange() {
    const t = (this.gl = this.renderer.gl);
    (this.CONTEXT_UID = this.renderer.CONTEXT_UID),
      (this.webGLVersion = this.renderer.context.webGLVersion),
      (this.internalFormats = (function (t) {
        let e;
        return (
          (e =
            "WebGL2RenderingContext" in globalThis &&
            t instanceof globalThis.WebGL2RenderingContext
              ? {
                  [nn.UNSIGNED_BYTE]: {
                    [rn.RGBA]: t.RGBA8,
                    [rn.RGB]: t.RGB8,
                    [rn.RG]: t.RG8,
                    [rn.RED]: t.R8,
                    [rn.RGBA_INTEGER]: t.RGBA8UI,
                    [rn.RGB_INTEGER]: t.RGB8UI,
                    [rn.RG_INTEGER]: t.RG8UI,
                    [rn.RED_INTEGER]: t.R8UI,
                    [rn.ALPHA]: t.ALPHA,
                    [rn.LUMINANCE]: t.LUMINANCE,
                    [rn.LUMINANCE_ALPHA]: t.LUMINANCE_ALPHA,
                  },
                  [nn.BYTE]: {
                    [rn.RGBA]: t.RGBA8_SNORM,
                    [rn.RGB]: t.RGB8_SNORM,
                    [rn.RG]: t.RG8_SNORM,
                    [rn.RED]: t.R8_SNORM,
                    [rn.RGBA_INTEGER]: t.RGBA8I,
                    [rn.RGB_INTEGER]: t.RGB8I,
                    [rn.RG_INTEGER]: t.RG8I,
                    [rn.RED_INTEGER]: t.R8I,
                  },
                  [nn.UNSIGNED_SHORT]: {
                    [rn.RGBA_INTEGER]: t.RGBA16UI,
                    [rn.RGB_INTEGER]: t.RGB16UI,
                    [rn.RG_INTEGER]: t.RG16UI,
                    [rn.RED_INTEGER]: t.R16UI,
                    [rn.DEPTH_COMPONENT]: t.DEPTH_COMPONENT16,
                  },
                  [nn.SHORT]: {
                    [rn.RGBA_INTEGER]: t.RGBA16I,
                    [rn.RGB_INTEGER]: t.RGB16I,
                    [rn.RG_INTEGER]: t.RG16I,
                    [rn.RED_INTEGER]: t.R16I,
                  },
                  [nn.UNSIGNED_INT]: {
                    [rn.RGBA_INTEGER]: t.RGBA32UI,
                    [rn.RGB_INTEGER]: t.RGB32UI,
                    [rn.RG_INTEGER]: t.RG32UI,
                    [rn.RED_INTEGER]: t.R32UI,
                    [rn.DEPTH_COMPONENT]: t.DEPTH_COMPONENT24,
                  },
                  [nn.INT]: {
                    [rn.RGBA_INTEGER]: t.RGBA32I,
                    [rn.RGB_INTEGER]: t.RGB32I,
                    [rn.RG_INTEGER]: t.RG32I,
                    [rn.RED_INTEGER]: t.R32I,
                  },
                  [nn.FLOAT]: {
                    [rn.RGBA]: t.RGBA32F,
                    [rn.RGB]: t.RGB32F,
                    [rn.RG]: t.RG32F,
                    [rn.RED]: t.R32F,
                    [rn.DEPTH_COMPONENT]: t.DEPTH_COMPONENT32F,
                  },
                  [nn.HALF_FLOAT]: {
                    [rn.RGBA]: t.RGBA16F,
                    [rn.RGB]: t.RGB16F,
                    [rn.RG]: t.RG16F,
                    [rn.RED]: t.R16F,
                  },
                  [nn.UNSIGNED_SHORT_5_6_5]: { [rn.RGB]: t.RGB565 },
                  [nn.UNSIGNED_SHORT_4_4_4_4]: { [rn.RGBA]: t.RGBA4 },
                  [nn.UNSIGNED_SHORT_5_5_5_1]: { [rn.RGBA]: t.RGB5_A1 },
                  [nn.UNSIGNED_INT_2_10_10_10_REV]: {
                    [rn.RGBA]: t.RGB10_A2,
                    [rn.RGBA_INTEGER]: t.RGB10_A2UI,
                  },
                  [nn.UNSIGNED_INT_10F_11F_11F_REV]: {
                    [rn.RGB]: t.R11F_G11F_B10F,
                  },
                  [nn.UNSIGNED_INT_5_9_9_9_REV]: { [rn.RGB]: t.RGB9_E5 },
                  [nn.UNSIGNED_INT_24_8]: {
                    [rn.DEPTH_STENCIL]: t.DEPTH24_STENCIL8,
                  },
                  [nn.FLOAT_32_UNSIGNED_INT_24_8_REV]: {
                    [rn.DEPTH_STENCIL]: t.DEPTH32F_STENCIL8,
                  },
                }
              : {
                  [nn.UNSIGNED_BYTE]: {
                    [rn.RGBA]: t.RGBA,
                    [rn.RGB]: t.RGB,
                    [rn.ALPHA]: t.ALPHA,
                    [rn.LUMINANCE]: t.LUMINANCE,
                    [rn.LUMINANCE_ALPHA]: t.LUMINANCE_ALPHA,
                  },
                  [nn.UNSIGNED_SHORT_5_6_5]: { [rn.RGB]: t.RGB },
                  [nn.UNSIGNED_SHORT_4_4_4_4]: { [rn.RGBA]: t.RGBA },
                  [nn.UNSIGNED_SHORT_5_5_5_1]: { [rn.RGBA]: t.RGBA },
                }),
          e
        );
      })(t)),
      (this.samplerTypes = (function (t) {
        let e;
        return (
          (e =
            "WebGL2RenderingContext" in globalThis &&
            t instanceof globalThis.WebGL2RenderingContext
              ? {
                  [t.RGB]: on.FLOAT,
                  [t.RGBA]: on.FLOAT,
                  [t.ALPHA]: on.FLOAT,
                  [t.LUMINANCE]: on.FLOAT,
                  [t.LUMINANCE_ALPHA]: on.FLOAT,
                  [t.R8]: on.FLOAT,
                  [t.R8_SNORM]: on.FLOAT,
                  [t.RG8]: on.FLOAT,
                  [t.RG8_SNORM]: on.FLOAT,
                  [t.RGB8]: on.FLOAT,
                  [t.RGB8_SNORM]: on.FLOAT,
                  [t.RGB565]: on.FLOAT,
                  [t.RGBA4]: on.FLOAT,
                  [t.RGB5_A1]: on.FLOAT,
                  [t.RGBA8]: on.FLOAT,
                  [t.RGBA8_SNORM]: on.FLOAT,
                  [t.RGB10_A2]: on.FLOAT,
                  [t.RGB10_A2UI]: on.FLOAT,
                  [t.SRGB8]: on.FLOAT,
                  [t.SRGB8_ALPHA8]: on.FLOAT,
                  [t.R16F]: on.FLOAT,
                  [t.RG16F]: on.FLOAT,
                  [t.RGB16F]: on.FLOAT,
                  [t.RGBA16F]: on.FLOAT,
                  [t.R32F]: on.FLOAT,
                  [t.RG32F]: on.FLOAT,
                  [t.RGB32F]: on.FLOAT,
                  [t.RGBA32F]: on.FLOAT,
                  [t.R11F_G11F_B10F]: on.FLOAT,
                  [t.RGB9_E5]: on.FLOAT,
                  [t.R8I]: on.INT,
                  [t.R8UI]: on.UINT,
                  [t.R16I]: on.INT,
                  [t.R16UI]: on.UINT,
                  [t.R32I]: on.INT,
                  [t.R32UI]: on.UINT,
                  [t.RG8I]: on.INT,
                  [t.RG8UI]: on.UINT,
                  [t.RG16I]: on.INT,
                  [t.RG16UI]: on.UINT,
                  [t.RG32I]: on.INT,
                  [t.RG32UI]: on.UINT,
                  [t.RGB8I]: on.INT,
                  [t.RGB8UI]: on.UINT,
                  [t.RGB16I]: on.INT,
                  [t.RGB16UI]: on.UINT,
                  [t.RGB32I]: on.INT,
                  [t.RGB32UI]: on.UINT,
                  [t.RGBA8I]: on.INT,
                  [t.RGBA8UI]: on.UINT,
                  [t.RGBA16I]: on.INT,
                  [t.RGBA16UI]: on.UINT,
                  [t.RGBA32I]: on.INT,
                  [t.RGBA32UI]: on.UINT,
                  [t.DEPTH_COMPONENT16]: on.FLOAT,
                  [t.DEPTH_COMPONENT24]: on.FLOAT,
                  [t.DEPTH_COMPONENT32F]: on.FLOAT,
                  [t.DEPTH_STENCIL]: on.FLOAT,
                  [t.DEPTH24_STENCIL8]: on.FLOAT,
                  [t.DEPTH32F_STENCIL8]: on.FLOAT,
                }
              : {
                  [t.RGB]: on.FLOAT,
                  [t.RGBA]: on.FLOAT,
                  [t.ALPHA]: on.FLOAT,
                  [t.LUMINANCE]: on.FLOAT,
                  [t.LUMINANCE_ALPHA]: on.FLOAT,
                  [t.DEPTH_STENCIL]: on.FLOAT,
                }),
          e
        );
      })(t));
    const e = t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS);
    this.boundTextures.length = e;
    for (let i = 0; i < e; i++) this.boundTextures[i] = null;
    this.emptyTextures = {};
    const r = new Ja(t.createTexture());
    t.bindTexture(t.TEXTURE_2D, r.texture),
      t.texImage2D(
        t.TEXTURE_2D,
        0,
        t.RGBA,
        1,
        1,
        0,
        t.RGBA,
        t.UNSIGNED_BYTE,
        new Uint8Array(4)
      ),
      (this.emptyTextures[t.TEXTURE_2D] = r),
      (this.emptyTextures[t.TEXTURE_CUBE_MAP] = new Ja(t.createTexture())),
      t.bindTexture(
        t.TEXTURE_CUBE_MAP,
        this.emptyTextures[t.TEXTURE_CUBE_MAP].texture
      );
    for (let i = 0; i < 6; i++)
      t.texImage2D(
        t.TEXTURE_CUBE_MAP_POSITIVE_X + i,
        0,
        t.RGBA,
        1,
        1,
        0,
        t.RGBA,
        t.UNSIGNED_BYTE,
        null
      );
    t.texParameteri(t.TEXTURE_CUBE_MAP, t.TEXTURE_MAG_FILTER, t.LINEAR),
      t.texParameteri(t.TEXTURE_CUBE_MAP, t.TEXTURE_MIN_FILTER, t.LINEAR);
    for (let i = 0; i < this.boundTextures.length; i++) this.bind(null, i);
  }
  bind(t, e = 0) {
    const { gl: r } = this;
    if (
      (null == (t = null == t ? void 0 : t.castToBaseTexture())
        ? void 0
        : t.valid) &&
      !t.parentTextureArray
    ) {
      t.touched = this.renderer.textureGC.count;
      const i = t._glTextures[this.CONTEXT_UID] || this.initTexture(t);
      this.boundTextures[e] !== t &&
        (this.currentLocation !== e &&
          ((this.currentLocation = e), r.activeTexture(r.TEXTURE0 + e)),
        r.bindTexture(t.target, i.texture)),
        i.dirtyId !== t.dirtyId
          ? (this.currentLocation !== e &&
              ((this.currentLocation = e), r.activeTexture(r.TEXTURE0 + e)),
            this.updateTexture(t))
          : i.dirtyStyleId !== t.dirtyStyleId && this.updateTextureStyle(t),
        (this.boundTextures[e] = t);
    } else
      this.currentLocation !== e &&
        ((this.currentLocation = e), r.activeTexture(r.TEXTURE0 + e)),
        r.bindTexture(r.TEXTURE_2D, this.emptyTextures[r.TEXTURE_2D].texture),
        (this.boundTextures[e] = null);
  }
  reset() {
    (this._unknownBoundTextures = !0),
      (this.hasIntegerTextures = !1),
      (this.currentLocation = -1);
    for (let t = 0; t < this.boundTextures.length; t++)
      this.boundTextures[t] = this.unknownTexture;
  }
  unbind(t) {
    const { gl: e, boundTextures: r } = this;
    if (this._unknownBoundTextures) {
      this._unknownBoundTextures = !1;
      for (let t = 0; t < r.length; t++)
        r[t] === this.unknownTexture && this.bind(null, t);
    }
    for (let i = 0; i < r.length; i++)
      r[i] === t &&
        (this.currentLocation !== i &&
          (e.activeTexture(e.TEXTURE0 + i), (this.currentLocation = i)),
        e.bindTexture(t.target, this.emptyTextures[t.target].texture),
        (r[i] = null));
  }
  ensureSamplerType(t) {
    const { boundTextures: e, hasIntegerTextures: r, CONTEXT_UID: i } = this;
    if (r)
      for (let s = t - 1; s >= 0; --s) {
        const t = e[s];
        t &&
          t._glTextures[i].samplerType !== on.FLOAT &&
          this.renderer.texture.unbind(t);
      }
  }
  initTexture(t) {
    const e = new Ja(this.gl.createTexture());
    return (
      (e.dirtyId = -1),
      (t._glTextures[this.CONTEXT_UID] = e),
      this.managedTextures.push(t),
      t.on("dispose", this.destroyTexture, this),
      e
    );
  }
  initTextureType(t, e) {
    var r;
    (e.internalFormat =
      (null == (r = this.internalFormats[t.type]) ? void 0 : r[t.format]) ??
      t.format),
      (e.samplerType = this.samplerTypes[e.internalFormat] ?? on.FLOAT),
      2 === this.webGLVersion && t.type === nn.HALF_FLOAT
        ? (e.type = this.gl.HALF_FLOAT)
        : (e.type = t.type);
  }
  updateTexture(t) {
    var e;
    const r = t._glTextures[this.CONTEXT_UID];
    if (!r) return;
    const i = this.renderer;
    if (
      (this.initTextureType(t, r),
      null == (e = t.resource) ? void 0 : e.upload(i, t, r))
    )
      r.samplerType !== on.FLOAT && (this.hasIntegerTextures = !0);
    else {
      const e = t.realWidth,
        s = t.realHeight,
        n = i.gl;
      (r.width !== e || r.height !== s || r.dirtyId < 0) &&
        ((r.width = e),
        (r.height = s),
        n.texImage2D(
          t.target,
          0,
          r.internalFormat,
          e,
          s,
          0,
          t.format,
          r.type,
          null
        ));
    }
    t.dirtyStyleId !== r.dirtyStyleId && this.updateTextureStyle(t),
      (r.dirtyId = t.dirtyId);
  }
  destroyTexture(t, e) {
    const { gl: r } = this;
    if (
      (t = t.castToBaseTexture())._glTextures[this.CONTEXT_UID] &&
      (this.unbind(t),
      r.deleteTexture(t._glTextures[this.CONTEXT_UID].texture),
      t.off("dispose", this.destroyTexture, this),
      delete t._glTextures[this.CONTEXT_UID],
      !e)
    ) {
      const e = this.managedTextures.indexOf(t);
      -1 !== e && et(this.managedTextures, e, 1);
    }
  }
  updateTextureStyle(t) {
    var e;
    const r = t._glTextures[this.CONTEXT_UID];
    r &&
      ((t.mipmap !== ln.POW2 && 2 === this.webGLVersion) || t.isPowerOfTwo
        ? (r.mipmap = t.mipmap >= 1)
        : (r.mipmap = !1),
      2 === this.webGLVersion || t.isPowerOfTwo
        ? (r.wrapMode = t.wrapMode)
        : (r.wrapMode = hn.CLAMP),
      (null == (e = t.resource) ? void 0 : e.style(this.renderer, t, r)) ||
        this.setStyle(t, r),
      (r.dirtyStyleId = t.dirtyStyleId));
  }
  setStyle(t, e) {
    const r = this.gl;
    if (
      (e.mipmap && t.mipmap !== ln.ON_MANUAL && r.generateMipmap(t.target),
      r.texParameteri(t.target, r.TEXTURE_WRAP_S, e.wrapMode),
      r.texParameteri(t.target, r.TEXTURE_WRAP_T, e.wrapMode),
      e.mipmap)
    ) {
      r.texParameteri(
        t.target,
        r.TEXTURE_MIN_FILTER,
        t.scaleMode === an.LINEAR
          ? r.LINEAR_MIPMAP_LINEAR
          : r.NEAREST_MIPMAP_NEAREST
      );
      const e = this.renderer.context.extensions.anisotropicFiltering;
      if (e && t.anisotropicLevel > 0 && t.scaleMode === an.LINEAR) {
        const i = Math.min(
          t.anisotropicLevel,
          r.getParameter(e.MAX_TEXTURE_MAX_ANISOTROPY_EXT)
        );
        r.texParameterf(t.target, e.TEXTURE_MAX_ANISOTROPY_EXT, i);
      }
    } else
      r.texParameteri(
        t.target,
        r.TEXTURE_MIN_FILTER,
        t.scaleMode === an.LINEAR ? r.LINEAR : r.NEAREST
      );
    r.texParameteri(
      t.target,
      r.TEXTURE_MAG_FILTER,
      t.scaleMode === an.LINEAR ? r.LINEAR : r.NEAREST
    );
  }
  destroy() {
    this.renderer = null;
  }
}
(th.extension = { type: Gs.RendererSystem, name: "texture" }), kn.add(th);
class eh {
  constructor(t) {
    this.renderer = t;
  }
  contextChange() {
    (this.gl = this.renderer.gl),
      (this.CONTEXT_UID = this.renderer.CONTEXT_UID);
  }
  bind(t) {
    const { gl: e, CONTEXT_UID: r } = this,
      i = t._glTransformFeedbacks[r] || this.createGLTransformFeedback(t);
    e.bindTransformFeedback(e.TRANSFORM_FEEDBACK, i);
  }
  unbind() {
    const { gl: t } = this;
    t.bindTransformFeedback(t.TRANSFORM_FEEDBACK, null);
  }
  beginTransformFeedback(t, e) {
    const { gl: r, renderer: i } = this;
    e && i.shader.bind(e), r.beginTransformFeedback(t);
  }
  endTransformFeedback() {
    const { gl: t } = this;
    t.endTransformFeedback();
  }
  createGLTransformFeedback(t) {
    const { gl: e, renderer: r, CONTEXT_UID: i } = this,
      s = e.createTransformFeedback();
    (t._glTransformFeedbacks[i] = s),
      e.bindTransformFeedback(e.TRANSFORM_FEEDBACK, s);
    for (let n = 0; n < t.buffers.length; n++) {
      const s = t.buffers[n];
      s &&
        (r.buffer.update(s),
        s._glBuffers[i].refCount++,
        e.bindBufferBase(
          e.TRANSFORM_FEEDBACK_BUFFER,
          n,
          s._glBuffers[i].buffer || null
        ));
    }
    return (
      e.bindTransformFeedback(e.TRANSFORM_FEEDBACK, null),
      t.disposeRunner.add(this),
      s
    );
  }
  disposeTransformFeedback(t, e) {
    const r = t._glTransformFeedbacks[this.CONTEXT_UID],
      i = this.gl;
    t.disposeRunner.remove(this);
    const s = this.renderer.buffer;
    if (s)
      for (let n = 0; n < t.buffers.length; n++) {
        const r = t.buffers[n];
        if (!r) continue;
        const i = r._glBuffers[this.CONTEXT_UID];
        i && (i.refCount--, 0 === i.refCount && !e && s.dispose(r, e));
      }
    r &&
      (e || i.deleteTransformFeedback(r),
      delete t._glTransformFeedbacks[this.CONTEXT_UID]);
  }
  destroy() {
    this.renderer = null;
  }
}
(eh.extension = { type: Gs.RendererSystem, name: "transformFeedback" }),
  kn.add(eh);
class rh {
  constructor(t) {
    this.renderer = t;
  }
  init(t) {
    (this.screen = new uo(0, 0, t.width, t.height)),
      (this.element = t.view || _n.ADAPTER.createCanvas()),
      (this.resolution = t.resolution || _n.RESOLUTION),
      (this.autoDensity = !!t.autoDensity);
  }
  resizeView(t, e) {
    (this.element.width = Math.round(t * this.resolution)),
      (this.element.height = Math.round(e * this.resolution));
    const r = this.element.width / this.resolution,
      i = this.element.height / this.resolution;
    (this.screen.width = r),
      (this.screen.height = i),
      this.autoDensity &&
        ((this.element.style.width = `${r}px`),
        (this.element.style.height = `${i}px`)),
      this.renderer.emit("resize", r, i),
      this.renderer.runners.resize.emit(this.screen.width, this.screen.height);
  }
  destroy(t) {
    var e;
    t && (null == (e = this.element.parentNode) || e.removeChild(this.element)),
      (this.renderer = null),
      (this.element = null),
      (this.screen = null);
  }
}
(rh.defaultOptions = {
  width: 800,
  height: 600,
  resolution: void 0,
  autoDensity: !1,
}),
  (rh.extension = {
    type: [Gs.RendererSystem, Gs.CanvasRendererSystem],
    name: "_view",
  }),
  kn.add(rh),
  (_n.PREFER_ENV = Zs.WEBGL2),
  (_n.STRICT_TEXTURE_CACHE = !1),
  (_n.RENDER_OPTIONS = {
    ...ea.defaultOptions,
    ...Qo.defaultOptions,
    ...rh.defaultOptions,
    ...$a.defaultOptions,
  }),
  Object.defineProperties(_n, {
    WRAP_MODE: {
      get: () => Yn.defaultOptions.wrapMode,
      set(t) {
        W(
          0,
          "settings.WRAP_MODE is deprecated, use BaseTexture.defaultOptions.wrapMode"
        ),
          (Yn.defaultOptions.wrapMode = t);
      },
    },
    SCALE_MODE: {
      get: () => Yn.defaultOptions.scaleMode,
      set(t) {
        W(
          0,
          "settings.SCALE_MODE is deprecated, use BaseTexture.defaultOptions.scaleMode"
        ),
          (Yn.defaultOptions.scaleMode = t);
      },
    },
    MIPMAP_TEXTURES: {
      get: () => Yn.defaultOptions.mipmap,
      set(t) {
        W(
          0,
          "settings.MIPMAP_TEXTURES is deprecated, use BaseTexture.defaultOptions.mipmap"
        ),
          (Yn.defaultOptions.mipmap = t);
      },
    },
    ANISOTROPIC_LEVEL: {
      get: () => Yn.defaultOptions.anisotropicLevel,
      set(t) {
        W(
          0,
          "settings.ANISOTROPIC_LEVEL is deprecated, use BaseTexture.defaultOptions.anisotropicLevel"
        ),
          (Yn.defaultOptions.anisotropicLevel = t);
      },
    },
    FILTER_RESOLUTION: {
      get: () => (
        W(
          0,
          "settings.FILTER_RESOLUTION is deprecated, use Filter.defaultResolution"
        ),
        Zo.defaultResolution
      ),
      set(t) {
        Zo.defaultResolution = t;
      },
    },
    FILTER_MULTISAMPLE: {
      get: () => (
        W(
          0,
          "settings.FILTER_MULTISAMPLE is deprecated, use Filter.defaultMultisample"
        ),
        Zo.defaultMultisample
      ),
      set(t) {
        Zo.defaultMultisample = t;
      },
    },
    SPRITE_MAX_TEXTURES: {
      get: () => qo.defaultMaxTextures,
      set(t) {
        W(
          0,
          "settings.SPRITE_MAX_TEXTURES is deprecated, use BatchRenderer.defaultMaxTextures"
        ),
          (qo.defaultMaxTextures = t);
      },
    },
    SPRITE_BATCH_SIZE: {
      get: () => qo.defaultBatchSize,
      set(t) {
        W(
          0,
          "settings.SPRITE_BATCH_SIZE is deprecated, use BatchRenderer.defaultBatchSize"
        ),
          (qo.defaultBatchSize = t);
      },
    },
    CAN_UPLOAD_SAME_BUFFER: {
      get: () => qo.canUploadSameBuffer,
      set(t) {
        W(
          0,
          "settings.CAN_UPLOAD_SAME_BUFFER is deprecated, use BatchRenderer.canUploadSameBuffer"
        ),
          (qo.canUploadSameBuffer = t);
      },
    },
    GC_MODE: {
      get: () => Qa.defaultMode,
      set(t) {
        W(0, "settings.GC_MODE is deprecated, use TextureGCSystem.defaultMode"),
          (Qa.defaultMode = t);
      },
    },
    GC_MAX_IDLE: {
      get: () => Qa.defaultMaxIdle,
      set(t) {
        W(
          0,
          "settings.GC_MAX_IDLE is deprecated, use TextureGCSystem.defaultMaxIdle"
        ),
          (Qa.defaultMaxIdle = t);
      },
    },
    GC_MAX_CHECK_COUNT: {
      get: () => Qa.defaultCheckCountMax,
      set(t) {
        W(
          0,
          "settings.GC_MAX_CHECK_COUNT is deprecated, use TextureGCSystem.defaultCheckCountMax"
        ),
          (Qa.defaultCheckCountMax = t);
      },
    },
    PRECISION_VERTEX: {
      get: () => Ho.defaultVertexPrecision,
      set(t) {
        W(
          0,
          "settings.PRECISION_VERTEX is deprecated, use Program.defaultVertexPrecision"
        ),
          (Ho.defaultVertexPrecision = t);
      },
    },
    PRECISION_FRAGMENT: {
      get: () => Ho.defaultFragmentPrecision,
      set(t) {
        W(
          0,
          "settings.PRECISION_FRAGMENT is deprecated, use Program.defaultFragmentPrecision"
        ),
          (Ho.defaultFragmentPrecision = t);
      },
    },
  }),
  (js = ((t) => (
    (t[(t.INTERACTION = 50)] = "INTERACTION"),
    (t[(t.HIGH = 25)] = "HIGH"),
    (t[(t.NORMAL = 0)] = "NORMAL"),
    (t[(t.LOW = -25)] = "LOW"),
    (t[(t.UTILITY = -50)] = "UTILITY"),
    t
  ))(js || {}));
class ih {
  constructor(t, e = null, r = 0, i = !1) {
    (this.next = null),
      (this.previous = null),
      (this._destroyed = !1),
      (this.fn = t),
      (this.context = e),
      (this.priority = r),
      (this.once = i);
  }
  match(t, e = null) {
    return this.fn === t && this.context === e;
  }
  emit(t) {
    this.fn && (this.context ? this.fn.call(this.context, t) : this.fn(t));
    const e = this.next;
    return (
      this.once && this.destroy(!0), this._destroyed && (this.next = null), e
    );
  }
  connect(t) {
    (this.previous = t),
      t.next && (t.next.previous = this),
      (this.next = t.next),
      (t.next = this);
  }
  destroy(t = !1) {
    (this._destroyed = !0),
      (this.fn = null),
      (this.context = null),
      this.previous && (this.previous.next = this.next),
      this.next && (this.next.previous = this.previous);
    const e = this.next;
    return (this.next = t ? null : e), (this.previous = null), e;
  }
}
const sh = class t {
  constructor() {
    (this.autoStart = !1),
      (this.deltaTime = 1),
      (this.lastTime = -1),
      (this.speed = 1),
      (this.started = !1),
      (this._requestId = null),
      (this._maxElapsedMS = 100),
      (this._minElapsedMS = 0),
      (this._protected = !1),
      (this._lastFrame = -1),
      (this._head = new ih(null, null, 1 / 0)),
      (this.deltaMS = 1 / t.targetFPMS),
      (this.elapsedMS = 1 / t.targetFPMS),
      (this._tick = (t) => {
        (this._requestId = null),
          this.started &&
            (this.update(t),
            this.started &&
              null === this._requestId &&
              this._head.next &&
              (this._requestId = requestAnimationFrame(this._tick)));
      });
  }
  _requestIfNeeded() {
    null === this._requestId &&
      this._head.next &&
      ((this.lastTime = performance.now()),
      (this._lastFrame = this.lastTime),
      (this._requestId = requestAnimationFrame(this._tick)));
  }
  _cancelIfNeeded() {
    null !== this._requestId &&
      (cancelAnimationFrame(this._requestId), (this._requestId = null));
  }
  _startIfPossible() {
    this.started ? this._requestIfNeeded() : this.autoStart && this.start();
  }
  add(t, e, r = js.NORMAL) {
    return this._addListener(new ih(t, e, r));
  }
  addOnce(t, e, r = js.NORMAL) {
    return this._addListener(new ih(t, e, r, !0));
  }
  _addListener(t) {
    let e = this._head.next,
      r = this._head;
    if (e) {
      for (; e; ) {
        if (t.priority > e.priority) {
          t.connect(r);
          break;
        }
        (r = e), (e = e.next);
      }
      t.previous || t.connect(r);
    } else t.connect(r);
    return this._startIfPossible(), this;
  }
  remove(t, e) {
    let r = this._head.next;
    for (; r; ) r = r.match(t, e) ? r.destroy() : r.next;
    return this._head.next || this._cancelIfNeeded(), this;
  }
  get count() {
    if (!this._head) return 0;
    let t = 0,
      e = this._head;
    for (; (e = e.next); ) t++;
    return t;
  }
  start() {
    this.started || ((this.started = !0), this._requestIfNeeded());
  }
  stop() {
    this.started && ((this.started = !1), this._cancelIfNeeded());
  }
  destroy() {
    if (!this._protected) {
      this.stop();
      let t = this._head.next;
      for (; t; ) t = t.destroy(!0);
      this._head.destroy(), (this._head = null);
    }
  }
  update(e = performance.now()) {
    let r;
    if (e > this.lastTime) {
      if (
        ((r = this.elapsedMS = e - this.lastTime),
        r > this._maxElapsedMS && (r = this._maxElapsedMS),
        (r *= this.speed),
        this._minElapsedMS)
      ) {
        const t = (e - this._lastFrame) | 0;
        if (t < this._minElapsedMS) return;
        this._lastFrame = e - (t % this._minElapsedMS);
      }
      (this.deltaMS = r), (this.deltaTime = this.deltaMS * t.targetFPMS);
      const i = this._head;
      let s = i.next;
      for (; s; ) s = s.emit(this.deltaTime);
      i.next || this._cancelIfNeeded();
    } else this.deltaTime = this.deltaMS = this.elapsedMS = 0;
    this.lastTime = e;
  }
  get FPS() {
    return 1e3 / this.elapsedMS;
  }
  get minFPS() {
    return 1e3 / this._maxElapsedMS;
  }
  set minFPS(e) {
    const r = Math.min(this.maxFPS, e),
      i = Math.min(Math.max(0, r) / 1e3, t.targetFPMS);
    this._maxElapsedMS = 1 / i;
  }
  get maxFPS() {
    return this._minElapsedMS ? Math.round(1e3 / this._minElapsedMS) : 0;
  }
  set maxFPS(t) {
    if (0 === t) this._minElapsedMS = 0;
    else {
      const e = Math.max(this.minFPS, t);
      this._minElapsedMS = 1 / (e / 1e3);
    }
  }
  static get shared() {
    if (!t._shared) {
      const e = (t._shared = new t());
      (e.autoStart = !0), (e._protected = !0);
    }
    return t._shared;
  }
  static get system() {
    if (!t._system) {
      const e = (t._system = new t());
      (e.autoStart = !0), (e._protected = !0);
    }
    return t._system;
  }
};
sh.targetFPMS = 0.06;
let nh = sh;
Object.defineProperties(_n, {
  TARGET_FPMS: {
    get: () => nh.targetFPMS,
    set(t) {
      W(0, "settings.TARGET_FPMS is deprecated, use Ticker.targetFPMS"),
        (nh.targetFPMS = t);
    },
  },
});
class oh {
  static init(t) {
    (t = Object.assign({ autoStart: !0, sharedTicker: !1 }, t)),
      Object.defineProperty(this, "ticker", {
        set(t) {
          this._ticker && this._ticker.remove(this.render, this),
            (this._ticker = t),
            t && t.add(this.render, this, js.LOW);
        },
        get() {
          return this._ticker;
        },
      }),
      (this.stop = () => {
        this._ticker.stop();
      }),
      (this.start = () => {
        this._ticker.start();
      }),
      (this._ticker = null),
      (this.ticker = t.sharedTicker ? nh.shared : new nh()),
      t.autoStart && this.start();
  }
  static destroy() {
    if (this._ticker) {
      const t = this._ticker;
      (this.ticker = null), t.destroy();
    }
  }
}
(oh.extension = Gs.Application), kn.add(oh);
const ah = [];
kn.handleByList(Gs.Renderer, ah);
const hh =
  "attribute vec2 aVertexPosition;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nuniform vec4 inputSize;\nuniform vec4 outputFrame;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aVertexPosition * (outputFrame.zw * inputSize.zw);\n}\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n}\n";
class lh {
  constructor(t) {
    this.renderer = t;
  }
  contextChange(t) {
    let e;
    if (1 === this.renderer.context.webGLVersion) {
      const r = t.getParameter(t.FRAMEBUFFER_BINDING);
      t.bindFramebuffer(t.FRAMEBUFFER, null),
        (e = t.getParameter(t.SAMPLES)),
        t.bindFramebuffer(t.FRAMEBUFFER, r);
    } else {
      const r = t.getParameter(t.DRAW_FRAMEBUFFER_BINDING);
      t.bindFramebuffer(t.DRAW_FRAMEBUFFER, null),
        (e = t.getParameter(t.SAMPLES)),
        t.bindFramebuffer(t.DRAW_FRAMEBUFFER, r);
    }
    e >= mn.HIGH
      ? (this.multisample = mn.HIGH)
      : e >= mn.MEDIUM
      ? (this.multisample = mn.MEDIUM)
      : e >= mn.LOW
      ? (this.multisample = mn.LOW)
      : (this.multisample = mn.NONE);
  }
  destroy() {}
}
(lh.extension = { type: Gs.RendererSystem, name: "_multisample" }), kn.add(lh);
class uh {
  constructor(t) {
    (this.buffer = t || null),
      (this.updateID = -1),
      (this.byteLength = -1),
      (this.refCount = 0);
  }
}
class ch {
  constructor(t) {
    (this.renderer = t),
      (this.managedBuffers = {}),
      (this.boundBufferBases = {});
  }
  destroy() {
    this.renderer = null;
  }
  contextChange() {
    this.disposeAll(!0),
      (this.gl = this.renderer.gl),
      (this.CONTEXT_UID = this.renderer.CONTEXT_UID);
  }
  bind(t) {
    const { gl: e, CONTEXT_UID: r } = this,
      i = t._glBuffers[r] || this.createGLBuffer(t);
    e.bindBuffer(t.type, i.buffer);
  }
  unbind(t) {
    const { gl: e } = this;
    e.bindBuffer(t, null);
  }
  bindBufferBase(t, e) {
    const { gl: r, CONTEXT_UID: i } = this;
    if (this.boundBufferBases[e] !== t) {
      const s = t._glBuffers[i] || this.createGLBuffer(t);
      (this.boundBufferBases[e] = t),
        r.bindBufferBase(r.UNIFORM_BUFFER, e, s.buffer);
    }
  }
  bindBufferRange(t, e, r) {
    const { gl: i, CONTEXT_UID: s } = this;
    r = r || 0;
    const n = t._glBuffers[s] || this.createGLBuffer(t);
    i.bindBufferRange(i.UNIFORM_BUFFER, e || 0, n.buffer, 256 * r, 256);
  }
  update(t) {
    const { gl: e, CONTEXT_UID: r } = this,
      i = t._glBuffers[r] || this.createGLBuffer(t);
    if (t._updateID !== i.updateID)
      if (
        ((i.updateID = t._updateID),
        e.bindBuffer(t.type, i.buffer),
        i.byteLength >= t.data.byteLength)
      )
        e.bufferSubData(t.type, 0, t.data);
      else {
        const r = t.static ? e.STATIC_DRAW : e.DYNAMIC_DRAW;
        (i.byteLength = t.data.byteLength), e.bufferData(t.type, t.data, r);
      }
  }
  dispose(t, e) {
    if (!this.managedBuffers[t.id]) return;
    delete this.managedBuffers[t.id];
    const r = t._glBuffers[this.CONTEXT_UID],
      i = this.gl;
    t.disposeRunner.remove(this),
      r &&
        (e || i.deleteBuffer(r.buffer), delete t._glBuffers[this.CONTEXT_UID]);
  }
  disposeAll(t) {
    const e = Object.keys(this.managedBuffers);
    for (let r = 0; r < e.length; r++)
      this.dispose(this.managedBuffers[e[r]], t);
  }
  createGLBuffer(t) {
    const { CONTEXT_UID: e, gl: r } = this;
    return (
      (t._glBuffers[e] = new uh(r.createBuffer())),
      (this.managedBuffers[t.id] = t),
      t.disposeRunner.add(this),
      t._glBuffers[e]
    );
  }
}
(ch.extension = { type: Gs.RendererSystem, name: "buffer" }), kn.add(ch);
class dh {
  constructor(t) {
    this.renderer = t;
  }
  render(t, e) {
    const r = this.renderer;
    let i, s, n, o;
    if (
      (e &&
        ((i = e.renderTexture),
        (s = e.clear),
        (n = e.transform),
        (o = e.skipUpdateTransform)),
      (this.renderingToScreen = !i),
      r.runners.prerender.emit(),
      r.emit("prerender"),
      (r.projection.transform = n),
      !r.context.isLost)
    ) {
      if ((i || (this.lastObjectRendered = t), !o)) {
        const e = t.enableTempParent();
        t.updateTransform(), t.disableTempParent(e);
      }
      r.renderTexture.bind(i),
        r.batch.currentRenderer.start(),
        (s ?? r.background.clearBeforeRender) && r.renderTexture.clear(),
        t.render(r),
        r.batch.currentRenderer.flush(),
        i && (e.blit && r.framebuffer.blit(), i.baseTexture.update()),
        r.runners.postrender.emit(),
        (r.projection.transform = null),
        r.emit("postrender");
    }
  }
  destroy() {
    (this.renderer = null), (this.lastObjectRendered = null);
  }
}
(dh.extension = { type: Gs.RendererSystem, name: "objectRenderer" }),
  kn.add(dh);
const ph = class t extends Ka {
  constructor(e) {
    super(),
      (this.type = Qs.WEBGL),
      (e = Object.assign({}, _n.RENDER_OPTIONS, e)),
      (this.gl = null),
      (this.CONTEXT_UID = 0),
      (this.globalUniforms = new Xo({ projectionMatrix: new go() }, !0));
    const r = {
      runners: [
        "init",
        "destroy",
        "contextChange",
        "resolutionChange",
        "reset",
        "update",
        "postrender",
        "prerender",
        "resize",
      ],
      systems: t.__systems,
      priority: [
        "_view",
        "textureGenerator",
        "background",
        "_plugin",
        "startup",
        "context",
        "state",
        "texture",
        "buffer",
        "geometry",
        "framebuffer",
        "transformFeedback",
        "mask",
        "scissor",
        "stencil",
        "projection",
        "textureGC",
        "filter",
        "renderTexture",
        "batch",
        "objectRenderer",
        "_multisample",
      ],
    };
    this.setup(r),
      "useContextAlpha" in e &&
        (W(
          0,
          "options.useContextAlpha is deprecated, use options.premultipliedAlpha and options.backgroundAlpha instead"
        ),
        (e.premultipliedAlpha =
          e.useContextAlpha && "notMultiplied" !== e.useContextAlpha),
        (e.backgroundAlpha = !1 === e.useContextAlpha ? 1 : e.backgroundAlpha)),
      (this._plugin.rendererPlugins = t.__plugins),
      (this.options = e),
      this.startup.run(this.options);
  }
  static test(t) {
    return (
      !(null == t ? void 0 : t.forceCanvas) &&
      (typeof wn > "u" &&
        (wn = (function () {
          var t;
          const e = {
            stencil: !0,
            failIfMajorPerformanceCaveat: _n.FAIL_IF_MAJOR_PERFORMANCE_CAVEAT,
          };
          try {
            if (!_n.ADAPTER.getWebGLRenderingContext()) return !1;
            const r = _n.ADAPTER.createCanvas();
            let i =
              r.getContext("webgl", e) || r.getContext("experimental-webgl", e);
            const s = !!(null ==
            (t = null == i ? void 0 : i.getContextAttributes())
              ? void 0
              : t.stencil);
            if (i) {
              const t = i.getExtension("WEBGL_lose_context");
              t && t.loseContext();
            }
            return (i = null), s;
          } catch {
            return !1;
          }
        })()),
      wn)
    );
  }
  render(t, e) {
    this.objectRenderer.render(t, e);
  }
  resize(t, e) {
    this._view.resizeView(t, e);
  }
  reset() {
    return this.runners.reset.emit(), this;
  }
  clear() {
    this.renderTexture.bind(), this.renderTexture.clear();
  }
  destroy(t = !1) {
    this.runners.destroy.items.reverse(),
      this.emitWithCustomOptions(this.runners.destroy, { _view: t }),
      super.destroy();
  }
  get plugins() {
    return this._plugin.plugins;
  }
  get multisample() {
    return this._multisample.multisample;
  }
  get width() {
    return this._view.element.width;
  }
  get height() {
    return this._view.element.height;
  }
  get resolution() {
    return this._view.resolution;
  }
  set resolution(t) {
    (this._view.resolution = t), this.runners.resolutionChange.emit(t);
  }
  get autoDensity() {
    return this._view.autoDensity;
  }
  get view() {
    return this._view.element;
  }
  get screen() {
    return this._view.screen;
  }
  get lastObjectRendered() {
    return this.objectRenderer.lastObjectRendered;
  }
  get renderingToScreen() {
    return this.objectRenderer.renderingToScreen;
  }
  get rendererLogId() {
    return `WebGL ${this.context.webGLVersion}`;
  }
  get clearBeforeRender() {
    return (
      W(
        0,
        "renderer.clearBeforeRender has been deprecated, please use renderer.background.clearBeforeRender instead."
      ),
      this.background.clearBeforeRender
    );
  }
  get useContextAlpha() {
    return (
      W(
        0,
        "renderer.useContextAlpha has been deprecated, please use renderer.context.premultipliedAlpha instead."
      ),
      this.context.useContextAlpha
    );
  }
  get preserveDrawingBuffer() {
    return (
      W(
        0,
        "renderer.preserveDrawingBuffer has been deprecated, we cannot truly know this unless pixi created the context"
      ),
      this.context.preserveDrawingBuffer
    );
  }
  get backgroundColor() {
    return (
      W(
        0,
        "renderer.backgroundColor has been deprecated, use renderer.background.color instead."
      ),
      this.background.color
    );
  }
  set backgroundColor(t) {
    W(
      0,
      "renderer.backgroundColor has been deprecated, use renderer.background.color instead."
    ),
      (this.background.color = t);
  }
  get backgroundAlpha() {
    return (
      W(
        0,
        "renderer.backgroundAlpha has been deprecated, use renderer.background.alpha instead."
      ),
      this.background.alpha
    );
  }
  set backgroundAlpha(t) {
    W(
      0,
      "renderer.backgroundAlpha has been deprecated, use renderer.background.alpha instead."
    ),
      (this.background.alpha = t);
  }
  get powerPreference() {
    return (
      W(
        0,
        "renderer.powerPreference has been deprecated, we can only know this if pixi creates the context"
      ),
      this.context.powerPreference
    );
  }
  generateTexture(t, e) {
    return this.textureGenerator.generateTexture(t, e);
  }
};
(ph.extension = { type: Gs.Renderer, priority: 1 }),
  (ph.__plugins = {}),
  (ph.__systems = {});
let fh = ph;
kn.handleByMap(Gs.RendererPlugin, fh.__plugins),
  kn.handleByMap(Gs.RendererSystem, fh.__systems),
  kn.add(fh);
class mh extends Vn {
  constructor(t, e) {
    const { width: r, height: i } = e || {};
    super(r, i), (this.items = []), (this.itemDirtyIds = []);
    for (let s = 0; s < t; s++) {
      const t = new Yn();
      this.items.push(t), this.itemDirtyIds.push(-2);
    }
    (this.length = t), (this._load = null), (this.baseTexture = null);
  }
  initFromArray(t, e) {
    for (let r = 0; r < this.length; r++)
      t[r] &&
        (t[r].castToBaseTexture
          ? this.addBaseTextureAt(t[r].castToBaseTexture(), r)
          : t[r] instanceof Vn
          ? this.addResourceAt(t[r], r)
          : this.addResourceAt(ht(t[r], e), r));
  }
  dispose() {
    for (let t = 0, e = this.length; t < e; t++) this.items[t].destroy();
    (this.items = null), (this.itemDirtyIds = null), (this._load = null);
  }
  addResourceAt(t, e) {
    if (!this.items[e]) throw new Error(`Index ${e} is out of bounds`);
    return (
      t.valid && !this.valid && this.resize(t.width, t.height),
      this.items[e].setResource(t),
      this
    );
  }
  bind(t) {
    if (null !== this.baseTexture)
      throw new Error("Only one base texture per TextureArray is allowed");
    super.bind(t);
    for (let e = 0; e < this.length; e++)
      (this.items[e].parentTextureArray = t),
        this.items[e].on("update", t.update, t);
  }
  unbind(t) {
    super.unbind(t);
    for (let e = 0; e < this.length; e++)
      (this.items[e].parentTextureArray = null),
        this.items[e].off("update", t.update, t);
  }
  load() {
    if (this._load) return this._load;
    const t = this.items
      .map((t) => t.resource)
      .filter((t) => t)
      .map((t) => t.load());
    return (
      (this._load = Promise.all(t).then(() => {
        const { realWidth: t, realHeight: e } = this.items[0];
        return this.resize(t, e), this.update(), Promise.resolve(this);
      })),
      this._load
    );
  }
}
const gh = class t extends mh {
  constructor(e, r) {
    const { width: i, height: s, autoLoad: n, linkBaseTexture: o } = r || {};
    if (e && e.length !== t.SIDES)
      throw new Error(`Invalid length. Got ${e.length}, expected 6`);
    super(6, { width: i, height: s });
    for (let a = 0; a < t.SIDES; a++)
      this.items[a].target = sn.TEXTURE_CUBE_MAP_POSITIVE_X + a;
    (this.linkBaseTexture = !1 !== o),
      e && this.initFromArray(e, r),
      !1 !== n && this.load();
  }
  bind(t) {
    super.bind(t), (t.target = sn.TEXTURE_CUBE_MAP);
  }
  addBaseTextureAt(t, e, r) {
    if ((void 0 === r && (r = this.linkBaseTexture), !this.items[e]))
      throw new Error(`Index ${e} is out of bounds`);
    if (
      !this.linkBaseTexture ||
      t.parentTextureArray ||
      Object.keys(t._glTextures).length > 0
    ) {
      if (!t.resource)
        throw new Error(
          "CubeResource does not support copying of renderTexture."
        );
      this.addResourceAt(t.resource, e);
    } else
      (t.target = sn.TEXTURE_CUBE_MAP_POSITIVE_X + e),
        (t.parentTextureArray = this.baseTexture),
        (this.items[e] = t);
    return (
      t.valid && !this.valid && this.resize(t.realWidth, t.realHeight),
      (this.items[e] = t),
      this
    );
  }
  upload(e, r, i) {
    const s = this.itemDirtyIds;
    for (let n = 0; n < t.SIDES; n++) {
      const t = this.items[n];
      (s[n] < t.dirtyId || i.dirtyId < r.dirtyId) &&
        (t.valid && t.resource
          ? (t.resource.upload(e, t, i), (s[n] = t.dirtyId))
          : s[n] < -1 &&
            (e.gl.texImage2D(
              t.target,
              0,
              i.internalFormat,
              r.realWidth,
              r.realHeight,
              0,
              r.format,
              i.type,
              null
            ),
            (s[n] = -1)));
    }
    return !0;
  }
  static test(e) {
    return Array.isArray(e) && e.length === t.SIDES;
  }
};
gh.SIDES = 6;
let _h = gh;
class yh extends sa {
  constructor(t, e) {
    let r, i, s;
    (e = e || {}),
      "string" == typeof t
        ? ((r = yh.EMPTY), (i = t), (s = !0))
        : ((r = t), (i = null), (s = !1)),
      super(r),
      (this.url = i),
      (this.crossOrigin = e.crossOrigin ?? !0),
      (this.alphaMode = "number" == typeof e.alphaMode ? e.alphaMode : null),
      (this.ownsImageBitmap = e.ownsImageBitmap ?? s),
      (this._load = null),
      !1 !== e.autoLoad && this.load();
  }
  load() {
    return (
      this._load ||
        (this._load = new Promise(async (t, e) => {
          if (null !== this.url)
            try {
              const e = await _n.ADAPTER.fetch(this.url, {
                mode: this.crossOrigin ? "cors" : "no-cors",
              });
              if (this.destroyed) return;
              const r = await e.blob();
              if (this.destroyed) return;
              const i = await createImageBitmap(r, {
                premultiplyAlpha:
                  null === this.alphaMode || this.alphaMode === un.UNPACK
                    ? "premultiply"
                    : "none",
              });
              if (this.destroyed) return void i.close();
              (this.source = i), this.update(), t(this);
            } catch (fc) {
              if (this.destroyed) return;
              e(fc), this.onError.emit(fc);
            }
          else t(this);
        })),
      this._load
    );
  }
  upload(t, e, r) {
    return this.source instanceof ImageBitmap
      ? ("number" == typeof this.alphaMode && (e.alphaMode = this.alphaMode),
        super.upload(t, e, r))
      : (this.load(), !1);
  }
  dispose() {
    this.ownsImageBitmap &&
      this.source instanceof ImageBitmap &&
      this.source.close(),
      super.dispose(),
      (this._load = null);
  }
  static test(t) {
    return (
      !!globalThis.createImageBitmap &&
      typeof ImageBitmap < "u" &&
      ("string" == typeof t || t instanceof ImageBitmap)
    );
  }
  static get EMPTY() {
    return (yh._EMPTY = yh._EMPTY ?? _n.ADAPTER.createCanvas(0, 0)), yh._EMPTY;
  }
}
const vh = class t extends sa {
  constructor(t, e) {
    (e = e || {}),
      super(_n.ADAPTER.createCanvas()),
      (this._width = 0),
      (this._height = 0),
      (this.svg = t),
      (this.scale = e.scale || 1),
      (this._overrideWidth = e.width),
      (this._overrideHeight = e.height),
      (this._resolve = null),
      (this._crossorigin = e.crossorigin),
      (this._load = null),
      !1 !== e.autoLoad && this.load();
  }
  load() {
    return (
      this._load ||
        (this._load = new Promise((e) => {
          if (
            ((this._resolve = () => {
              this.update(), e(this);
            }),
            t.SVG_XML.test(this.svg.trim()))
          ) {
            if (!btoa)
              throw new Error(
                "Your browser doesn't support base64 conversions."
              );
            this.svg = `data:image/svg+xml;base64,${btoa(
              unescape(encodeURIComponent(this.svg))
            )}`;
          }
          this._loadSvg();
        })),
      this._load
    );
  }
  _loadSvg() {
    const t = new Image();
    sa.crossOrigin(t, this.svg, this._crossorigin),
      (t.src = this.svg),
      (t.onerror = (e) => {
        this._resolve && ((t.onerror = null), this.onError.emit(e));
      }),
      (t.onload = () => {
        if (!this._resolve) return;
        const e = t.width,
          r = t.height;
        if (!e || !r)
          throw new Error(
            "The SVG image must have width and height defined (in pixels), canvas API needs them."
          );
        let i = e * this.scale,
          s = r * this.scale;
        (this._overrideWidth || this._overrideHeight) &&
          ((i = this._overrideWidth || (this._overrideHeight / r) * e),
          (s = this._overrideHeight || (this._overrideWidth / e) * r)),
          (i = Math.round(i)),
          (s = Math.round(s));
        const n = this.source;
        (n.width = i),
          (n.height = s),
          (n._pixiId = `canvas_${it()}`),
          n.getContext("2d").drawImage(t, 0, 0, e, r, 0, 0, i, s),
          this._resolve(),
          (this._resolve = null);
      });
  }
  static getSize(e) {
    const r = t.SVG_SIZE.exec(e),
      i = {};
    return (
      r &&
        ((i[r[1]] = Math.round(parseFloat(r[3]))),
        (i[r[5]] = Math.round(parseFloat(r[7])))),
      i
    );
  }
  dispose() {
    super.dispose(), (this._resolve = null), (this._crossorigin = null);
  }
  static test(e, r) {
    return (
      "svg" === r ||
      ("string" == typeof e && e.startsWith("data:image/svg+xml")) ||
      ("string" == typeof e && t.SVG_XML.test(e))
    );
  }
};
(vh.SVG_XML = /^(<\?xml[^?]+\?>)?\s*(<!--[^(-->)]*-->)?\s*\<svg/m),
  (vh.SVG_SIZE =
    /<svg[^>]*(?:\s(width|height)=('|")(\d*(?:\.\d+)?)(?:px)?('|"))[^>]*(?:\s(width|height)=('|")(\d*(?:\.\d+)?)(?:px)?('|"))[^>]*>/i);
let xh = vh;
const bh = class t extends sa {
  constructor(e, r) {
    if (((r = r || {}), !(e instanceof HTMLVideoElement))) {
      const i = document.createElement("video");
      !1 !== r.autoLoad && i.setAttribute("preload", "auto"),
        !1 !== r.playsinline &&
          (i.setAttribute("webkit-playsinline", ""),
          i.setAttribute("playsinline", "")),
        !0 === r.muted && (i.setAttribute("muted", ""), (i.muted = !0)),
        !0 === r.loop && i.setAttribute("loop", ""),
        !1 !== r.autoPlay && i.setAttribute("autoplay", ""),
        "string" == typeof e && (e = [e]);
      const s = e[0].src || e[0];
      sa.crossOrigin(i, s, r.crossorigin);
      for (let r = 0; r < e.length; ++r) {
        const s = document.createElement("source");
        let { src: n, mime: o } = e[r];
        if (((n = n || e[r]), n.startsWith("data:")))
          o = n.slice(5, n.indexOf(";"));
        else if (!n.startsWith("blob:")) {
          const e = n.split("?").shift().toLowerCase(),
            r = e.slice(e.lastIndexOf(".") + 1);
          o = o || t.MIME_TYPES[r] || `video/${r}`;
        }
        (s.src = n), o && (s.type = o), i.appendChild(s);
      }
      e = i;
    }
    super(e),
      (this.noSubImage = !0),
      (this._autoUpdate = !0),
      (this._isConnectedToTicker = !1),
      (this._updateFPS = r.updateFPS || 0),
      (this._msToNextUpdate = 0),
      (this.autoPlay = !1 !== r.autoPlay),
      (this._videoFrameRequestCallback =
        this._videoFrameRequestCallback.bind(this)),
      (this._videoFrameRequestCallbackHandle = null),
      (this._load = null),
      (this._resolve = null),
      (this._reject = null),
      (this._onCanPlay = this._onCanPlay.bind(this)),
      (this._onError = this._onError.bind(this)),
      (this._onPlayStart = this._onPlayStart.bind(this)),
      (this._onPlayStop = this._onPlayStop.bind(this)),
      (this._onSeeked = this._onSeeked.bind(this)),
      !1 !== r.autoLoad && this.load();
  }
  update(t = 0) {
    if (!this.destroyed) {
      if (this._updateFPS) {
        const t = nh.shared.elapsedMS * this.source.playbackRate;
        this._msToNextUpdate = Math.floor(this._msToNextUpdate - t);
      }
      (!this._updateFPS || this._msToNextUpdate <= 0) &&
        (super.update(),
        (this._msToNextUpdate = this._updateFPS
          ? Math.floor(1e3 / this._updateFPS)
          : 0));
    }
  }
  _videoFrameRequestCallback() {
    this.update(),
      this.destroyed
        ? (this._videoFrameRequestCallbackHandle = null)
        : (this._videoFrameRequestCallbackHandle =
            this.source.requestVideoFrameCallback(
              this._videoFrameRequestCallback
            ));
  }
  load() {
    if (this._load) return this._load;
    const t = this.source;
    return (
      (t.readyState === t.HAVE_ENOUGH_DATA ||
        t.readyState === t.HAVE_FUTURE_DATA) &&
        t.width &&
        t.height &&
        (t.complete = !0),
      t.addEventListener("play", this._onPlayStart),
      t.addEventListener("pause", this._onPlayStop),
      t.addEventListener("seeked", this._onSeeked),
      this._isSourceReady()
        ? this._onCanPlay()
        : (t.addEventListener("canplay", this._onCanPlay),
          t.addEventListener("canplaythrough", this._onCanPlay),
          t.addEventListener("error", this._onError, !0)),
      (this._load = new Promise((e, r) => {
        this.valid
          ? e(this)
          : ((this._resolve = e), (this._reject = r), t.load());
      })),
      this._load
    );
  }
  _onError(t) {
    this.source.removeEventListener("error", this._onError, !0),
      this.onError.emit(t),
      this._reject &&
        (this._reject(t), (this._reject = null), (this._resolve = null));
  }
  _isSourcePlaying() {
    const t = this.source;
    return !t.paused && !t.ended && this._isSourceReady();
  }
  _isSourceReady() {
    return this.source.readyState > 2;
  }
  _onPlayStart() {
    this.valid || this._onCanPlay(), this._configureAutoUpdate();
  }
  _onPlayStop() {
    this._configureAutoUpdate();
  }
  _onSeeked() {
    this._autoUpdate &&
      !this._isSourcePlaying() &&
      ((this._msToNextUpdate = 0), this.update(), (this._msToNextUpdate = 0));
  }
  _onCanPlay() {
    const t = this.source;
    t.removeEventListener("canplay", this._onCanPlay),
      t.removeEventListener("canplaythrough", this._onCanPlay);
    const e = this.valid;
    (this._msToNextUpdate = 0),
      this.update(),
      (this._msToNextUpdate = 0),
      !e &&
        this._resolve &&
        (this._resolve(this), (this._resolve = null), (this._reject = null)),
      this._isSourcePlaying() ? this._onPlayStart() : this.autoPlay && t.play();
  }
  dispose() {
    this._configureAutoUpdate();
    const t = this.source;
    t &&
      (t.removeEventListener("play", this._onPlayStart),
      t.removeEventListener("pause", this._onPlayStop),
      t.removeEventListener("seeked", this._onSeeked),
      t.removeEventListener("canplay", this._onCanPlay),
      t.removeEventListener("canplaythrough", this._onCanPlay),
      t.removeEventListener("error", this._onError, !0),
      t.pause(),
      (t.src = ""),
      t.load()),
      super.dispose();
  }
  get autoUpdate() {
    return this._autoUpdate;
  }
  set autoUpdate(t) {
    t !== this._autoUpdate &&
      ((this._autoUpdate = t), this._configureAutoUpdate());
  }
  get updateFPS() {
    return this._updateFPS;
  }
  set updateFPS(t) {
    t !== this._updateFPS &&
      ((this._updateFPS = t), this._configureAutoUpdate());
  }
  _configureAutoUpdate() {
    this._autoUpdate && this._isSourcePlaying()
      ? !this._updateFPS && this.source.requestVideoFrameCallback
        ? (this._isConnectedToTicker &&
            (nh.shared.remove(this.update, this),
            (this._isConnectedToTicker = !1),
            (this._msToNextUpdate = 0)),
          null === this._videoFrameRequestCallbackHandle &&
            (this._videoFrameRequestCallbackHandle =
              this.source.requestVideoFrameCallback(
                this._videoFrameRequestCallback
              )))
        : (null !== this._videoFrameRequestCallbackHandle &&
            (this.source.cancelVideoFrameCallback(
              this._videoFrameRequestCallbackHandle
            ),
            (this._videoFrameRequestCallbackHandle = null)),
          this._isConnectedToTicker ||
            (nh.shared.add(this.update, this),
            (this._isConnectedToTicker = !0),
            (this._msToNextUpdate = 0)))
      : (null !== this._videoFrameRequestCallbackHandle &&
          (this.source.cancelVideoFrameCallback(
            this._videoFrameRequestCallbackHandle
          ),
          (this._videoFrameRequestCallbackHandle = null)),
        this._isConnectedToTicker &&
          (nh.shared.remove(this.update, this),
          (this._isConnectedToTicker = !1),
          (this._msToNextUpdate = 0)));
  }
  static test(e, r) {
    return (
      (globalThis.HTMLVideoElement && e instanceof HTMLVideoElement) ||
      t.TYPES.includes(r)
    );
  }
};
(bh.TYPES = ["mp4", "m4v", "webm", "ogg", "ogv", "h264", "avi", "mov"]),
  (bh.MIME_TYPES = {
    ogv: "video/ogg",
    mov: "video/quicktime",
    m4v: "video/mp4",
  });
let Eh = bh;
jn.push(
  yh,
  na,
  class extends sa {
    constructor(t) {
      super(t);
    }
    static test(t) {
      const { OffscreenCanvas: e } = globalThis;
      return (
        !!(e && t instanceof e) ||
        (globalThis.HTMLCanvasElement && t instanceof HTMLCanvasElement)
      );
    }
  },
  Eh,
  xh,
  zn,
  _h,
  class extends mh {
    constructor(t, e) {
      const { width: r, height: i } = e || {};
      let s, n;
      Array.isArray(t) ? ((s = t), (n = t.length)) : (n = t),
        super(n, { width: r, height: i }),
        s && this.initFromArray(s, e);
    }
    addBaseTextureAt(t, e) {
      if (!t.resource)
        throw new Error("ArrayResource does not support RenderTexture");
      return this.addResourceAt(t.resource, e), this;
    }
    bind(t) {
      super.bind(t), (t.target = sn.TEXTURE_2D_ARRAY);
    }
    upload(t, e, r) {
      const { length: i, itemDirtyIds: s, items: n } = this,
        { gl: o } = t;
      r.dirtyId < 0 &&
        o.texImage3D(
          o.TEXTURE_2D_ARRAY,
          0,
          r.internalFormat,
          this._width,
          this._height,
          i,
          0,
          e.format,
          r.type,
          null
        );
      for (let a = 0; a < i; a++) {
        const t = n[a];
        s[a] < t.dirtyId &&
          ((s[a] = t.dirtyId),
          t.valid &&
            o.texSubImage3D(
              o.TEXTURE_2D_ARRAY,
              0,
              0,
              0,
              a,
              t.resource.width,
              t.resource.height,
              1,
              e.format,
              r.type,
              t.resource.source
            ));
      }
      return !0;
    }
  }
);
class Th {
  constructor() {
    (this.minX = 1 / 0),
      (this.minY = 1 / 0),
      (this.maxX = -1 / 0),
      (this.maxY = -1 / 0),
      (this.rect = null),
      (this.updateID = -1);
  }
  isEmpty() {
    return this.minX > this.maxX || this.minY > this.maxY;
  }
  clear() {
    (this.minX = 1 / 0),
      (this.minY = 1 / 0),
      (this.maxX = -1 / 0),
      (this.maxY = -1 / 0);
  }
  getRectangle(t) {
    return this.minX > this.maxX || this.minY > this.maxY
      ? uo.EMPTY
      : (((t = t || new uo(0, 0, 1, 1)).x = this.minX),
        (t.y = this.minY),
        (t.width = this.maxX - this.minX),
        (t.height = this.maxY - this.minY),
        t);
  }
  addPoint(t) {
    (this.minX = Math.min(this.minX, t.x)),
      (this.maxX = Math.max(this.maxX, t.x)),
      (this.minY = Math.min(this.minY, t.y)),
      (this.maxY = Math.max(this.maxY, t.y));
  }
  addPointMatrix(t, e) {
    const { a: r, b: i, c: s, d: n, tx: o, ty: a } = t,
      h = r * e.x + s * e.y + o,
      l = i * e.x + n * e.y + a;
    (this.minX = Math.min(this.minX, h)),
      (this.maxX = Math.max(this.maxX, h)),
      (this.minY = Math.min(this.minY, l)),
      (this.maxY = Math.max(this.maxY, l));
  }
  addQuad(t) {
    let e = this.minX,
      r = this.minY,
      i = this.maxX,
      s = this.maxY,
      n = t[0],
      o = t[1];
    (e = n < e ? n : e),
      (r = o < r ? o : r),
      (i = n > i ? n : i),
      (s = o > s ? o : s),
      (n = t[2]),
      (o = t[3]),
      (e = n < e ? n : e),
      (r = o < r ? o : r),
      (i = n > i ? n : i),
      (s = o > s ? o : s),
      (n = t[4]),
      (o = t[5]),
      (e = n < e ? n : e),
      (r = o < r ? o : r),
      (i = n > i ? n : i),
      (s = o > s ? o : s),
      (n = t[6]),
      (o = t[7]),
      (e = n < e ? n : e),
      (r = o < r ? o : r),
      (i = n > i ? n : i),
      (s = o > s ? o : s),
      (this.minX = e),
      (this.minY = r),
      (this.maxX = i),
      (this.maxY = s);
  }
  addFrame(t, e, r, i, s) {
    this.addFrameMatrix(t.worldTransform, e, r, i, s);
  }
  addFrameMatrix(t, e, r, i, s) {
    const n = t.a,
      o = t.b,
      a = t.c,
      h = t.d,
      l = t.tx,
      u = t.ty;
    let c = this.minX,
      d = this.minY,
      p = this.maxX,
      f = this.maxY,
      m = n * e + a * r + l,
      g = o * e + h * r + u;
    (c = m < c ? m : c),
      (d = g < d ? g : d),
      (p = m > p ? m : p),
      (f = g > f ? g : f),
      (m = n * i + a * r + l),
      (g = o * i + h * r + u),
      (c = m < c ? m : c),
      (d = g < d ? g : d),
      (p = m > p ? m : p),
      (f = g > f ? g : f),
      (m = n * e + a * s + l),
      (g = o * e + h * s + u),
      (c = m < c ? m : c),
      (d = g < d ? g : d),
      (p = m > p ? m : p),
      (f = g > f ? g : f),
      (m = n * i + a * s + l),
      (g = o * i + h * s + u),
      (c = m < c ? m : c),
      (d = g < d ? g : d),
      (p = m > p ? m : p),
      (f = g > f ? g : f),
      (this.minX = c),
      (this.minY = d),
      (this.maxX = p),
      (this.maxY = f);
  }
  addVertexData(t, e, r) {
    let i = this.minX,
      s = this.minY,
      n = this.maxX,
      o = this.maxY;
    for (let a = e; a < r; a += 2) {
      const e = t[a],
        r = t[a + 1];
      (i = e < i ? e : i),
        (s = r < s ? r : s),
        (n = e > n ? e : n),
        (o = r > o ? r : o);
    }
    (this.minX = i), (this.minY = s), (this.maxX = n), (this.maxY = o);
  }
  addVertices(t, e, r, i) {
    this.addVerticesMatrix(t.worldTransform, e, r, i);
  }
  addVerticesMatrix(t, e, r, i, s = 0, n = s) {
    const o = t.a,
      a = t.b,
      h = t.c,
      l = t.d,
      u = t.tx,
      c = t.ty;
    let d = this.minX,
      p = this.minY,
      f = this.maxX,
      m = this.maxY;
    for (let g = r; g < i; g += 2) {
      const t = e[g],
        r = e[g + 1],
        i = o * t + h * r + u,
        _ = l * r + a * t + c;
      (d = Math.min(d, i - s)),
        (f = Math.max(f, i + s)),
        (p = Math.min(p, _ - n)),
        (m = Math.max(m, _ + n));
    }
    (this.minX = d), (this.minY = p), (this.maxX = f), (this.maxY = m);
  }
  addBounds(t) {
    const e = this.minX,
      r = this.minY,
      i = this.maxX,
      s = this.maxY;
    (this.minX = t.minX < e ? t.minX : e),
      (this.minY = t.minY < r ? t.minY : r),
      (this.maxX = t.maxX > i ? t.maxX : i),
      (this.maxY = t.maxY > s ? t.maxY : s);
  }
  addBoundsMask(t, e) {
    const r = t.minX > e.minX ? t.minX : e.minX,
      i = t.minY > e.minY ? t.minY : e.minY,
      s = t.maxX < e.maxX ? t.maxX : e.maxX,
      n = t.maxY < e.maxY ? t.maxY : e.maxY;
    if (r <= s && i <= n) {
      const t = this.minX,
        e = this.minY,
        o = this.maxX,
        a = this.maxY;
      (this.minX = r < t ? r : t),
        (this.minY = i < e ? i : e),
        (this.maxX = s > o ? s : o),
        (this.maxY = n > a ? n : a);
    }
  }
  addBoundsMatrix(t, e) {
    this.addFrameMatrix(e, t.minX, t.minY, t.maxX, t.maxY);
  }
  addBoundsArea(t, e) {
    const r = t.minX > e.x ? t.minX : e.x,
      i = t.minY > e.y ? t.minY : e.y,
      s = t.maxX < e.x + e.width ? t.maxX : e.x + e.width,
      n = t.maxY < e.y + e.height ? t.maxY : e.y + e.height;
    if (r <= s && i <= n) {
      const t = this.minX,
        e = this.minY,
        o = this.maxX,
        a = this.maxY;
      (this.minX = r < t ? r : t),
        (this.minY = i < e ? i : e),
        (this.maxX = s > o ? s : o),
        (this.maxY = n > a ? n : a);
    }
  }
  pad(t = 0, e = t) {
    this.isEmpty() ||
      ((this.minX -= t), (this.maxX += t), (this.minY -= e), (this.maxY += e));
  }
  addFramePad(t, e, r, i, s, n) {
    (t -= s),
      (e -= n),
      (r += s),
      (i += n),
      (this.minX = this.minX < t ? this.minX : t),
      (this.maxX = this.maxX > r ? this.maxX : r),
      (this.minY = this.minY < e ? this.minY : e),
      (this.maxY = this.maxY > i ? this.maxY : i);
  }
}
class Ah extends vn {
  constructor() {
    super(),
      (this.tempDisplayObjectParent = null),
      (this.transform = new Ro()),
      (this.alpha = 1),
      (this.visible = !0),
      (this.renderable = !0),
      (this.cullable = !1),
      (this.cullArea = null),
      (this.parent = null),
      (this.worldAlpha = 1),
      (this._lastSortedIndex = 0),
      (this._zIndex = 0),
      (this.filterArea = null),
      (this.filters = null),
      (this._enabledFilters = null),
      (this._bounds = new Th()),
      (this._localBounds = null),
      (this._boundsID = 0),
      (this._boundsRect = null),
      (this._localBoundsRect = null),
      (this._mask = null),
      (this._maskRefCount = 0),
      (this._destroyed = !1),
      (this.isSprite = !1),
      (this.isMask = !1);
  }
  static mixin(t) {
    const e = Object.keys(t);
    for (let r = 0; r < e.length; ++r) {
      const i = e[r];
      Object.defineProperty(
        Ah.prototype,
        i,
        Object.getOwnPropertyDescriptor(t, i)
      );
    }
  }
  get destroyed() {
    return this._destroyed;
  }
  _recursivePostUpdateTransform() {
    this.parent
      ? (this.parent._recursivePostUpdateTransform(),
        this.transform.updateTransform(this.parent.transform))
      : this.transform.updateTransform(this._tempDisplayObjectParent.transform);
  }
  updateTransform() {
    this._boundsID++,
      this.transform.updateTransform(this.parent.transform),
      (this.worldAlpha = this.alpha * this.parent.worldAlpha);
  }
  getBounds(t, e) {
    return (
      t ||
        (this.parent
          ? (this._recursivePostUpdateTransform(), this.updateTransform())
          : ((this.parent = this._tempDisplayObjectParent),
            this.updateTransform(),
            (this.parent = null))),
      this._bounds.updateID !== this._boundsID &&
        (this.calculateBounds(), (this._bounds.updateID = this._boundsID)),
      e ||
        (this._boundsRect || (this._boundsRect = new uo()),
        (e = this._boundsRect)),
      this._bounds.getRectangle(e)
    );
  }
  getLocalBounds(t) {
    t ||
      (this._localBoundsRect || (this._localBoundsRect = new uo()),
      (t = this._localBoundsRect)),
      this._localBounds || (this._localBounds = new Th());
    const e = this.transform,
      r = this.parent;
    (this.parent = null),
      (this._tempDisplayObjectParent.worldAlpha =
        (null == r ? void 0 : r.worldAlpha) ?? 1),
      (this.transform = this._tempDisplayObjectParent.transform);
    const i = this._bounds,
      s = this._boundsID;
    this._bounds = this._localBounds;
    const n = this.getBounds(!1, t);
    return (
      (this.parent = r),
      (this.transform = e),
      (this._bounds = i),
      (this._bounds.updateID += this._boundsID - s),
      n
    );
  }
  toGlobal(t, e, r = !1) {
    return (
      r ||
        (this._recursivePostUpdateTransform(),
        this.parent
          ? this.displayObjectUpdateTransform()
          : ((this.parent = this._tempDisplayObjectParent),
            this.displayObjectUpdateTransform(),
            (this.parent = null))),
      this.worldTransform.apply(t, e)
    );
  }
  toLocal(t, e, r, i) {
    return (
      e && (t = e.toGlobal(t, r, i)),
      i ||
        (this._recursivePostUpdateTransform(),
        this.parent
          ? this.displayObjectUpdateTransform()
          : ((this.parent = this._tempDisplayObjectParent),
            this.displayObjectUpdateTransform(),
            (this.parent = null))),
      this.worldTransform.applyInverse(t, r)
    );
  }
  setParent(t) {
    if (!t || !t.addChild)
      throw new Error("setParent: Argument must be a Container");
    return t.addChild(this), t;
  }
  removeFromParent() {
    var t;
    null == (t = this.parent) || t.removeChild(this);
  }
  setTransform(t = 0, e = 0, r = 1, i = 1, s = 0, n = 0, o = 0, a = 0, h = 0) {
    return (
      (this.position.x = t),
      (this.position.y = e),
      (this.scale.x = r || 1),
      (this.scale.y = i || 1),
      (this.rotation = s),
      (this.skew.x = n),
      (this.skew.y = o),
      (this.pivot.x = a),
      (this.pivot.y = h),
      this
    );
  }
  destroy(t) {
    this.removeFromParent(),
      (this._destroyed = !0),
      (this.transform = null),
      (this.parent = null),
      (this._bounds = null),
      (this.mask = null),
      (this.cullArea = null),
      (this.filters = null),
      (this.filterArea = null),
      (this.hitArea = null),
      (this.eventMode = "auto"),
      (this.interactiveChildren = !1),
      this.emit("destroyed"),
      this.removeAllListeners();
  }
  get _tempDisplayObjectParent() {
    return (
      null === this.tempDisplayObjectParent &&
        (this.tempDisplayObjectParent = new wh()),
      this.tempDisplayObjectParent
    );
  }
  enableTempParent() {
    const t = this.parent;
    return (this.parent = this._tempDisplayObjectParent), t;
  }
  disableTempParent(t) {
    this.parent = t;
  }
  get x() {
    return this.position.x;
  }
  set x(t) {
    this.transform.position.x = t;
  }
  get y() {
    return this.position.y;
  }
  set y(t) {
    this.transform.position.y = t;
  }
  get worldTransform() {
    return this.transform.worldTransform;
  }
  get localTransform() {
    return this.transform.localTransform;
  }
  get position() {
    return this.transform.position;
  }
  set position(t) {
    this.transform.position.copyFrom(t);
  }
  get scale() {
    return this.transform.scale;
  }
  set scale(t) {
    this.transform.scale.copyFrom(t);
  }
  get pivot() {
    return this.transform.pivot;
  }
  set pivot(t) {
    this.transform.pivot.copyFrom(t);
  }
  get skew() {
    return this.transform.skew;
  }
  set skew(t) {
    this.transform.skew.copyFrom(t);
  }
  get rotation() {
    return this.transform.rotation;
  }
  set rotation(t) {
    this.transform.rotation = t;
  }
  get angle() {
    return this.transform.rotation * oo;
  }
  set angle(t) {
    this.transform.rotation = t * ao;
  }
  get zIndex() {
    return this._zIndex;
  }
  set zIndex(t) {
    (this._zIndex = t), this.parent && (this.parent.sortDirty = !0);
  }
  get worldVisible() {
    let t = this;
    do {
      if (!t.visible) return !1;
      t = t.parent;
    } while (t);
    return !0;
  }
  get mask() {
    return this._mask;
  }
  set mask(t) {
    if (this._mask !== t) {
      if (this._mask) {
        const t = this._mask.isMaskData ? this._mask.maskObject : this._mask;
        t &&
          (t._maskRefCount--,
          0 === t._maskRefCount && ((t.renderable = !0), (t.isMask = !1)));
      }
      if (((this._mask = t), this._mask)) {
        const t = this._mask.isMaskData ? this._mask.maskObject : this._mask;
        t &&
          (0 === t._maskRefCount && ((t.renderable = !1), (t.isMask = !0)),
          t._maskRefCount++);
      }
    }
  }
}
class wh extends Ah {
  constructor() {
    super(...arguments), (this.sortDirty = null);
  }
}
Ah.prototype.displayObjectUpdateTransform = Ah.prototype.updateTransform;
const Sh = new go(),
  Rh = class t extends Ah {
    constructor() {
      super(),
        (this.children = []),
        (this.sortableChildren = t.defaultSortableChildren),
        (this.sortDirty = !1);
    }
    onChildrenChange(t) {}
    addChild(...t) {
      if (t.length > 1) for (let e = 0; e < t.length; e++) this.addChild(t[e]);
      else {
        const e = t[0];
        e.parent && e.parent.removeChild(e),
          (e.parent = this),
          (this.sortDirty = !0),
          (e.transform._parentID = -1),
          this.children.push(e),
          this._boundsID++,
          this.onChildrenChange(this.children.length - 1),
          this.emit("childAdded", e, this, this.children.length - 1),
          e.emit("added", this);
      }
      return t[0];
    }
    addChildAt(t, e) {
      if (e < 0 || e > this.children.length)
        throw new Error(
          `${t}addChildAt: The index ${e} supplied is out of bounds ${this.children.length}`
        );
      return (
        t.parent && t.parent.removeChild(t),
        (t.parent = this),
        (this.sortDirty = !0),
        (t.transform._parentID = -1),
        this.children.splice(e, 0, t),
        this._boundsID++,
        this.onChildrenChange(e),
        t.emit("added", this),
        this.emit("childAdded", t, this, e),
        t
      );
    }
    swapChildren(t, e) {
      if (t === e) return;
      const r = this.getChildIndex(t),
        i = this.getChildIndex(e);
      (this.children[r] = e),
        (this.children[i] = t),
        this.onChildrenChange(r < i ? r : i);
    }
    getChildIndex(t) {
      const e = this.children.indexOf(t);
      if (-1 === e)
        throw new Error(
          "The supplied DisplayObject must be a child of the caller"
        );
      return e;
    }
    setChildIndex(t, e) {
      if (e < 0 || e >= this.children.length)
        throw new Error(
          `The index ${e} supplied is out of bounds ${this.children.length}`
        );
      const r = this.getChildIndex(t);
      et(this.children, r, 1),
        this.children.splice(e, 0, t),
        this.onChildrenChange(e);
    }
    getChildAt(t) {
      if (t < 0 || t >= this.children.length)
        throw new Error(`getChildAt: Index (${t}) does not exist.`);
      return this.children[t];
    }
    removeChild(...t) {
      if (t.length > 1)
        for (let e = 0; e < t.length; e++) this.removeChild(t[e]);
      else {
        const e = t[0],
          r = this.children.indexOf(e);
        if (-1 === r) return null;
        (e.parent = null),
          (e.transform._parentID = -1),
          et(this.children, r, 1),
          this._boundsID++,
          this.onChildrenChange(r),
          e.emit("removed", this),
          this.emit("childRemoved", e, this, r);
      }
      return t[0];
    }
    removeChildAt(t) {
      const e = this.getChildAt(t);
      return (
        (e.parent = null),
        (e.transform._parentID = -1),
        et(this.children, t, 1),
        this._boundsID++,
        this.onChildrenChange(t),
        e.emit("removed", this),
        this.emit("childRemoved", e, this, t),
        e
      );
    }
    removeChildren(t = 0, e = this.children.length) {
      const r = t,
        i = e - r;
      let s;
      if (i > 0 && i <= e) {
        s = this.children.splice(r, i);
        for (let t = 0; t < s.length; ++t)
          (s[t].parent = null),
            s[t].transform && (s[t].transform._parentID = -1);
        this._boundsID++, this.onChildrenChange(t);
        for (let t = 0; t < s.length; ++t)
          s[t].emit("removed", this), this.emit("childRemoved", s[t], this, t);
        return s;
      }
      if (0 === i && 0 === this.children.length) return [];
      throw new RangeError(
        "removeChildren: numeric values are outside the acceptable range."
      );
    }
    sortChildren() {
      let t = !1;
      for (let e = 0, r = this.children.length; e < r; ++e) {
        const r = this.children[e];
        (r._lastSortedIndex = e), !t && 0 !== r.zIndex && (t = !0);
      }
      t && this.children.length > 1 && this.children.sort(yt),
        (this.sortDirty = !1);
    }
    updateTransform() {
      this.sortableChildren && this.sortDirty && this.sortChildren(),
        this._boundsID++,
        this.transform.updateTransform(this.parent.transform),
        (this.worldAlpha = this.alpha * this.parent.worldAlpha);
      for (let t = 0, e = this.children.length; t < e; ++t) {
        const e = this.children[t];
        e.visible && e.updateTransform();
      }
    }
    calculateBounds() {
      this._bounds.clear(), this._calculateBounds();
      for (let t = 0; t < this.children.length; t++) {
        const e = this.children[t];
        if (e.visible && e.renderable)
          if ((e.calculateBounds(), e._mask)) {
            const t = e._mask.isMaskData ? e._mask.maskObject : e._mask;
            t
              ? (t.calculateBounds(),
                this._bounds.addBoundsMask(e._bounds, t._bounds))
              : this._bounds.addBounds(e._bounds);
          } else
            e.filterArea
              ? this._bounds.addBoundsArea(e._bounds, e.filterArea)
              : this._bounds.addBounds(e._bounds);
      }
      this._bounds.updateID = this._boundsID;
    }
    getLocalBounds(t, e = !1) {
      const r = super.getLocalBounds(t);
      if (!e)
        for (let i = 0, s = this.children.length; i < s; ++i) {
          const t = this.children[i];
          t.visible && t.updateTransform();
        }
      return r;
    }
    _calculateBounds() {}
    _renderWithCulling(e) {
      const r = e.renderTexture.sourceFrame;
      if (!(r.width > 0 && r.height > 0)) return;
      let i, s;
      this.cullArea
        ? ((i = this.cullArea), (s = this.worldTransform))
        : this._render !== t.prototype._render && (i = this.getBounds(!0));
      const n = e.projection.transform;
      if (
        (n && (s ? ((s = Sh.copyFrom(s)), s.prepend(n)) : (s = n)),
        i && r.intersects(i, s))
      )
        this._render(e);
      else if (this.cullArea) return;
      for (let t = 0, o = this.children.length; t < o; ++t) {
        const r = this.children[t],
          i = r.cullable;
        (r.cullable = i || !this.cullArea), r.render(e), (r.cullable = i);
      }
    }
    render(t) {
      var e;
      if (this.visible && !(this.worldAlpha <= 0) && this.renderable)
        if (this._mask || (null == (e = this.filters) ? void 0 : e.length))
          this.renderAdvanced(t);
        else if (this.cullable) this._renderWithCulling(t);
        else {
          this._render(t);
          for (let e = 0, r = this.children.length; e < r; ++e)
            this.children[e].render(t);
        }
    }
    renderAdvanced(t) {
      var e, r, i;
      const s = this.filters,
        n = this._mask;
      if (s) {
        this._enabledFilters || (this._enabledFilters = []),
          (this._enabledFilters.length = 0);
        for (let t = 0; t < s.length; t++)
          s[t].enabled && this._enabledFilters.push(s[t]);
      }
      const o =
        (s && (null == (e = this._enabledFilters) ? void 0 : e.length)) ||
        (n &&
          (!n.isMaskData ||
            (n.enabled && (n.autoDetect || n.type !== fn.NONE))));
      if (
        (o && t.batch.flush(),
        s &&
          (null == (r = this._enabledFilters) ? void 0 : r.length) &&
          t.filter.push(this, this._enabledFilters),
        n && t.mask.push(this, this._mask),
        this.cullable)
      )
        this._renderWithCulling(t);
      else {
        this._render(t);
        for (let e = 0, r = this.children.length; e < r; ++e)
          this.children[e].render(t);
      }
      o && t.batch.flush(),
        n && t.mask.pop(this),
        s &&
          (null == (i = this._enabledFilters) ? void 0 : i.length) &&
          t.filter.pop();
    }
    _render(t) {}
    destroy(t) {
      super.destroy(), (this.sortDirty = !1);
      const e = "boolean" == typeof t ? t : null == t ? void 0 : t.children,
        r = this.removeChildren(0, this.children.length);
      if (e) for (let i = 0; i < r.length; ++i) r[i].destroy(t);
    }
    get width() {
      return this.scale.x * this.getLocalBounds().width;
    }
    set width(t) {
      const e = this.getLocalBounds().width;
      (this.scale.x = 0 !== e ? t / e : 1), (this._width = t);
    }
    get height() {
      return this.scale.y * this.getLocalBounds().height;
    }
    set height(t) {
      const e = this.getLocalBounds().height;
      (this.scale.y = 0 !== e ? t / e : 1), (this._height = t);
    }
  };
Rh.defaultSortableChildren = !1;
let Ih = Rh;
(Ih.prototype.containerUpdateTransform = Ih.prototype.updateTransform),
  Object.defineProperties(_n, {
    SORTABLE_CHILDREN: {
      get: () => Ih.defaultSortableChildren,
      set(t) {
        W(
          0,
          "settings.SORTABLE_CHILDREN is deprecated, use Container.defaultSortableChildren"
        ),
          (Ih.defaultSortableChildren = t);
      },
    },
  });
const Ch = new ho(),
  Ph = new Uint16Array([0, 1, 2, 0, 2, 3]);
class Mh extends Ih {
  constructor(t) {
    super(),
      (this._anchor = new wo(
        this._onAnchorUpdate,
        this,
        t ? t.defaultAnchor.x : 0,
        t ? t.defaultAnchor.y : 0
      )),
      (this._texture = null),
      (this._width = 0),
      (this._height = 0),
      (this._tintColor = new Rn(16777215)),
      (this._tintRGB = null),
      (this.tint = 16777215),
      (this.blendMode = tn.NORMAL),
      (this._cachedTint = 16777215),
      (this.uvs = null),
      (this.texture = t || ha.EMPTY),
      (this.vertexData = new Float32Array(8)),
      (this.vertexTrimmedData = null),
      (this._transformID = -1),
      (this._textureID = -1),
      (this._transformTrimmedID = -1),
      (this._textureTrimmedID = -1),
      (this.indices = Ph),
      (this.pluginName = "batch"),
      (this.isSprite = !0),
      (this._roundPixels = _n.ROUND_PIXELS);
  }
  _onTextureUpdate() {
    (this._textureID = -1),
      (this._textureTrimmedID = -1),
      (this._cachedTint = 16777215),
      this._width &&
        (this.scale.x =
          (rt(this.scale.x) * this._width) / this._texture.orig.width),
      this._height &&
        (this.scale.y =
          (rt(this.scale.y) * this._height) / this._texture.orig.height);
  }
  _onAnchorUpdate() {
    (this._transformID = -1), (this._transformTrimmedID = -1);
  }
  calculateVertices() {
    const t = this._texture;
    if (
      this._transformID === this.transform._worldID &&
      this._textureID === t._updateID
    )
      return;
    this._textureID !== t._updateID &&
      (this.uvs = this._texture._uvs.uvsFloat32),
      (this._transformID = this.transform._worldID),
      (this._textureID = t._updateID);
    const e = this.transform.worldTransform,
      r = e.a,
      i = e.b,
      s = e.c,
      n = e.d,
      o = e.tx,
      a = e.ty,
      h = this.vertexData,
      l = t.trim,
      u = t.orig,
      c = this._anchor;
    let d = 0,
      p = 0,
      f = 0,
      m = 0;
    if (
      (l
        ? ((p = l.x - c._x * u.width),
          (d = p + l.width),
          (m = l.y - c._y * u.height),
          (f = m + l.height))
        : ((p = -c._x * u.width),
          (d = p + u.width),
          (m = -c._y * u.height),
          (f = m + u.height)),
      (h[0] = r * p + s * m + o),
      (h[1] = n * m + i * p + a),
      (h[2] = r * d + s * m + o),
      (h[3] = n * m + i * d + a),
      (h[4] = r * d + s * f + o),
      (h[5] = n * f + i * d + a),
      (h[6] = r * p + s * f + o),
      (h[7] = n * f + i * p + a),
      this._roundPixels)
    ) {
      const t = _n.RESOLUTION;
      for (let e = 0; e < h.length; ++e) h[e] = Math.round(h[e] * t) / t;
    }
  }
  calculateTrimmedVertices() {
    if (this.vertexTrimmedData) {
      if (
        this._transformTrimmedID === this.transform._worldID &&
        this._textureTrimmedID === this._texture._updateID
      )
        return;
    } else this.vertexTrimmedData = new Float32Array(8);
    (this._transformTrimmedID = this.transform._worldID),
      (this._textureTrimmedID = this._texture._updateID);
    const t = this._texture,
      e = this.vertexTrimmedData,
      r = t.orig,
      i = this._anchor,
      s = this.transform.worldTransform,
      n = s.a,
      o = s.b,
      a = s.c,
      h = s.d,
      l = s.tx,
      u = s.ty,
      c = -i._x * r.width,
      d = c + r.width,
      p = -i._y * r.height,
      f = p + r.height;
    if (
      ((e[0] = n * c + a * p + l),
      (e[1] = h * p + o * c + u),
      (e[2] = n * d + a * p + l),
      (e[3] = h * p + o * d + u),
      (e[4] = n * d + a * f + l),
      (e[5] = h * f + o * d + u),
      (e[6] = n * c + a * f + l),
      (e[7] = h * f + o * c + u),
      this._roundPixels)
    ) {
      const t = _n.RESOLUTION;
      for (let r = 0; r < e.length; ++r) e[r] = Math.round(e[r] * t) / t;
    }
  }
  _render(t) {
    this.calculateVertices(),
      t.batch.setObjectRenderer(t.plugins[this.pluginName]),
      t.plugins[this.pluginName].render(this);
  }
  _calculateBounds() {
    const t = this._texture.trim,
      e = this._texture.orig;
    !t || (t.width === e.width && t.height === e.height)
      ? (this.calculateVertices(), this._bounds.addQuad(this.vertexData))
      : (this.calculateTrimmedVertices(),
        this._bounds.addQuad(this.vertexTrimmedData));
  }
  getLocalBounds(t) {
    return 0 === this.children.length
      ? (this._localBounds || (this._localBounds = new Th()),
        (this._localBounds.minX = this._texture.orig.width * -this._anchor._x),
        (this._localBounds.minY = this._texture.orig.height * -this._anchor._y),
        (this._localBounds.maxX =
          this._texture.orig.width * (1 - this._anchor._x)),
        (this._localBounds.maxY =
          this._texture.orig.height * (1 - this._anchor._y)),
        t ||
          (this._localBoundsRect || (this._localBoundsRect = new uo()),
          (t = this._localBoundsRect)),
        this._localBounds.getRectangle(t))
      : super.getLocalBounds.call(this, t);
  }
  containsPoint(t) {
    this.worldTransform.applyInverse(t, Ch);
    const e = this._texture.orig.width,
      r = this._texture.orig.height,
      i = -e * this.anchor.x;
    let s = 0;
    return (
      Ch.x >= i &&
      Ch.x < i + e &&
      ((s = -r * this.anchor.y), Ch.y >= s && Ch.y < s + r)
    );
  }
  destroy(t) {
    if (
      (super.destroy(t),
      this._texture.off("update", this._onTextureUpdate, this),
      (this._anchor = null),
      "boolean" == typeof t ? t : null == t ? void 0 : t.texture)
    ) {
      const e = "boolean" == typeof t ? t : null == t ? void 0 : t.baseTexture;
      this._texture.destroy(!!e);
    }
    this._texture = null;
  }
  static from(t, e) {
    const r = t instanceof ha ? t : ha.from(t, e);
    return new Mh(r);
  }
  set roundPixels(t) {
    this._roundPixels !== t &&
      ((this._transformID = -1), (this._transformTrimmedID = -1)),
      (this._roundPixels = t);
  }
  get roundPixels() {
    return this._roundPixels;
  }
  get width() {
    return Math.abs(this.scale.x) * this._texture.orig.width;
  }
  set width(t) {
    const e = rt(this.scale.x) || 1;
    (this.scale.x = (e * t) / this._texture.orig.width), (this._width = t);
  }
  get height() {
    return Math.abs(this.scale.y) * this._texture.orig.height;
  }
  set height(t) {
    const e = rt(this.scale.y) || 1;
    (this.scale.y = (e * t) / this._texture.orig.height), (this._height = t);
  }
  get anchor() {
    return this._anchor;
  }
  set anchor(t) {
    this._anchor.copyFrom(t);
  }
  get tint() {
    return this._tintColor.value;
  }
  set tint(t) {
    this._tintColor.setValue(t),
      (this._tintRGB = this._tintColor.toLittleEndianNumber());
  }
  get tintValue() {
    return this._tintColor.toNumber();
  }
  get texture() {
    return this._texture;
  }
  set texture(t) {
    this._texture !== t &&
      (this._texture &&
        this._texture.off("update", this._onTextureUpdate, this),
      (this._texture = t || ha.EMPTY),
      (this._cachedTint = 16777215),
      (this._textureID = -1),
      (this._textureTrimmedID = -1),
      t &&
        (t.baseTexture.valid
          ? this._onTextureUpdate()
          : t.once("update", this._onTextureUpdate, this)));
  }
}
const Dh = new go();
(Ah.prototype._cacheAsBitmap = !1),
  (Ah.prototype._cacheData = null),
  (Ah.prototype._cacheAsBitmapResolution = null),
  (Ah.prototype._cacheAsBitmapMultisample = null);
class Oh {
  constructor() {
    (this.textureCacheId = null),
      (this.originalRender = null),
      (this.originalRenderCanvas = null),
      (this.originalCalculateBounds = null),
      (this.originalGetLocalBounds = null),
      (this.originalUpdateTransform = null),
      (this.originalDestroy = null),
      (this.originalMask = null),
      (this.originalFilterArea = null),
      (this.originalContainsPoint = null),
      (this.sprite = null);
  }
}
Object.defineProperties(Ah.prototype, {
  cacheAsBitmapResolution: {
    get() {
      return this._cacheAsBitmapResolution;
    },
    set(t) {
      t !== this._cacheAsBitmapResolution &&
        ((this._cacheAsBitmapResolution = t),
        this.cacheAsBitmap &&
          ((this.cacheAsBitmap = !1), (this.cacheAsBitmap = !0)));
    },
  },
  cacheAsBitmapMultisample: {
    get() {
      return this._cacheAsBitmapMultisample;
    },
    set(t) {
      t !== this._cacheAsBitmapMultisample &&
        ((this._cacheAsBitmapMultisample = t),
        this.cacheAsBitmap &&
          ((this.cacheAsBitmap = !1), (this.cacheAsBitmap = !0)));
    },
  },
  cacheAsBitmap: {
    get() {
      return this._cacheAsBitmap;
    },
    set(t) {
      if (this._cacheAsBitmap === t) return;
      let e;
      (this._cacheAsBitmap = t),
        t
          ? (this._cacheData || (this._cacheData = new Oh()),
            (e = this._cacheData),
            (e.originalRender = this.render),
            (e.originalRenderCanvas = this.renderCanvas),
            (e.originalUpdateTransform = this.updateTransform),
            (e.originalCalculateBounds = this.calculateBounds),
            (e.originalGetLocalBounds = this.getLocalBounds),
            (e.originalDestroy = this.destroy),
            (e.originalContainsPoint = this.containsPoint),
            (e.originalMask = this._mask),
            (e.originalFilterArea = this.filterArea),
            (this.render = this._renderCached),
            (this.renderCanvas = this._renderCachedCanvas),
            (this.destroy = this._cacheAsBitmapDestroy))
          : ((e = this._cacheData),
            e.sprite && this._destroyCachedDisplayObject(),
            (this.render = e.originalRender),
            (this.renderCanvas = e.originalRenderCanvas),
            (this.calculateBounds = e.originalCalculateBounds),
            (this.getLocalBounds = e.originalGetLocalBounds),
            (this.destroy = e.originalDestroy),
            (this.updateTransform = e.originalUpdateTransform),
            (this.containsPoint = e.originalContainsPoint),
            (this._mask = e.originalMask),
            (this.filterArea = e.originalFilterArea));
    },
  },
}),
  (Ah.prototype._renderCached = function (t) {
    !this.visible ||
      this.worldAlpha <= 0 ||
      !this.renderable ||
      (this._initCachedDisplayObject(t),
      (this._cacheData.sprite.transform._worldID = this.transform._worldID),
      (this._cacheData.sprite.worldAlpha = this.worldAlpha),
      this._cacheData.sprite._render(t));
  }),
  (Ah.prototype._initCachedDisplayObject = function (t) {
    var e, r;
    if (null == (e = this._cacheData) ? void 0 : e.sprite) return;
    const i = this.alpha;
    (this.alpha = 1), t.batch.flush();
    const s = this.getLocalBounds(new uo(), !0);
    if (null == (r = this.filters) ? void 0 : r.length) {
      const t = this.filters[0].padding;
      s.pad(t);
    }
    const n = this.cacheAsBitmapResolution || t.resolution;
    s.ceil(n),
      (s.width = Math.max(s.width, 1 / n)),
      (s.height = Math.max(s.height, 1 / n));
    const o = t.renderTexture.current,
      a = t.renderTexture.sourceFrame.clone(),
      h = t.renderTexture.destinationFrame.clone(),
      l = t.projection.transform,
      u = la.create({
        width: s.width,
        height: s.height,
        resolution: n,
        multisample: this.cacheAsBitmapMultisample ?? t.multisample,
      }),
      c = `cacheAsBitmap_${it()}`;
    (this._cacheData.textureCacheId = c),
      Yn.addToCache(u.baseTexture, c),
      ha.addToCache(u, c);
    const d = this.transform.localTransform
      .copyTo(Dh)
      .invert()
      .translate(-s.x, -s.y);
    (this.render = this._cacheData.originalRender),
      t.render(this, {
        renderTexture: u,
        clear: !0,
        transform: d,
        skipUpdateTransform: !1,
      }),
      t.framebuffer.blit(),
      (t.projection.transform = l),
      t.renderTexture.bind(o, a, h),
      (this.render = this._renderCached),
      (this.updateTransform = this.displayObjectUpdateTransform),
      (this.calculateBounds = this._calculateCachedBounds),
      (this.getLocalBounds = this._getCachedLocalBounds),
      (this._mask = null),
      (this.filterArea = null),
      (this.alpha = i);
    const p = new Mh(u);
    (p.transform.worldTransform = this.transform.worldTransform),
      (p.anchor.x = -s.x / s.width),
      (p.anchor.y = -s.y / s.height),
      (p.alpha = i),
      (p._bounds = this._bounds),
      (this._cacheData.sprite = p),
      (this.transform._parentID = -1),
      this.parent
        ? this.updateTransform()
        : (this.enableTempParent(),
          this.updateTransform(),
          this.disableTempParent(null)),
      (this.containsPoint = p.containsPoint.bind(p));
  }),
  (Ah.prototype._renderCachedCanvas = function (t) {
    !this.visible ||
      this.worldAlpha <= 0 ||
      !this.renderable ||
      (this._initCachedDisplayObjectCanvas(t),
      (this._cacheData.sprite.worldAlpha = this.worldAlpha),
      this._cacheData.sprite._renderCanvas(t));
  }),
  (Ah.prototype._initCachedDisplayObjectCanvas = function (t) {
    var e;
    if (null == (e = this._cacheData) ? void 0 : e.sprite) return;
    const r = this.getLocalBounds(new uo(), !0),
      i = this.alpha;
    this.alpha = 1;
    const s = t.canvasContext.activeContext,
      n = t._projTransform,
      o = this.cacheAsBitmapResolution || t.resolution;
    r.ceil(o),
      (r.width = Math.max(r.width, 1 / o)),
      (r.height = Math.max(r.height, 1 / o));
    const a = la.create({ width: r.width, height: r.height, resolution: o }),
      h = `cacheAsBitmap_${it()}`;
    (this._cacheData.textureCacheId = h),
      Yn.addToCache(a.baseTexture, h),
      ha.addToCache(a, h);
    const l = Dh;
    this.transform.localTransform.copyTo(l),
      l.invert(),
      (l.tx -= r.x),
      (l.ty -= r.y),
      (this.renderCanvas = this._cacheData.originalRenderCanvas),
      t.render(this, {
        renderTexture: a,
        clear: !0,
        transform: l,
        skipUpdateTransform: !1,
      }),
      (t.canvasContext.activeContext = s),
      (t._projTransform = n),
      (this.renderCanvas = this._renderCachedCanvas),
      (this.updateTransform = this.displayObjectUpdateTransform),
      (this.calculateBounds = this._calculateCachedBounds),
      (this.getLocalBounds = this._getCachedLocalBounds),
      (this._mask = null),
      (this.filterArea = null),
      (this.alpha = i);
    const u = new Mh(a);
    (u.transform.worldTransform = this.transform.worldTransform),
      (u.anchor.x = -r.x / r.width),
      (u.anchor.y = -r.y / r.height),
      (u.alpha = i),
      (u._bounds = this._bounds),
      (this._cacheData.sprite = u),
      (this.transform._parentID = -1),
      this.parent
        ? this.updateTransform()
        : ((this.parent = t._tempDisplayObjectParent),
          this.updateTransform(),
          (this.parent = null)),
      (this.containsPoint = u.containsPoint.bind(u));
  }),
  (Ah.prototype._calculateCachedBounds = function () {
    this._bounds.clear(),
      (this._cacheData.sprite.transform._worldID = this.transform._worldID),
      this._cacheData.sprite._calculateBounds(),
      (this._bounds.updateID = this._boundsID);
  }),
  (Ah.prototype._getCachedLocalBounds = function () {
    return this._cacheData.sprite.getLocalBounds(null);
  }),
  (Ah.prototype._destroyCachedDisplayObject = function () {
    this._cacheData.sprite._texture.destroy(!0),
      (this._cacheData.sprite = null),
      Yn.removeFromCache(this._cacheData.textureCacheId),
      ha.removeFromCache(this._cacheData.textureCacheId),
      (this._cacheData.textureCacheId = null);
  }),
  (Ah.prototype._cacheAsBitmapDestroy = function (t) {
    (this.cacheAsBitmap = !1), this.destroy(t);
  }),
  (Ah.prototype.name = null),
  (Ih.prototype.getChildByName = function (t, e) {
    for (let r = 0, i = this.children.length; r < i; r++)
      if (this.children[r].name === t) return this.children[r];
    if (e)
      for (let r = 0, i = this.children.length; r < i; r++) {
        const e = this.children[r];
        if (!e.getChildByName) continue;
        const i = e.getChildByName(t, !0);
        if (i) return i;
      }
    return null;
  }),
  (Ah.prototype.getGlobalPosition = function (t = new ho(), e = !1) {
    return (
      this.parent
        ? this.parent.toGlobal(this.position, t, e)
        : ((t.x = this.position.x), (t.y = this.position.y)),
      t
    );
  });
const Bh = {
    5: [0.153388, 0.221461, 0.250301],
    7: [0.071303, 0.131514, 0.189879, 0.214607],
    9: [0.028532, 0.067234, 0.124009, 0.179044, 0.20236],
    11: [0.0093, 0.028002, 0.065984, 0.121703, 0.175713, 0.198596],
    13: [0.002406, 0.009255, 0.027867, 0.065666, 0.121117, 0.174868, 0.197641],
    15: [
      489e-6, 0.002403, 0.009246, 0.02784, 0.065602, 0.120999, 0.174697,
      0.197448,
    ],
  },
  Nh = [
    "varying vec2 vBlurTexCoords[%size%];",
    "uniform sampler2D uSampler;",
    "void main(void)",
    "{",
    "    gl_FragColor = vec4(0.0);",
    "    %blur%",
    "}",
  ].join("\n");
class Fh extends Zo {
  constructor(t, e = 8, r = 4, i = Zo.defaultResolution, s = 5) {
    const n = (function (t, e) {
        const r = Math.ceil(t / 2);
        let i,
          s =
            "\n    attribute vec2 aVertexPosition;\n\n    uniform mat3 projectionMatrix;\n\n    uniform float strength;\n\n    varying vec2 vBlurTexCoords[%size%];\n\n    uniform vec4 inputSize;\n    uniform vec4 outputFrame;\n\n    vec4 filterVertexPosition( void )\n    {\n        vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n        return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n    }\n\n    vec2 filterTextureCoord( void )\n    {\n        return aVertexPosition * (outputFrame.zw * inputSize.zw);\n    }\n\n    void main(void)\n    {\n        gl_Position = filterVertexPosition();\n\n        vec2 textureCoord = filterTextureCoord();\n        %blur%\n    }",
          n = "";
        i = e
          ? "vBlurTexCoords[%index%] =  textureCoord + vec2(%sampleIndex% * strength, 0.0);"
          : "vBlurTexCoords[%index%] =  textureCoord + vec2(0.0, %sampleIndex% * strength);";
        for (let o = 0; o < t; o++) {
          let t = i.replace("%index%", o.toString());
          (t = t.replace("%sampleIndex%", o - (r - 1) + ".0")),
            (n += t),
            (n += "\n");
        }
        return (
          (s = s.replace("%blur%", n)),
          (s = s.replace("%size%", t.toString())),
          s
        );
      })(s, t),
      o = (function (t) {
        const e = Bh[t],
          r = e.length;
        let i,
          s = Nh,
          n = "";
        for (let o = 0; o < t; o++) {
          let s =
            "gl_FragColor += texture2D(uSampler, vBlurTexCoords[%index%]) * %value%;".replace(
              "%index%",
              o.toString()
            );
          (i = o),
            o >= r && (i = t - o - 1),
            (s = s.replace("%value%", e[i].toString())),
            (n += s),
            (n += "\n");
        }
        return (
          (s = s.replace("%blur%", n)),
          (s = s.replace("%size%", t.toString())),
          s
        );
      })(s);
    super(n, o),
      (this.horizontal = t),
      (this.resolution = i),
      (this._quality = 0),
      (this.quality = r),
      (this.blur = e);
  }
  apply(t, e, r, i) {
    if (
      (r
        ? this.horizontal
          ? (this.uniforms.strength = (1 / r.width) * (r.width / e.width))
          : (this.uniforms.strength = (1 / r.height) * (r.height / e.height))
        : this.horizontal
        ? (this.uniforms.strength =
            (1 / t.renderer.width) * (t.renderer.width / e.width))
        : (this.uniforms.strength =
            (1 / t.renderer.height) * (t.renderer.height / e.height)),
      (this.uniforms.strength *= this.strength),
      (this.uniforms.strength /= this.passes),
      1 === this.passes)
    )
      t.applyFilter(this, e, r, i);
    else {
      const s = t.getFilterTexture(),
        n = t.renderer;
      let o = e,
        a = s;
      (this.state.blend = !1), t.applyFilter(this, o, a, cn.CLEAR);
      for (let e = 1; e < this.passes - 1; e++) {
        t.bindAndClear(o, cn.BLIT), (this.uniforms.uSampler = a);
        const e = a;
        (a = o), (o = e), n.shader.bind(this), n.geometry.draw(5);
      }
      (this.state.blend = !0),
        t.applyFilter(this, a, r, i),
        t.returnFilterTexture(s);
    }
  }
  get blur() {
    return this.strength;
  }
  set blur(t) {
    (this.padding = 1 + 2 * Math.abs(t)), (this.strength = t);
  }
  get quality() {
    return this._quality;
  }
  set quality(t) {
    (this._quality = t), (this.passes = t);
  }
}
class Lh extends Zo {
  constructor() {
    const t = {
      m: new Float32Array([
        1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0,
      ]),
      uAlpha: 1,
    };
    super(
      hh,
      "varying vec2 vTextureCoord;\nuniform sampler2D uSampler;\nuniform float m[20];\nuniform float uAlpha;\n\nvoid main(void)\n{\n    vec4 c = texture2D(uSampler, vTextureCoord);\n\n    if (uAlpha == 0.0) {\n        gl_FragColor = c;\n        return;\n    }\n\n    // Un-premultiply alpha before applying the color matrix. See issue #3539.\n    if (c.a > 0.0) {\n      c.rgb /= c.a;\n    }\n\n    vec4 result;\n\n    result.r = (m[0] * c.r);\n        result.r += (m[1] * c.g);\n        result.r += (m[2] * c.b);\n        result.r += (m[3] * c.a);\n        result.r += m[4];\n\n    result.g = (m[5] * c.r);\n        result.g += (m[6] * c.g);\n        result.g += (m[7] * c.b);\n        result.g += (m[8] * c.a);\n        result.g += m[9];\n\n    result.b = (m[10] * c.r);\n       result.b += (m[11] * c.g);\n       result.b += (m[12] * c.b);\n       result.b += (m[13] * c.a);\n       result.b += m[14];\n\n    result.a = (m[15] * c.r);\n       result.a += (m[16] * c.g);\n       result.a += (m[17] * c.b);\n       result.a += (m[18] * c.a);\n       result.a += m[19];\n\n    vec3 rgb = mix(c.rgb, result.rgb, uAlpha);\n\n    // Premultiply alpha again.\n    rgb *= result.a;\n\n    gl_FragColor = vec4(rgb, result.a);\n}\n",
      t
    ),
      (this.alpha = 1);
  }
  _loadMatrix(t, e = !1) {
    let r = t;
    e && (this._multiply(r, this.uniforms.m, t), (r = this._colorMatrix(r))),
      (this.uniforms.m = r);
  }
  _multiply(t, e, r) {
    return (
      (t[0] = e[0] * r[0] + e[1] * r[5] + e[2] * r[10] + e[3] * r[15]),
      (t[1] = e[0] * r[1] + e[1] * r[6] + e[2] * r[11] + e[3] * r[16]),
      (t[2] = e[0] * r[2] + e[1] * r[7] + e[2] * r[12] + e[3] * r[17]),
      (t[3] = e[0] * r[3] + e[1] * r[8] + e[2] * r[13] + e[3] * r[18]),
      (t[4] = e[0] * r[4] + e[1] * r[9] + e[2] * r[14] + e[3] * r[19] + e[4]),
      (t[5] = e[5] * r[0] + e[6] * r[5] + e[7] * r[10] + e[8] * r[15]),
      (t[6] = e[5] * r[1] + e[6] * r[6] + e[7] * r[11] + e[8] * r[16]),
      (t[7] = e[5] * r[2] + e[6] * r[7] + e[7] * r[12] + e[8] * r[17]),
      (t[8] = e[5] * r[3] + e[6] * r[8] + e[7] * r[13] + e[8] * r[18]),
      (t[9] = e[5] * r[4] + e[6] * r[9] + e[7] * r[14] + e[8] * r[19] + e[9]),
      (t[10] = e[10] * r[0] + e[11] * r[5] + e[12] * r[10] + e[13] * r[15]),
      (t[11] = e[10] * r[1] + e[11] * r[6] + e[12] * r[11] + e[13] * r[16]),
      (t[12] = e[10] * r[2] + e[11] * r[7] + e[12] * r[12] + e[13] * r[17]),
      (t[13] = e[10] * r[3] + e[11] * r[8] + e[12] * r[13] + e[13] * r[18]),
      (t[14] =
        e[10] * r[4] + e[11] * r[9] + e[12] * r[14] + e[13] * r[19] + e[14]),
      (t[15] = e[15] * r[0] + e[16] * r[5] + e[17] * r[10] + e[18] * r[15]),
      (t[16] = e[15] * r[1] + e[16] * r[6] + e[17] * r[11] + e[18] * r[16]),
      (t[17] = e[15] * r[2] + e[16] * r[7] + e[17] * r[12] + e[18] * r[17]),
      (t[18] = e[15] * r[3] + e[16] * r[8] + e[17] * r[13] + e[18] * r[18]),
      (t[19] =
        e[15] * r[4] + e[16] * r[9] + e[17] * r[14] + e[18] * r[19] + e[19]),
      t
    );
  }
  _colorMatrix(t) {
    const e = new Float32Array(t);
    return (e[4] /= 255), (e[9] /= 255), (e[14] /= 255), (e[19] /= 255), e;
  }
  brightness(t, e) {
    const r = [t, 0, 0, 0, 0, 0, t, 0, 0, 0, 0, 0, t, 0, 0, 0, 0, 0, 1, 0];
    this._loadMatrix(r, e);
  }
  tint(t, e) {
    const [r, i, s] = Rn.shared.setValue(t).toArray(),
      n = [r, 0, 0, 0, 0, 0, i, 0, 0, 0, 0, 0, s, 0, 0, 0, 0, 0, 1, 0];
    this._loadMatrix(n, e);
  }
  greyscale(t, e) {
    const r = [t, t, t, 0, 0, t, t, t, 0, 0, t, t, t, 0, 0, 0, 0, 0, 1, 0];
    this._loadMatrix(r, e);
  }
  blackAndWhite(t) {
    this._loadMatrix(
      [
        0.3, 0.6, 0.1, 0, 0, 0.3, 0.6, 0.1, 0, 0, 0.3, 0.6, 0.1, 0, 0, 0, 0, 0,
        1, 0,
      ],
      t
    );
  }
  hue(t, e) {
    t = ((t || 0) / 180) * Math.PI;
    const r = Math.cos(t),
      i = Math.sin(t),
      s = 1 / 3,
      n = (0, Math.sqrt)(s),
      o = [
        r + (1 - r) * s,
        s * (1 - r) - n * i,
        s * (1 - r) + n * i,
        0,
        0,
        s * (1 - r) + n * i,
        r + s * (1 - r),
        s * (1 - r) - n * i,
        0,
        0,
        s * (1 - r) - n * i,
        s * (1 - r) + n * i,
        r + s * (1 - r),
        0,
        0,
        0,
        0,
        0,
        1,
        0,
      ];
    this._loadMatrix(o, e);
  }
  contrast(t, e) {
    const r = (t || 0) + 1,
      i = -0.5 * (r - 1),
      s = [r, 0, 0, 0, i, 0, r, 0, 0, i, 0, 0, r, 0, i, 0, 0, 0, 1, 0];
    this._loadMatrix(s, e);
  }
  saturate(t = 0, e) {
    const r = (2 * t) / 3 + 1,
      i = -0.5 * (r - 1),
      s = [r, i, i, 0, 0, i, r, i, 0, 0, i, i, r, 0, 0, 0, 0, 0, 1, 0];
    this._loadMatrix(s, e);
  }
  desaturate() {
    this.saturate(-1);
  }
  negative(t) {
    this._loadMatrix(
      [-1, 0, 0, 1, 0, 0, -1, 0, 1, 0, 0, 0, -1, 1, 0, 0, 0, 0, 1, 0],
      t
    );
  }
  sepia(t) {
    this._loadMatrix(
      [
        0.393, 0.7689999, 0.18899999, 0, 0, 0.349, 0.6859999, 0.16799999, 0, 0,
        0.272, 0.5339999, 0.13099999, 0, 0, 0, 0, 0, 1, 0,
      ],
      t
    );
  }
  technicolor(t) {
    this._loadMatrix(
      [
        1.9125277891456083, -0.8545344976951645, -0.09155508482755585, 0,
        11.793603434377337, -0.3087833385928097, 1.7658908555458428,
        -0.10601743074722245, 0, -70.35205161461398, -0.231103377548616,
        -0.7501899197440212, 1.847597816108189, 0, 30.950940869491138, 0, 0, 0,
        1, 0,
      ],
      t
    );
  }
  polaroid(t) {
    this._loadMatrix(
      [
        1.438, -0.062, -0.062, 0, 0, -0.122, 1.378, -0.122, 0, 0, -0.016,
        -0.016, 1.483, 0, 0, 0, 0, 0, 1, 0,
      ],
      t
    );
  }
  toBGR(t) {
    this._loadMatrix(
      [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0],
      t
    );
  }
  kodachrome(t) {
    this._loadMatrix(
      [
        1.1285582396593525, -0.3967382283601348, -0.03992559172921793, 0,
        63.72958762196502, -0.16404339962244616, 1.0835251566291304,
        -0.05498805115633132, 0, 24.732407896706203, -0.16786010706155763,
        -0.5603416277695248, 1.6014850761964943, 0, 35.62982807460946, 0, 0, 0,
        1, 0,
      ],
      t
    );
  }
  browni(t) {
    this._loadMatrix(
      [
        0.5997023498159715, 0.34553243048391263, -0.2708298674538042, 0,
        47.43192855600873, -0.037703249837783157, 0.8609577587992641,
        0.15059552388459913, 0, -36.96841498319127, 0.24113635128153335,
        -0.07441037908422492, 0.44972182064877153, 0, -7.562075277591283, 0, 0,
        0, 1, 0,
      ],
      t
    );
  }
  vintage(t) {
    this._loadMatrix(
      [
        0.6279345635605994, 0.3202183420819367, -0.03965408211312453, 0,
        9.651285835294123, 0.02578397704808868, 0.6441188644374771,
        0.03259127616149294, 0, 7.462829176470591, 0.0466055556782719,
        -0.0851232987247891, 0.5241648018700465, 0, 5.159190588235296, 0, 0, 0,
        1, 0,
      ],
      t
    );
  }
  colorTone(t, e, r, i, s) {
    (t = t || 0.2), (e = e || 0.15), (r = r || 16770432), (i = i || 3375104);
    const n = Rn.shared,
      [o, a, h] = n.setValue(r).toArray(),
      [l, u, c] = n.setValue(i).toArray(),
      d = [
        0.3,
        0.59,
        0.11,
        0,
        0,
        o,
        a,
        h,
        t,
        0,
        l,
        u,
        c,
        e,
        0,
        o - l,
        a - u,
        h - c,
        0,
        0,
      ];
    this._loadMatrix(d, s);
  }
  night(t, e) {
    const r = [
      -2 * (t = t || 0.1),
      -t,
      0,
      0,
      0,
      -t,
      0,
      t,
      0,
      0,
      0,
      t,
      2 * t,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
    ];
    this._loadMatrix(r, e);
  }
  predator(t, e) {
    const r = [
      11.224130630493164 * t,
      -4.794486999511719 * t,
      -2.8746118545532227 * t,
      0 * t,
      0.40342438220977783 * t,
      -3.6330697536468506 * t,
      9.193157196044922 * t,
      -2.951810836791992 * t,
      0 * t,
      -1.316135048866272 * t,
      -3.2184197902679443 * t,
      -4.2375030517578125 * t,
      7.476448059082031 * t,
      0 * t,
      0.8044459223747253 * t,
      0,
      0,
      0,
      1,
      0,
    ];
    this._loadMatrix(r, e);
  }
  lsd(t) {
    this._loadMatrix(
      [
        2, -0.4, 0.5, 0, 0, -0.5, 2, -0.4, 0, 0, -0.4, -0.5, 3, 0, 0, 0, 0, 0,
        1, 0,
      ],
      t
    );
  }
  reset() {
    this._loadMatrix(
      [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],
      !1
    );
  }
  get matrix() {
    return this.uniforms.m;
  }
  set matrix(t) {
    this.uniforms.m = t;
  }
  get alpha() {
    return this.uniforms.uAlpha;
  }
  set alpha(t) {
    this.uniforms.uAlpha = t;
  }
}
Lh.prototype.grayscale = Lh.prototype.greyscale;
const kh = {
  AlphaFilter: class extends Zo {
    constructor(t = 1) {
      super(
        "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n    vTextureCoord = aTextureCoord;\n}",
        "varying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\nuniform float uAlpha;\n\nvoid main(void)\n{\n   gl_FragColor = texture2D(uSampler, vTextureCoord) * uAlpha;\n}\n",
        { uAlpha: 1 }
      ),
        (this.alpha = t);
    }
    get alpha() {
      return this.uniforms.uAlpha;
    }
    set alpha(t) {
      this.uniforms.uAlpha = t;
    }
  },
  BlurFilter: class extends Zo {
    constructor(t = 8, e = 4, r = Zo.defaultResolution, i = 5) {
      super(),
        (this._repeatEdgePixels = !1),
        (this.blurXFilter = new Fh(!0, t, e, r, i)),
        (this.blurYFilter = new Fh(!1, t, e, r, i)),
        (this.resolution = r),
        (this.quality = e),
        (this.blur = t),
        (this.repeatEdgePixels = !1);
    }
    apply(t, e, r, i) {
      const s = Math.abs(this.blurXFilter.strength),
        n = Math.abs(this.blurYFilter.strength);
      if (s && n) {
        const s = t.getFilterTexture();
        this.blurXFilter.apply(t, e, s, cn.CLEAR),
          this.blurYFilter.apply(t, s, r, i),
          t.returnFilterTexture(s);
      } else
        n
          ? this.blurYFilter.apply(t, e, r, i)
          : this.blurXFilter.apply(t, e, r, i);
    }
    updatePadding() {
      this._repeatEdgePixels
        ? (this.padding = 0)
        : (this.padding =
            2 *
            Math.max(
              Math.abs(this.blurXFilter.strength),
              Math.abs(this.blurYFilter.strength)
            ));
    }
    get blur() {
      return this.blurXFilter.blur;
    }
    set blur(t) {
      (this.blurXFilter.blur = this.blurYFilter.blur = t), this.updatePadding();
    }
    get quality() {
      return this.blurXFilter.quality;
    }
    set quality(t) {
      this.blurXFilter.quality = this.blurYFilter.quality = t;
    }
    get blurX() {
      return this.blurXFilter.blur;
    }
    set blurX(t) {
      (this.blurXFilter.blur = t), this.updatePadding();
    }
    get blurY() {
      return this.blurYFilter.blur;
    }
    set blurY(t) {
      (this.blurYFilter.blur = t), this.updatePadding();
    }
    get blendMode() {
      return this.blurYFilter.blendMode;
    }
    set blendMode(t) {
      this.blurYFilter.blendMode = t;
    }
    get repeatEdgePixels() {
      return this._repeatEdgePixels;
    }
    set repeatEdgePixels(t) {
      (this._repeatEdgePixels = t), this.updatePadding();
    }
  },
  BlurFilterPass: Fh,
  ColorMatrixFilter: Lh,
  DisplacementFilter: class extends Zo {
    constructor(t, e) {
      const r = new go();
      (t.renderable = !1),
        super(
          "attribute vec2 aVertexPosition;\n\nuniform mat3 projectionMatrix;\nuniform mat3 filterMatrix;\n\nvarying vec2 vTextureCoord;\nvarying vec2 vFilterCoord;\n\nuniform vec4 inputSize;\nuniform vec4 outputFrame;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aVertexPosition * (outputFrame.zw * inputSize.zw);\n}\n\nvoid main(void)\n{\n\tgl_Position = filterVertexPosition();\n\tvTextureCoord = filterTextureCoord();\n\tvFilterCoord = ( filterMatrix * vec3( vTextureCoord, 1.0)  ).xy;\n}\n",
          "varying vec2 vFilterCoord;\nvarying vec2 vTextureCoord;\n\nuniform vec2 scale;\nuniform mat2 rotation;\nuniform sampler2D uSampler;\nuniform sampler2D mapSampler;\n\nuniform highp vec4 inputSize;\nuniform vec4 inputClamp;\n\nvoid main(void)\n{\n  vec4 map =  texture2D(mapSampler, vFilterCoord);\n\n  map -= 0.5;\n  map.xy = scale * inputSize.zw * (rotation * map.xy);\n\n  gl_FragColor = texture2D(uSampler, clamp(vec2(vTextureCoord.x + map.x, vTextureCoord.y + map.y), inputClamp.xy, inputClamp.zw));\n}\n",
          {
            mapSampler: t._texture,
            filterMatrix: r,
            scale: { x: 1, y: 1 },
            rotation: new Float32Array([1, 0, 0, 1]),
          }
        ),
        (this.maskSprite = t),
        (this.maskMatrix = r),
        null == e && (e = 20),
        (this.scale = new ho(e, e));
    }
    apply(t, e, r, i) {
      (this.uniforms.filterMatrix = t.calculateSpriteMatrix(
        this.maskMatrix,
        this.maskSprite
      )),
        (this.uniforms.scale.x = this.scale.x),
        (this.uniforms.scale.y = this.scale.y);
      const s = this.maskSprite.worldTransform,
        n = Math.sqrt(s.a * s.a + s.b * s.b),
        o = Math.sqrt(s.c * s.c + s.d * s.d);
      0 !== n &&
        0 !== o &&
        ((this.uniforms.rotation[0] = s.a / n),
        (this.uniforms.rotation[1] = s.b / n),
        (this.uniforms.rotation[2] = s.c / o),
        (this.uniforms.rotation[3] = s.d / o)),
        t.applyFilter(this, e, r, i);
    }
    get map() {
      return this.uniforms.mapSampler;
    }
    set map(t) {
      this.uniforms.mapSampler = t;
    }
  },
  FXAAFilter: class extends Zo {
    constructor() {
      super(
        "\nattribute vec2 aVertexPosition;\n\nuniform mat3 projectionMatrix;\n\nvarying vec2 v_rgbNW;\nvarying vec2 v_rgbNE;\nvarying vec2 v_rgbSW;\nvarying vec2 v_rgbSE;\nvarying vec2 v_rgbM;\n\nvarying vec2 vFragCoord;\n\nuniform vec4 inputSize;\nuniform vec4 outputFrame;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;\n\n    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n}\n\nvoid texcoords(vec2 fragCoord, vec2 inverseVP,\n               out vec2 v_rgbNW, out vec2 v_rgbNE,\n               out vec2 v_rgbSW, out vec2 v_rgbSE,\n               out vec2 v_rgbM) {\n    v_rgbNW = (fragCoord + vec2(-1.0, -1.0)) * inverseVP;\n    v_rgbNE = (fragCoord + vec2(1.0, -1.0)) * inverseVP;\n    v_rgbSW = (fragCoord + vec2(-1.0, 1.0)) * inverseVP;\n    v_rgbSE = (fragCoord + vec2(1.0, 1.0)) * inverseVP;\n    v_rgbM = vec2(fragCoord * inverseVP);\n}\n\nvoid main(void) {\n\n   gl_Position = filterVertexPosition();\n\n   vFragCoord = aVertexPosition * outputFrame.zw;\n\n   texcoords(vFragCoord, inputSize.zw, v_rgbNW, v_rgbNE, v_rgbSW, v_rgbSE, v_rgbM);\n}\n",
        'varying vec2 v_rgbNW;\nvarying vec2 v_rgbNE;\nvarying vec2 v_rgbSW;\nvarying vec2 v_rgbSE;\nvarying vec2 v_rgbM;\n\nvarying vec2 vFragCoord;\nuniform sampler2D uSampler;\nuniform highp vec4 inputSize;\n\n\n/**\n Basic FXAA implementation based on the code on geeks3d.com with the\n modification that the texture2DLod stuff was removed since it\'s\n unsupported by WebGL.\n\n --\n\n From:\n https://github.com/mitsuhiko/webgl-meincraft\n\n Copyright (c) 2011 by Armin Ronacher.\n\n Some rights reserved.\n\n Redistribution and use in source and binary forms, with or without\n modification, are permitted provided that the following conditions are\n met:\n\n * Redistributions of source code must retain the above copyright\n notice, this list of conditions and the following disclaimer.\n\n * Redistributions in binary form must reproduce the above\n copyright notice, this list of conditions and the following\n disclaimer in the documentation and/or other materials provided\n with the distribution.\n\n * The names of the contributors may not be used to endorse or\n promote products derived from this software without specific\n prior written permission.\n\n THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS\n "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT\n LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR\n A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT\n OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,\n SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT\n LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,\n DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY\n THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE\n OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n */\n\n#ifndef FXAA_REDUCE_MIN\n#define FXAA_REDUCE_MIN   (1.0/ 128.0)\n#endif\n#ifndef FXAA_REDUCE_MUL\n#define FXAA_REDUCE_MUL   (1.0 / 8.0)\n#endif\n#ifndef FXAA_SPAN_MAX\n#define FXAA_SPAN_MAX     8.0\n#endif\n\n//optimized version for mobile, where dependent\n//texture reads can be a bottleneck\nvec4 fxaa(sampler2D tex, vec2 fragCoord, vec2 inverseVP,\n          vec2 v_rgbNW, vec2 v_rgbNE,\n          vec2 v_rgbSW, vec2 v_rgbSE,\n          vec2 v_rgbM) {\n    vec4 color;\n    vec3 rgbNW = texture2D(tex, v_rgbNW).xyz;\n    vec3 rgbNE = texture2D(tex, v_rgbNE).xyz;\n    vec3 rgbSW = texture2D(tex, v_rgbSW).xyz;\n    vec3 rgbSE = texture2D(tex, v_rgbSE).xyz;\n    vec4 texColor = texture2D(tex, v_rgbM);\n    vec3 rgbM  = texColor.xyz;\n    vec3 luma = vec3(0.299, 0.587, 0.114);\n    float lumaNW = dot(rgbNW, luma);\n    float lumaNE = dot(rgbNE, luma);\n    float lumaSW = dot(rgbSW, luma);\n    float lumaSE = dot(rgbSE, luma);\n    float lumaM  = dot(rgbM,  luma);\n    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));\n    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));\n\n    mediump vec2 dir;\n    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));\n    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));\n\n    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) *\n                          (0.25 * FXAA_REDUCE_MUL), FXAA_REDUCE_MIN);\n\n    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);\n    dir = min(vec2(FXAA_SPAN_MAX, FXAA_SPAN_MAX),\n              max(vec2(-FXAA_SPAN_MAX, -FXAA_SPAN_MAX),\n                  dir * rcpDirMin)) * inverseVP;\n\n    vec3 rgbA = 0.5 * (\n                       texture2D(tex, fragCoord * inverseVP + dir * (1.0 / 3.0 - 0.5)).xyz +\n                       texture2D(tex, fragCoord * inverseVP + dir * (2.0 / 3.0 - 0.5)).xyz);\n    vec3 rgbB = rgbA * 0.5 + 0.25 * (\n                                     texture2D(tex, fragCoord * inverseVP + dir * -0.5).xyz +\n                                     texture2D(tex, fragCoord * inverseVP + dir * 0.5).xyz);\n\n    float lumaB = dot(rgbB, luma);\n    if ((lumaB < lumaMin) || (lumaB > lumaMax))\n        color = vec4(rgbA, texColor.a);\n    else\n        color = vec4(rgbB, texColor.a);\n    return color;\n}\n\nvoid main() {\n\n      vec4 color;\n\n      color = fxaa(uSampler, vFragCoord, inputSize.zw, v_rgbNW, v_rgbNE, v_rgbSW, v_rgbSE, v_rgbM);\n\n      gl_FragColor = color;\n}\n'
      );
    }
  },
  NoiseFilter: class extends Zo {
    constructor(t = 0.5, e = Math.random()) {
      super(
        hh,
        "precision highp float;\n\nvarying vec2 vTextureCoord;\nvarying vec4 vColor;\n\nuniform float uNoise;\nuniform float uSeed;\nuniform sampler2D uSampler;\n\nfloat rand(vec2 co)\n{\n    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);\n}\n\nvoid main()\n{\n    vec4 color = texture2D(uSampler, vTextureCoord);\n    float randomValue = rand(gl_FragCoord.xy * uSeed);\n    float diff = (randomValue - 0.5) * uNoise;\n\n    // Un-premultiply alpha before applying the color matrix. See issue #3539.\n    if (color.a > 0.0) {\n        color.rgb /= color.a;\n    }\n\n    color.r += diff;\n    color.g += diff;\n    color.b += diff;\n\n    // Premultiply alpha again.\n    color.rgb *= color.a;\n\n    gl_FragColor = color;\n}\n",
        { uNoise: 0, uSeed: 0 }
      ),
        (this.noise = t),
        (this.seed = e);
    }
    get noise() {
      return this.uniforms.uNoise;
    }
    set noise(t) {
      this.uniforms.uNoise = t;
    }
    get seed() {
      return this.uniforms.uSeed;
    }
    set seed(t) {
      this.uniforms.uSeed = t;
    }
  },
};
Object.entries(kh).forEach(([t, e]) => {
  Object.defineProperty(kh, t, {
    get: () => (W(0, `filters.${t} has moved to ${t}`), e),
  });
});
const Uh = new (class {
  constructor() {
    (this.interactionFrequency = 10),
      (this._deltaTime = 0),
      (this._didMove = !1),
      (this.tickerAdded = !1),
      (this._pauseUpdate = !0);
  }
  init(t) {
    this.removeTickerListener(),
      (this.events = t),
      (this.interactionFrequency = 10),
      (this._deltaTime = 0),
      (this._didMove = !1),
      (this.tickerAdded = !1),
      (this._pauseUpdate = !0);
  }
  get pauseUpdate() {
    return this._pauseUpdate;
  }
  set pauseUpdate(t) {
    this._pauseUpdate = t;
  }
  addTickerListener() {
    this.tickerAdded ||
      !this.domElement ||
      (nh.system.add(this.tickerUpdate, this, js.INTERACTION),
      (this.tickerAdded = !0));
  }
  removeTickerListener() {
    this.tickerAdded &&
      (nh.system.remove(this.tickerUpdate, this), (this.tickerAdded = !1));
  }
  pointerMoved() {
    this._didMove = !0;
  }
  update() {
    if (!this.domElement || this._pauseUpdate) return;
    if (this._didMove) return void (this._didMove = !1);
    const t = this.events.rootPointerEvent;
    (this.events.supportsTouchEvents && "touch" === t.pointerType) ||
      globalThis.document.dispatchEvent(
        new PointerEvent("pointermove", {
          clientX: t.clientX,
          clientY: t.clientY,
        })
      );
  }
  tickerUpdate(t) {
    (this._deltaTime += t),
      !(this._deltaTime < this.interactionFrequency) &&
        ((this._deltaTime = 0), this.update());
  }
})();
class Gh {
  constructor(t) {
    (this.bubbles = !0),
      (this.cancelBubble = !0),
      (this.cancelable = !1),
      (this.composed = !1),
      (this.defaultPrevented = !1),
      (this.eventPhase = Gh.prototype.NONE),
      (this.propagationStopped = !1),
      (this.propagationImmediatelyStopped = !1),
      (this.layer = new ho()),
      (this.page = new ho()),
      (this.NONE = 0),
      (this.CAPTURING_PHASE = 1),
      (this.AT_TARGET = 2),
      (this.BUBBLING_PHASE = 3),
      (this.manager = t);
  }
  get layerX() {
    return this.layer.x;
  }
  get layerY() {
    return this.layer.y;
  }
  get pageX() {
    return this.page.x;
  }
  get pageY() {
    return this.page.y;
  }
  get data() {
    return this;
  }
  composedPath() {
    return (
      this.manager &&
        (!this.path || this.path[this.path.length - 1] !== this.target) &&
        (this.path = this.target
          ? this.manager.propagationPath(this.target)
          : []),
      this.path
    );
  }
  initEvent(t, e, r) {
    throw new Error(
      "initEvent() is a legacy DOM API. It is not implemented in the Federated Events API."
    );
  }
  initUIEvent(t, e, r, i, s) {
    throw new Error(
      "initUIEvent() is a legacy DOM API. It is not implemented in the Federated Events API."
    );
  }
  preventDefault() {
    this.nativeEvent instanceof Event &&
      this.nativeEvent.cancelable &&
      this.nativeEvent.preventDefault(),
      (this.defaultPrevented = !0);
  }
  stopImmediatePropagation() {
    this.propagationImmediatelyStopped = !0;
  }
  stopPropagation() {
    this.propagationStopped = !0;
  }
}
class Hh extends Gh {
  constructor() {
    super(...arguments),
      (this.client = new ho()),
      (this.movement = new ho()),
      (this.offset = new ho()),
      (this.global = new ho()),
      (this.screen = new ho());
  }
  get clientX() {
    return this.client.x;
  }
  get clientY() {
    return this.client.y;
  }
  get x() {
    return this.clientX;
  }
  get y() {
    return this.clientY;
  }
  get movementX() {
    return this.movement.x;
  }
  get movementY() {
    return this.movement.y;
  }
  get offsetX() {
    return this.offset.x;
  }
  get offsetY() {
    return this.offset.y;
  }
  get globalX() {
    return this.global.x;
  }
  get globalY() {
    return this.global.y;
  }
  get screenX() {
    return this.screen.x;
  }
  get screenY() {
    return this.screen.y;
  }
  getLocalPosition(t, e, r) {
    return t.worldTransform.applyInverse(r || this.global, e);
  }
  getModifierState(t) {
    return (
      "getModifierState" in this.nativeEvent &&
      this.nativeEvent.getModifierState(t)
    );
  }
  initMouseEvent(t, e, r, i, s, n, o, a, h, l, u, c, d, p, f) {
    throw new Error("Method not implemented.");
  }
}
class jh extends Hh {
  constructor() {
    super(...arguments),
      (this.width = 0),
      (this.height = 0),
      (this.isPrimary = !1);
  }
  getCoalescedEvents() {
    return "pointermove" === this.type ||
      "mousemove" === this.type ||
      "touchmove" === this.type
      ? [this]
      : [];
  }
  getPredictedEvents() {
    throw new Error("getPredictedEvents is not supported!");
  }
}
class Xh extends Hh {
  constructor() {
    super(...arguments),
      (this.DOM_DELTA_PIXEL = 0),
      (this.DOM_DELTA_LINE = 1),
      (this.DOM_DELTA_PAGE = 2);
  }
}
(Xh.DOM_DELTA_PIXEL = 0), (Xh.DOM_DELTA_LINE = 1), (Xh.DOM_DELTA_PAGE = 2);
const Vh = new ho(),
  zh = new ho();
class Wh {
  constructor(t) {
    (this.dispatch = new vn()),
      (this.moveOnAll = !1),
      (this.enableGlobalMoveEvents = !0),
      (this.mappingState = { trackingData: {} }),
      (this.eventPool = new Map()),
      (this._allInteractiveElements = []),
      (this._hitElements = []),
      (this._isPointerMoveEvent = !1),
      (this.rootTarget = t),
      (this.hitPruneFn = this.hitPruneFn.bind(this)),
      (this.hitTestFn = this.hitTestFn.bind(this)),
      (this.mapPointerDown = this.mapPointerDown.bind(this)),
      (this.mapPointerMove = this.mapPointerMove.bind(this)),
      (this.mapPointerOut = this.mapPointerOut.bind(this)),
      (this.mapPointerOver = this.mapPointerOver.bind(this)),
      (this.mapPointerUp = this.mapPointerUp.bind(this)),
      (this.mapPointerUpOutside = this.mapPointerUpOutside.bind(this)),
      (this.mapWheel = this.mapWheel.bind(this)),
      (this.mappingTable = {}),
      this.addEventMapping("pointerdown", this.mapPointerDown),
      this.addEventMapping("pointermove", this.mapPointerMove),
      this.addEventMapping("pointerout", this.mapPointerOut),
      this.addEventMapping("pointerleave", this.mapPointerOut),
      this.addEventMapping("pointerover", this.mapPointerOver),
      this.addEventMapping("pointerup", this.mapPointerUp),
      this.addEventMapping("pointerupoutside", this.mapPointerUpOutside),
      this.addEventMapping("wheel", this.mapWheel);
  }
  addEventMapping(t, e) {
    this.mappingTable[t] || (this.mappingTable[t] = []),
      this.mappingTable[t].push({ fn: e, priority: 0 }),
      this.mappingTable[t].sort((t, e) => t.priority - e.priority);
  }
  dispatchEvent(t, e) {
    (t.propagationStopped = !1),
      (t.propagationImmediatelyStopped = !1),
      this.propagate(t, e),
      this.dispatch.emit(e || t.type, t);
  }
  mapEvent(t) {
    if (!this.rootTarget) return;
    const e = this.mappingTable[t.type];
    if (e) for (let r = 0, i = e.length; r < i; r++) e[r].fn(t);
  }
  hitTest(t, e) {
    Uh.pauseUpdate = !0;
    const r = this[
      this._isPointerMoveEvent && this.enableGlobalMoveEvents
        ? "hitTestMoveRecursive"
        : "hitTestRecursive"
    ](
      this.rootTarget,
      this.rootTarget.eventMode,
      Vh.set(t, e),
      this.hitTestFn,
      this.hitPruneFn
    );
    return r && r[0];
  }
  propagate(t, e) {
    if (!t.target) return;
    const r = t.composedPath();
    t.eventPhase = t.CAPTURING_PHASE;
    for (let i = 0, s = r.length - 1; i < s; i++)
      if (
        ((t.currentTarget = r[i]),
        this.notifyTarget(t, e),
        t.propagationStopped || t.propagationImmediatelyStopped)
      )
        return;
    if (
      ((t.eventPhase = t.AT_TARGET),
      (t.currentTarget = t.target),
      this.notifyTarget(t, e),
      !t.propagationStopped && !t.propagationImmediatelyStopped)
    ) {
      t.eventPhase = t.BUBBLING_PHASE;
      for (let i = r.length - 2; i >= 0; i--)
        if (
          ((t.currentTarget = r[i]),
          this.notifyTarget(t, e),
          t.propagationStopped || t.propagationImmediatelyStopped)
        )
          return;
    }
  }
  all(t, e, r = this._allInteractiveElements) {
    if (0 === r.length) return;
    t.eventPhase = t.BUBBLING_PHASE;
    const i = Array.isArray(e) ? e : [e];
    for (let s = r.length - 1; s >= 0; s--)
      i.forEach((e) => {
        (t.currentTarget = r[s]), this.notifyTarget(t, e);
      });
  }
  propagationPath(t) {
    const e = [t];
    for (let r = 0; r < 2048 && t !== this.rootTarget; r++) {
      if (!t.parent)
        throw new Error("Cannot find propagation path to disconnected target");
      e.push(t.parent), (t = t.parent);
    }
    return e.reverse(), e;
  }
  hitTestMoveRecursive(t, e, r, i, s, n = !1) {
    let o = !1;
    if (this._interactivePrune(t)) return null;
    if (
      (("dynamic" === t.eventMode || "dynamic" === e) && (Uh.pauseUpdate = !1),
      t.interactiveChildren && t.children)
    ) {
      const a = t.children;
      for (let h = a.length - 1; h >= 0; h--) {
        const l = a[h],
          u = this.hitTestMoveRecursive(
            l,
            this._isInteractive(e) ? e : l.eventMode,
            r,
            i,
            s,
            n || s(t, r)
          );
        if (u) {
          if (u.length > 0 && !u[u.length - 1].parent) continue;
          const e = t.isInteractive();
          (u.length > 0 || e) &&
            (e && this._allInteractiveElements.push(t), u.push(t)),
            0 === this._hitElements.length && (this._hitElements = u),
            (o = !0);
        }
      }
    }
    const a = this._isInteractive(e),
      h = t.isInteractive();
    return (
      h && h && this._allInteractiveElements.push(t),
      n || this._hitElements.length > 0
        ? null
        : o
        ? this._hitElements
        : a && !s(t, r) && i(t, r)
        ? h
          ? [t]
          : []
        : null
    );
  }
  hitTestRecursive(t, e, r, i, s) {
    if (this._interactivePrune(t) || s(t, r)) return null;
    if (
      (("dynamic" === t.eventMode || "dynamic" === e) && (Uh.pauseUpdate = !1),
      t.interactiveChildren && t.children)
    ) {
      const n = t.children;
      for (let o = n.length - 1; o >= 0; o--) {
        const a = n[o],
          h = this.hitTestRecursive(
            a,
            this._isInteractive(e) ? e : a.eventMode,
            r,
            i,
            s
          );
        if (h) {
          if (h.length > 0 && !h[h.length - 1].parent) continue;
          const e = t.isInteractive();
          return (h.length > 0 || e) && h.push(t), h;
        }
      }
    }
    const n = this._isInteractive(e),
      o = t.isInteractive();
    return n && i(t, r) ? (o ? [t] : []) : null;
  }
  _isInteractive(t) {
    return "static" === t || "dynamic" === t;
  }
  _interactivePrune(t) {
    return !(
      t &&
      !t.isMask &&
      t.visible &&
      t.renderable &&
      "none" !== t.eventMode &&
      ("passive" !== t.eventMode || t.interactiveChildren) &&
      !t.isMask
    );
  }
  hitPruneFn(t, e) {
    var r;
    if (
      t.hitArea &&
      (t.worldTransform.applyInverse(e, zh), !t.hitArea.contains(zh.x, zh.y))
    )
      return !0;
    if (t._mask) {
      const i = t._mask.isMaskData ? t._mask.maskObject : t._mask;
      if (i && !(null == (r = i.containsPoint) ? void 0 : r.call(i, e)))
        return !0;
    }
    return !1;
  }
  hitTestFn(t, e) {
    return (
      "passive" !== t.eventMode &&
      (!!t.hitArea || (!!t.containsPoint && t.containsPoint(e)))
    );
  }
  notifyTarget(t, e) {
    var r, i;
    const s = `on${(e = e ?? t.type)}`;
    null == (i = (r = t.currentTarget)[s]) || i.call(r, t);
    const n =
      t.eventPhase === t.CAPTURING_PHASE || t.eventPhase === t.AT_TARGET
        ? `${e}capture`
        : e;
    this.notifyListeners(t, n),
      t.eventPhase === t.AT_TARGET && this.notifyListeners(t, e);
  }
  mapPointerDown(t) {
    if (!(t instanceof jh)) return;
    const e = this.createPointerEvent(t);
    if ((this.dispatchEvent(e, "pointerdown"), "touch" === e.pointerType))
      this.dispatchEvent(e, "touchstart");
    else if ("mouse" === e.pointerType || "pen" === e.pointerType) {
      const t = 2 === e.button;
      this.dispatchEvent(e, t ? "rightdown" : "mousedown");
    }
    (this.trackingData(t.pointerId).pressTargetsByButton[t.button] =
      e.composedPath()),
      this.freeEvent(e);
  }
  mapPointerMove(t) {
    var e, r;
    if (!(t instanceof jh)) return;
    (this._allInteractiveElements.length = 0),
      (this._hitElements.length = 0),
      (this._isPointerMoveEvent = !0);
    const i = this.createPointerEvent(t);
    this._isPointerMoveEvent = !1;
    const s = "mouse" === i.pointerType || "pen" === i.pointerType,
      n = this.trackingData(t.pointerId),
      o = this.findMountedTarget(n.overTargets);
    if (
      (null == (e = n.overTargets) ? void 0 : e.length) > 0 &&
      o !== i.target
    ) {
      const e = "mousemove" === t.type ? "mouseout" : "pointerout",
        r = this.createPointerEvent(t, e, o);
      if (
        (this.dispatchEvent(r, "pointerout"),
        s && this.dispatchEvent(r, "mouseout"),
        !i.composedPath().includes(o))
      ) {
        const e = this.createPointerEvent(t, "pointerleave", o);
        for (
          e.eventPhase = e.AT_TARGET;
          e.target && !i.composedPath().includes(e.target);

        )
          (e.currentTarget = e.target),
            this.notifyTarget(e),
            s && this.notifyTarget(e, "mouseleave"),
            (e.target = e.target.parent);
        this.freeEvent(e);
      }
      this.freeEvent(r);
    }
    if (o !== i.target) {
      const e = "mousemove" === t.type ? "mouseover" : "pointerover",
        r = this.clonePointerEvent(i, e);
      this.dispatchEvent(r, "pointerover"),
        s && this.dispatchEvent(r, "mouseover");
      let n = null == o ? void 0 : o.parent;
      for (; n && n !== this.rootTarget.parent && n !== i.target; )
        n = n.parent;
      if (!n || n === this.rootTarget.parent) {
        const t = this.clonePointerEvent(i, "pointerenter");
        for (
          t.eventPhase = t.AT_TARGET;
          t.target && t.target !== o && t.target !== this.rootTarget.parent;

        )
          (t.currentTarget = t.target),
            this.notifyTarget(t),
            s && this.notifyTarget(t, "mouseenter"),
            (t.target = t.target.parent);
        this.freeEvent(t);
      }
      this.freeEvent(r);
    }
    const a = [],
      h = this.enableGlobalMoveEvents ?? !0;
    this.moveOnAll
      ? a.push("pointermove")
      : this.dispatchEvent(i, "pointermove"),
      h && a.push("globalpointermove"),
      "touch" === i.pointerType &&
        (this.moveOnAll
          ? a.splice(1, 0, "touchmove")
          : this.dispatchEvent(i, "touchmove"),
        h && a.push("globaltouchmove")),
      s &&
        (this.moveOnAll
          ? a.splice(1, 0, "mousemove")
          : this.dispatchEvent(i, "mousemove"),
        h && a.push("globalmousemove"),
        (this.cursor = null == (r = i.target) ? void 0 : r.cursor)),
      a.length > 0 && this.all(i, a),
      (this._allInteractiveElements.length = 0),
      (this._hitElements.length = 0),
      (n.overTargets = i.composedPath()),
      this.freeEvent(i);
  }
  mapPointerOver(t) {
    var e;
    if (!(t instanceof jh)) return;
    const r = this.trackingData(t.pointerId),
      i = this.createPointerEvent(t),
      s = "mouse" === i.pointerType || "pen" === i.pointerType;
    this.dispatchEvent(i, "pointerover"),
      s && this.dispatchEvent(i, "mouseover"),
      "mouse" === i.pointerType &&
        (this.cursor = null == (e = i.target) ? void 0 : e.cursor);
    const n = this.clonePointerEvent(i, "pointerenter");
    for (
      n.eventPhase = n.AT_TARGET;
      n.target && n.target !== this.rootTarget.parent;

    )
      (n.currentTarget = n.target),
        this.notifyTarget(n),
        s && this.notifyTarget(n, "mouseenter"),
        (n.target = n.target.parent);
    (r.overTargets = i.composedPath()), this.freeEvent(i), this.freeEvent(n);
  }
  mapPointerOut(t) {
    if (!(t instanceof jh)) return;
    const e = this.trackingData(t.pointerId);
    if (e.overTargets) {
      const r = "mouse" === t.pointerType || "pen" === t.pointerType,
        i = this.findMountedTarget(e.overTargets),
        s = this.createPointerEvent(t, "pointerout", i);
      this.dispatchEvent(s), r && this.dispatchEvent(s, "mouseout");
      const n = this.createPointerEvent(t, "pointerleave", i);
      for (
        n.eventPhase = n.AT_TARGET;
        n.target && n.target !== this.rootTarget.parent;

      )
        (n.currentTarget = n.target),
          this.notifyTarget(n),
          r && this.notifyTarget(n, "mouseleave"),
          (n.target = n.target.parent);
      (e.overTargets = null), this.freeEvent(s), this.freeEvent(n);
    }
    this.cursor = null;
  }
  mapPointerUp(t) {
    if (!(t instanceof jh)) return;
    const e = performance.now(),
      r = this.createPointerEvent(t);
    if ((this.dispatchEvent(r, "pointerup"), "touch" === r.pointerType))
      this.dispatchEvent(r, "touchend");
    else if ("mouse" === r.pointerType || "pen" === r.pointerType) {
      const t = 2 === r.button;
      this.dispatchEvent(r, t ? "rightup" : "mouseup");
    }
    const i = this.trackingData(t.pointerId),
      s = this.findMountedTarget(i.pressTargetsByButton[t.button]);
    let n = s;
    if (s && !r.composedPath().includes(s)) {
      let e = s;
      for (; e && !r.composedPath().includes(e); ) {
        if (
          ((r.currentTarget = e),
          this.notifyTarget(r, "pointerupoutside"),
          "touch" === r.pointerType)
        )
          this.notifyTarget(r, "touchendoutside");
        else if ("mouse" === r.pointerType || "pen" === r.pointerType) {
          const t = 2 === r.button;
          this.notifyTarget(r, t ? "rightupoutside" : "mouseupoutside");
        }
        e = e.parent;
      }
      delete i.pressTargetsByButton[t.button], (n = e);
    }
    if (n) {
      const s = this.clonePointerEvent(r, "click");
      (s.target = n),
        (s.path = null),
        i.clicksByButton[t.button] ||
          (i.clicksByButton[t.button] = {
            clickCount: 0,
            target: s.target,
            timeStamp: e,
          });
      const o = i.clicksByButton[t.button];
      if (
        (o.target === s.target && e - o.timeStamp < 200
          ? ++o.clickCount
          : (o.clickCount = 1),
        (o.target = s.target),
        (o.timeStamp = e),
        (s.detail = o.clickCount),
        "mouse" === s.pointerType)
      ) {
        const t = 2 === s.button;
        this.dispatchEvent(s, t ? "rightclick" : "click");
      } else "touch" === s.pointerType && this.dispatchEvent(s, "tap");
      this.dispatchEvent(s, "pointertap"), this.freeEvent(s);
    }
    this.freeEvent(r);
  }
  mapPointerUpOutside(t) {
    if (!(t instanceof jh)) return;
    const e = this.trackingData(t.pointerId),
      r = this.findMountedTarget(e.pressTargetsByButton[t.button]),
      i = this.createPointerEvent(t);
    if (r) {
      let s = r;
      for (; s; )
        (i.currentTarget = s),
          this.notifyTarget(i, "pointerupoutside"),
          "touch" === i.pointerType
            ? this.notifyTarget(i, "touchendoutside")
            : ("mouse" === i.pointerType || "pen" === i.pointerType) &&
              this.notifyTarget(
                i,
                2 === i.button ? "rightupoutside" : "mouseupoutside"
              ),
          (s = s.parent);
      delete e.pressTargetsByButton[t.button];
    }
    this.freeEvent(i);
  }
  mapWheel(t) {
    if (!(t instanceof Xh)) return;
    const e = this.createWheelEvent(t);
    this.dispatchEvent(e), this.freeEvent(e);
  }
  findMountedTarget(t) {
    if (!t) return null;
    let e = t[0];
    for (let r = 1; r < t.length && t[r].parent === e; r++) e = t[r];
    return e;
  }
  createPointerEvent(t, e, r) {
    const i = this.allocateEvent(jh);
    return (
      this.copyPointerData(t, i),
      this.copyMouseData(t, i),
      this.copyData(t, i),
      (i.nativeEvent = t.nativeEvent),
      (i.originalEvent = t),
      (i.target =
        r ?? this.hitTest(i.global.x, i.global.y) ?? this._hitElements[0]),
      "string" == typeof e && (i.type = e),
      i
    );
  }
  createWheelEvent(t) {
    const e = this.allocateEvent(Xh);
    return (
      this.copyWheelData(t, e),
      this.copyMouseData(t, e),
      this.copyData(t, e),
      (e.nativeEvent = t.nativeEvent),
      (e.originalEvent = t),
      (e.target = this.hitTest(e.global.x, e.global.y)),
      e
    );
  }
  clonePointerEvent(t, e) {
    const r = this.allocateEvent(jh);
    return (
      (r.nativeEvent = t.nativeEvent),
      (r.originalEvent = t.originalEvent),
      this.copyPointerData(t, r),
      this.copyMouseData(t, r),
      this.copyData(t, r),
      (r.target = t.target),
      (r.path = t.composedPath().slice()),
      (r.type = e ?? r.type),
      r
    );
  }
  copyWheelData(t, e) {
    (e.deltaMode = t.deltaMode),
      (e.deltaX = t.deltaX),
      (e.deltaY = t.deltaY),
      (e.deltaZ = t.deltaZ);
  }
  copyPointerData(t, e) {
    t instanceof jh &&
      e instanceof jh &&
      ((e.pointerId = t.pointerId),
      (e.width = t.width),
      (e.height = t.height),
      (e.isPrimary = t.isPrimary),
      (e.pointerType = t.pointerType),
      (e.pressure = t.pressure),
      (e.tangentialPressure = t.tangentialPressure),
      (e.tiltX = t.tiltX),
      (e.tiltY = t.tiltY),
      (e.twist = t.twist));
  }
  copyMouseData(t, e) {
    t instanceof Hh &&
      e instanceof Hh &&
      ((e.altKey = t.altKey),
      (e.button = t.button),
      (e.buttons = t.buttons),
      e.client.copyFrom(t.client),
      (e.ctrlKey = t.ctrlKey),
      (e.metaKey = t.metaKey),
      e.movement.copyFrom(t.movement),
      e.screen.copyFrom(t.screen),
      (e.shiftKey = t.shiftKey),
      e.global.copyFrom(t.global));
  }
  copyData(t, e) {
    (e.isTrusted = t.isTrusted),
      (e.srcElement = t.srcElement),
      (e.timeStamp = performance.now()),
      (e.type = t.type),
      (e.detail = t.detail),
      (e.view = t.view),
      (e.which = t.which),
      e.layer.copyFrom(t.layer),
      e.page.copyFrom(t.page);
  }
  trackingData(t) {
    return (
      this.mappingState.trackingData[t] ||
        (this.mappingState.trackingData[t] = {
          pressTargetsByButton: {},
          clicksByButton: {},
          overTarget: null,
        }),
      this.mappingState.trackingData[t]
    );
  }
  allocateEvent(t) {
    this.eventPool.has(t) || this.eventPool.set(t, []);
    const e = this.eventPool.get(t).pop() || new t(this);
    return (
      (e.eventPhase = e.NONE),
      (e.currentTarget = null),
      (e.path = null),
      (e.target = null),
      e
    );
  }
  freeEvent(t) {
    if (t.manager !== this)
      throw new Error(
        "It is illegal to free an event not managed by this EventBoundary!"
      );
    const e = t.constructor;
    this.eventPool.has(e) || this.eventPool.set(e, []),
      this.eventPool.get(e).push(t);
  }
  notifyListeners(t, e) {
    const r = t.currentTarget._events[e];
    if (r && t.currentTarget.isInteractive())
      if ("fn" in r)
        r.once && t.currentTarget.removeListener(e, r.fn, void 0, !0),
          r.fn.call(r.context, t);
      else
        for (
          let i = 0, s = r.length;
          i < s && !t.propagationImmediatelyStopped;
          i++
        )
          r[i].once && t.currentTarget.removeListener(e, r[i].fn, void 0, !0),
            r[i].fn.call(r[i].context, t);
  }
}
const $h = {
    touchstart: "pointerdown",
    touchend: "pointerup",
    touchendoutside: "pointerupoutside",
    touchmove: "pointermove",
    touchcancel: "pointercancel",
  },
  Yh = class t {
    constructor(e) {
      (this.supportsTouchEvents = "ontouchstart" in globalThis),
        (this.supportsPointerEvents = !!globalThis.PointerEvent),
        (this.domElement = null),
        (this.resolution = 1),
        (this.renderer = e),
        (this.rootBoundary = new Wh(null)),
        Uh.init(this),
        (this.autoPreventDefault = !0),
        (this.eventsAdded = !1),
        (this.rootPointerEvent = new jh(null)),
        (this.rootWheelEvent = new Xh(null)),
        (this.cursorStyles = { default: "inherit", pointer: "pointer" }),
        (this.features = new Proxy(
          { ...t.defaultEventFeatures },
          {
            set: (t, e, r) => (
              "globalMove" === e &&
                (this.rootBoundary.enableGlobalMoveEvents = r),
              (t[e] = r),
              !0
            ),
          }
        )),
        (this.onPointerDown = this.onPointerDown.bind(this)),
        (this.onPointerMove = this.onPointerMove.bind(this)),
        (this.onPointerUp = this.onPointerUp.bind(this)),
        (this.onPointerOverOut = this.onPointerOverOut.bind(this)),
        (this.onWheel = this.onWheel.bind(this));
    }
    static get defaultEventMode() {
      return this._defaultEventMode;
    }
    init(e) {
      const { view: r, resolution: i } = this.renderer;
      this.setTargetElement(r),
        (this.resolution = i),
        (t._defaultEventMode = e.eventMode ?? "auto"),
        Object.assign(this.features, e.eventFeatures ?? {}),
        (this.rootBoundary.enableGlobalMoveEvents = this.features.globalMove);
    }
    resolutionChange(t) {
      this.resolution = t;
    }
    destroy() {
      this.setTargetElement(null), (this.renderer = null);
    }
    setCursor(t) {
      t = t || "default";
      let e = !0;
      if (
        (globalThis.OffscreenCanvas &&
          this.domElement instanceof OffscreenCanvas &&
          (e = !1),
        this.currentCursor === t)
      )
        return;
      this.currentCursor = t;
      const r = this.cursorStyles[t];
      if (r)
        switch (typeof r) {
          case "string":
            e && (this.domElement.style.cursor = r);
            break;
          case "function":
            r(t);
            break;
          case "object":
            e && Object.assign(this.domElement.style, r);
        }
      else
        e &&
          "string" == typeof t &&
          !Object.prototype.hasOwnProperty.call(this.cursorStyles, t) &&
          (this.domElement.style.cursor = t);
    }
    get pointer() {
      return this.rootPointerEvent;
    }
    onPointerDown(t) {
      if (!this.features.click) return;
      this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
      const e = this.normalizeToPointerData(t);
      this.autoPreventDefault &&
        e[0].isNormalized &&
        (t.cancelable || !("cancelable" in t)) &&
        t.preventDefault();
      for (let r = 0, i = e.length; r < i; r++) {
        const t = e[r],
          i = this.bootstrapEvent(this.rootPointerEvent, t);
        this.rootBoundary.mapEvent(i);
      }
      this.setCursor(this.rootBoundary.cursor);
    }
    onPointerMove(t) {
      if (!this.features.move) return;
      (this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
        Uh.pointerMoved();
      const e = this.normalizeToPointerData(t);
      for (let r = 0, i = e.length; r < i; r++) {
        const t = this.bootstrapEvent(this.rootPointerEvent, e[r]);
        this.rootBoundary.mapEvent(t);
      }
      this.setCursor(this.rootBoundary.cursor);
    }
    onPointerUp(t) {
      if (!this.features.click) return;
      this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
      let e = t.target;
      t.composedPath &&
        t.composedPath().length > 0 &&
        (e = t.composedPath()[0]);
      const r = e !== this.domElement ? "outside" : "",
        i = this.normalizeToPointerData(t);
      for (let s = 0, n = i.length; s < n; s++) {
        const t = this.bootstrapEvent(this.rootPointerEvent, i[s]);
        (t.type += r), this.rootBoundary.mapEvent(t);
      }
      this.setCursor(this.rootBoundary.cursor);
    }
    onPointerOverOut(t) {
      if (!this.features.click) return;
      this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
      const e = this.normalizeToPointerData(t);
      for (let r = 0, i = e.length; r < i; r++) {
        const t = this.bootstrapEvent(this.rootPointerEvent, e[r]);
        this.rootBoundary.mapEvent(t);
      }
      this.setCursor(this.rootBoundary.cursor);
    }
    onWheel(t) {
      if (!this.features.wheel) return;
      const e = this.normalizeWheelEvent(t);
      (this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
        this.rootBoundary.mapEvent(e);
    }
    setTargetElement(t) {
      this.removeEvents(),
        (this.domElement = t),
        (Uh.domElement = t),
        this.addEvents();
    }
    addEvents() {
      if (this.eventsAdded || !this.domElement) return;
      Uh.addTickerListener();
      const t = this.domElement.style;
      t &&
        (globalThis.navigator.msPointerEnabled
          ? ((t.msContentZooming = "none"), (t.msTouchAction = "none"))
          : this.supportsPointerEvents && (t.touchAction = "none")),
        this.supportsPointerEvents
          ? (globalThis.document.addEventListener(
              "pointermove",
              this.onPointerMove,
              !0
            ),
            this.domElement.addEventListener(
              "pointerdown",
              this.onPointerDown,
              !0
            ),
            this.domElement.addEventListener(
              "pointerleave",
              this.onPointerOverOut,
              !0
            ),
            this.domElement.addEventListener(
              "pointerover",
              this.onPointerOverOut,
              !0
            ),
            globalThis.addEventListener("pointerup", this.onPointerUp, !0))
          : (globalThis.document.addEventListener(
              "mousemove",
              this.onPointerMove,
              !0
            ),
            this.domElement.addEventListener(
              "mousedown",
              this.onPointerDown,
              !0
            ),
            this.domElement.addEventListener(
              "mouseout",
              this.onPointerOverOut,
              !0
            ),
            this.domElement.addEventListener(
              "mouseover",
              this.onPointerOverOut,
              !0
            ),
            globalThis.addEventListener("mouseup", this.onPointerUp, !0),
            this.supportsTouchEvents &&
              (this.domElement.addEventListener(
                "touchstart",
                this.onPointerDown,
                !0
              ),
              this.domElement.addEventListener(
                "touchend",
                this.onPointerUp,
                !0
              ),
              this.domElement.addEventListener(
                "touchmove",
                this.onPointerMove,
                !0
              ))),
        this.domElement.addEventListener("wheel", this.onWheel, {
          passive: !0,
          capture: !0,
        }),
        (this.eventsAdded = !0);
    }
    removeEvents() {
      if (!this.eventsAdded || !this.domElement) return;
      Uh.removeTickerListener();
      const t = this.domElement.style;
      globalThis.navigator.msPointerEnabled
        ? ((t.msContentZooming = ""), (t.msTouchAction = ""))
        : this.supportsPointerEvents && (t.touchAction = ""),
        this.supportsPointerEvents
          ? (globalThis.document.removeEventListener(
              "pointermove",
              this.onPointerMove,
              !0
            ),
            this.domElement.removeEventListener(
              "pointerdown",
              this.onPointerDown,
              !0
            ),
            this.domElement.removeEventListener(
              "pointerleave",
              this.onPointerOverOut,
              !0
            ),
            this.domElement.removeEventListener(
              "pointerover",
              this.onPointerOverOut,
              !0
            ),
            globalThis.removeEventListener("pointerup", this.onPointerUp, !0))
          : (globalThis.document.removeEventListener(
              "mousemove",
              this.onPointerMove,
              !0
            ),
            this.domElement.removeEventListener(
              "mousedown",
              this.onPointerDown,
              !0
            ),
            this.domElement.removeEventListener(
              "mouseout",
              this.onPointerOverOut,
              !0
            ),
            this.domElement.removeEventListener(
              "mouseover",
              this.onPointerOverOut,
              !0
            ),
            globalThis.removeEventListener("mouseup", this.onPointerUp, !0),
            this.supportsTouchEvents &&
              (this.domElement.removeEventListener(
                "touchstart",
                this.onPointerDown,
                !0
              ),
              this.domElement.removeEventListener(
                "touchend",
                this.onPointerUp,
                !0
              ),
              this.domElement.removeEventListener(
                "touchmove",
                this.onPointerMove,
                !0
              ))),
        this.domElement.removeEventListener("wheel", this.onWheel, !0),
        (this.domElement = null),
        (this.eventsAdded = !1);
    }
    mapPositionToPoint(t, e, r) {
      const i = this.domElement.isConnected
          ? this.domElement.getBoundingClientRect()
          : {
              x: 0,
              y: 0,
              width: this.domElement.width,
              height: this.domElement.height,
              left: 0,
              top: 0,
            },
        s = 1 / this.resolution;
      (t.x = (e - i.left) * (this.domElement.width / i.width) * s),
        (t.y = (r - i.top) * (this.domElement.height / i.height) * s);
    }
    normalizeToPointerData(t) {
      const e = [];
      if (this.supportsTouchEvents && t instanceof TouchEvent)
        for (let r = 0, i = t.changedTouches.length; r < i; r++) {
          const i = t.changedTouches[r];
          typeof i.button > "u" && (i.button = 0),
            typeof i.buttons > "u" && (i.buttons = 1),
            typeof i.isPrimary > "u" &&
              (i.isPrimary = 1 === t.touches.length && "touchstart" === t.type),
            typeof i.width > "u" && (i.width = i.radiusX || 1),
            typeof i.height > "u" && (i.height = i.radiusY || 1),
            typeof i.tiltX > "u" && (i.tiltX = 0),
            typeof i.tiltY > "u" && (i.tiltY = 0),
            typeof i.pointerType > "u" && (i.pointerType = "touch"),
            typeof i.pointerId > "u" && (i.pointerId = i.identifier || 0),
            typeof i.pressure > "u" && (i.pressure = i.force || 0.5),
            typeof i.twist > "u" && (i.twist = 0),
            typeof i.tangentialPressure > "u" && (i.tangentialPressure = 0),
            typeof i.layerX > "u" && (i.layerX = i.offsetX = i.clientX),
            typeof i.layerY > "u" && (i.layerY = i.offsetY = i.clientY),
            (i.isNormalized = !0),
            (i.type = t.type),
            e.push(i);
        }
      else if (
        !globalThis.MouseEvent ||
        (t instanceof MouseEvent &&
          !(this.supportsPointerEvents && t instanceof globalThis.PointerEvent))
      ) {
        const r = t;
        typeof r.isPrimary > "u" && (r.isPrimary = !0),
          typeof r.width > "u" && (r.width = 1),
          typeof r.height > "u" && (r.height = 1),
          typeof r.tiltX > "u" && (r.tiltX = 0),
          typeof r.tiltY > "u" && (r.tiltY = 0),
          typeof r.pointerType > "u" && (r.pointerType = "mouse"),
          typeof r.pointerId > "u" && (r.pointerId = 1),
          typeof r.pressure > "u" && (r.pressure = 0.5),
          typeof r.twist > "u" && (r.twist = 0),
          typeof r.tangentialPressure > "u" && (r.tangentialPressure = 0),
          (r.isNormalized = !0),
          e.push(r);
      } else e.push(t);
      return e;
    }
    normalizeWheelEvent(t) {
      const e = this.rootWheelEvent;
      return (
        this.transferMouseData(e, t),
        (e.deltaX = t.deltaX),
        (e.deltaY = t.deltaY),
        (e.deltaZ = t.deltaZ),
        (e.deltaMode = t.deltaMode),
        this.mapPositionToPoint(e.screen, t.clientX, t.clientY),
        e.global.copyFrom(e.screen),
        e.offset.copyFrom(e.screen),
        (e.nativeEvent = t),
        (e.type = t.type),
        e
      );
    }
    bootstrapEvent(t, e) {
      return (
        (t.originalEvent = null),
        (t.nativeEvent = e),
        (t.pointerId = e.pointerId),
        (t.width = e.width),
        (t.height = e.height),
        (t.isPrimary = e.isPrimary),
        (t.pointerType = e.pointerType),
        (t.pressure = e.pressure),
        (t.tangentialPressure = e.tangentialPressure),
        (t.tiltX = e.tiltX),
        (t.tiltY = e.tiltY),
        (t.twist = e.twist),
        this.transferMouseData(t, e),
        this.mapPositionToPoint(t.screen, e.clientX, e.clientY),
        t.global.copyFrom(t.screen),
        t.offset.copyFrom(t.screen),
        (t.isTrusted = e.isTrusted),
        "pointerleave" === t.type && (t.type = "pointerout"),
        t.type.startsWith("mouse") &&
          (t.type = t.type.replace("mouse", "pointer")),
        t.type.startsWith("touch") && (t.type = $h[t.type] || t.type),
        t
      );
    }
    transferMouseData(t, e) {
      (t.isTrusted = e.isTrusted),
        (t.srcElement = e.srcElement),
        (t.timeStamp = performance.now()),
        (t.type = e.type),
        (t.altKey = e.altKey),
        (t.button = e.button),
        (t.buttons = e.buttons),
        (t.client.x = e.clientX),
        (t.client.y = e.clientY),
        (t.ctrlKey = e.ctrlKey),
        (t.metaKey = e.metaKey),
        (t.movement.x = e.movementX),
        (t.movement.y = e.movementY),
        (t.page.x = e.pageX),
        (t.page.y = e.pageY),
        (t.relatedTarget = null),
        (t.shiftKey = e.shiftKey);
    }
  };
(Yh.extension = {
  name: "events",
  type: [Gs.RendererSystem, Gs.CanvasRendererSystem],
}),
  (Yh.defaultEventFeatures = {
    move: !0,
    globalMove: !0,
    click: !0,
    wheel: !0,
  });
let qh = Yh;
kn.add(qh);
const Kh = {
  onclick: null,
  onmousedown: null,
  onmouseenter: null,
  onmouseleave: null,
  onmousemove: null,
  onglobalmousemove: null,
  onmouseout: null,
  onmouseover: null,
  onmouseup: null,
  onmouseupoutside: null,
  onpointercancel: null,
  onpointerdown: null,
  onpointerenter: null,
  onpointerleave: null,
  onpointermove: null,
  onglobalpointermove: null,
  onpointerout: null,
  onpointerover: null,
  onpointertap: null,
  onpointerup: null,
  onpointerupoutside: null,
  onrightclick: null,
  onrightdown: null,
  onrightup: null,
  onrightupoutside: null,
  ontap: null,
  ontouchcancel: null,
  ontouchend: null,
  ontouchendoutside: null,
  ontouchmove: null,
  onglobaltouchmove: null,
  ontouchstart: null,
  onwheel: null,
  _internalInteractive: void 0,
  get interactive() {
    return this._internalInteractive ?? vt(qh.defaultEventMode);
  },
  set interactive(t) {
    W(
      0,
      "Setting interactive is deprecated, use eventMode = 'none'/'passive'/'auto'/'static'/'dynamic' instead."
    ),
      (this._internalInteractive = t),
      (this.eventMode = t ? "static" : "auto");
  },
  _internalEventMode: void 0,
  get eventMode() {
    return this._internalEventMode ?? qh.defaultEventMode;
  },
  set eventMode(t) {
    (this._internalInteractive = vt(t)), (this._internalEventMode = t);
  },
  isInteractive() {
    return "static" === this.eventMode || "dynamic" === this.eventMode;
  },
  interactiveChildren: !0,
  hitArea: null,
  addEventListener(t, e, r) {
    const i = "function" == typeof e ? void 0 : e;
    (t =
      ("boolean" == typeof r && r) || ("object" == typeof r && r.capture)
        ? `${t}capture`
        : t),
      (e = "function" == typeof e ? e : e.handleEvent),
      this.on(t, e, i);
  },
  removeEventListener(t, e, r) {
    const i = "function" == typeof e ? void 0 : e;
    (t =
      ("boolean" == typeof r && r) || ("object" == typeof r && r.capture)
        ? `${t}capture`
        : t),
      (e = "function" == typeof e ? e : e.handleEvent),
      this.off(t, e, i);
  },
  dispatchEvent(t) {
    if (!(t instanceof Gh))
      throw new Error(
        "DisplayObject cannot propagate events outside of the Federated Events API"
      );
    return (
      (t.defaultPrevented = !1),
      (t.path = null),
      (t.target = this),
      t.manager.dispatchEvent(t),
      !t.defaultPrevented
    );
  },
};
Ah.mixin(Kh),
  Ah.mixin({
    accessible: !1,
    accessibleTitle: null,
    accessibleHint: null,
    tabIndex: 0,
    _accessibleActive: !1,
    _accessibleDiv: null,
    accessibleType: "button",
    accessiblePointerEvents: "auto",
    accessibleChildren: !0,
    renderId: -1,
  });
class Zh {
  constructor(t) {
    (this.debug = !1),
      (this._isActive = !1),
      (this._isMobileAccessibility = !1),
      (this.pool = []),
      (this.renderId = 0),
      (this.children = []),
      (this.androidUpdateCount = 0),
      (this.androidUpdateFrequency = 500),
      (this._hookDiv = null),
      (yn.tablet || yn.phone) && this.createTouchHook();
    const e = document.createElement("div");
    (e.style.width = "100px"),
      (e.style.height = "100px"),
      (e.style.position = "absolute"),
      (e.style.top = "0px"),
      (e.style.left = "0px"),
      (e.style.zIndex = (2).toString()),
      (this.div = e),
      (this.renderer = t),
      (this._onKeyDown = this._onKeyDown.bind(this)),
      (this._onMouseMove = this._onMouseMove.bind(this)),
      globalThis.addEventListener("keydown", this._onKeyDown, !1);
  }
  get isActive() {
    return this._isActive;
  }
  get isMobileAccessibility() {
    return this._isMobileAccessibility;
  }
  createTouchHook() {
    const t = document.createElement("button");
    (t.style.width = "1px"),
      (t.style.height = "1px"),
      (t.style.position = "absolute"),
      (t.style.top = "-1000px"),
      (t.style.left = "-1000px"),
      (t.style.zIndex = (2).toString()),
      (t.style.backgroundColor = "#FF0000"),
      (t.title = "select to enable accessibility for this content"),
      t.addEventListener("focus", () => {
        (this._isMobileAccessibility = !0),
          this.activate(),
          this.destroyTouchHook();
      }),
      document.body.appendChild(t),
      (this._hookDiv = t);
  }
  destroyTouchHook() {
    this._hookDiv &&
      (document.body.removeChild(this._hookDiv), (this._hookDiv = null));
  }
  activate() {
    var t;
    this._isActive ||
      ((this._isActive = !0),
      globalThis.document.addEventListener("mousemove", this._onMouseMove, !0),
      globalThis.removeEventListener("keydown", this._onKeyDown, !1),
      this.renderer.on("postrender", this.update, this),
      null == (t = this.renderer.view.parentNode) || t.appendChild(this.div));
  }
  deactivate() {
    var t;
    !this._isActive ||
      this._isMobileAccessibility ||
      ((this._isActive = !1),
      globalThis.document.removeEventListener(
        "mousemove",
        this._onMouseMove,
        !0
      ),
      globalThis.addEventListener("keydown", this._onKeyDown, !1),
      this.renderer.off("postrender", this.update),
      null == (t = this.div.parentNode) || t.removeChild(this.div));
  }
  updateAccessibleObjects(t) {
    if (!t.visible || !t.accessibleChildren) return;
    t.accessible &&
      t.isInteractive() &&
      (t._accessibleActive || this.addChild(t), (t.renderId = this.renderId));
    const e = t.children;
    if (e)
      for (let r = 0; r < e.length; r++) this.updateAccessibleObjects(e[r]);
  }
  update() {
    const t = performance.now();
    if (
      (yn.android.device && t < this.androidUpdateCount) ||
      ((this.androidUpdateCount = t + this.androidUpdateFrequency),
      !this.renderer.renderingToScreen)
    )
      return;
    this.renderer.lastObjectRendered &&
      this.updateAccessibleObjects(this.renderer.lastObjectRendered);
    const {
        x: e,
        y: r,
        width: i,
        height: s,
      } = this.renderer.view.getBoundingClientRect(),
      { width: n, height: o, resolution: a } = this.renderer,
      h = (i / n) * a,
      l = (s / o) * a;
    let u = this.div;
    (u.style.left = `${e}px`),
      (u.style.top = `${r}px`),
      (u.style.width = `${n}px`),
      (u.style.height = `${o}px`);
    for (let c = 0; c < this.children.length; c++) {
      const t = this.children[c];
      if (t.renderId !== this.renderId)
        (t._accessibleActive = !1),
          et(this.children, c, 1),
          this.div.removeChild(t._accessibleDiv),
          this.pool.push(t._accessibleDiv),
          (t._accessibleDiv = null),
          c--;
      else {
        u = t._accessibleDiv;
        let e = t.hitArea;
        const r = t.worldTransform;
        t.hitArea
          ? ((u.style.left = (r.tx + e.x * r.a) * h + "px"),
            (u.style.top = (r.ty + e.y * r.d) * l + "px"),
            (u.style.width = e.width * r.a * h + "px"),
            (u.style.height = e.height * r.d * l + "px"))
          : ((e = t.getBounds()),
            this.capHitArea(e),
            (u.style.left = e.x * h + "px"),
            (u.style.top = e.y * l + "px"),
            (u.style.width = e.width * h + "px"),
            (u.style.height = e.height * l + "px"),
            u.title !== t.accessibleTitle &&
              null !== t.accessibleTitle &&
              (u.title = t.accessibleTitle),
            u.getAttribute("aria-label") !== t.accessibleHint &&
              null !== t.accessibleHint &&
              u.setAttribute("aria-label", t.accessibleHint)),
          (t.accessibleTitle !== u.title || t.tabIndex !== u.tabIndex) &&
            ((u.title = t.accessibleTitle),
            (u.tabIndex = t.tabIndex),
            this.debug && this.updateDebugHTML(u));
      }
    }
    this.renderId++;
  }
  updateDebugHTML(t) {
    t.innerHTML = `type: ${t.type}</br> title : ${t.title}</br> tabIndex: ${t.tabIndex}`;
  }
  capHitArea(t) {
    t.x < 0 && ((t.width += t.x), (t.x = 0)),
      t.y < 0 && ((t.height += t.y), (t.y = 0));
    const { width: e, height: r } = this.renderer;
    t.x + t.width > e && (t.width = e - t.x),
      t.y + t.height > r && (t.height = r - t.y);
  }
  addChild(t) {
    let e = this.pool.pop();
    e ||
      ((e = document.createElement("button")),
      (e.style.width = "100px"),
      (e.style.height = "100px"),
      (e.style.backgroundColor = this.debug
        ? "rgba(255,255,255,0.5)"
        : "transparent"),
      (e.style.position = "absolute"),
      (e.style.zIndex = (2).toString()),
      (e.style.borderStyle = "none"),
      navigator.userAgent.toLowerCase().includes("chrome")
        ? e.setAttribute("aria-live", "off")
        : e.setAttribute("aria-live", "polite"),
      navigator.userAgent.match(/rv:.*Gecko\//)
        ? e.setAttribute("aria-relevant", "additions")
        : e.setAttribute("aria-relevant", "text"),
      e.addEventListener("click", this._onClick.bind(this)),
      e.addEventListener("focus", this._onFocus.bind(this)),
      e.addEventListener("focusout", this._onFocusOut.bind(this))),
      (e.style.pointerEvents = t.accessiblePointerEvents),
      (e.type = t.accessibleType),
      t.accessibleTitle && null !== t.accessibleTitle
        ? (e.title = t.accessibleTitle)
        : (!t.accessibleHint || null === t.accessibleHint) &&
          (e.title = `displayObject ${t.tabIndex}`),
      t.accessibleHint &&
        null !== t.accessibleHint &&
        e.setAttribute("aria-label", t.accessibleHint),
      this.debug && this.updateDebugHTML(e),
      (t._accessibleActive = !0),
      (t._accessibleDiv = e),
      (e.displayObject = t),
      this.children.push(t),
      this.div.appendChild(t._accessibleDiv),
      (t._accessibleDiv.tabIndex = t.tabIndex);
  }
  _dispatchEvent(t, e) {
    const { displayObject: r } = t.target,
      i = this.renderer.events.rootBoundary,
      s = Object.assign(new Gh(i), { target: r });
    (i.rootTarget = this.renderer.lastObjectRendered),
      e.forEach((t) => i.dispatchEvent(s, t));
  }
  _onClick(t) {
    this._dispatchEvent(t, ["click", "pointertap", "tap"]);
  }
  _onFocus(t) {
    t.target.getAttribute("aria-live") ||
      t.target.setAttribute("aria-live", "assertive"),
      this._dispatchEvent(t, ["mouseover"]);
  }
  _onFocusOut(t) {
    t.target.getAttribute("aria-live") ||
      t.target.setAttribute("aria-live", "polite"),
      this._dispatchEvent(t, ["mouseout"]);
  }
  _onKeyDown(t) {
    9 === t.keyCode && this.activate();
  }
  _onMouseMove(t) {
    (0 === t.movementX && 0 === t.movementY) || this.deactivate();
  }
  destroy() {
    this.destroyTouchHook(),
      (this.div = null),
      globalThis.document.removeEventListener(
        "mousemove",
        this._onMouseMove,
        !0
      ),
      globalThis.removeEventListener("keydown", this._onKeyDown),
      (this.pool = null),
      (this.children = null),
      (this.renderer = null);
  }
}
(Zh.extension = {
  name: "accessibility",
  type: [Gs.RendererPlugin, Gs.CanvasRendererPlugin],
}),
  kn.add(Zh);
const Qh = class t {
  constructor(e) {
    (this.stage = new Ih()),
      (e = Object.assign({ forceCanvas: !1 }, e)),
      (this.renderer = (function (t) {
        for (const e of ah) if (e.test(t)) return new e(t);
        throw new Error("Unable to auto-detect a suitable renderer.");
      })(e)),
      t._plugins.forEach((t) => {
        t.init.call(this, e);
      });
  }
  render() {
    this.renderer.render(this.stage);
  }
  get view() {
    var t;
    return null == (t = this.renderer) ? void 0 : t.view;
  }
  get screen() {
    var t;
    return null == (t = this.renderer) ? void 0 : t.screen;
  }
  destroy(e, r) {
    const i = t._plugins.slice(0);
    i.reverse(),
      i.forEach((t) => {
        t.destroy.call(this);
      }),
      this.stage.destroy(r),
      (this.stage = null),
      this.renderer.destroy(e),
      (this.renderer = null);
  }
};
Qh._plugins = [];
let Jh = Qh;
kn.handleByList(Gs.Application, Jh._plugins);
class tl {
  static init(t) {
    Object.defineProperty(this, "resizeTo", {
      set(t) {
        globalThis.removeEventListener("resize", this.queueResize),
          (this._resizeTo = t),
          t &&
            (globalThis.addEventListener("resize", this.queueResize),
            this.resize());
      },
      get() {
        return this._resizeTo;
      },
    }),
      (this.queueResize = () => {
        this._resizeTo &&
          (this.cancelResize(),
          (this._resizeId = requestAnimationFrame(() => this.resize())));
      }),
      (this.cancelResize = () => {
        this._resizeId &&
          (cancelAnimationFrame(this._resizeId), (this._resizeId = null));
      }),
      (this.resize = () => {
        if (!this._resizeTo) return;
        let t, e;
        if ((this.cancelResize(), this._resizeTo === globalThis.window))
          (t = globalThis.innerWidth), (e = globalThis.innerHeight);
        else {
          const { clientWidth: r, clientHeight: i } = this._resizeTo;
          (t = r), (e = i);
        }
        this.renderer.resize(t, e), this.render();
      }),
      (this._resizeId = null),
      (this._resizeTo = null),
      (this.resizeTo = t.resizeTo || null);
  }
  static destroy() {
    globalThis.removeEventListener("resize", this.queueResize),
      this.cancelResize(),
      (this.cancelResize = null),
      (this.queueResize = null),
      (this.resizeTo = null),
      (this.resize = null);
  }
}
(tl.extension = Gs.Application), kn.add(tl);
const el = {
  loader: Gs.LoadParser,
  resolver: Gs.ResolveParser,
  cache: Gs.CacheParser,
  detection: Gs.DetectionParser,
};
kn.handle(
  Gs.Asset,
  (t) => {
    const e = t.ref;
    Object.entries(el)
      .filter(([t]) => !!e[t])
      .forEach(([t, r]) =>
        kn.add(Object.assign(e[t], { extension: e[t].extension ?? r }))
      );
  },
  (t) => {
    const e = t.ref;
    Object.keys(el)
      .filter((t) => !!e[t])
      .forEach((t) => kn.remove(e[t]));
  }
);
class rl {
  constructor(t, e = !1) {
    (this._loader = t),
      (this._assetList = []),
      (this._isLoading = !1),
      (this._maxConcurrent = 1),
      (this.verbose = e);
  }
  add(t) {
    t.forEach((t) => {
      this._assetList.push(t);
    }),
      this.verbose,
      this._isActive && !this._isLoading && this._next();
  }
  async _next() {
    if (this._assetList.length && this._isActive) {
      this._isLoading = !0;
      const t = [],
        e = Math.min(this._assetList.length, this._maxConcurrent);
      for (let r = 0; r < e; r++) t.push(this._assetList.pop());
      await this._loader.load(t), (this._isLoading = !1), this._next();
    }
  }
  get active() {
    return this._isActive;
  }
  set active(t) {
    this._isActive !== t &&
      ((this._isActive = t), t && !this._isLoading && this._next());
  }
}
const il = (t, e, r = !1) => (
    Array.isArray(t) || (t = [t]),
    e ? t.map((t) => ("string" == typeof t || r ? e(t) : t)) : t
  ),
  sl = (t, e) => {
    const r = e.split("?")[1];
    return r && (t += `?${r}`), t;
  },
  nl = (t) => !Array.isArray(t),
  ol = new (class {
    constructor() {
      (this._parsers = []),
        (this._cache = new Map()),
        (this._cacheMap = new Map());
    }
    reset() {
      this._cacheMap.clear(), this._cache.clear();
    }
    has(t) {
      return this._cache.has(t);
    }
    get(t) {
      return this._cache.get(t);
    }
    set(t, e) {
      const r = il(t);
      let i;
      for (let o = 0; o < this.parsers.length; o++) {
        const t = this.parsers[o];
        if (t.test(e)) {
          i = t.getCacheableAssets(r, e);
          break;
        }
      }
      i ||
        ((i = {}),
        r.forEach((t) => {
          i[t] = e;
        }));
      const s = Object.keys(i),
        n = { cacheKeys: s, keys: r };
      if (
        (r.forEach((t) => {
          this._cacheMap.set(t, n);
        }),
        s.forEach((t) => {
          this._cache.has(t) && this._cache.get(t), this._cache.set(t, i[t]);
        }),
        e instanceof ha)
      ) {
        const t = e;
        r.forEach((e) => {
          t.baseTexture !== ha.EMPTY.baseTexture &&
            Yn.addToCache(t.baseTexture, e),
            ha.addToCache(t, e);
        });
      }
    }
    remove(t) {
      if (!this._cacheMap.has(t)) return;
      const e = this._cacheMap.get(t);
      e.cacheKeys.forEach((t) => {
        this._cache.delete(t);
      }),
        e.keys.forEach((t) => {
          this._cacheMap.delete(t);
        });
    }
    get parsers() {
      return this._parsers;
    }
  })();
class al {
  constructor() {
    (this._parsers = []),
      (this._parsersValidated = !1),
      (this.parsers = new Proxy(this._parsers, {
        set: (t, e, r) => ((this._parsersValidated = !1), (t[e] = r), !0),
      })),
      (this.promiseCache = {});
  }
  reset() {
    (this._parsersValidated = !1), (this.promiseCache = {});
  }
  _getLoadPromiseAndParser(t, e) {
    const r = { promise: null, parser: null };
    return (
      (r.promise = (async () => {
        var i, s;
        let n = null,
          o = null;
        if ((e.loadParser && (o = this._parserHash[e.loadParser]), !o)) {
          for (let r = 0; r < this.parsers.length; r++) {
            const s = this.parsers[r];
            if (
              s.load &&
              (null == (i = s.test) ? void 0 : i.call(s, t, e, this))
            ) {
              o = s;
              break;
            }
          }
          if (!o) return null;
        }
        (n = await o.load(t, e, this)), (r.parser = o);
        for (let t = 0; t < this.parsers.length; t++) {
          const i = this.parsers[t];
          i.parse &&
            i.parse &&
            (await (null == (s = i.testParse)
              ? void 0
              : s.call(i, n, e, this))) &&
            ((n = (await i.parse(n, e, this)) || n), (r.parser = i));
        }
        return n;
      })()),
      r
    );
  }
  async load(t, e) {
    this._parsersValidated || this._validateParsers();
    let r = 0;
    const i = {},
      s = nl(t),
      n = il(t, (t) => ({ alias: [t], src: t })),
      o = n.length,
      a = n.map(async (t) => {
        const s = Tn.toAbsolute(t.src);
        if (!i[t.src])
          try {
            this.promiseCache[s] ||
              (this.promiseCache[s] = this._getLoadPromiseAndParser(s, t)),
              (i[t.src] = await this.promiseCache[s].promise),
              e && e(++r / o);
          } catch (fc) {
            throw (
              (delete this.promiseCache[s],
              delete i[t.src],
              new Error(`[Loader.load] Failed to load ${s}.\n${fc}`))
            );
          }
      });
    return await Promise.all(a), s ? i[n[0].src] : i;
  }
  async unload(t) {
    const e = il(t, (t) => ({ alias: [t], src: t })).map(async (t) => {
      var e, r;
      const i = Tn.toAbsolute(t.src),
        s = this.promiseCache[i];
      if (s) {
        const n = await s.promise;
        delete this.promiseCache[i],
          null == (r = null == (e = s.parser) ? void 0 : e.unload) ||
            r.call(e, n, t, this);
      }
    });
    await Promise.all(e);
  }
  _validateParsers() {
    (this._parsersValidated = !0),
      (this._parserHash = this._parsers
        .filter((t) => t.name)
        .reduce((t, e) => (t[e.name], { ...t, [e.name]: e }), {}));
  }
}
Xs = ((t) => (
  (t[(t.Low = 0)] = "Low"),
  (t[(t.Normal = 1)] = "Normal"),
  (t[(t.High = 2)] = "High"),
  t
))(Xs || {});
const hl = {
  extension: { type: Gs.LoadParser, priority: Xs.Low },
  name: "loadJson",
  test: (t) => xt(t, "application/json") || bt(t, ".json"),
  load: async (t) => await (await _n.ADAPTER.fetch(t)).json(),
};
kn.add(hl);
const ll = {
  name: "loadTxt",
  extension: { type: Gs.LoadParser, priority: Xs.Low },
  test: (t) => xt(t, "text/plain") || bt(t, ".txt"),
  load: async (t) => await (await _n.ADAPTER.fetch(t)).text(),
};
kn.add(ll);
const ul = [
    "normal",
    "bold",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900",
  ],
  cl = [".ttf", ".otf", ".woff", ".woff2"],
  dl = ["font/ttf", "font/otf", "font/woff", "font/woff2"],
  pl = /^(--|-?[A-Z_])[0-9A-Z_-]*$/i,
  fl = {
    extension: { type: Gs.LoadParser, priority: Xs.Low },
    name: "loadWebFont",
    test: (t) => xt(t, dl) || bt(t, cl),
    async load(t, e) {
      var r, i, s;
      const n = _n.ADAPTER.getFontFaceSet();
      if (n) {
        const o = [],
          a =
            (null == (r = e.data) ? void 0 : r.family) ??
            (function (t) {
              const e = Tn.extname(t),
                r = Tn.basename(t, e)
                  .replace(/(-|_)/g, " ")
                  .toLowerCase()
                  .split(" ")
                  .map((t) => t.charAt(0).toUpperCase() + t.slice(1));
              let i = r.length > 0;
              for (const n of r)
                if (!n.match(pl)) {
                  i = !1;
                  break;
                }
              let s = r.join(" ");
              return i || (s = `"${s.replace(/[\\"]/g, "\\$&")}"`), s;
            })(t),
          h = (null == (s = null == (i = e.data) ? void 0 : i.weights)
            ? void 0
            : s.filter((t) => ul.includes(t))) ?? ["normal"],
          l = e.data ?? {};
        for (let e = 0; e < h.length; e++) {
          const r = h[e],
            i = new FontFace(a, `url(${encodeURI(t)})`, { ...l, weight: r });
          await i.load(), n.add(i), o.push(i);
        }
        return 1 === o.length ? o[0] : o;
      }
      return null;
    },
    unload(t) {
      (Array.isArray(t) ? t : [t]).forEach((t) =>
        _n.ADAPTER.getFontFaceSet().delete(t)
      );
    },
  };
kn.add(fl);
let ml,
  gl,
  _l = 0;
const yl = new (class {
    constructor() {
      (this._initialized = !1),
        (this._createdWorkers = 0),
        (this.workerPool = []),
        (this.queue = []),
        (this.resolveHash = {});
    }
    isImageBitmapSupported() {
      return (
        void 0 !== this._isImageBitmapSupported ||
          (this._isImageBitmapSupported = new Promise((t) => {
            const e = URL.createObjectURL(
                new Blob(
                  [
                    "\n    async function checkImageBitmap()\n    {\n        try\n        {\n            if (typeof createImageBitmap !== 'function') return false;\n\n            const response = await fetch('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=');\n            const imageBlob =  await response.blob();\n            const imageBitmap = await createImageBitmap(imageBlob);\n\n            return imageBitmap.width === 1 && imageBitmap.height === 1;\n        }\n        catch (e)\n        {\n            return false;\n        }\n    }\n    checkImageBitmap().then((result) => { self.postMessage(result); });\n    ",
                  ],
                  { type: "application/javascript" }
                )
              ),
              r = new Worker(e);
            r.addEventListener("message", (i) => {
              r.terminate(), URL.revokeObjectURL(e), t(i.data);
            });
          })),
        this._isImageBitmapSupported
      );
    }
    loadImageBitmap(t) {
      return this._run("loadImageBitmap", [t]);
    }
    async _initWorkers() {
      this._initialized || (this._initialized = !0);
    }
    getWorker() {
      void 0 === ml && (ml = navigator.hardwareConcurrency || 4);
      let t = this.workerPool.pop();
      return (
        !t &&
          this._createdWorkers < ml &&
          (gl ||
            (gl = URL.createObjectURL(
              new Blob(
                [
                  "\n    async function loadImageBitmap(url)\n    {\n        const response = await fetch(url);\n\n        if (!response.ok)\n        {\n            throw new Error(`[WorkerManager.loadImageBitmap] Failed to fetch ${url}: `\n                + `${response.status} ${response.statusText}`);\n        }\n\n        const imageBlob =  await response.blob();\n        const imageBitmap = await createImageBitmap(imageBlob);\n\n        return imageBitmap;\n    }\n    self.onmessage = async (event) =>\n    {\n        try\n        {\n            const imageBitmap = await loadImageBitmap(event.data.data[0]);\n\n            self.postMessage({\n                data: imageBitmap,\n                uuid: event.data.uuid,\n                id: event.data.id,\n            }, [imageBitmap]);\n        }\n        catch(e)\n        {\n            self.postMessage({\n                error: e,\n                uuid: event.data.uuid,\n                id: event.data.id,\n            });\n        }\n    };",
                ],
                { type: "application/javascript" }
              )
            )),
          this._createdWorkers++,
          (t = new Worker(gl)),
          t.addEventListener("message", (t) => {
            this.complete(t.data), this.returnWorker(t.target), this.next();
          })),
        t
      );
    }
    returnWorker(t) {
      this.workerPool.push(t);
    }
    complete(t) {
      void 0 !== t.error
        ? this.resolveHash[t.uuid].reject(t.error)
        : this.resolveHash[t.uuid].resolve(t.data),
        (this.resolveHash[t.uuid] = null);
    }
    async _run(t, e) {
      await this._initWorkers();
      const r = new Promise((r, i) => {
        this.queue.push({ id: t, arguments: e, resolve: r, reject: i });
      });
      return this.next(), r;
    }
    next() {
      if (!this.queue.length) return;
      const t = this.getWorker();
      if (!t) return;
      const e = this.queue.pop(),
        r = e.id;
      (this.resolveHash[_l] = { resolve: e.resolve, reject: e.reject }),
        t.postMessage({ data: e.arguments, uuid: _l++, id: r });
    }
  })(),
  vl = [".jpeg", ".jpg", ".png", ".webp", ".avif"],
  xl = ["image/jpeg", "image/png", "image/webp", "image/avif"],
  bl = {
    name: "loadTextures",
    extension: { type: Gs.LoadParser, priority: Xs.High },
    config: {
      preferWorkers: !0,
      preferCreateImageBitmap: !0,
      crossOrigin: "anonymous",
    },
    test: (t) => xt(t, xl) || bt(t, vl),
    async load(t, e, r) {
      var i;
      const s =
        globalThis.createImageBitmap && this.config.preferCreateImageBitmap;
      let n;
      n = s
        ? this.config.preferWorkers && (await yl.isImageBitmapSupported())
          ? await yl.loadImageBitmap(t)
          : await (async function (t) {
              const e = await _n.ADAPTER.fetch(t);
              if (!e.ok)
                throw new Error(
                  `[loadImageBitmap] Failed to fetch ${t}: ${e.status} ${e.statusText}`
                );
              const r = await e.blob();
              return await createImageBitmap(r);
            })(t)
        : await new Promise((e, r) => {
            const i = new Image();
            (i.crossOrigin = this.config.crossOrigin),
              (i.src = t),
              i.complete
                ? e(i)
                : ((i.onload = () => e(i)), (i.onerror = (t) => r(t)));
          });
      const o = { ...e.data };
      o.resolution ?? (o.resolution = ot(t)),
        s &&
          void 0 ===
            (null == (i = o.resourceOptions) ? void 0 : i.ownsImageBitmap) &&
          ((o.resourceOptions = { ...o.resourceOptions }),
          (o.resourceOptions.ownsImageBitmap = !0));
      const a = new Yn(n, o);
      return (a.resource.src = t), At(a, r, t);
    },
    unload(t) {
      t.destroy(!0);
    },
  };
kn.add(bl);
const El = {
  extension: { type: Gs.LoadParser, priority: Xs.High },
  name: "loadSVG",
  test: (t) => xt(t, "image/svg+xml") || bt(t, ".svg"),
  testParse: async (t) => xh.test(t),
  async parse(t, e, r) {
    var i;
    const s = new xh(
      t,
      null == (i = null == e ? void 0 : e.data) ? void 0 : i.resourceOptions
    );
    await s.load();
    const n = new Yn(s, {
      resolution: ot(t),
      ...(null == e ? void 0 : e.data),
    });
    return (n.resource.src = e.src), At(n, r, e.src);
  },
  load: async (t, e) => (await _n.ADAPTER.fetch(t)).text(),
  unload: bl.unload,
};
kn.add(El);
const Tl = [".mp4", ".m4v", ".webm", ".ogv"],
  Al = ["video/mp4", "video/webm", "video/ogg"],
  wl = {
    name: "loadVideo",
    extension: { type: Gs.LoadParser, priority: Xs.High },
    config: { defaultAutoPlay: !0 },
    test: (t) => xt(t, Al) || bt(t, Tl),
    async load(t, e, r) {
      var i;
      let s;
      const n = await (await _n.ADAPTER.fetch(t)).blob(),
        o = URL.createObjectURL(n);
      try {
        const n = {
            autoPlay: this.config.defaultAutoPlay,
            ...(null == (i = null == e ? void 0 : e.data)
              ? void 0
              : i.resourceOptions),
          },
          a = new Eh(o, n);
        await a.load();
        const h = new Yn(a, {
          alphaMode: await q(),
          resolution: ot(t),
          ...(null == e ? void 0 : e.data),
        });
        (h.resource.src = t),
          (s = At(h, r, t)),
          s.baseTexture.once("destroyed", () => {
            URL.revokeObjectURL(o);
          });
      } catch (fc) {
        throw (URL.revokeObjectURL(o), fc);
      }
      return s;
    },
    unload(t) {
      t.destroy(!0);
    },
  };
kn.add(wl);
class Sl {
  constructor() {
    (this._defaultBundleIdentifierOptions = {
      connector: "-",
      createBundleAssetId: (t, e) => `${t}${this._bundleIdConnector}${e}`,
      extractAssetIdFromBundle: (t, e) =>
        e.replace(`${t}${this._bundleIdConnector}`, ""),
    }),
      (this._bundleIdConnector =
        this._defaultBundleIdentifierOptions.connector),
      (this._createBundleAssetId =
        this._defaultBundleIdentifierOptions.createBundleAssetId),
      (this._extractAssetIdFromBundle =
        this._defaultBundleIdentifierOptions.extractAssetIdFromBundle),
      (this._assetMap = {}),
      (this._preferredOrder = []),
      (this._parsers = []),
      (this._resolverHash = {}),
      (this._bundles = {});
  }
  setBundleIdentifier(t) {
    if (
      ((this._bundleIdConnector = t.connector ?? this._bundleIdConnector),
      (this._createBundleAssetId =
        t.createBundleAssetId ?? this._createBundleAssetId),
      (this._extractAssetIdFromBundle =
        t.extractAssetIdFromBundle ?? this._extractAssetIdFromBundle),
      "bar" !==
        this._extractAssetIdFromBundle(
          "foo",
          this._createBundleAssetId("foo", "bar")
        ))
    )
      throw new Error(
        "[Resolver] GenerateBundleAssetId are not working correctly"
      );
  }
  prefer(...t) {
    t.forEach((t) => {
      this._preferredOrder.push(t),
        t.priority || (t.priority = Object.keys(t.params));
    }),
      (this._resolverHash = {});
  }
  set basePath(t) {
    this._basePath = t;
  }
  get basePath() {
    return this._basePath;
  }
  set rootPath(t) {
    this._rootPath = t;
  }
  get rootPath() {
    return this._rootPath;
  }
  get parsers() {
    return this._parsers;
  }
  reset() {
    this.setBundleIdentifier(this._defaultBundleIdentifierOptions),
      (this._assetMap = {}),
      (this._preferredOrder = []),
      (this._resolverHash = {}),
      (this._rootPath = null),
      (this._basePath = null),
      (this._manifest = null),
      (this._bundles = {}),
      (this._defaultSearchParams = null);
  }
  setDefaultSearchParams(t) {
    if ("string" == typeof t) this._defaultSearchParams = t;
    else {
      const e = t;
      this._defaultSearchParams = Object.keys(e)
        .map((t) => `${encodeURIComponent(t)}=${encodeURIComponent(e[t])}`)
        .join("&");
    }
  }
  getAlias(t) {
    const { alias: e, name: r, src: i, srcs: s } = t;
    return il(
      e || r || i || s,
      (t) =>
        "string" == typeof t
          ? t
          : Array.isArray(t)
          ? t.map(
              (t) =>
                (null == t ? void 0 : t.src) ??
                (null == t ? void 0 : t.srcs) ??
                t
            )
          : (null == t ? void 0 : t.src) || (null == t ? void 0 : t.srcs)
          ? t.src ?? t.srcs
          : t,
      !0
    );
  }
  addManifest(t) {
    this._manifest,
      (this._manifest = t),
      t.bundles.forEach((t) => {
        this.addBundle(t.name, t.assets);
      });
  }
  addBundle(t, e) {
    const r = [];
    Array.isArray(e)
      ? e.forEach((e) => {
          const i = e.src ?? e.srcs,
            s = e.alias ?? e.name;
          let n;
          if ("string" == typeof s) {
            const e = this._createBundleAssetId(t, s);
            r.push(e), (n = [s, e]);
          } else {
            const e = s.map((e) => this._createBundleAssetId(t, e));
            r.push(...e), (n = [...s, ...e]);
          }
          this.add({ ...e, alias: n, src: i });
        })
      : Object.keys(e).forEach((i) => {
          const s = [i, this._createBundleAssetId(t, i)];
          if ("string" == typeof e[i]) this.add({ alias: s, src: e[i] });
          else if (Array.isArray(e[i])) this.add({ alias: s, src: e[i] });
          else {
            const t = e[i],
              r = t.src ?? t.srcs;
            this.add({ ...t, alias: s, src: Array.isArray(r) ? r : [r] });
          }
          r.push(...s);
        }),
      (this._bundles[t] = r);
  }
  add(t, e, r, i, s) {
    const n = [];
    let o;
    "string" == typeof t || (Array.isArray(t) && "string" == typeof t[0])
      ? (W(
          0,
          "Assets.add now uses an object instead of individual parameters.\nPlease use Assets.add({ alias, src, data, format, loadParser }) instead."
        ),
        n.push({ alias: t, src: e, data: r, format: i, loadParser: s }))
      : Array.isArray(t)
      ? n.push(...t)
      : n.push(t),
      (o = (t) => {
        this.hasKey(t);
      }),
      il(n).forEach((t) => {
        const { src: e, srcs: r } = t;
        let { data: i, format: s, loadParser: n } = t;
        const a = il(e || r).map((t) =>
            "string" == typeof t ? Tt(t) : Array.isArray(t) ? t : [t]
          ),
          h = this.getAlias(t);
        Array.isArray(h) ? h.forEach(o) : o(h);
        const l = [];
        a.forEach((t) => {
          t.forEach((t) => {
            let e = {};
            if ("object" != typeof t) {
              e.src = t;
              for (let r = 0; r < this._parsers.length; r++) {
                const i = this._parsers[r];
                if (i.test(t)) {
                  e = i.parse(t);
                  break;
                }
              }
            } else
              (i = t.data ?? i),
                (s = t.format ?? s),
                (n = t.loadParser ?? n),
                (e = { ...e, ...t });
            if (!h)
              throw new Error(
                `[Resolver] alias is undefined for this asset: ${e.src}`
              );
            (e = this.buildResolvedAsset(e, {
              aliases: h,
              data: i,
              format: s,
              loadParser: n,
            })),
              l.push(e);
          });
        }),
          h.forEach((t) => {
            this._assetMap[t] = l;
          });
      });
  }
  resolveBundle(t) {
    const e = nl(t);
    t = il(t);
    const r = {};
    return (
      t.forEach((t) => {
        const e = this._bundles[t];
        if (e) {
          const i = this.resolve(e),
            s = {};
          for (const e in i) {
            const r = i[e];
            s[this._extractAssetIdFromBundle(t, e)] = r;
          }
          r[t] = s;
        }
      }),
      e ? r[t[0]] : r
    );
  }
  resolveUrl(t) {
    const e = this.resolve(t);
    if ("string" != typeof t) {
      const t = {};
      for (const r in e) t[r] = e[r].src;
      return t;
    }
    return e.src;
  }
  resolve(t) {
    const e = nl(t);
    t = il(t);
    const r = {};
    return (
      t.forEach((t) => {
        if (!this._resolverHash[t])
          if (this._assetMap[t]) {
            let e = this._assetMap[t];
            const r = e[0],
              i = this._getPreferredOrder(e);
            null == i ||
              i.priority.forEach((t) => {
                i.params[t].forEach((r) => {
                  const i = e.filter((e) => !!e[t] && e[t] === r);
                  i.length && (e = i);
                });
              }),
              (this._resolverHash[t] = e[0] ?? r);
          } else
            this._resolverHash[t] = this.buildResolvedAsset(
              { alias: [t], src: t },
              {}
            );
        r[t] = this._resolverHash[t];
      }),
      e ? r[t[0]] : r
    );
  }
  hasKey(t) {
    return !!this._assetMap[t];
  }
  hasBundle(t) {
    return !!this._bundles[t];
  }
  _getPreferredOrder(t) {
    for (let e = 0; e < t.length; e++) {
      const e = t[0],
        r = this._preferredOrder.find((t) =>
          t.params.format.includes(e.format)
        );
      if (r) return r;
    }
    return this._preferredOrder[0];
  }
  _appendDefaultSearchParams(t) {
    return this._defaultSearchParams
      ? `${t}${/\?/.test(t) ? "&" : "?"}${this._defaultSearchParams}`
      : t;
  }
  buildResolvedAsset(t, e) {
    const { aliases: r, data: i, loadParser: s, format: n } = e;
    return (
      (this._basePath || this._rootPath) &&
        (t.src = Tn.toAbsolute(t.src, this._basePath, this._rootPath)),
      (t.alias = r ?? t.alias ?? [t.src]),
      (t.src = this._appendDefaultSearchParams(t.src)),
      (t.data = { ...(i || {}), ...t.data }),
      (t.loadParser = s ?? t.loadParser),
      (t.format = n ?? t.src.split(".").pop()),
      (t.srcs = t.src),
      (t.name = t.alias),
      t
    );
  }
}
const Rl = new (class {
  constructor() {
    (this._detections = []),
      (this._initialized = !1),
      (this.resolver = new Sl()),
      (this.loader = new al()),
      (this.cache = ol),
      (this._backgroundLoader = new rl(this.loader)),
      (this._backgroundLoader.active = !0),
      this.reset();
  }
  async init(t = {}) {
    var e, r;
    if (this._initialized) return;
    if (
      ((this._initialized = !0),
      t.defaultSearchParams &&
        this.resolver.setDefaultSearchParams(t.defaultSearchParams),
      t.basePath && (this.resolver.basePath = t.basePath),
      t.bundleIdentifier &&
        this.resolver.setBundleIdentifier(t.bundleIdentifier),
      t.manifest)
    ) {
      let e = t.manifest;
      "string" == typeof e && (e = await this.load(e)),
        this.resolver.addManifest(e);
    }
    const i = (null == (e = t.texturePreference) ? void 0 : e.resolution) ?? 1,
      s = "number" == typeof i ? [i] : i,
      n = await this._detectFormats({
        preferredFormats: null == (r = t.texturePreference) ? void 0 : r.format,
        skipDetections: t.skipDetections,
        detections: this._detections,
      });
    this.resolver.prefer({ params: { format: n, resolution: s } }),
      t.preferences && this.setPreferences(t.preferences);
  }
  add(t, e, r, i, s) {
    this.resolver.add(t, e, r, i, s);
  }
  async load(t, e) {
    this._initialized || (await this.init());
    const r = nl(t),
      i = il(t).map((t) => {
        if ("string" != typeof t) {
          const e = this.resolver.getAlias(t);
          return (
            e.some((t) => !this.resolver.hasKey(t)) && this.add(t),
            Array.isArray(e) ? e[0] : e
          );
        }
        return this.resolver.hasKey(t) || this.add({ alias: t, src: t }), t;
      }),
      s = this.resolver.resolve(i),
      n = await this._mapLoadToResolve(s, e);
    return r ? n[i[0]] : n;
  }
  addBundle(t, e) {
    this.resolver.addBundle(t, e);
  }
  async loadBundle(t, e) {
    this._initialized || (await this.init());
    let r = !1;
    "string" == typeof t && ((r = !0), (t = [t]));
    const i = this.resolver.resolveBundle(t),
      s = {},
      n = Object.keys(i);
    let o = 0,
      a = 0;
    const h = () => {
        null == e || e(++o / a);
      },
      l = n.map((t) => {
        const e = i[t];
        return (
          (a += Object.keys(e).length),
          this._mapLoadToResolve(e, h).then((e) => {
            s[t] = e;
          })
        );
      });
    return await Promise.all(l), r ? s[t[0]] : s;
  }
  async backgroundLoad(t) {
    this._initialized || (await this.init()), "string" == typeof t && (t = [t]);
    const e = this.resolver.resolve(t);
    this._backgroundLoader.add(Object.values(e));
  }
  async backgroundLoadBundle(t) {
    this._initialized || (await this.init()), "string" == typeof t && (t = [t]);
    const e = this.resolver.resolveBundle(t);
    Object.values(e).forEach((t) => {
      this._backgroundLoader.add(Object.values(t));
    });
  }
  reset() {
    this.resolver.reset(),
      this.loader.reset(),
      this.cache.reset(),
      (this._initialized = !1);
  }
  get(t) {
    if ("string" == typeof t) return ol.get(t);
    const e = {};
    for (let r = 0; r < t.length; r++) e[r] = ol.get(t[r]);
    return e;
  }
  async _mapLoadToResolve(t, e) {
    const r = Object.values(t),
      i = Object.keys(t);
    this._backgroundLoader.active = !1;
    const s = await this.loader.load(r, e);
    this._backgroundLoader.active = !0;
    const n = {};
    return (
      r.forEach((t, e) => {
        const r = s[t.src],
          o = [t.src];
        t.alias && o.push(...t.alias), (n[i[e]] = r), ol.set(o, r);
      }),
      n
    );
  }
  async unload(t) {
    this._initialized || (await this.init());
    const e = il(t).map((t) => ("string" != typeof t ? t.src : t)),
      r = this.resolver.resolve(e);
    await this._unloadFromResolved(r);
  }
  async unloadBundle(t) {
    this._initialized || (await this.init()), (t = il(t));
    const e = this.resolver.resolveBundle(t),
      r = Object.keys(e).map((t) => this._unloadFromResolved(e[t]));
    await Promise.all(r);
  }
  async _unloadFromResolved(t) {
    const e = Object.values(t);
    e.forEach((t) => {
      ol.remove(t.src);
    }),
      await this.loader.unload(e);
  }
  async _detectFormats(t) {
    let e = [];
    t.preferredFormats &&
      (e = Array.isArray(t.preferredFormats)
        ? t.preferredFormats
        : [t.preferredFormats]);
    for (const r of t.detections)
      t.skipDetections || (await r.test())
        ? (e = await r.add(e))
        : t.skipDetections || (e = await r.remove(e));
    return (e = e.filter((t, r) => e.indexOf(t) === r)), e;
  }
  get detections() {
    return this._detections;
  }
  get preferWorkers() {
    return bl.config.preferWorkers;
  }
  set preferWorkers(t) {
    W(
      0,
      "Assets.prefersWorkers is deprecated, use Assets.setPreferences({ preferWorkers: true }) instead."
    ),
      this.setPreferences({ preferWorkers: t });
  }
  setPreferences(t) {
    this.loader.parsers.forEach((e) => {
      e.config &&
        Object.keys(e.config)
          .filter((e) => e in t)
          .forEach((r) => {
            e.config[r] = t[r];
          });
    });
  }
})();
kn.handleByList(Gs.LoadParser, Rl.loader.parsers)
  .handleByList(Gs.ResolveParser, Rl.resolver.parsers)
  .handleByList(Gs.CacheParser, Rl.cache.parsers)
  .handleByList(Gs.DetectionParser, Rl.detections);
const Il = {
  extension: Gs.CacheParser,
  test: (t) => Array.isArray(t) && t.every((t) => t instanceof ha),
  getCacheableAssets: (t, e) => {
    const r = {};
    return (
      t.forEach((t) => {
        e.forEach((e, i) => {
          r[t + (0 === i ? "" : i + 1)] = e;
        });
      }),
      r
    );
  },
};
kn.add(Il);
const Cl = {
  extension: { type: Gs.DetectionParser, priority: 1 },
  test: async () =>
    new Promise((t) => {
      const e = new Image();
      (e.onload = () => {
        t(!0);
      }),
        (e.onerror = () => {
          t(!1);
        }),
        (e.src =
          "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAAB0AAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAIAAAACAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQ0MAAAAABNjb2xybmNseAACAAIAAYAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAACVtZGF0EgAKCBgANogQEAwgMg8f8D///8WfhwB8+ErK42A=");
    }),
  add: async (t) => [...t, "avif"],
  remove: async (t) => t.filter((t) => "avif" !== t),
};
kn.add(Cl);
const Pl = {
  extension: { type: Gs.DetectionParser, priority: 0 },
  test: async () =>
    new Promise((t) => {
      const e = new Image();
      (e.onload = () => {
        t(!0);
      }),
        (e.onerror = () => {
          t(!1);
        }),
        (e.src =
          "data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA=");
    }),
  add: async (t) => [...t, "webp"],
  remove: async (t) => t.filter((t) => "webp" !== t),
};
kn.add(Pl);
const Ml = ["png", "jpg", "jpeg"],
  Dl = {
    extension: { type: Gs.DetectionParser, priority: -1 },
    test: () => Promise.resolve(!0),
    add: async (t) => [...t, ...Ml],
    remove: async (t) => t.filter((t) => !Ml.includes(t)),
  };
kn.add(Dl);
const Ol =
    "WorkerGlobalScope" in globalThis &&
    globalThis instanceof globalThis.WorkerGlobalScope,
  Bl = {
    extension: { type: Gs.DetectionParser, priority: 0 },
    test: async () => wt("video/webm"),
    add: async (t) => [...t, "webm"],
    remove: async (t) => t.filter((t) => "webm" !== t),
  };
kn.add(Bl);
const Nl = {
  extension: { type: Gs.DetectionParser, priority: 0 },
  test: async () => wt("video/mp4"),
  add: async (t) => [...t, "mp4", "m4v"],
  remove: async (t) => t.filter((t) => "mp4" !== t && "m4v" !== t),
};
kn.add(Nl);
const Fl = {
  extension: { type: Gs.DetectionParser, priority: 0 },
  test: async () => wt("video/ogg"),
  add: async (t) => [...t, "ogv"],
  remove: async (t) => t.filter((t) => "ogv" !== t),
};
kn.add(Fl);
const Ll = {
  extension: Gs.ResolveParser,
  test: bl.test,
  parse: (t) => {
    var e;
    return {
      resolution: parseFloat(
        (null == (e = _n.RETINA_PREFIX.exec(t)) ? void 0 : e[1]) ?? "1"
      ),
      format: t.split(".").pop(),
      src: t,
    };
  },
};
kn.add(Ll),
  (Vs = ((t) => (
    (t[(t.COMPRESSED_RGB_S3TC_DXT1_EXT = 33776)] =
      "COMPRESSED_RGB_S3TC_DXT1_EXT"),
    (t[(t.COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777)] =
      "COMPRESSED_RGBA_S3TC_DXT1_EXT"),
    (t[(t.COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778)] =
      "COMPRESSED_RGBA_S3TC_DXT3_EXT"),
    (t[(t.COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779)] =
      "COMPRESSED_RGBA_S3TC_DXT5_EXT"),
    (t[(t.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = 35917)] =
      "COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT"),
    (t[(t.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = 35918)] =
      "COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT"),
    (t[(t.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = 35919)] =
      "COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT"),
    (t[(t.COMPRESSED_SRGB_S3TC_DXT1_EXT = 35916)] =
      "COMPRESSED_SRGB_S3TC_DXT1_EXT"),
    (t[(t.COMPRESSED_R11_EAC = 37488)] = "COMPRESSED_R11_EAC"),
    (t[(t.COMPRESSED_SIGNED_R11_EAC = 37489)] = "COMPRESSED_SIGNED_R11_EAC"),
    (t[(t.COMPRESSED_RG11_EAC = 37490)] = "COMPRESSED_RG11_EAC"),
    (t[(t.COMPRESSED_SIGNED_RG11_EAC = 37491)] = "COMPRESSED_SIGNED_RG11_EAC"),
    (t[(t.COMPRESSED_RGB8_ETC2 = 37492)] = "COMPRESSED_RGB8_ETC2"),
    (t[(t.COMPRESSED_RGBA8_ETC2_EAC = 37496)] = "COMPRESSED_RGBA8_ETC2_EAC"),
    (t[(t.COMPRESSED_SRGB8_ETC2 = 37493)] = "COMPRESSED_SRGB8_ETC2"),
    (t[(t.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = 37497)] =
      "COMPRESSED_SRGB8_ALPHA8_ETC2_EAC"),
    (t[(t.COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37494)] =
      "COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2"),
    (t[(t.COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37495)] =
      "COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2"),
    (t[(t.COMPRESSED_RGB_PVRTC_4BPPV1_IMG = 35840)] =
      "COMPRESSED_RGB_PVRTC_4BPPV1_IMG"),
    (t[(t.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG = 35842)] =
      "COMPRESSED_RGBA_PVRTC_4BPPV1_IMG"),
    (t[(t.COMPRESSED_RGB_PVRTC_2BPPV1_IMG = 35841)] =
      "COMPRESSED_RGB_PVRTC_2BPPV1_IMG"),
    (t[(t.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG = 35843)] =
      "COMPRESSED_RGBA_PVRTC_2BPPV1_IMG"),
    (t[(t.COMPRESSED_RGB_ETC1_WEBGL = 36196)] = "COMPRESSED_RGB_ETC1_WEBGL"),
    (t[(t.COMPRESSED_RGB_ATC_WEBGL = 35986)] = "COMPRESSED_RGB_ATC_WEBGL"),
    (t[(t.COMPRESSED_RGBA_ATC_EXPLICIT_ALPHA_WEBGL = 35986)] =
      "COMPRESSED_RGBA_ATC_EXPLICIT_ALPHA_WEBGL"),
    (t[(t.COMPRESSED_RGBA_ATC_INTERPOLATED_ALPHA_WEBGL = 34798)] =
      "COMPRESSED_RGBA_ATC_INTERPOLATED_ALPHA_WEBGL"),
    (t[(t.COMPRESSED_RGBA_ASTC_4x4_KHR = 37808)] =
      "COMPRESSED_RGBA_ASTC_4x4_KHR"),
    t
  ))(Vs || {}));
const kl = {
  33776: 0.5,
  33777: 0.5,
  33778: 1,
  33779: 1,
  35916: 0.5,
  35917: 0.5,
  35918: 1,
  35919: 1,
  37488: 0.5,
  37489: 0.5,
  37490: 1,
  37491: 1,
  37492: 0.5,
  37496: 1,
  37493: 0.5,
  37497: 1,
  37494: 0.5,
  37495: 0.5,
  35840: 0.5,
  35842: 0.5,
  35841: 0.25,
  35843: 0.25,
  36196: 0.5,
  35986: 0.5,
  35986: 1,
  34798: 1,
  37808: 1,
};
let Ul, Gl;
const Hl = {
  extension: { type: Gs.DetectionParser, priority: 2 },
  test: async () => {
    const t = _n.ADAPTER.createCanvas().getContext("webgl");
    return !!t && ((Ul = t), !0);
  },
  add: async (t) => {
    Gl || St();
    const e = [];
    for (const r in Gl) Gl[r] && e.push(r);
    return [...e, ...t];
  },
  remove: async (t) => (Gl || St(), t.filter((t) => !(t in Gl))),
};
kn.add(Hl);
class jl extends zn {
  constructor(t, e = { width: 1, height: 1, autoLoad: !0 }) {
    let r, i;
    "string" == typeof t
      ? ((r = t), (i = new Uint8Array()))
      : ((r = null), (i = t)),
      super(i, e),
      (this.origin = r),
      (this.buffer = i ? new Un(i) : null),
      (this._load = null),
      (this.loaded = !1),
      null !== this.origin && !1 !== e.autoLoad && this.load(),
      null === this.origin &&
        this.buffer &&
        ((this._load = Promise.resolve(this)),
        (this.loaded = !0),
        this.onBlobLoaded(this.buffer.rawBinaryData));
  }
  onBlobLoaded(t) {}
  load() {
    return (
      this._load ||
        (this._load = fetch(this.origin)
          .then((t) => t.blob())
          .then((t) => t.arrayBuffer())
          .then(
            (t) => (
              (this.data = new Uint32Array(t)),
              (this.buffer = new Un(t)),
              (this.loaded = !0),
              this.onBlobLoaded(t),
              this.update(),
              this
            )
          )),
      this._load
    );
  }
}
class Xl extends jl {
  constructor(t, e) {
    super(t, e),
      (this.format = e.format),
      (this.levels = e.levels || 1),
      (this._width = e.width),
      (this._height = e.height),
      (this._extension = Xl._formatToExtension(this.format)),
      (e.levelBuffers || this.buffer) &&
        (this._levelBuffers =
          e.levelBuffers ||
          Xl._createLevelBuffers(
            t instanceof Uint8Array ? t : this.buffer.uint8View,
            this.format,
            this.levels,
            4,
            4,
            this.width,
            this.height
          ));
  }
  upload(t, e, r) {
    const i = t.gl;
    if (!t.context.extensions[this._extension])
      throw new Error(
        `${this._extension} textures are not supported on the current machine`
      );
    if (!this._levelBuffers) return !1;
    i.pixelStorei(i.UNPACK_ALIGNMENT, 4);
    for (let s = 0, n = this.levels; s < n; s++) {
      const {
        levelID: t,
        levelWidth: e,
        levelHeight: r,
        levelBuffer: n,
      } = this._levelBuffers[s];
      i.compressedTexImage2D(i.TEXTURE_2D, t, this.format, e, r, 0, n);
    }
    return !0;
  }
  onBlobLoaded() {
    this._levelBuffers = Xl._createLevelBuffers(
      this.buffer.uint8View,
      this.format,
      this.levels,
      4,
      4,
      this.width,
      this.height
    );
  }
  static _formatToExtension(t) {
    if (t >= 33776 && t <= 33779) return "s3tc";
    if (t >= 37488 && t <= 37497) return "etc";
    if (t >= 35840 && t <= 35843) return "pvrtc";
    if (t >= 36196) return "etc1";
    if (t >= 35986 && t <= 34798) return "atc";
    throw new Error("Invalid (compressed) texture format given!");
  }
  static _createLevelBuffers(t, e, r, i, s, n, o) {
    const a = new Array(r);
    let h = t.byteOffset,
      l = n,
      u = o,
      c = (l + i - 1) & ~(i - 1),
      d = (u + s - 1) & ~(s - 1),
      p = c * d * kl[e];
    for (let f = 0; f < r; f++)
      (a[f] = {
        levelID: f,
        levelWidth: r > 1 ? l : c,
        levelHeight: r > 1 ? u : d,
        levelBuffer: new Uint8Array(t.buffer, h, p),
      }),
        (h += p),
        (l = l >> 1 || 1),
        (u = u >> 1 || 1),
        (c = (l + i - 1) & ~(i - 1)),
        (d = (u + s - 1) & ~(s - 1)),
        (p = c * d * kl[e]);
    return a;
  }
}
const Vl = {
    827611204: Vs.COMPRESSED_RGBA_S3TC_DXT1_EXT,
    861165636: Vs.COMPRESSED_RGBA_S3TC_DXT3_EXT,
    894720068: Vs.COMPRESSED_RGBA_S3TC_DXT5_EXT,
  },
  zl = {
    70: Vs.COMPRESSED_RGBA_S3TC_DXT1_EXT,
    71: Vs.COMPRESSED_RGBA_S3TC_DXT1_EXT,
    73: Vs.COMPRESSED_RGBA_S3TC_DXT3_EXT,
    74: Vs.COMPRESSED_RGBA_S3TC_DXT3_EXT,
    76: Vs.COMPRESSED_RGBA_S3TC_DXT5_EXT,
    77: Vs.COMPRESSED_RGBA_S3TC_DXT5_EXT,
    72: Vs.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT,
    75: Vs.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT,
    78: Vs.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT,
  },
  Wl = [171, 75, 84, 88, 32, 49, 49, 187, 13, 10, 26, 10],
  $l = {
    [nn.UNSIGNED_BYTE]: 1,
    [nn.UNSIGNED_SHORT]: 2,
    [nn.INT]: 4,
    [nn.UNSIGNED_INT]: 4,
    [nn.FLOAT]: 4,
    [nn.HALF_FLOAT]: 8,
  },
  Yl = {
    [rn.RGBA]: 4,
    [rn.RGB]: 3,
    [rn.RG]: 2,
    [rn.RED]: 1,
    [rn.LUMINANCE]: 1,
    [rn.LUMINANCE_ALPHA]: 2,
    [rn.ALPHA]: 1,
  },
  ql = {
    [nn.UNSIGNED_SHORT_4_4_4_4]: 2,
    [nn.UNSIGNED_SHORT_5_5_5_1]: 2,
    [nn.UNSIGNED_SHORT_5_6_5]: 2,
  },
  Kl = {
    extension: { type: Gs.LoadParser, priority: Xs.High },
    name: "loadDDS",
    test: (t) => bt(t, ".dds"),
    async load(t, e, r) {
      const i = (function (t) {
        const e = new Uint32Array(t);
        if (542327876 !== e[0]) throw new Error("Invalid DDS file magic word");
        const r = new Uint32Array(t, 0, 124 / Uint32Array.BYTES_PER_ELEMENT),
          i = r[3],
          s = r[4],
          n = r[7],
          o = new Uint32Array(
            t,
            19 * Uint32Array.BYTES_PER_ELEMENT,
            32 / Uint32Array.BYTES_PER_ELEMENT
          ),
          a = o[1];
        if (4 & a) {
          const r = o[2];
          if (808540228 !== r) {
            const e = Vl[r],
              o = new Uint8Array(t, 128);
            return [new Xl(o, { format: e, width: s, height: i, levels: n })];
          }
          const a = 128,
            h = new Uint32Array(
              e.buffer,
              a,
              20 / Uint32Array.BYTES_PER_ELEMENT
            ),
            l = h[0],
            u = h[1],
            c = h[2],
            d = h[3],
            p = zl[l];
          if (void 0 === p)
            throw new Error(
              `DDSParser cannot parse texture data with DXGI format ${l}`
            );
          if (4 === c)
            throw new Error("DDSParser does not support cubemap textures");
          if (6 === u)
            throw new Error("DDSParser does not supported 3D texture data");
          const f = new Array(),
            m = 148;
          if (1 === d) f.push(new Uint8Array(t, m));
          else {
            const e = kl[p];
            let r = 0,
              o = s,
              a = i;
            for (let t = 0; t < n; t++)
              (r += Math.max(1, (o + 3) & -4) * Math.max(1, (a + 3) & -4) * e),
                (o >>>= 1),
                (a >>>= 1);
            let h = m;
            for (let i = 0; i < d; i++)
              f.push(new Uint8Array(t, h, r)), (h += r);
          }
          return f.map(
            (t) => new Xl(t, { format: p, width: s, height: i, levels: n })
          );
        }
        throw 64 & a
          ? new Error("DDSParser does not support uncompressed texture data.")
          : 512 & a
          ? new Error(
              "DDSParser does not supported YUV uncompressed texture data."
            )
          : 131072 & a
          ? new Error(
              "DDSParser does not support single-channel (lumninance) texture data!"
            )
          : 2 & a
          ? new Error(
              "DDSParser does not support single-channel (alpha) texture data!"
            )
          : new Error(
              "DDSParser failed to load a texture file due to an unknown reason!"
            );
      })(await (await _n.ADAPTER.fetch(t)).arrayBuffer()).map((i) =>
        At(
          new Yn(i, {
            mipmap: ln.OFF,
            alphaMode: un.NO_PREMULTIPLIED_ALPHA,
            resolution: ot(t),
            ...e.data,
          }),
          r,
          t
        )
      );
      return 1 === i.length ? i[0] : i;
    },
    unload(t) {
      Array.isArray(t) ? t.forEach((t) => t.destroy(!0)) : t.destroy(!0);
    },
  };
kn.add(Kl);
const Zl = {
  extension: { type: Gs.LoadParser, priority: Xs.High },
  name: "loadKTX",
  test: (t) => bt(t, ".ktx"),
  async load(t, e, r) {
    const i = await (await _n.ADAPTER.fetch(t)).arrayBuffer(),
      {
        compressed: s,
        uncompressed: n,
        kvData: o,
      } = (function (t, e, r = !1) {
        const i = new DataView(e);
        if (
          !(function (t, e) {
            for (let r = 0; r < Wl.length; r++)
              if (e.getUint8(r) !== Wl[r]) return !1;
            return !0;
          })(0, i)
        )
          return null;
        const s = 67305985 === i.getUint32(12, !0),
          n = i.getUint32(16, s),
          o = i.getUint32(24, s),
          a = i.getUint32(28, s),
          h = i.getUint32(36, s),
          l = i.getUint32(40, s) || 1,
          u = i.getUint32(44, s) || 1,
          c = i.getUint32(48, s) || 1,
          d = i.getUint32(52, s),
          p = i.getUint32(56, s),
          f = i.getUint32(60, s);
        if (0 === l || 1 !== u)
          throw new Error("Only 2D textures are supported");
        if (1 !== d)
          throw new Error("CubeTextures are not supported by KTXLoader yet!");
        if (1 !== c) throw new Error("WebGL does not support array textures");
        const m = (h + 3) & -4,
          g = (l + 3) & -4,
          _ = new Array(c);
        let y,
          v = h * l;
        if (
          (0 === n && (v = m * g),
          (y = 0 !== n ? ($l[n] ? $l[n] * Yl[o] : ql[n]) : kl[a]),
          void 0 === y)
        )
          throw new Error(
            "Unable to resolve the pixel format stored in the *.ktx file!"
          );
        const x = r
          ? (function (t, e, r) {
              const i = new Map();
              let s = 0;
              for (; s < e; ) {
                const n = t.getUint32(64 + s, r),
                  o = 64 + s + 4,
                  a = 3 - ((n + 3) % 4);
                if (0 === n || n > e - s) break;
                let h = 0;
                for (; h < n && 0 !== t.getUint8(o + h); h++);
                if (-1 === h) break;
                const l = new TextDecoder().decode(
                    new Uint8Array(t.buffer, o, h)
                  ),
                  u = new DataView(t.buffer, o + h + 1, n - h - 1);
                i.set(l, u), (s += 4 + n + a);
              }
              return i;
            })(i, f, s)
          : null;
        let b = v * y,
          E = h,
          T = l,
          A = m,
          w = g,
          S = 64 + f;
        for (let R = 0; R < p; R++) {
          const t = i.getUint32(S, s);
          let r = S + 4;
          for (let i = 0; i < c; i++) {
            let t = _[i];
            t || (t = _[i] = new Array(p)),
              (t[R] = {
                levelID: R,
                levelWidth: p > 1 || 0 !== n ? E : A,
                levelHeight: p > 1 || 0 !== n ? T : w,
                levelBuffer: new Uint8Array(e, r, b),
              }),
              (r += b);
          }
          (S += t + 4),
            (S = S % 4 != 0 ? S + 4 - (S % 4) : S),
            (E = E >> 1 || 1),
            (T = T >> 1 || 1),
            (A = (E + 4 - 1) & -4),
            (w = (T + 4 - 1) & -4),
            (b = A * w * y);
        }
        return 0 !== n
          ? {
              uncompressed: _.map((t) => {
                let e = t[0].levelBuffer,
                  r = !1;
                return (
                  n === nn.FLOAT
                    ? (e = new Float32Array(
                        t[0].levelBuffer.buffer,
                        t[0].levelBuffer.byteOffset,
                        t[0].levelBuffer.byteLength / 4
                      ))
                    : n === nn.UNSIGNED_INT
                    ? ((r = !0),
                      (e = new Uint32Array(
                        t[0].levelBuffer.buffer,
                        t[0].levelBuffer.byteOffset,
                        t[0].levelBuffer.byteLength / 4
                      )))
                    : n === nn.INT &&
                      ((r = !0),
                      (e = new Int32Array(
                        t[0].levelBuffer.buffer,
                        t[0].levelBuffer.byteOffset,
                        t[0].levelBuffer.byteLength / 4
                      ))),
                  {
                    resource: new zn(e, {
                      width: t[0].levelWidth,
                      height: t[0].levelHeight,
                    }),
                    type: n,
                    format: r ? Rt(o) : o,
                  }
                );
              }),
              kvData: x,
            }
          : {
              compressed: _.map(
                (t) =>
                  new Xl(null, {
                    format: a,
                    width: h,
                    height: l,
                    levels: p,
                    levelBuffers: t,
                  })
              ),
              kvData: x,
            };
      })(0, i),
      a = s ?? n,
      h = {
        mipmap: ln.OFF,
        alphaMode: un.NO_PREMULTIPLIED_ALPHA,
        resolution: ot(t),
        ...e.data,
      },
      l = a.map((e) => {
        a === n && Object.assign(h, { type: e.type, format: e.format });
        const i = e.resource ?? e,
          s = new Yn(i, h);
        return (s.ktxKeyValueData = o), At(s, r, t);
      });
    return 1 === l.length ? l[0] : l;
  },
  unload(t) {
    Array.isArray(t) ? t.forEach((t) => t.destroy(!0)) : t.destroy(!0);
  },
};
kn.add(Zl);
const Ql = {
  extension: Gs.ResolveParser,
  test: (t) => {
    const e = t.split("?")[0].split(".").pop();
    return ["basis", "ktx", "dds"].includes(e);
  },
  parse: (t) => {
    var e, r;
    if ("ktx" === t.split("?")[0].split(".").pop()) {
      const r = [
        ".s3tc.ktx",
        ".s3tc_sRGB.ktx",
        ".etc.ktx",
        ".etc1.ktx",
        ".pvrt.ktx",
        ".atc.ktx",
        ".astc.ktx",
      ];
      if (r.some((e) => t.endsWith(e)))
        return {
          resolution: parseFloat(
            (null == (e = _n.RETINA_PREFIX.exec(t)) ? void 0 : e[1]) ?? "1"
          ),
          format: r.find((e) => t.endsWith(e)),
          src: t,
        };
    }
    return {
      resolution: parseFloat(
        (null == (r = _n.RETINA_PREFIX.exec(t)) ? void 0 : r[1]) ?? "1"
      ),
      format: t.split(".").pop(),
      src: t,
    };
  },
};
kn.add(Ql);
const Jl = new uo(),
  tu = class t {
    constructor(t) {
      (this.renderer = t), (this._rendererPremultipliedAlpha = !1);
    }
    contextChange() {
      var t;
      const e =
        null == (t = this.renderer) ? void 0 : t.gl.getContextAttributes();
      this._rendererPremultipliedAlpha = !!(
        e &&
        e.alpha &&
        e.premultipliedAlpha
      );
    }
    async image(t, e, r, i) {
      const s = new Image();
      return (s.src = await this.base64(t, e, r, i)), s;
    }
    async base64(t, e, r, i) {
      const s = this.canvas(t, i);
      if (void 0 !== s.toBlob)
        return new Promise((t, i) => {
          s.toBlob(
            (e) => {
              if (!e) return void i(new Error("ICanvas.toBlob failed!"));
              const r = new FileReader();
              (r.onload = () => t(r.result)),
                (r.onerror = i),
                r.readAsDataURL(e);
            },
            e,
            r
          );
        });
      if (void 0 !== s.toDataURL) return s.toDataURL(e, r);
      if (void 0 !== s.convertToBlob) {
        const t = await s.convertToBlob({ type: e, quality: r });
        return new Promise((e, r) => {
          const i = new FileReader();
          (i.onload = () => e(i.result)), (i.onerror = r), i.readAsDataURL(t);
        });
      }
      throw new Error(
        "Extract.base64() requires ICanvas.toDataURL, ICanvas.toBlob, or ICanvas.convertToBlob to be implemented"
      );
    }
    canvas(e, r) {
      const {
        pixels: i,
        width: s,
        height: n,
        flipY: o,
        premultipliedAlpha: a,
      } = this._rawPixels(e, r);
      o && t._flipY(i, s, n), a && t._unpremultiplyAlpha(i);
      const h = new Nn(s, n, 1),
        l = new ImageData(new Uint8ClampedArray(i.buffer), s, n);
      return h.context.putImageData(l, 0, 0), h.canvas;
    }
    pixels(e, r) {
      const {
        pixels: i,
        width: s,
        height: n,
        flipY: o,
        premultipliedAlpha: a,
      } = this._rawPixels(e, r);
      return o && t._flipY(i, s, n), a && t._unpremultiplyAlpha(i), i;
    }
    _rawPixels(t, e) {
      const r = this.renderer;
      if (!r) throw new Error("The Extract has already been destroyed");
      let i,
        s,
        n = !1,
        o = !1,
        a = !1;
      t &&
        (t instanceof la
          ? (s = t)
          : ((s = r.generateTexture(t, {
              region: e,
              resolution: r.resolution,
              multisample: r.multisample,
            })),
            (a = !0),
            e && ((Jl.width = e.width), (Jl.height = e.height), (e = Jl))));
      const h = r.gl;
      if (s) {
        if (
          ((i = s.baseTexture.resolution),
          (e = e ?? s.frame),
          (n = !1),
          (o = s.baseTexture.alphaMode > 0 && s.baseTexture.format === rn.RGBA),
          !a)
        ) {
          r.renderTexture.bind(s);
          const t = s.framebuffer.glFramebuffers[r.CONTEXT_UID];
          t.blitFramebuffer && r.framebuffer.bind(t.blitFramebuffer);
        }
      } else
        (i = r.resolution),
          e || (((e = Jl).width = r.width / i), (e.height = r.height / i)),
          (n = !0),
          (o = this._rendererPremultipliedAlpha),
          r.renderTexture.bind();
      const l = Math.max(Math.round(e.width * i), 1),
        u = Math.max(Math.round(e.height * i), 1),
        c = new Uint8Array(4 * l * u);
      return (
        h.readPixels(
          Math.round(e.x * i),
          Math.round(e.y * i),
          l,
          u,
          h.RGBA,
          h.UNSIGNED_BYTE,
          c
        ),
        a && (null == s || s.destroy(!0)),
        { pixels: c, width: l, height: u, flipY: n, premultipliedAlpha: o }
      );
    }
    destroy() {
      this.renderer = null;
    }
    static _flipY(t, e, r) {
      const i = e << 2,
        s = r >> 1,
        n = new Uint8Array(i);
      for (let o = 0; o < s; o++) {
        const e = o * i,
          s = (r - o - 1) * i;
        n.set(t.subarray(e, e + i)), t.copyWithin(e, s, s + i), t.set(n, s);
      }
    }
    static _unpremultiplyAlpha(t) {
      t instanceof Uint8ClampedArray && (t = new Uint8Array(t.buffer));
      const e = t.length;
      for (let r = 0; r < e; r += 4) {
        const e = t[r + 3];
        if (0 !== e) {
          const i = 255.001 / e;
          (t[r] = t[r] * i + 0.5),
            (t[r + 1] = t[r + 1] * i + 0.5),
            (t[r + 2] = t[r + 2] * i + 0.5);
        }
      }
    }
  };
tu.extension = { name: "extract", type: Gs.RendererSystem };
let eu = tu;
kn.add(eu);
const ru = {
    build(t) {
      const e = t.points;
      let r, i, s, n, o, a;
      if (t.type === Hs.CIRC) {
        const e = t.shape;
        (r = e.x), (i = e.y), (o = a = e.radius), (s = n = 0);
      } else if (t.type === Hs.ELIP) {
        const e = t.shape;
        (r = e.x), (i = e.y), (o = e.width), (a = e.height), (s = n = 0);
      } else {
        const e = t.shape,
          h = e.width / 2,
          l = e.height / 2;
        (r = e.x + h),
          (i = e.y + l),
          (o = a = Math.max(0, Math.min(e.radius, Math.min(h, l)))),
          (s = h - o),
          (n = l - a);
      }
      if (!(o >= 0 && a >= 0 && s >= 0 && n >= 0)) return void (e.length = 0);
      const h = Math.ceil(2.3 * Math.sqrt(o + a)),
        l = 8 * h + (s ? 4 : 0) + (n ? 4 : 0);
      if (((e.length = l), 0 === l)) return;
      if (0 === h)
        return (
          (e.length = 8),
          (e[0] = e[6] = r + s),
          (e[1] = e[3] = i + n),
          (e[2] = e[4] = r - s),
          void (e[5] = e[7] = i - n)
        );
      let u = 0,
        c = 4 * h + (s ? 2 : 0) + 2,
        d = c,
        p = l;
      {
        const t = s + o,
          a = n,
          h = r + t,
          l = r - t,
          f = i + a;
        if (((e[u++] = h), (e[u++] = f), (e[--c] = f), (e[--c] = l), n)) {
          const t = i - a;
          (e[d++] = l), (e[d++] = t), (e[--p] = t), (e[--p] = h);
        }
      }
      for (let f = 1; f < h; f++) {
        const t = (Math.PI / 2) * (f / h),
          l = s + Math.cos(t) * o,
          m = n + Math.sin(t) * a,
          g = r + l,
          _ = r - l,
          y = i + m,
          v = i - m;
        (e[u++] = g),
          (e[u++] = y),
          (e[--c] = y),
          (e[--c] = _),
          (e[d++] = _),
          (e[d++] = v),
          (e[--p] = v),
          (e[--p] = g);
      }
      {
        const t = n + a,
          o = r + s,
          h = r - s,
          l = i + t,
          c = i - t;
        (e[u++] = o),
          (e[u++] = l),
          (e[--p] = c),
          (e[--p] = o),
          s && ((e[u++] = h), (e[u++] = l), (e[--p] = c), (e[--p] = h));
      }
    },
    triangulate(t, e) {
      const r = t.points,
        i = e.points,
        s = e.indices;
      if (0 === r.length) return;
      let n = i.length / 2;
      const o = n;
      let a, h;
      if (t.type !== Hs.RREC) {
        const e = t.shape;
        (a = e.x), (h = e.y);
      } else {
        const e = t.shape;
        (a = e.x + e.width / 2), (h = e.y + e.height / 2);
      }
      const l = t.matrix;
      i.push(
        t.matrix ? l.a * a + l.c * h + l.tx : a,
        t.matrix ? l.b * a + l.d * h + l.ty : h
      ),
        n++,
        i.push(r[0], r[1]);
      for (let u = 2; u < r.length; u += 2)
        i.push(r[u], r[u + 1]), s.push(n++, o, n);
      s.push(o + 1, o, n);
    },
  },
  iu = {
    build(t) {
      t.points = t.shape.points.slice();
    },
    triangulate(t, e) {
      let r = t.points;
      const i = t.holes,
        s = e.points,
        n = e.indices;
      if (r.length >= 6) {
        It(r, !1);
        const t = [];
        for (let s = 0; s < i.length; s++) {
          const e = i[s];
          It(e.points, !0), t.push(r.length / 2), (r = r.concat(e.points));
        }
        const e = xn(r, t, 2);
        if (!e) return;
        const o = s.length / 2;
        for (let r = 0; r < e.length; r += 3)
          n.push(e[r] + o), n.push(e[r + 1] + o), n.push(e[r + 2] + o);
        for (let i = 0; i < r.length; i++) s.push(r[i]);
      }
    },
  },
  su = {
    build(t) {
      const e = t.shape,
        r = e.x,
        i = e.y,
        s = e.width,
        n = e.height,
        o = t.points;
      (o.length = 0),
        s >= 0 && n >= 0 && o.push(r, i, r + s, i, r + s, i + n, r, i + n);
    },
    triangulate(t, e) {
      const r = t.points,
        i = e.points;
      if (0 === r.length) return;
      const s = i.length / 2;
      i.push(r[0], r[1], r[2], r[3], r[6], r[7], r[4], r[5]),
        e.indices.push(s, s + 1, s + 2, s + 1, s + 2, s + 3);
    },
  },
  nu = {
    build(t) {
      ru.build(t);
    },
    triangulate(t, e) {
      ru.triangulate(t, e);
    },
  };
(zs = ((t) => (
  (t.MITER = "miter"), (t.BEVEL = "bevel"), (t.ROUND = "round"), t
))(zs || {})),
  (Ws = ((t) => (
    (t.BUTT = "butt"), (t.ROUND = "round"), (t.SQUARE = "square"), t
  ))(Ws || {}));
const ou = {
  adaptive: !0,
  maxLength: 10,
  minSegments: 8,
  maxSegments: 2048,
  epsilon: 1e-4,
  _segmentsCount(t, e = 20) {
    if (!this.adaptive || !t || isNaN(t)) return e;
    let r = Math.ceil(t / this.maxLength);
    return (
      r < this.minSegments
        ? (r = this.minSegments)
        : r > this.maxSegments && (r = this.maxSegments),
      r
    );
  },
};
class au {
  static curveTo(t, e, r, i, s, n) {
    const o = n[n.length - 2],
      a = n[n.length - 1] - e,
      h = o - t,
      l = i - e,
      u = r - t,
      c = Math.abs(a * u - h * l);
    if (c < 1e-8 || 0 === s)
      return (
        (n[n.length - 2] !== t || n[n.length - 1] !== e) && n.push(t, e), null
      );
    const d = a * a + h * h,
      p = l * l + u * u,
      f = a * l + h * u,
      m = (s * Math.sqrt(d)) / c,
      g = (s * Math.sqrt(p)) / c,
      _ = (m * f) / d,
      y = (g * f) / p,
      v = m * u + g * h,
      x = m * l + g * a,
      b = h * (g + _),
      E = a * (g + _),
      T = u * (m + y),
      A = l * (m + y);
    return {
      cx: v + t,
      cy: x + e,
      radius: s,
      startAngle: Math.atan2(E - x, b - v),
      endAngle: Math.atan2(A - x, T - v),
      anticlockwise: h * l > u * a,
    };
  }
  static arc(t, e, r, i, s, n, o, a, h) {
    const l = o - n,
      u = ou._segmentsCount(Math.abs(l) * s, 40 * Math.ceil(Math.abs(l) / no)),
      c = l / (2 * u),
      d = 2 * c,
      p = Math.cos(c),
      f = Math.sin(c),
      m = u - 1,
      g = (m % 1) / m;
    for (let _ = 0; _ <= m; ++_) {
      const t = c + n + d * (_ + g * _),
        e = Math.cos(t),
        o = -Math.sin(t);
      h.push((p * e + f * o) * s + r, (p * -o + f * e) * s + i);
    }
  }
}
class hu {
  constructor() {
    this.reset();
  }
  begin(t, e, r) {
    this.reset(), (this.style = t), (this.start = e), (this.attribStart = r);
  }
  end(t, e) {
    (this.attribSize = e - this.attribStart), (this.size = t - this.start);
  }
  reset() {
    (this.style = null),
      (this.size = 0),
      (this.start = 0),
      (this.attribStart = 0),
      (this.attribSize = 0);
  }
}
class lu {
  static curveLength(t, e, r, i, s, n, o, a) {
    let h = 0,
      l = 0,
      u = 0,
      c = 0,
      d = 0,
      p = 0,
      f = 0,
      m = 0,
      g = 0,
      _ = 0,
      y = 0,
      v = t,
      x = e;
    for (let b = 1; b <= 10; ++b)
      (l = b / 10),
        (u = l * l),
        (c = u * l),
        (d = 1 - l),
        (p = d * d),
        (f = p * d),
        (m = f * t + 3 * p * l * r + 3 * d * u * s + c * o),
        (g = f * e + 3 * p * l * i + 3 * d * u * n + c * a),
        (_ = v - m),
        (y = x - g),
        (v = m),
        (x = g),
        (h += Math.sqrt(_ * _ + y * y));
    return h;
  }
  static curveTo(t, e, r, i, s, n, o) {
    const a = o[o.length - 2],
      h = o[o.length - 1];
    o.length -= 2;
    const l = ou._segmentsCount(lu.curveLength(a, h, t, e, r, i, s, n));
    let u = 0,
      c = 0,
      d = 0,
      p = 0,
      f = 0;
    o.push(a, h);
    for (let m = 1, g = 0; m <= l; ++m)
      (g = m / l),
        (u = 1 - g),
        (c = u * u),
        (d = c * u),
        (p = g * g),
        (f = p * g),
        o.push(
          d * a + 3 * c * g * t + 3 * u * p * r + f * s,
          d * h + 3 * c * g * e + 3 * u * p * i + f * n
        );
  }
}
class uu {
  static curveLength(t, e, r, i, s, n) {
    const o = t - 2 * r + s,
      a = e - 2 * i + n,
      h = 2 * r - 2 * t,
      l = 2 * i - 2 * e,
      u = 4 * (o * o + a * a),
      c = 4 * (o * h + a * l),
      d = h * h + l * l,
      p = 2 * Math.sqrt(u + c + d),
      f = Math.sqrt(u),
      m = 2 * u * f,
      g = 2 * Math.sqrt(d),
      _ = c / f;
    return (
      (m * p +
        f * c * (p - g) +
        (4 * d * u - c * c) * Math.log((2 * f + _ + p) / (_ + g))) /
      (4 * m)
    );
  }
  static curveTo(t, e, r, i, s) {
    const n = s[s.length - 2],
      o = s[s.length - 1],
      a = ou._segmentsCount(uu.curveLength(n, o, t, e, r, i));
    let h = 0,
      l = 0;
    for (let u = 1; u <= a; ++u) {
      const c = u / a;
      (h = n + (t - n) * c),
        (l = o + (e - o) * c),
        s.push(h + (t + (r - t) * c - h) * c, l + (e + (i - e) * c - l) * c);
    }
  }
}
const cu = {
    [Hs.POLY]: iu,
    [Hs.CIRC]: ru,
    [Hs.ELIP]: ru,
    [Hs.RECT]: su,
    [Hs.RREC]: nu,
  },
  du = [],
  pu = [];
class fu {
  constructor(t, e = null, r = null, i = null) {
    (this.points = []),
      (this.holes = []),
      (this.shape = t),
      (this.lineStyle = r),
      (this.fillStyle = e),
      (this.matrix = i),
      (this.type = t.type);
  }
  clone() {
    return new fu(this.shape, this.fillStyle, this.lineStyle, this.matrix);
  }
  destroy() {
    (this.shape = null),
      (this.holes.length = 0),
      (this.holes = null),
      (this.points.length = 0),
      (this.points = null),
      (this.lineStyle = null),
      (this.fillStyle = null);
  }
}
const mu = new ho(),
  gu = class t extends so {
    constructor() {
      super(),
        (this.closePointEps = 1e-4),
        (this.boundsPadding = 0),
        (this.uvsFloat32 = null),
        (this.indicesUint16 = null),
        (this.batchable = !1),
        (this.points = []),
        (this.colors = []),
        (this.uvs = []),
        (this.indices = []),
        (this.textureIds = []),
        (this.graphicsData = []),
        (this.drawCalls = []),
        (this.batchDirty = -1),
        (this.batches = []),
        (this.dirty = 0),
        (this.cacheDirty = -1),
        (this.clearDirty = 0),
        (this.shapeIndex = 0),
        (this._bounds = new Th()),
        (this.boundsDirty = -1);
    }
    get bounds() {
      return (
        this.updateBatches(),
        this.boundsDirty !== this.dirty &&
          ((this.boundsDirty = this.dirty), this.calculateBounds()),
        this._bounds
      );
    }
    invalidate() {
      (this.boundsDirty = -1),
        this.dirty++,
        this.batchDirty++,
        (this.shapeIndex = 0),
        (this.points.length = 0),
        (this.colors.length = 0),
        (this.uvs.length = 0),
        (this.indices.length = 0),
        (this.textureIds.length = 0);
      for (let t = 0; t < this.drawCalls.length; t++)
        this.drawCalls[t].texArray.clear(), pu.push(this.drawCalls[t]);
      this.drawCalls.length = 0;
      for (let t = 0; t < this.batches.length; t++) {
        const e = this.batches[t];
        e.reset(), du.push(e);
      }
      this.batches.length = 0;
    }
    clear() {
      return (
        this.graphicsData.length > 0 &&
          (this.invalidate(),
          this.clearDirty++,
          (this.graphicsData.length = 0)),
        this
      );
    }
    drawShape(t, e = null, r = null, i = null) {
      const s = new fu(t, e, r, i);
      return this.graphicsData.push(s), this.dirty++, this;
    }
    drawHole(t, e = null) {
      if (!this.graphicsData.length) return null;
      const r = new fu(t, null, null, e),
        i = this.graphicsData[this.graphicsData.length - 1];
      return (r.lineStyle = i.lineStyle), i.holes.push(r), this.dirty++, this;
    }
    destroy() {
      super.destroy();
      for (let t = 0; t < this.graphicsData.length; ++t)
        this.graphicsData[t].destroy();
      (this.points.length = 0),
        (this.points = null),
        (this.colors.length = 0),
        (this.colors = null),
        (this.uvs.length = 0),
        (this.uvs = null),
        (this.indices.length = 0),
        (this.indices = null),
        this.indexBuffer.destroy(),
        (this.indexBuffer = null),
        (this.graphicsData.length = 0),
        (this.graphicsData = null),
        (this.drawCalls.length = 0),
        (this.drawCalls = null),
        (this.batches.length = 0),
        (this.batches = null),
        (this._bounds = null);
    }
    containsPoint(t) {
      const e = this.graphicsData;
      for (let r = 0; r < e.length; ++r) {
        const i = e[r];
        if (
          i.fillStyle.visible &&
          i.shape &&
          (i.matrix ? i.matrix.applyInverse(t, mu) : mu.copyFrom(t),
          i.shape.contains(mu.x, mu.y))
        ) {
          let t = !1;
          if (i.holes)
            for (let e = 0; e < i.holes.length; e++)
              if (i.holes[e].shape.contains(mu.x, mu.y)) {
                t = !0;
                break;
              }
          if (!t) return !0;
        }
      }
      return !1;
    }
    updateBatches() {
      if (!this.graphicsData.length) return void (this.batchable = !0);
      if (!this.validateBatching()) return;
      this.cacheDirty = this.dirty;
      const t = this.uvs,
        e = this.graphicsData;
      let r = null,
        i = null;
      this.batches.length > 0 &&
        ((r = this.batches[this.batches.length - 1]), (i = r.style));
      for (let a = this.shapeIndex; a < e.length; a++) {
        this.shapeIndex++;
        const s = e[a],
          n = s.fillStyle,
          o = s.lineStyle;
        cu[s.type].build(s),
          s.matrix && this.transformPoints(s.points, s.matrix),
          (n.visible || o.visible) && this.processHoles(s.holes);
        for (let e = 0; e < 2; e++) {
          const a = 0 === e ? n : o;
          if (!a.visible) continue;
          const h = a.texture.baseTexture,
            l = this.indices.length,
            u = this.points.length / 2;
          (h.wrapMode = hn.REPEAT),
            0 === e ? this.processFill(s) : this.processLine(s);
          const c = this.points.length / 2 - u;
          0 !== c &&
            (r && !this._compareStyles(i, a) && (r.end(l, u), (r = null)),
            r ||
              ((r = du.pop() || new hu()),
              r.begin(a, l, u),
              this.batches.push(r),
              (i = a)),
            this.addUvs(this.points, t, a.texture, u, c, a.matrix));
        }
      }
      const s = this.indices.length,
        n = this.points.length / 2;
      if ((r && r.end(s, n), 0 === this.batches.length))
        return void (this.batchable = !0);
      const o = n > 65535;
      this.indicesUint16 &&
      this.indices.length === this.indicesUint16.length &&
      o === this.indicesUint16.BYTES_PER_ELEMENT > 2
        ? this.indicesUint16.set(this.indices)
        : (this.indicesUint16 = o
            ? new Uint32Array(this.indices)
            : new Uint16Array(this.indices)),
        (this.batchable = this.isBatchable()),
        this.batchable ? this.packBatches() : this.buildDrawCalls();
    }
    _compareStyles(t, e) {
      return !(
        !t ||
        !e ||
        t.texture.baseTexture !== e.texture.baseTexture ||
        t.color + t.alpha !== e.color + e.alpha ||
        !!t.native != !!e.native
      );
    }
    validateBatching() {
      if (this.dirty === this.cacheDirty || !this.graphicsData.length)
        return !1;
      for (let t = 0, e = this.graphicsData.length; t < e; t++) {
        const e = this.graphicsData[t],
          r = e.fillStyle,
          i = e.lineStyle;
        if (
          (r && !r.texture.baseTexture.valid) ||
          (i && !i.texture.baseTexture.valid)
        )
          return !1;
      }
      return !0;
    }
    packBatches() {
      this.batchDirty++, (this.uvsFloat32 = new Float32Array(this.uvs));
      const t = this.batches;
      for (let e = 0, r = t.length; e < r; e++) {
        const r = t[e];
        for (let t = 0; t < r.size; t++) {
          const e = r.start + t;
          this.indicesUint16[e] = this.indicesUint16[e] - r.attribStart;
        }
      }
    }
    isBatchable() {
      if (this.points.length > 131070) return !1;
      const e = this.batches;
      for (let t = 0; t < e.length; t++) if (e[t].style.native) return !1;
      return this.points.length < 2 * t.BATCHABLE_SIZE;
    }
    buildDrawCalls() {
      let t = ++Yn._globalBatch;
      for (let u = 0; u < this.drawCalls.length; u++)
        this.drawCalls[u].texArray.clear(), pu.push(this.drawCalls[u]);
      this.drawCalls.length = 0;
      const e = this.colors,
        r = this.textureIds;
      let i = pu.pop();
      i || ((i = new qn()), (i.texArray = new Wo())),
        (i.texArray.count = 0),
        (i.start = 0),
        (i.size = 0),
        (i.type = en.TRIANGLES);
      let s = 0,
        n = null,
        o = 0,
        a = !1,
        h = en.TRIANGLES,
        l = 0;
      this.drawCalls.push(i);
      for (let u = 0; u < this.batches.length; u++) {
        const c = this.batches[u],
          d = 8,
          p = c.style,
          f = p.texture.baseTexture;
        a !== !!p.native &&
          ((a = !!p.native),
          (h = a ? en.LINES : en.TRIANGLES),
          (n = null),
          (s = d),
          t++),
          n !== f &&
            ((n = f),
            f._batchEnabled !== t &&
              (s === d &&
                (t++,
                (s = 0),
                i.size > 0 &&
                  ((i = pu.pop()),
                  i || ((i = new qn()), (i.texArray = new Wo())),
                  this.drawCalls.push(i)),
                (i.start = l),
                (i.size = 0),
                (i.texArray.count = 0),
                (i.type = h)),
              (f.touched = 1),
              (f._batchEnabled = t),
              (f._batchLocation = s),
              (f.wrapMode = hn.REPEAT),
              (i.texArray.elements[i.texArray.count++] = f),
              s++)),
          (i.size += c.size),
          (l += c.size),
          (o = f._batchLocation),
          this.addColors(e, p.color, p.alpha, c.attribSize, c.attribStart),
          this.addTextureIds(r, o, c.attribSize, c.attribStart);
      }
      (Yn._globalBatch = t), this.packAttributes();
    }
    packAttributes() {
      const t = this.points,
        e = this.uvs,
        r = this.colors,
        i = this.textureIds,
        s = new ArrayBuffer(3 * t.length * 4),
        n = new Float32Array(s),
        o = new Uint32Array(s);
      let a = 0;
      for (let h = 0; h < t.length / 2; h++)
        (n[a++] = t[2 * h]),
          (n[a++] = t[2 * h + 1]),
          (n[a++] = e[2 * h]),
          (n[a++] = e[2 * h + 1]),
          (o[a++] = r[h]),
          (n[a++] = i[h]);
      this._buffer.update(s), this._indexBuffer.update(this.indicesUint16);
    }
    processFill(t) {
      t.holes.length
        ? iu.triangulate(t, this)
        : cu[t.type].triangulate(t, this);
    }
    processLine(t) {
      Mt(t, this);
      for (let e = 0; e < t.holes.length; e++) Mt(t.holes[e], this);
    }
    processHoles(t) {
      for (let e = 0; e < t.length; e++) {
        const r = t[e];
        cu[r.type].build(r),
          r.matrix && this.transformPoints(r.points, r.matrix);
      }
    }
    calculateBounds() {
      const t = this._bounds;
      t.clear(),
        t.addVertexData(this.points, 0, this.points.length),
        t.pad(this.boundsPadding, this.boundsPadding);
    }
    transformPoints(t, e) {
      for (let r = 0; r < t.length / 2; r++) {
        const i = t[2 * r],
          s = t[2 * r + 1];
        (t[2 * r] = e.a * i + e.c * s + e.tx),
          (t[2 * r + 1] = e.b * i + e.d * s + e.ty);
      }
    }
    addColors(t, e, r, i, s = 0) {
      const n = Rn.shared.setValue(e).toLittleEndianNumber(),
        o = Rn.shared.setValue(n).toPremultiplied(r);
      t.length = Math.max(t.length, s + i);
      for (let a = 0; a < i; a++) t[s + a] = o;
    }
    addTextureIds(t, e, r, i = 0) {
      t.length = Math.max(t.length, i + r);
      for (let s = 0; s < r; s++) t[i + s] = e;
    }
    addUvs(t, e, r, i, s, n = null) {
      let o = 0;
      const a = e.length,
        h = r.frame;
      for (; o < s; ) {
        let r = t[2 * (i + o)],
          s = t[2 * (i + o) + 1];
        if (n) {
          const t = n.a * r + n.c * s + n.tx;
          (s = n.b * r + n.d * s + n.ty), (r = t);
        }
        o++, e.push(r / h.width, s / h.height);
      }
      const l = r.baseTexture;
      (h.width < l.width || h.height < l.height) && this.adjustUvs(e, r, a, s);
    }
    adjustUvs(t, e, r, i) {
      const s = e.baseTexture,
        n = 1e-6,
        o = r + 2 * i,
        a = e.frame,
        h = a.width / s.width,
        l = a.height / s.height;
      let u = a.x / a.width,
        c = a.y / a.height,
        d = Math.floor(t[r] + n),
        p = Math.floor(t[r + 1] + n);
      for (let f = r + 2; f < o; f += 2)
        (d = Math.min(d, Math.floor(t[f] + n))),
          (p = Math.min(p, Math.floor(t[f + 1] + n)));
      (u -= d), (c -= p);
      for (let f = r; f < o; f += 2)
        (t[f] = (t[f] + u) * h), (t[f + 1] = (t[f + 1] + c) * l);
    }
  };
gu.BATCHABLE_SIZE = 100;
let _u = gu;
class yu {
  constructor() {
    (this.color = 16777215),
      (this.alpha = 1),
      (this.texture = ha.WHITE),
      (this.matrix = null),
      (this.visible = !1),
      this.reset();
  }
  clone() {
    const t = new yu();
    return (
      (t.color = this.color),
      (t.alpha = this.alpha),
      (t.texture = this.texture),
      (t.matrix = this.matrix),
      (t.visible = this.visible),
      t
    );
  }
  reset() {
    (this.color = 16777215),
      (this.alpha = 1),
      (this.texture = ha.WHITE),
      (this.matrix = null),
      (this.visible = !1);
  }
  destroy() {
    (this.texture = null), (this.matrix = null);
  }
}
class vu extends yu {
  constructor() {
    super(...arguments),
      (this.width = 0),
      (this.alignment = 0.5),
      (this.native = !1),
      (this.cap = Ws.BUTT),
      (this.join = zs.MITER),
      (this.miterLimit = 10);
  }
  clone() {
    const t = new vu();
    return (
      (t.color = this.color),
      (t.alpha = this.alpha),
      (t.texture = this.texture),
      (t.matrix = this.matrix),
      (t.visible = this.visible),
      (t.width = this.width),
      (t.alignment = this.alignment),
      (t.native = this.native),
      (t.cap = this.cap),
      (t.join = this.join),
      (t.miterLimit = this.miterLimit),
      t
    );
  }
  reset() {
    super.reset(),
      (this.color = 0),
      (this.alignment = 0.5),
      (this.width = 0),
      (this.native = !1),
      (this.cap = Ws.BUTT),
      (this.join = zs.MITER),
      (this.miterLimit = 10);
  }
}
const xu = {},
  bu = class t extends Ih {
    constructor(t = null) {
      super(),
        (this.shader = null),
        (this.pluginName = "batch"),
        (this.currentPath = null),
        (this.batches = []),
        (this.batchTint = -1),
        (this.batchDirty = -1),
        (this.vertexData = null),
        (this._fillStyle = new yu()),
        (this._lineStyle = new vu()),
        (this._matrix = null),
        (this._holeMode = !1),
        (this.state = Hn.for2d()),
        (this._geometry = t || new _u()),
        this._geometry.refCount++,
        (this._transformID = -1),
        (this._tintColor = new Rn(16777215)),
        (this.blendMode = tn.NORMAL);
    }
    get geometry() {
      return this._geometry;
    }
    clone() {
      return this.finishPoly(), new t(this._geometry);
    }
    set blendMode(t) {
      this.state.blendMode = t;
    }
    get blendMode() {
      return this.state.blendMode;
    }
    get tint() {
      return this._tintColor.value;
    }
    set tint(t) {
      this._tintColor.setValue(t);
    }
    get fill() {
      return this._fillStyle;
    }
    get line() {
      return this._lineStyle;
    }
    lineStyle(t = null, e = 0, r, i = 0.5, s = !1) {
      return (
        "number" == typeof t &&
          (t = { width: t, color: e, alpha: r, alignment: i, native: s }),
        this.lineTextureStyle(t)
      );
    }
    lineTextureStyle(t) {
      const e = {
        width: 0,
        texture: ha.WHITE,
        color: (null == t ? void 0 : t.texture) ? 16777215 : 0,
        matrix: null,
        alignment: 0.5,
        native: !1,
        cap: Ws.BUTT,
        join: zs.MITER,
        miterLimit: 10,
      };
      (t = Object.assign(e, t)),
        this.normalizeColor(t),
        this.currentPath && this.startPoly();
      const r = t.width > 0 && t.alpha > 0;
      return (
        r
          ? (t.matrix && ((t.matrix = t.matrix.clone()), t.matrix.invert()),
            Object.assign(this._lineStyle, { visible: r }, t))
          : this._lineStyle.reset(),
        this
      );
    }
    startPoly() {
      if (this.currentPath) {
        const t = this.currentPath.points,
          e = this.currentPath.points.length;
        e > 2 &&
          (this.drawShape(this.currentPath),
          (this.currentPath = new fo()),
          (this.currentPath.closeStroke = !1),
          this.currentPath.points.push(t[e - 2], t[e - 1]));
      } else (this.currentPath = new fo()), (this.currentPath.closeStroke = !1);
    }
    finishPoly() {
      this.currentPath &&
        (this.currentPath.points.length > 2
          ? (this.drawShape(this.currentPath), (this.currentPath = null))
          : (this.currentPath.points.length = 0));
    }
    moveTo(t, e) {
      return (
        this.startPoly(),
        (this.currentPath.points[0] = t),
        (this.currentPath.points[1] = e),
        this
      );
    }
    lineTo(t, e) {
      this.currentPath || this.moveTo(0, 0);
      const r = this.currentPath.points,
        i = r[r.length - 2],
        s = r[r.length - 1];
      return (i !== t || s !== e) && r.push(t, e), this;
    }
    _initCurve(t = 0, e = 0) {
      this.currentPath
        ? 0 === this.currentPath.points.length &&
          (this.currentPath.points = [t, e])
        : this.moveTo(t, e);
    }
    quadraticCurveTo(t, e, r, i) {
      this._initCurve();
      const s = this.currentPath.points;
      return (
        0 === s.length && this.moveTo(0, 0), uu.curveTo(t, e, r, i, s), this
      );
    }
    bezierCurveTo(t, e, r, i, s, n) {
      return (
        this._initCurve(),
        lu.curveTo(t, e, r, i, s, n, this.currentPath.points),
        this
      );
    }
    arcTo(t, e, r, i, s) {
      this._initCurve(t, e);
      const n = this.currentPath.points,
        o = au.curveTo(t, e, r, i, s, n);
      if (o) {
        const {
          cx: t,
          cy: e,
          radius: r,
          startAngle: i,
          endAngle: s,
          anticlockwise: n,
        } = o;
        this.arc(t, e, r, i, s, n);
      }
      return this;
    }
    arc(t, e, r, i, s, n = !1) {
      if (i === s) return this;
      if ((!n && s <= i ? (s += no) : n && i <= s && (i += no), s - i == 0))
        return this;
      const o = t + Math.cos(i) * r,
        a = e + Math.sin(i) * r,
        h = this._geometry.closePointEps;
      let l = this.currentPath ? this.currentPath.points : null;
      if (l) {
        const t = Math.abs(l[l.length - 2] - o),
          e = Math.abs(l[l.length - 1] - a);
        (t < h && e < h) || l.push(o, a);
      } else this.moveTo(o, a), (l = this.currentPath.points);
      return au.arc(o, a, t, e, r, i, s, n, l), this;
    }
    beginFill(t = 0, e) {
      return this.beginTextureFill({ texture: ha.WHITE, color: t, alpha: e });
    }
    normalizeColor(t) {
      const e = Rn.shared.setValue(t.color ?? 0);
      (t.color = e.toNumber()), t.alpha ?? (t.alpha = e.alpha);
    }
    beginTextureFill(t) {
      const e = { texture: ha.WHITE, color: 16777215, matrix: null };
      (t = Object.assign(e, t)),
        this.normalizeColor(t),
        this.currentPath && this.startPoly();
      const r = t.alpha > 0;
      return (
        r
          ? (t.matrix && ((t.matrix = t.matrix.clone()), t.matrix.invert()),
            Object.assign(this._fillStyle, { visible: r }, t))
          : this._fillStyle.reset(),
        this
      );
    }
    endFill() {
      return this.finishPoly(), this._fillStyle.reset(), this;
    }
    drawRect(t, e, r, i) {
      return this.drawShape(new uo(t, e, r, i));
    }
    drawRoundedRect(t, e, r, i, s) {
      return this.drawShape(new mo(t, e, r, i, s));
    }
    drawCircle(t, e, r) {
      return this.drawShape(new co(t, e, r));
    }
    drawEllipse(t, e, r, i) {
      return this.drawShape(new po(t, e, r, i));
    }
    drawPolygon(...t) {
      let e,
        r = !0;
      const i = t[0];
      i.points
        ? ((r = i.closeStroke), (e = i.points))
        : (e = Array.isArray(t[0]) ? t[0] : t);
      const s = new fo(e);
      return (s.closeStroke = r), this.drawShape(s), this;
    }
    drawShape(t) {
      return (
        this._holeMode
          ? this._geometry.drawHole(t, this._matrix)
          : this._geometry.drawShape(
              t,
              this._fillStyle.clone(),
              this._lineStyle.clone(),
              this._matrix
            ),
        this
      );
    }
    clear() {
      return (
        this._geometry.clear(),
        this._lineStyle.reset(),
        this._fillStyle.reset(),
        this._boundsID++,
        (this._matrix = null),
        (this._holeMode = !1),
        (this.currentPath = null),
        this
      );
    }
    isFastRect() {
      const t = this._geometry.graphicsData;
      return !(
        1 !== t.length ||
        t[0].shape.type !== Hs.RECT ||
        t[0].matrix ||
        t[0].holes.length ||
        (t[0].lineStyle.visible && t[0].lineStyle.width)
      );
    }
    _render(t) {
      this.finishPoly();
      const e = this._geometry;
      e.updateBatches(),
        e.batchable
          ? (this.batchDirty !== e.batchDirty && this._populateBatches(),
            this._renderBatched(t))
          : (t.batch.flush(), this._renderDirect(t));
    }
    _populateBatches() {
      const t = this._geometry,
        e = this.blendMode,
        r = t.batches.length;
      (this.batchTint = -1),
        (this._transformID = -1),
        (this.batchDirty = t.batchDirty),
        (this.batches.length = r),
        (this.vertexData = new Float32Array(t.points));
      for (let i = 0; i < r; i++) {
        const r = t.batches[i],
          s = r.style.color,
          n = new Float32Array(
            this.vertexData.buffer,
            4 * r.attribStart * 2,
            2 * r.attribSize
          ),
          o = new Float32Array(
            t.uvsFloat32.buffer,
            4 * r.attribStart * 2,
            2 * r.attribSize
          ),
          a = {
            vertexData: n,
            blendMode: e,
            indices: new Uint16Array(
              t.indicesUint16.buffer,
              2 * r.start,
              r.size
            ),
            uvs: o,
            _batchRGB: Rn.shared.setValue(s).toRgbArray(),
            _tintRGB: s,
            _texture: r.style.texture,
            alpha: r.style.alpha,
            worldAlpha: 1,
          };
        this.batches[i] = a;
      }
    }
    _renderBatched(t) {
      if (this.batches.length) {
        t.batch.setObjectRenderer(t.plugins[this.pluginName]),
          this.calculateVertices(),
          this.calculateTints();
        for (let e = 0, r = this.batches.length; e < r; e++) {
          const r = this.batches[e];
          (r.worldAlpha = this.worldAlpha * r.alpha),
            t.plugins[this.pluginName].render(r);
        }
      }
    }
    _renderDirect(t) {
      const e = this._resolveDirectShader(t),
        r = this._geometry,
        i = this.worldAlpha,
        s = e.uniforms,
        n = r.drawCalls;
      (s.translationMatrix = this.transform.worldTransform),
        Rn.shared.setValue(this._tintColor).premultiply(i).toArray(s.tint),
        t.shader.bind(e),
        t.geometry.bind(r, e),
        t.state.set(this.state);
      for (let o = 0, a = n.length; o < a; o++)
        this._renderDrawCallDirect(t, r.drawCalls[o]);
    }
    _renderDrawCallDirect(t, e) {
      const { texArray: r, type: i, size: s, start: n } = e,
        o = r.count;
      for (let a = 0; a < o; a++) t.texture.bind(r.elements[a], a);
      t.geometry.draw(i, s, n);
    }
    _resolveDirectShader(t) {
      let e = this.shader;
      const r = this.pluginName;
      if (!e) {
        if (!xu[r]) {
          const { maxTextures: e } = t.plugins[r],
            i = new Int32Array(e);
          for (let t = 0; t < e; t++) i[t] = t;
          const s = {
              tint: new Float32Array([1, 1, 1, 1]),
              translationMatrix: new go(),
              default: Xo.from({ uSamplers: i }, !0),
            },
            n = t.plugins[r]._shader.program;
          xu[r] = new Vo(n, s);
        }
        e = xu[r];
      }
      return e;
    }
    _calculateBounds() {
      this.finishPoly();
      const t = this._geometry;
      if (!t.graphicsData.length) return;
      const { minX: e, minY: r, maxX: i, maxY: s } = t.bounds;
      this._bounds.addFrame(this.transform, e, r, i, s);
    }
    containsPoint(e) {
      return (
        this.worldTransform.applyInverse(e, t._TEMP_POINT),
        this._geometry.containsPoint(t._TEMP_POINT)
      );
    }
    calculateTints() {
      if (this.batchTint !== this.tint) {
        this.batchTint = this._tintColor.toNumber();
        for (let t = 0; t < this.batches.length; t++) {
          const e = this.batches[t];
          e._tintRGB = Rn.shared
            .setValue(this._tintColor)
            .multiply(e._batchRGB)
            .toLittleEndianNumber();
        }
      }
    }
    calculateVertices() {
      const t = this.transform._worldID;
      if (this._transformID === t) return;
      this._transformID = t;
      const e = this.transform.worldTransform,
        r = e.a,
        i = e.b,
        s = e.c,
        n = e.d,
        o = e.tx,
        a = e.ty,
        h = this._geometry.points,
        l = this.vertexData;
      let u = 0;
      for (let c = 0; c < h.length; c += 2) {
        const t = h[c],
          e = h[c + 1];
        (l[u++] = r * t + s * e + o), (l[u++] = n * e + i * t + a);
      }
    }
    closePath() {
      const t = this.currentPath;
      return t && ((t.closeStroke = !0), this.finishPoly()), this;
    }
    setMatrix(t) {
      return (this._matrix = t), this;
    }
    beginHole() {
      return this.finishPoly(), (this._holeMode = !0), this;
    }
    endHole() {
      return this.finishPoly(), (this._holeMode = !1), this;
    }
    destroy(t) {
      this._geometry.refCount--,
        0 === this._geometry.refCount && this._geometry.dispose(),
        (this._matrix = null),
        (this.currentPath = null),
        this._lineStyle.destroy(),
        (this._lineStyle = null),
        this._fillStyle.destroy(),
        (this._fillStyle = null),
        (this._geometry = null),
        (this.shader = null),
        (this.vertexData = null),
        (this.batches.length = 0),
        (this.batches = null),
        super.destroy(t);
    }
  };
(bu.curves = ou), (bu._TEMP_POINT = new ho());
let Eu = bu;
class Tu {
  constructor(t, e) {
    (this.uvBuffer = t),
      (this.uvMatrix = e),
      (this.data = null),
      (this._bufferUpdateId = -1),
      (this._textureUpdateId = -1),
      (this._updateID = 0);
  }
  update(t) {
    if (
      !t &&
      this._bufferUpdateId === this.uvBuffer._updateID &&
      this._textureUpdateId === this.uvMatrix._updateID
    )
      return;
    (this._bufferUpdateId = this.uvBuffer._updateID),
      (this._textureUpdateId = this.uvMatrix._updateID);
    const e = this.uvBuffer.data;
    (!this.data || this.data.length !== e.length) &&
      (this.data = new Float32Array(e.length)),
      this.uvMatrix.multiplyUvs(e, this.data),
      this._updateID++;
  }
}
const Au = new ho(),
  wu = new fo(),
  Su = class t extends Ih {
    constructor(t, e, r, i = en.TRIANGLES) {
      super(),
        (this.geometry = t),
        (this.shader = e),
        (this.state = r || Hn.for2d()),
        (this.drawMode = i),
        (this.start = 0),
        (this.size = 0),
        (this.uvs = null),
        (this.indices = null),
        (this.vertexData = new Float32Array(1)),
        (this.vertexDirty = -1),
        (this._transformID = -1),
        (this._roundPixels = _n.ROUND_PIXELS),
        (this.batchUvs = null);
    }
    get geometry() {
      return this._geometry;
    }
    set geometry(t) {
      this._geometry !== t &&
        (this._geometry &&
          (this._geometry.refCount--,
          0 === this._geometry.refCount && this._geometry.dispose()),
        (this._geometry = t),
        this._geometry && this._geometry.refCount++,
        (this.vertexDirty = -1));
    }
    get uvBuffer() {
      return this.geometry.buffers[1];
    }
    get verticesBuffer() {
      return this.geometry.buffers[0];
    }
    set material(t) {
      this.shader = t;
    }
    get material() {
      return this.shader;
    }
    set blendMode(t) {
      this.state.blendMode = t;
    }
    get blendMode() {
      return this.state.blendMode;
    }
    set roundPixels(t) {
      this._roundPixels !== t && (this._transformID = -1),
        (this._roundPixels = t);
    }
    get roundPixels() {
      return this._roundPixels;
    }
    get tint() {
      return "tint" in this.shader ? this.shader.tint : null;
    }
    set tint(t) {
      this.shader.tint = t;
    }
    get tintValue() {
      return this.shader.tintValue;
    }
    get texture() {
      return "texture" in this.shader ? this.shader.texture : null;
    }
    set texture(t) {
      this.shader.texture = t;
    }
    _render(e) {
      const r = this.geometry.buffers[0].data;
      this.shader.batchable &&
      this.drawMode === en.TRIANGLES &&
      r.length < 2 * t.BATCHABLE_SIZE
        ? this._renderToBatch(e)
        : this._renderDefault(e);
    }
    _renderDefault(t) {
      const e = this.shader;
      (e.alpha = this.worldAlpha),
        e.update && e.update(),
        t.batch.flush(),
        (e.uniforms.translationMatrix = this.transform.worldTransform.toArray(
          !0
        )),
        t.shader.bind(e),
        t.state.set(this.state),
        t.geometry.bind(this.geometry, e),
        t.geometry.draw(
          this.drawMode,
          this.size,
          this.start,
          this.geometry.instanceCount
        );
    }
    _renderToBatch(t) {
      const e = this.geometry,
        r = this.shader;
      r.uvMatrix && (r.uvMatrix.update(), this.calculateUvs()),
        this.calculateVertices(),
        (this.indices = e.indexBuffer.data),
        (this._tintRGB = r._tintRGB),
        (this._texture = r.texture);
      const i = this.material.pluginName;
      t.batch.setObjectRenderer(t.plugins[i]), t.plugins[i].render(this);
    }
    calculateVertices() {
      const t = this.geometry.buffers[0],
        e = t.data,
        r = t._updateID;
      if (
        r === this.vertexDirty &&
        this._transformID === this.transform._worldID
      )
        return;
      (this._transformID = this.transform._worldID),
        this.vertexData.length !== e.length &&
          (this.vertexData = new Float32Array(e.length));
      const i = this.transform.worldTransform,
        s = i.a,
        n = i.b,
        o = i.c,
        a = i.d,
        h = i.tx,
        l = i.ty,
        u = this.vertexData;
      for (let c = 0; c < u.length / 2; c++) {
        const t = e[2 * c],
          r = e[2 * c + 1];
        (u[2 * c] = s * t + o * r + h), (u[2 * c + 1] = n * t + a * r + l);
      }
      if (this._roundPixels) {
        const t = _n.RESOLUTION;
        for (let e = 0; e < u.length; ++e) u[e] = Math.round(u[e] * t) / t;
      }
      this.vertexDirty = r;
    }
    calculateUvs() {
      const t = this.geometry.buffers[1],
        e = this.shader;
      e.uvMatrix.isSimple
        ? (this.uvs = t.data)
        : (this.batchUvs || (this.batchUvs = new Tu(t, e.uvMatrix)),
          this.batchUvs.update(),
          (this.uvs = this.batchUvs.data));
    }
    _calculateBounds() {
      this.calculateVertices(),
        this._bounds.addVertexData(this.vertexData, 0, this.vertexData.length);
    }
    containsPoint(t) {
      if (!this.getBounds().contains(t.x, t.y)) return !1;
      this.worldTransform.applyInverse(t, Au);
      const e = this.geometry.getBuffer("aVertexPosition").data,
        r = wu.points,
        i = this.geometry.getIndex().data,
        s = i.length,
        n = 4 === this.drawMode ? 3 : 1;
      for (let o = 0; o + 2 < s; o += n) {
        const t = 2 * i[o],
          s = 2 * i[o + 1],
          n = 2 * i[o + 2];
        if (
          ((r[0] = e[t]),
          (r[1] = e[t + 1]),
          (r[2] = e[s]),
          (r[3] = e[s + 1]),
          (r[4] = e[n]),
          (r[5] = e[n + 1]),
          wu.contains(Au.x, Au.y))
        )
          return !0;
      }
      return !1;
    }
    destroy(t) {
      super.destroy(t),
        this._cachedTexture &&
          (this._cachedTexture.destroy(), (this._cachedTexture = null)),
        (this.geometry = null),
        (this.shader = null),
        (this.state = null),
        (this.uvs = null),
        (this.indices = null),
        (this.vertexData = null);
    }
  };
Su.BATCHABLE_SIZE = 100;
let Ru = Su;
class Iu extends io {
  constructor(t, e, r) {
    super();
    const i = new Zn(t),
      s = new Zn(e, !0),
      n = new Zn(r, !0, !0);
    this.addAttribute("aVertexPosition", i, 2, !1, nn.FLOAT)
      .addAttribute("aTextureCoord", s, 2, !1, nn.FLOAT)
      .addIndex(n),
      (this._updateId = -1);
  }
  get vertexDirtyId() {
    return this.buffers[0]._updateID;
  }
}
class Cu extends Vo {
  constructor(t, e) {
    const r = {
      uSampler: t,
      alpha: 1,
      uTextureMatrix: go.IDENTITY,
      uColor: new Float32Array([1, 1, 1, 1]),
    };
    (e = Object.assign({ tint: 16777215, alpha: 1, pluginName: "batch" }, e))
      .uniforms && Object.assign(r, e.uniforms),
      super(
        e.program ||
          Ho.from(
            "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\nuniform mat3 translationMatrix;\nuniform mat3 uTextureMatrix;\n\nvarying vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = (uTextureMatrix * vec3(aTextureCoord, 1.0)).xy;\n}\n",
            "varying vec2 vTextureCoord;\nuniform vec4 uColor;\n\nuniform sampler2D uSampler;\n\nvoid main(void)\n{\n    gl_FragColor = texture2D(uSampler, vTextureCoord) * uColor;\n}\n"
          ),
        r
      ),
      (this._colorDirty = !1),
      (this.uvMatrix = new Ta(t)),
      (this.batchable = void 0 === e.program),
      (this.pluginName = e.pluginName),
      (this._tintColor = new Rn(e.tint)),
      (this._tintRGB = this._tintColor.toLittleEndianNumber()),
      (this._colorDirty = !0),
      (this.alpha = e.alpha);
  }
  get texture() {
    return this.uniforms.uSampler;
  }
  set texture(t) {
    this.uniforms.uSampler !== t &&
      (!this.uniforms.uSampler.baseTexture.alphaMode !=
        !t.baseTexture.alphaMode && (this._colorDirty = !0),
      (this.uniforms.uSampler = t),
      (this.uvMatrix.texture = t));
  }
  set alpha(t) {
    t !== this._alpha && ((this._alpha = t), (this._colorDirty = !0));
  }
  get alpha() {
    return this._alpha;
  }
  set tint(t) {
    t !== this.tint &&
      (this._tintColor.setValue(t),
      (this._tintRGB = this._tintColor.toLittleEndianNumber()),
      (this._colorDirty = !0));
  }
  get tint() {
    return this._tintColor.value;
  }
  get tintValue() {
    return this._tintColor.toNumber();
  }
  update() {
    if (this._colorDirty) {
      this._colorDirty = !1;
      const t = this.texture.baseTexture.alphaMode;
      Rn.shared
        .setValue(this._tintColor)
        .premultiply(this._alpha, t)
        .toArray(this.uniforms.uColor);
    }
    this.uvMatrix.update() &&
      (this.uniforms.uTextureMatrix = this.uvMatrix.mapCoord);
  }
}
class Pu {
  constructor(t, e, r) {
    (this.geometry = new io()),
      (this.indexBuffer = null),
      (this.size = r),
      (this.dynamicProperties = []),
      (this.staticProperties = []);
    for (let i = 0; i < t.length; ++i) {
      let r = t[i];
      (r = {
        attributeName: r.attributeName,
        size: r.size,
        uploadFunction: r.uploadFunction,
        type: r.type || nn.FLOAT,
        offset: r.offset,
      }),
        e[i] ? this.dynamicProperties.push(r) : this.staticProperties.push(r);
    }
    (this.staticStride = 0),
      (this.staticBuffer = null),
      (this.staticData = null),
      (this.staticDataUint32 = null),
      (this.dynamicStride = 0),
      (this.dynamicBuffer = null),
      (this.dynamicData = null),
      (this.dynamicDataUint32 = null),
      (this._updateID = 0),
      this.initBuffers();
  }
  initBuffers() {
    const t = this.geometry;
    let e = 0;
    (this.indexBuffer = new Zn(
      (function (t, e = null) {
        const r = 6 * t;
        if ((e = e || new Uint16Array(r)).length !== r)
          throw new Error(
            `Out buffer length is incorrect, got ${e.length} and expected ${r}`
          );
        for (let i = 0, s = 0; i < r; i += 6, s += 4)
          (e[i + 0] = s + 0),
            (e[i + 1] = s + 1),
            (e[i + 2] = s + 2),
            (e[i + 3] = s + 0),
            (e[i + 4] = s + 2),
            (e[i + 5] = s + 3);
        return e;
      })(this.size),
      !0,
      !0
    )),
      t.addIndex(this.indexBuffer),
      (this.dynamicStride = 0);
    for (let n = 0; n < this.dynamicProperties.length; ++n) {
      const t = this.dynamicProperties[n];
      (t.offset = e), (e += t.size), (this.dynamicStride += t.size);
    }
    const r = new ArrayBuffer(this.size * this.dynamicStride * 4 * 4);
    (this.dynamicData = new Float32Array(r)),
      (this.dynamicDataUint32 = new Uint32Array(r)),
      (this.dynamicBuffer = new Zn(this.dynamicData, !1, !1));
    let i = 0;
    this.staticStride = 0;
    for (let n = 0; n < this.staticProperties.length; ++n) {
      const t = this.staticProperties[n];
      (t.offset = i), (i += t.size), (this.staticStride += t.size);
    }
    const s = new ArrayBuffer(this.size * this.staticStride * 4 * 4);
    (this.staticData = new Float32Array(s)),
      (this.staticDataUint32 = new Uint32Array(s)),
      (this.staticBuffer = new Zn(this.staticData, !0, !1));
    for (let n = 0; n < this.dynamicProperties.length; ++n) {
      const e = this.dynamicProperties[n];
      t.addAttribute(
        e.attributeName,
        this.dynamicBuffer,
        0,
        e.type === nn.UNSIGNED_BYTE,
        e.type,
        4 * this.dynamicStride,
        4 * e.offset
      );
    }
    for (let n = 0; n < this.staticProperties.length; ++n) {
      const e = this.staticProperties[n];
      t.addAttribute(
        e.attributeName,
        this.staticBuffer,
        0,
        e.type === nn.UNSIGNED_BYTE,
        e.type,
        4 * this.staticStride,
        4 * e.offset
      );
    }
  }
  uploadDynamic(t, e, r) {
    for (let i = 0; i < this.dynamicProperties.length; i++) {
      const s = this.dynamicProperties[i];
      s.uploadFunction(
        t,
        e,
        r,
        s.type === nn.UNSIGNED_BYTE ? this.dynamicDataUint32 : this.dynamicData,
        this.dynamicStride,
        s.offset
      );
    }
    this.dynamicBuffer._updateID++;
  }
  uploadStatic(t, e, r) {
    for (let i = 0; i < this.staticProperties.length; i++) {
      const s = this.staticProperties[i];
      s.uploadFunction(
        t,
        e,
        r,
        s.type === nn.UNSIGNED_BYTE ? this.staticDataUint32 : this.staticData,
        this.staticStride,
        s.offset
      );
    }
    this.staticBuffer._updateID++;
  }
  destroy() {
    (this.indexBuffer = null),
      (this.dynamicProperties = null),
      (this.dynamicBuffer = null),
      (this.dynamicData = null),
      (this.dynamicDataUint32 = null),
      (this.staticProperties = null),
      (this.staticBuffer = null),
      (this.staticData = null),
      (this.staticDataUint32 = null),
      this.geometry.destroy();
  }
}
class Mu extends $o {
  constructor(t) {
    super(t),
      (this.shader = null),
      (this.properties = null),
      (this.tempMatrix = new go()),
      (this.properties = [
        {
          attributeName: "aVertexPosition",
          size: 2,
          uploadFunction: this.uploadVertices,
          offset: 0,
        },
        {
          attributeName: "aPositionCoord",
          size: 2,
          uploadFunction: this.uploadPosition,
          offset: 0,
        },
        {
          attributeName: "aRotation",
          size: 1,
          uploadFunction: this.uploadRotation,
          offset: 0,
        },
        {
          attributeName: "aTextureCoord",
          size: 2,
          uploadFunction: this.uploadUvs,
          offset: 0,
        },
        {
          attributeName: "aColor",
          size: 1,
          type: nn.UNSIGNED_BYTE,
          uploadFunction: this.uploadTint,
          offset: 0,
        },
      ]),
      (this.shader = Vo.from(
        "attribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\nattribute vec4 aColor;\n\nattribute vec2 aPositionCoord;\nattribute float aRotation;\n\nuniform mat3 translationMatrix;\nuniform vec4 uColor;\n\nvarying vec2 vTextureCoord;\nvarying vec4 vColor;\n\nvoid main(void){\n    float x = (aVertexPosition.x) * cos(aRotation) - (aVertexPosition.y) * sin(aRotation);\n    float y = (aVertexPosition.x) * sin(aRotation) + (aVertexPosition.y) * cos(aRotation);\n\n    vec2 v = vec2(x, y);\n    v = v + aPositionCoord;\n\n    gl_Position = vec4((translationMatrix * vec3(v, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = aTextureCoord;\n    vColor = aColor * uColor;\n}\n",
        "varying vec2 vTextureCoord;\nvarying vec4 vColor;\n\nuniform sampler2D uSampler;\n\nvoid main(void){\n    vec4 color = texture2D(uSampler, vTextureCoord) * vColor;\n    gl_FragColor = color;\n}",
        {}
      )),
      (this.state = Hn.for2d());
  }
  render(t) {
    const e = t.children,
      r = t._maxSize,
      i = t._batchSize,
      s = this.renderer;
    let n = e.length;
    if (0 === n) return;
    n > r && !t.autoResize && (n = r);
    let o = t._buffers;
    o || (o = t._buffers = this.generateBuffers(t));
    const a = e[0]._texture.baseTexture,
      h = a.alphaMode > 0;
    (this.state.blendMode = K(t.blendMode, h)), s.state.set(this.state);
    const l = s.gl,
      u = t.worldTransform.copyTo(this.tempMatrix);
    u.prepend(s.globalUniforms.uniforms.projectionMatrix),
      (this.shader.uniforms.translationMatrix = u.toArray(!0)),
      (this.shader.uniforms.uColor = Rn.shared
        .setValue(t.tintRgb)
        .premultiply(t.worldAlpha, h)
        .toArray(this.shader.uniforms.uColor)),
      (this.shader.uniforms.uSampler = a),
      this.renderer.shader.bind(this.shader);
    let c = !1;
    for (let d = 0, p = 0; d < n; d += i, p += 1) {
      let r = n - d;
      r > i && (r = i), p >= o.length && o.push(this._generateOneMoreBuffer(t));
      const a = o[p];
      a.uploadDynamic(e, d, r);
      const h = t._bufferUpdateIDs[p] || 0;
      (c = c || a._updateID < h),
        c && ((a._updateID = t._updateID), a.uploadStatic(e, d, r)),
        s.geometry.bind(a.geometry),
        l.drawElements(l.TRIANGLES, 6 * r, l.UNSIGNED_SHORT, 0);
    }
  }
  generateBuffers(t) {
    const e = [],
      r = t._maxSize,
      i = t._batchSize,
      s = t._properties;
    for (let n = 0; n < r; n += i) e.push(new Pu(this.properties, s, i));
    return e;
  }
  _generateOneMoreBuffer(t) {
    const e = t._batchSize,
      r = t._properties;
    return new Pu(this.properties, r, e);
  }
  uploadVertices(t, e, r, i, s, n) {
    let o = 0,
      a = 0,
      h = 0,
      l = 0;
    for (let u = 0; u < r; ++u) {
      const r = t[e + u],
        c = r._texture,
        d = r.scale.x,
        p = r.scale.y,
        f = c.trim,
        m = c.orig;
      f
        ? ((a = f.x - r.anchor.x * m.width),
          (o = a + f.width),
          (l = f.y - r.anchor.y * m.height),
          (h = l + f.height))
        : ((o = m.width * (1 - r.anchor.x)),
          (a = m.width * -r.anchor.x),
          (h = m.height * (1 - r.anchor.y)),
          (l = m.height * -r.anchor.y)),
        (i[n] = a * d),
        (i[n + 1] = l * p),
        (i[n + s] = o * d),
        (i[n + s + 1] = l * p),
        (i[n + 2 * s] = o * d),
        (i[n + 2 * s + 1] = h * p),
        (i[n + 3 * s] = a * d),
        (i[n + 3 * s + 1] = h * p),
        (n += 4 * s);
    }
  }
  uploadPosition(t, e, r, i, s, n) {
    for (let o = 0; o < r; o++) {
      const r = t[e + o].position;
      (i[n] = r.x),
        (i[n + 1] = r.y),
        (i[n + s] = r.x),
        (i[n + s + 1] = r.y),
        (i[n + 2 * s] = r.x),
        (i[n + 2 * s + 1] = r.y),
        (i[n + 3 * s] = r.x),
        (i[n + 3 * s + 1] = r.y),
        (n += 4 * s);
    }
  }
  uploadRotation(t, e, r, i, s, n) {
    for (let o = 0; o < r; o++) {
      const r = t[e + o].rotation;
      (i[n] = r),
        (i[n + s] = r),
        (i[n + 2 * s] = r),
        (i[n + 3 * s] = r),
        (n += 4 * s);
    }
  }
  uploadUvs(t, e, r, i, s, n) {
    for (let o = 0; o < r; ++o) {
      const r = t[e + o]._texture._uvs;
      r
        ? ((i[n] = r.x0),
          (i[n + 1] = r.y0),
          (i[n + s] = r.x1),
          (i[n + s + 1] = r.y1),
          (i[n + 2 * s] = r.x2),
          (i[n + 2 * s + 1] = r.y2),
          (i[n + 3 * s] = r.x3),
          (i[n + 3 * s + 1] = r.y3),
          (n += 4 * s))
        : ((i[n] = 0),
          (i[n + 1] = 0),
          (i[n + s] = 0),
          (i[n + s + 1] = 0),
          (i[n + 2 * s] = 0),
          (i[n + 2 * s + 1] = 0),
          (i[n + 3 * s] = 0),
          (i[n + 3 * s + 1] = 0),
          (n += 4 * s));
    }
  }
  uploadTint(t, e, r, i, s, n) {
    for (let o = 0; o < r; ++o) {
      const r = t[e + o],
        a = Rn.shared
          .setValue(r._tintRGB)
          .toPremultiplied(r.alpha, r.texture.baseTexture.alphaMode > 0);
      (i[n] = a),
        (i[n + s] = a),
        (i[n + 2 * s] = a),
        (i[n + 3 * s] = a),
        (n += 4 * s);
    }
  }
  destroy() {
    super.destroy(),
      this.shader && (this.shader.destroy(), (this.shader = null)),
      (this.tempMatrix = null);
  }
}
(Mu.extension = { name: "particle", type: Gs.RendererPlugin }),
  kn.add(Mu),
  ($s = ((t) => (
    (t[(t.LINEAR_VERTICAL = 0)] = "LINEAR_VERTICAL"),
    (t[(t.LINEAR_HORIZONTAL = 1)] = "LINEAR_HORIZONTAL"),
    t
  ))($s || {}));
const Du = { willReadFrequently: !0 },
  Ou = class t {
    static get experimentalLetterSpacingSupported() {
      let e = t._experimentalLetterSpacingSupported;
      if (void 0 !== e) {
        const r = _n.ADAPTER.getCanvasRenderingContext2D().prototype;
        e = t._experimentalLetterSpacingSupported =
          "letterSpacing" in r || "textLetterSpacing" in r;
      }
      return e;
    }
    constructor(t, e, r, i, s, n, o, a, h) {
      (this.text = t),
        (this.style = e),
        (this.width = r),
        (this.height = i),
        (this.lines = s),
        (this.lineWidths = n),
        (this.lineHeight = o),
        (this.maxLineWidth = a),
        (this.fontProperties = h);
    }
    static measureText(e, r, i, s = t._canvas) {
      i = i ?? r.wordWrap;
      const n = r.toFontString(),
        o = t.measureFont(n);
      0 === o.fontSize && ((o.fontSize = r.fontSize), (o.ascent = r.fontSize));
      const a = s.getContext("2d", Du);
      a.font = n;
      const h = (i ? t.wordWrap(e, r, s) : e).split(/(?:\r\n|\r|\n)/),
        l = new Array(h.length);
      let u = 0;
      for (let f = 0; f < h.length; f++) {
        const e = t._measureText(h[f], r.letterSpacing, a);
        (l[f] = e), (u = Math.max(u, e));
      }
      let c = u + r.strokeThickness;
      r.dropShadow && (c += r.dropShadowDistance);
      const d = r.lineHeight || o.fontSize + r.strokeThickness;
      let p =
        Math.max(d, o.fontSize + 2 * r.strokeThickness) +
        r.leading +
        (h.length - 1) * (d + r.leading);
      return (
        r.dropShadow && (p += r.dropShadowDistance),
        new t(e, r, c, p, h, l, d + r.leading, u, o)
      );
    }
    static _measureText(e, r, i) {
      let s = !1;
      t.experimentalLetterSpacingSupported &&
        (t.experimentalLetterSpacing
          ? ((i.letterSpacing = `${r}px`),
            (i.textLetterSpacing = `${r}px`),
            (s = !0))
          : ((i.letterSpacing = "0px"), (i.textLetterSpacing = "0px")));
      let n = i.measureText(e).width;
      return (
        n > 0 &&
          (s ? (n -= r) : (n += (t.graphemeSegmenter(e).length - 1) * r)),
        n
      );
    }
    static wordWrap(e, r, i = t._canvas) {
      const s = i.getContext("2d", Du);
      let n = 0,
        o = "",
        a = "";
      const h = Object.create(null),
        { letterSpacing: l, whiteSpace: u } = r,
        c = t.collapseSpaces(u),
        d = t.collapseNewlines(u);
      let p = !c;
      const f = r.wordWrapWidth + l,
        m = t.tokenize(e);
      for (let g = 0; g < m.length; g++) {
        let e = m[g];
        if (t.isNewline(e)) {
          if (!d) {
            (a += t.addLine(o)), (p = !c), (o = ""), (n = 0);
            continue;
          }
          e = " ";
        }
        if (c) {
          const r = t.isBreakingSpace(e),
            i = t.isBreakingSpace(o[o.length - 1]);
          if (r && i) continue;
        }
        const i = t.getFromCache(e, l, h, s);
        if (i > f)
          if (
            ("" !== o && ((a += t.addLine(o)), (o = ""), (n = 0)),
            t.canBreakWords(e, r.breakWords))
          ) {
            const i = t.wordWrapSplit(e);
            for (let u = 0; u < i.length; u++) {
              let c = i[u],
                d = c,
                m = 1;
              for (; i[u + m]; ) {
                const s = i[u + m];
                if (t.canBreakChars(d, s, e, u, r.breakWords)) break;
                (c += s), (d = s), m++;
              }
              u += m - 1;
              const g = t.getFromCache(c, l, h, s);
              g + n > f && ((a += t.addLine(o)), (p = !1), (o = ""), (n = 0)),
                (o += c),
                (n += g);
            }
          } else {
            o.length > 0 && ((a += t.addLine(o)), (o = ""), (n = 0));
            const r = g === m.length - 1;
            (a += t.addLine(e, !r)), (p = !1), (o = ""), (n = 0);
          }
        else
          i + n > f && ((p = !1), (a += t.addLine(o)), (o = ""), (n = 0)),
            (o.length > 0 || !t.isBreakingSpace(e) || p) &&
              ((o += e), (n += i));
      }
      return (a += t.addLine(o, !1)), a;
    }
    static addLine(e, r = !0) {
      return (e = t.trimRight(e)), r ? `${e}\n` : e;
    }
    static getFromCache(e, r, i, s) {
      let n = i[e];
      return (
        "number" != typeof n && ((n = t._measureText(e, r, s) + r), (i[e] = n)),
        n
      );
    }
    static collapseSpaces(t) {
      return "normal" === t || "pre-line" === t;
    }
    static collapseNewlines(t) {
      return "normal" === t;
    }
    static trimRight(e) {
      if ("string" != typeof e) return "";
      for (let r = e.length - 1; r >= 0; r--) {
        const i = e[r];
        if (!t.isBreakingSpace(i)) break;
        e = e.slice(0, -1);
      }
      return e;
    }
    static isNewline(e) {
      return "string" == typeof e && t._newlines.includes(e.charCodeAt(0));
    }
    static isBreakingSpace(e, r) {
      return (
        "string" == typeof e && t._breakingSpaces.includes(e.charCodeAt(0))
      );
    }
    static tokenize(e) {
      const r = [];
      let i = "";
      if ("string" != typeof e) return r;
      for (let s = 0; s < e.length; s++) {
        const n = e[s],
          o = e[s + 1];
        t.isBreakingSpace(n, o) || t.isNewline(n)
          ? ("" !== i && (r.push(i), (i = "")), r.push(n))
          : (i += n);
      }
      return "" !== i && r.push(i), r;
    }
    static canBreakWords(t, e) {
      return e;
    }
    static canBreakChars(t, e, r, i, s) {
      return !0;
    }
    static wordWrapSplit(e) {
      return t.graphemeSegmenter(e);
    }
    static measureFont(e) {
      if (t._fonts[e]) return t._fonts[e];
      const r = { ascent: 0, descent: 0, fontSize: 0 },
        i = t._canvas,
        s = t._context;
      s.font = e;
      const n = t.METRICS_STRING + t.BASELINE_SYMBOL,
        o = Math.ceil(s.measureText(n).width);
      let a = Math.ceil(s.measureText(t.BASELINE_SYMBOL).width);
      const h = Math.ceil(t.HEIGHT_MULTIPLIER * a);
      if (((a = (a * t.BASELINE_MULTIPLIER) | 0), 0 === o || 0 === h))
        return (t._fonts[e] = r), r;
      (i.width = o),
        (i.height = h),
        (s.fillStyle = "#f00"),
        s.fillRect(0, 0, o, h),
        (s.font = e),
        (s.textBaseline = "alphabetic"),
        (s.fillStyle = "#000"),
        s.fillText(n, 0, a);
      const l = s.getImageData(0, 0, o, h).data,
        u = l.length,
        c = 4 * o;
      let d = 0,
        p = 0,
        f = !1;
      for (d = 0; d < a; ++d) {
        for (let t = 0; t < c; t += 4)
          if (255 !== l[p + t]) {
            f = !0;
            break;
          }
        if (f) break;
        p += c;
      }
      for (r.ascent = a - d, p = u - c, f = !1, d = h; d > a; --d) {
        for (let t = 0; t < c; t += 4)
          if (255 !== l[p + t]) {
            f = !0;
            break;
          }
        if (f) break;
        p -= c;
      }
      return (
        (r.descent = d - a),
        (r.fontSize = r.ascent + r.descent),
        (t._fonts[e] = r),
        r
      );
    }
    static clearMetrics(e = "") {
      e ? delete t._fonts[e] : (t._fonts = {});
    }
    static get _canvas() {
      var e;
      if (!t.__canvas) {
        let r;
        try {
          const i = new OffscreenCanvas(0, 0);
          if (null == (e = i.getContext("2d", Du)) ? void 0 : e.measureText)
            return (t.__canvas = i), i;
          r = _n.ADAPTER.createCanvas();
        } catch {
          r = _n.ADAPTER.createCanvas();
        }
        (r.width = r.height = 10), (t.__canvas = r);
      }
      return t.__canvas;
    }
    static get _context() {
      return (
        t.__context || (t.__context = t._canvas.getContext("2d", Du)),
        t.__context
      );
    }
  };
(Ou.METRICS_STRING = "|ÉqÅ"),
  (Ou.BASELINE_SYMBOL = "M"),
  (Ou.BASELINE_MULTIPLIER = 1.4),
  (Ou.HEIGHT_MULTIPLIER = 2),
  (Ou.graphemeSegmenter = (() => {
    if ("function" == typeof (null == Intl ? void 0 : Intl.Segmenter)) {
      const t = new Intl.Segmenter();
      return (e) => [...t.segment(e)].map((t) => t.segment);
    }
    return (t) => [...t];
  })()),
  (Ou.experimentalLetterSpacing = !1),
  (Ou._fonts = {}),
  (Ou._newlines = [10, 13]),
  (Ou._breakingSpaces = [
    9, 32, 8192, 8193, 8194, 8195, 8196, 8197, 8198, 8200, 8201, 8202, 8287,
    12288,
  ]);
let Bu = Ou;
const Nu = [
    "serif",
    "sans-serif",
    "monospace",
    "cursive",
    "fantasy",
    "system-ui",
  ],
  Fu = class t {
    constructor(t) {
      (this.styleID = 0), this.reset(), Ot(this, t, t);
    }
    clone() {
      const e = {};
      return Ot(e, this, t.defaultStyle), new t(e);
    }
    reset() {
      Ot(this, t.defaultStyle, t.defaultStyle);
    }
    get align() {
      return this._align;
    }
    set align(t) {
      this._align !== t && ((this._align = t), this.styleID++);
    }
    get breakWords() {
      return this._breakWords;
    }
    set breakWords(t) {
      this._breakWords !== t && ((this._breakWords = t), this.styleID++);
    }
    get dropShadow() {
      return this._dropShadow;
    }
    set dropShadow(t) {
      this._dropShadow !== t && ((this._dropShadow = t), this.styleID++);
    }
    get dropShadowAlpha() {
      return this._dropShadowAlpha;
    }
    set dropShadowAlpha(t) {
      this._dropShadowAlpha !== t &&
        ((this._dropShadowAlpha = t), this.styleID++);
    }
    get dropShadowAngle() {
      return this._dropShadowAngle;
    }
    set dropShadowAngle(t) {
      this._dropShadowAngle !== t &&
        ((this._dropShadowAngle = t), this.styleID++);
    }
    get dropShadowBlur() {
      return this._dropShadowBlur;
    }
    set dropShadowBlur(t) {
      this._dropShadowBlur !== t &&
        ((this._dropShadowBlur = t), this.styleID++);
    }
    get dropShadowColor() {
      return this._dropShadowColor;
    }
    set dropShadowColor(t) {
      const e = Dt(t);
      this._dropShadowColor !== e &&
        ((this._dropShadowColor = e), this.styleID++);
    }
    get dropShadowDistance() {
      return this._dropShadowDistance;
    }
    set dropShadowDistance(t) {
      this._dropShadowDistance !== t &&
        ((this._dropShadowDistance = t), this.styleID++);
    }
    get fill() {
      return this._fill;
    }
    set fill(t) {
      const e = Dt(t);
      this._fill !== e && ((this._fill = e), this.styleID++);
    }
    get fillGradientType() {
      return this._fillGradientType;
    }
    set fillGradientType(t) {
      this._fillGradientType !== t &&
        ((this._fillGradientType = t), this.styleID++);
    }
    get fillGradientStops() {
      return this._fillGradientStops;
    }
    set fillGradientStops(t) {
      (function (t, e) {
        if (!Array.isArray(t) || !Array.isArray(e) || t.length !== e.length)
          return !1;
        for (let r = 0; r < t.length; ++r) if (t[r] !== e[r]) return !1;
        return !0;
      })(this._fillGradientStops, t) ||
        ((this._fillGradientStops = t), this.styleID++);
    }
    get fontFamily() {
      return this._fontFamily;
    }
    set fontFamily(t) {
      this.fontFamily !== t && ((this._fontFamily = t), this.styleID++);
    }
    get fontSize() {
      return this._fontSize;
    }
    set fontSize(t) {
      this._fontSize !== t && ((this._fontSize = t), this.styleID++);
    }
    get fontStyle() {
      return this._fontStyle;
    }
    set fontStyle(t) {
      this._fontStyle !== t && ((this._fontStyle = t), this.styleID++);
    }
    get fontVariant() {
      return this._fontVariant;
    }
    set fontVariant(t) {
      this._fontVariant !== t && ((this._fontVariant = t), this.styleID++);
    }
    get fontWeight() {
      return this._fontWeight;
    }
    set fontWeight(t) {
      this._fontWeight !== t && ((this._fontWeight = t), this.styleID++);
    }
    get letterSpacing() {
      return this._letterSpacing;
    }
    set letterSpacing(t) {
      this._letterSpacing !== t && ((this._letterSpacing = t), this.styleID++);
    }
    get lineHeight() {
      return this._lineHeight;
    }
    set lineHeight(t) {
      this._lineHeight !== t && ((this._lineHeight = t), this.styleID++);
    }
    get leading() {
      return this._leading;
    }
    set leading(t) {
      this._leading !== t && ((this._leading = t), this.styleID++);
    }
    get lineJoin() {
      return this._lineJoin;
    }
    set lineJoin(t) {
      this._lineJoin !== t && ((this._lineJoin = t), this.styleID++);
    }
    get miterLimit() {
      return this._miterLimit;
    }
    set miterLimit(t) {
      this._miterLimit !== t && ((this._miterLimit = t), this.styleID++);
    }
    get padding() {
      return this._padding;
    }
    set padding(t) {
      this._padding !== t && ((this._padding = t), this.styleID++);
    }
    get stroke() {
      return this._stroke;
    }
    set stroke(t) {
      const e = Dt(t);
      this._stroke !== e && ((this._stroke = e), this.styleID++);
    }
    get strokeThickness() {
      return this._strokeThickness;
    }
    set strokeThickness(t) {
      this._strokeThickness !== t &&
        ((this._strokeThickness = t), this.styleID++);
    }
    get textBaseline() {
      return this._textBaseline;
    }
    set textBaseline(t) {
      this._textBaseline !== t && ((this._textBaseline = t), this.styleID++);
    }
    get trim() {
      return this._trim;
    }
    set trim(t) {
      this._trim !== t && ((this._trim = t), this.styleID++);
    }
    get whiteSpace() {
      return this._whiteSpace;
    }
    set whiteSpace(t) {
      this._whiteSpace !== t && ((this._whiteSpace = t), this.styleID++);
    }
    get wordWrap() {
      return this._wordWrap;
    }
    set wordWrap(t) {
      this._wordWrap !== t && ((this._wordWrap = t), this.styleID++);
    }
    get wordWrapWidth() {
      return this._wordWrapWidth;
    }
    set wordWrapWidth(t) {
      this._wordWrapWidth !== t && ((this._wordWrapWidth = t), this.styleID++);
    }
    toFontString() {
      const t =
        "number" == typeof this.fontSize ? `${this.fontSize}px` : this.fontSize;
      let e = this.fontFamily;
      Array.isArray(this.fontFamily) || (e = this.fontFamily.split(","));
      for (let r = e.length - 1; r >= 0; r--) {
        let t = e[r].trim();
        !/([\"\'])[^\'\"]+\1/.test(t) && !Nu.includes(t) && (t = `"${t}"`),
          (e[r] = t);
      }
      return `${this.fontStyle} ${this.fontVariant} ${
        this.fontWeight
      } ${t} ${e.join(",")}`;
    }
  };
Fu.defaultStyle = {
  align: "left",
  breakWords: !1,
  dropShadow: !1,
  dropShadowAlpha: 1,
  dropShadowAngle: Math.PI / 6,
  dropShadowBlur: 0,
  dropShadowColor: "black",
  dropShadowDistance: 5,
  fill: "black",
  fillGradientType: $s.LINEAR_VERTICAL,
  fillGradientStops: [],
  fontFamily: "Arial",
  fontSize: 26,
  fontStyle: "normal",
  fontVariant: "normal",
  fontWeight: "normal",
  leading: 0,
  letterSpacing: 0,
  lineHeight: 0,
  lineJoin: "miter",
  miterLimit: 10,
  padding: 0,
  stroke: "black",
  strokeThickness: 0,
  textBaseline: "alphabetic",
  trim: !1,
  whiteSpace: "pre",
  wordWrap: !1,
  wordWrapWidth: 100,
};
let Lu = Fu;
const ku = { texture: !0, children: !1, baseTexture: !0 },
  Uu = class t extends Mh {
    constructor(e, r, i) {
      let s = !1;
      i || ((i = _n.ADAPTER.createCanvas()), (s = !0)),
        (i.width = 3),
        (i.height = 3);
      const n = ha.from(i);
      (n.orig = new uo()),
        (n.trim = new uo()),
        super(n),
        (this._ownCanvas = s),
        (this.canvas = i),
        (this.context = i.getContext("2d", { willReadFrequently: !0 })),
        (this._resolution = t.defaultResolution ?? _n.RESOLUTION),
        (this._autoResolution = t.defaultAutoResolution),
        (this._text = null),
        (this._style = null),
        (this._styleListener = null),
        (this._font = ""),
        (this.text = e),
        (this.style = r),
        (this.localStyleID = -1);
    }
    static get experimentalLetterSpacing() {
      return Bu.experimentalLetterSpacing;
    }
    static set experimentalLetterSpacing(t) {
      W(
        0,
        "Text.experimentalLetterSpacing is deprecated, use TextMetrics.experimentalLetterSpacing"
      ),
        (Bu.experimentalLetterSpacing = t);
    }
    updateText(t) {
      const e = this._style;
      if (
        (this.localStyleID !== e.styleID &&
          ((this.dirty = !0), (this.localStyleID = e.styleID)),
        !this.dirty && t)
      )
        return;
      this._font = this._style.toFontString();
      const r = this.context,
        i = Bu.measureText(
          this._text || " ",
          this._style,
          this._style.wordWrap,
          this.canvas
        ),
        s = i.width,
        n = i.height,
        o = i.lines,
        a = i.lineHeight,
        h = i.lineWidths,
        l = i.maxLineWidth,
        u = i.fontProperties;
      let c, d;
      (this.canvas.width = Math.ceil(
        Math.ceil(Math.max(1, s) + 2 * e.padding) * this._resolution
      )),
        (this.canvas.height = Math.ceil(
          Math.ceil(Math.max(1, n) + 2 * e.padding) * this._resolution
        )),
        r.scale(this._resolution, this._resolution),
        r.clearRect(0, 0, this.canvas.width, this.canvas.height),
        (r.font = this._font),
        (r.lineWidth = e.strokeThickness),
        (r.textBaseline = e.textBaseline),
        (r.lineJoin = e.lineJoin),
        (r.miterLimit = e.miterLimit);
      const p = e.dropShadow ? 2 : 1;
      for (let f = 0; f < p; ++f) {
        const t = e.dropShadow && 0 === f,
          s = t ? Math.ceil(Math.max(1, n) + 2 * e.padding) : 0,
          p = s * this._resolution;
        if (t) {
          (r.fillStyle = "black"), (r.strokeStyle = "black");
          const t = e.dropShadowColor,
            i = e.dropShadowBlur * this._resolution,
            s = e.dropShadowDistance * this._resolution;
          (r.shadowColor = Rn.shared
            .setValue(t)
            .setAlpha(e.dropShadowAlpha)
            .toRgbaString()),
            (r.shadowBlur = i),
            (r.shadowOffsetX = Math.cos(e.dropShadowAngle) * s),
            (r.shadowOffsetY = Math.sin(e.dropShadowAngle) * s + p);
        } else
          (r.fillStyle = this._generateFillStyle(e, o, i)),
            (r.strokeStyle = e.stroke),
            (r.shadowColor = "black"),
            (r.shadowBlur = 0),
            (r.shadowOffsetX = 0),
            (r.shadowOffsetY = 0);
        let m = (a - u.fontSize) / 2;
        a - u.fontSize < 0 && (m = 0);
        for (let r = 0; r < o.length; r++)
          (c = e.strokeThickness / 2),
            (d = e.strokeThickness / 2 + r * a + u.ascent + m),
            "right" === e.align
              ? (c += l - h[r])
              : "center" === e.align && (c += (l - h[r]) / 2),
            e.stroke &&
              e.strokeThickness &&
              this.drawLetterSpacing(
                o[r],
                c + e.padding,
                d + e.padding - s,
                !0
              ),
            e.fill &&
              this.drawLetterSpacing(o[r], c + e.padding, d + e.padding - s);
      }
      this.updateTexture();
    }
    drawLetterSpacing(t, e, r, i = !1) {
      const s = this._style.letterSpacing;
      let n = !1;
      if (
        (Bu.experimentalLetterSpacingSupported &&
          (Bu.experimentalLetterSpacing
            ? ((this.context.letterSpacing = `${s}px`),
              (this.context.textLetterSpacing = `${s}px`),
              (n = !0))
            : ((this.context.letterSpacing = "0px"),
              (this.context.textLetterSpacing = "0px"))),
        0 === s || n)
      )
        return void (i
          ? this.context.strokeText(t, e, r)
          : this.context.fillText(t, e, r));
      let o = e;
      const a = Bu.graphemeSegmenter(t);
      let h = this.context.measureText(t).width,
        l = 0;
      for (let u = 0; u < a.length; ++u) {
        const t = a[u];
        i ? this.context.strokeText(t, o, r) : this.context.fillText(t, o, r);
        let e = "";
        for (let r = u + 1; r < a.length; ++r) e += a[r];
        (l = this.context.measureText(e).width), (o += h - l + s), (h = l);
      }
    }
    updateTexture() {
      const t = this.canvas;
      if (this._style.trim) {
        const e = (function (t) {
          const e = (function (t) {
              const { width: e, height: r } = t,
                i = t.getContext("2d", { willReadFrequently: !0 });
              if (null === i)
                throw new TypeError("Failed to get canvas 2D context");
              const s = i.getImageData(0, 0, e, r).data;
              let n = 0,
                o = 0,
                a = e - 1,
                h = r - 1;
              for (; o < r && st(s, e, o); ) ++o;
              if (o === r) return Mn.EMPTY;
              for (; st(s, e, h); ) --h;
              for (; nt(s, e, n, o, h); ) ++n;
              for (; nt(s, e, a, o, h); ) --a;
              return ++a, ++h, new Mn(n, o, a, h);
            })(t),
            { width: r, height: i } = e;
          let s = null;
          if (!e.isEmpty()) {
            const n = t.getContext("2d");
            if (null === n)
              throw new TypeError("Failed to get canvas 2D context");
            s = n.getImageData(e.left, e.top, r, i);
          }
          return { width: r, height: i, data: s };
        })(t);
        e.data &&
          ((t.width = e.width),
          (t.height = e.height),
          this.context.putImageData(e.data, 0, 0));
      }
      const e = this._texture,
        r = this._style,
        i = r.trim ? 0 : r.padding,
        s = e.baseTexture;
      (e.trim.width = e._frame.width = t.width / this._resolution),
        (e.trim.height = e._frame.height = t.height / this._resolution),
        (e.trim.x = -i),
        (e.trim.y = -i),
        (e.orig.width = e._frame.width - 2 * i),
        (e.orig.height = e._frame.height - 2 * i),
        this._onTextureUpdate(),
        s.setRealSize(t.width, t.height, this._resolution),
        e.updateUvs(),
        (this.dirty = !1);
    }
    _render(t) {
      this._autoResolution &&
        this._resolution !== t.resolution &&
        ((this._resolution = t.resolution), (this.dirty = !0)),
        this.updateText(!0),
        super._render(t);
    }
    updateTransform() {
      this.updateText(!0), super.updateTransform();
    }
    getBounds(t, e) {
      return (
        this.updateText(!0),
        -1 === this._textureID && (t = !1),
        super.getBounds(t, e)
      );
    }
    getLocalBounds(t) {
      return this.updateText(!0), super.getLocalBounds.call(this, t);
    }
    _calculateBounds() {
      this.calculateVertices(), this._bounds.addQuad(this.vertexData);
    }
    _generateFillStyle(t, e, r) {
      const i = t.fill;
      if (!Array.isArray(i)) return i;
      if (1 === i.length) return i[0];
      let s;
      const n = t.dropShadow ? t.dropShadowDistance : 0,
        o = t.padding || 0,
        a = this.canvas.width / this._resolution - n - 2 * o,
        h = this.canvas.height / this._resolution - n - 2 * o,
        l = i.slice(),
        u = t.fillGradientStops.slice();
      if (!u.length) {
        const t = l.length + 1;
        for (let e = 1; e < t; ++e) u.push(e / t);
      }
      if (
        (l.unshift(i[0]),
        u.unshift(0),
        l.push(i[i.length - 1]),
        u.push(1),
        t.fillGradientType === $s.LINEAR_VERTICAL)
      ) {
        s = this.context.createLinearGradient(a / 2, o, a / 2, h + o);
        const i = r.fontProperties.fontSize + t.strokeThickness;
        for (let t = 0; t < e.length; t++) {
          const n = r.lineHeight * (t - 1) + i,
            o = r.lineHeight * t;
          let a = o;
          t > 0 && n > o && (a = (o + n) / 2);
          const c = o + i,
            d = r.lineHeight * (t + 1);
          let p = c;
          t + 1 < e.length && d < c && (p = (c + d) / 2);
          const f = (p - a) / h;
          for (let t = 0; t < l.length; t++) {
            let e = 0;
            e = "number" == typeof u[t] ? u[t] : t / l.length;
            let r = Math.min(1, Math.max(0, a / h + e * f));
            (r = Number(r.toFixed(5))), s.addColorStop(r, l[t]);
          }
        }
      } else {
        s = this.context.createLinearGradient(o, h / 2, a + o, h / 2);
        const t = l.length + 1;
        let e = 1;
        for (let r = 0; r < l.length; r++) {
          let i;
          (i = "number" == typeof u[r] ? u[r] : e / t),
            s.addColorStop(i, l[r]),
            e++;
        }
      }
      return s;
    }
    destroy(t) {
      "boolean" == typeof t && (t = { children: t }),
        (t = Object.assign({}, ku, t)),
        super.destroy(t),
        this._ownCanvas && (this.canvas.height = this.canvas.width = 0),
        (this.context = null),
        (this.canvas = null),
        (this._style = null);
    }
    get width() {
      return (
        this.updateText(!0), Math.abs(this.scale.x) * this._texture.orig.width
      );
    }
    set width(t) {
      this.updateText(!0);
      const e = rt(this.scale.x) || 1;
      (this.scale.x = (e * t) / this._texture.orig.width), (this._width = t);
    }
    get height() {
      return (
        this.updateText(!0), Math.abs(this.scale.y) * this._texture.orig.height
      );
    }
    set height(t) {
      this.updateText(!0);
      const e = rt(this.scale.y) || 1;
      (this.scale.y = (e * t) / this._texture.orig.height), (this._height = t);
    }
    get style() {
      return this._style;
    }
    set style(t) {
      (t = t || {}),
        (this._style = t instanceof Lu ? t : new Lu(t)),
        (this.localStyleID = -1),
        (this.dirty = !0);
    }
    get text() {
      return this._text;
    }
    set text(t) {
      (t = String(t ?? "")),
        this._text !== t && ((this._text = t), (this.dirty = !0));
    }
    get resolution() {
      return this._resolution;
    }
    set resolution(t) {
      (this._autoResolution = !1),
        this._resolution !== t && ((this._resolution = t), (this.dirty = !0));
    }
  };
Uu.defaultAutoResolution = !0;
let Gu = Uu;
class Hu {
  constructor(t) {
    (this.maxItemsPerFrame = t), (this.itemsLeft = 0);
  }
  beginFrame() {
    this.itemsLeft = this.maxItemsPerFrame;
  }
  allowedToUpload() {
    return this.itemsLeft-- > 0;
  }
}
const ju = class t {
  constructor(e) {
    (this.limiter = new Hu(t.uploadsPerFrame)),
      (this.renderer = e),
      (this.uploadHookHelper = null),
      (this.queue = []),
      (this.addHooks = []),
      (this.uploadHooks = []),
      (this.completes = []),
      (this.ticking = !1),
      (this.delayedTick = () => {
        this.queue && this.prepareItems();
      }),
      this.registerFindHook(Ut),
      this.registerFindHook(Gt),
      this.registerFindHook(Bt),
      this.registerFindHook(Nt),
      this.registerFindHook(Ft),
      this.registerUploadHook(Lt),
      this.registerUploadHook(kt);
  }
  upload(t) {
    return new Promise((e) => {
      t && this.add(t),
        this.queue.length
          ? (this.completes.push(e),
            this.ticking ||
              ((this.ticking = !0),
              nh.system.addOnce(this.tick, this, js.UTILITY)))
          : e();
    });
  }
  tick() {
    setTimeout(this.delayedTick, 0);
  }
  prepareItems() {
    for (
      this.limiter.beginFrame();
      this.queue.length && this.limiter.allowedToUpload();

    ) {
      const t = this.queue[0];
      let e = !1;
      if (t && !t._destroyed)
        for (let r = 0, i = this.uploadHooks.length; r < i; r++)
          if (this.uploadHooks[r](this.uploadHookHelper, t)) {
            this.queue.shift(), (e = !0);
            break;
          }
      e || this.queue.shift();
    }
    if (this.queue.length) nh.system.addOnce(this.tick, this, js.UTILITY);
    else {
      this.ticking = !1;
      const t = this.completes.slice(0);
      this.completes.length = 0;
      for (let e = 0, r = t.length; e < r; e++) t[e]();
    }
  }
  registerFindHook(t) {
    return t && this.addHooks.push(t), this;
  }
  registerUploadHook(t) {
    return t && this.uploadHooks.push(t), this;
  }
  add(t) {
    for (
      let e = 0, r = this.addHooks.length;
      e < r && !this.addHooks[e](t, this.queue);
      e++
    );
    if (t instanceof Ih)
      for (let e = t.children.length - 1; e >= 0; e--) this.add(t.children[e]);
    return this;
  }
  destroy() {
    this.ticking && nh.system.remove(this.tick, this),
      (this.ticking = !1),
      (this.addHooks = null),
      (this.uploadHooks = null),
      (this.renderer = null),
      (this.completes = null),
      (this.queue = null),
      (this.limiter = null),
      (this.uploadHookHelper = null);
  }
};
ju.uploadsPerFrame = 4;
let Xu = ju;
Object.defineProperties(_n, {
  UPLOADS_PER_FRAME: {
    get: () => Xu.uploadsPerFrame,
    set(t) {
      W(
        0,
        "settings.UPLOADS_PER_FRAME is deprecated, use prepare.BasePrepare.uploadsPerFrame"
      ),
        (Xu.uploadsPerFrame = t);
    },
  },
});
class Vu extends Xu {
  constructor(t) {
    super(t),
      (this.uploadHookHelper = this.renderer),
      this.registerFindHook(Xt),
      this.registerUploadHook(Ht),
      this.registerUploadHook(jt);
  }
}
(Vu.extension = { name: "prepare", type: Gs.RendererSystem }),
  kn.add(Vu),
  (Ys =
    "#version 100\n#define SHADER_NAME Tiling-Sprite-100\n\nprecision lowp float;\n\nattribute vec2 aVertexPosition;\nattribute vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\nuniform mat3 translationMatrix;\nuniform mat3 uTransform;\n\nvarying vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = (uTransform * vec3(aTextureCoord, 1.0)).xy;\n}\n");
const zu = new go();
class Wu extends $o {
  constructor(t) {
    super(t),
      t.runners.contextChange.add(this),
      (this.quad = new da()),
      (this.state = Hn.for2d());
  }
  contextChange() {
    const t = this.renderer,
      e = { globals: t.globalUniforms };
    (this.simpleShader = Vo.from(
      Ys,
      "#version 100\n#define SHADER_NAME Tiling-Sprite-Simple-100\n\nprecision lowp float;\n\nvarying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\nuniform vec4 uColor;\n\nvoid main(void)\n{\n    vec4 texSample = texture2D(uSampler, vTextureCoord);\n    gl_FragColor = texSample * uColor;\n}\n",
      e
    )),
      (this.shader =
        t.context.webGLVersion > 1
          ? Vo.from(
              "#version 300 es\n#define SHADER_NAME Tiling-Sprite-300\n\nprecision lowp float;\n\nin vec2 aVertexPosition;\nin vec2 aTextureCoord;\n\nuniform mat3 projectionMatrix;\nuniform mat3 translationMatrix;\nuniform mat3 uTransform;\n\nout vec2 vTextureCoord;\n\nvoid main(void)\n{\n    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\n\n    vTextureCoord = (uTransform * vec3(aTextureCoord, 1.0)).xy;\n}\n",
              "#version 300 es\n#define SHADER_NAME Tiling-Sprite-100\n\nprecision lowp float;\n\nin vec2 vTextureCoord;\n\nout vec4 fragmentColor;\n\nuniform sampler2D uSampler;\nuniform vec4 uColor;\nuniform mat3 uMapCoord;\nuniform vec4 uClampFrame;\nuniform vec2 uClampOffset;\n\nvoid main(void)\n{\n    vec2 coord = vTextureCoord + ceil(uClampOffset - vTextureCoord);\n    coord = (uMapCoord * vec3(coord, 1.0)).xy;\n    vec2 unclamped = coord;\n    coord = clamp(coord, uClampFrame.xy, uClampFrame.zw);\n\n    vec4 texSample = texture(uSampler, coord, unclamped == coord ? 0.0f : -32.0f);// lod-bias very negative to force lod 0\n\n    fragmentColor = texSample * uColor;\n}\n",
              e
            )
          : Vo.from(
              Ys,
              "#version 100\n#ifdef GL_EXT_shader_texture_lod\n    #extension GL_EXT_shader_texture_lod : enable\n#endif\n#define SHADER_NAME Tiling-Sprite-100\n\nprecision lowp float;\n\nvarying vec2 vTextureCoord;\n\nuniform sampler2D uSampler;\nuniform vec4 uColor;\nuniform mat3 uMapCoord;\nuniform vec4 uClampFrame;\nuniform vec2 uClampOffset;\n\nvoid main(void)\n{\n    vec2 coord = vTextureCoord + ceil(uClampOffset - vTextureCoord);\n    coord = (uMapCoord * vec3(coord, 1.0)).xy;\n    vec2 unclamped = coord;\n    coord = clamp(coord, uClampFrame.xy, uClampFrame.zw);\n\n    #ifdef GL_EXT_shader_texture_lod\n        vec4 texSample = unclamped == coord\n            ? texture2D(uSampler, coord) \n            : texture2DLodEXT(uSampler, coord, 0);\n    #else\n        vec4 texSample = texture2D(uSampler, coord);\n    #endif\n\n    gl_FragColor = texSample * uColor;\n}\n",
              e
            ));
  }
  render(t) {
    const e = this.renderer,
      r = this.quad;
    let i = r.vertices;
    (i[0] = i[6] = t._width * -t.anchor.x),
      (i[1] = i[3] = t._height * -t.anchor.y),
      (i[2] = i[4] = t._width * (1 - t.anchor.x)),
      (i[5] = i[7] = t._height * (1 - t.anchor.y));
    const s = t.uvRespectAnchor ? t.anchor.x : 0,
      n = t.uvRespectAnchor ? t.anchor.y : 0;
    (i = r.uvs),
      (i[0] = i[6] = -s),
      (i[1] = i[3] = -n),
      (i[2] = i[4] = 1 - s),
      (i[5] = i[7] = 1 - n),
      r.invalidate();
    const o = t._texture,
      a = o.baseTexture,
      h = a.alphaMode > 0,
      l = t.tileTransform.localTransform,
      u = t.uvMatrix;
    let c =
      a.isPowerOfTwo &&
      o.frame.width === a.width &&
      o.frame.height === a.height;
    c &&
      (a._glTextures[e.CONTEXT_UID]
        ? (c = a.wrapMode !== hn.CLAMP)
        : a.wrapMode === hn.CLAMP && (a.wrapMode = hn.REPEAT));
    const d = c ? this.simpleShader : this.shader,
      p = o.width,
      f = o.height,
      m = t._width,
      g = t._height;
    zu.set(
      (l.a * p) / m,
      (l.b * p) / g,
      (l.c * f) / m,
      (l.d * f) / g,
      l.tx / m,
      l.ty / g
    ),
      zu.invert(),
      c
        ? zu.prepend(u.mapCoord)
        : ((d.uniforms.uMapCoord = u.mapCoord.toArray(!0)),
          (d.uniforms.uClampFrame = u.uClampFrame),
          (d.uniforms.uClampOffset = u.uClampOffset)),
      (d.uniforms.uTransform = zu.toArray(!0)),
      (d.uniforms.uColor = Rn.shared
        .setValue(t.tint)
        .premultiply(t.worldAlpha, h)
        .toArray(d.uniforms.uColor)),
      (d.uniforms.translationMatrix = t.transform.worldTransform.toArray(!0)),
      (d.uniforms.uSampler = o),
      e.shader.bind(d),
      e.geometry.bind(r),
      (this.state.blendMode = K(t.blendMode, h)),
      e.state.set(this.state),
      e.geometry.draw(this.renderer.gl.TRIANGLES, 6, 0);
  }
}
(Wu.extension = { name: "tilingSprite", type: Gs.RendererPlugin }), kn.add(Wu);
const $u = class t {
  constructor(t, e, r = null) {
    (this.linkedSheets = []),
      (this._texture = t instanceof ha ? t : null),
      (this.baseTexture = t instanceof Yn ? t : this._texture.baseTexture),
      (this.textures = {}),
      (this.animations = {}),
      (this.data = e);
    const i = this.baseTexture.resource;
    (this.resolution = this._updateResolution(r || (i ? i.url : null))),
      (this._frames = this.data.frames),
      (this._frameKeys = Object.keys(this._frames)),
      (this._batchIndex = 0),
      (this._callback = null);
  }
  _updateResolution(t = null) {
    const { scale: e } = this.data.meta;
    let r = ot(t, null);
    return (
      null === r && (r = parseFloat(e ?? "1")),
      1 !== r && this.baseTexture.setResolution(r),
      r
    );
  }
  parse() {
    return new Promise((e) => {
      (this._callback = e),
        (this._batchIndex = 0),
        this._frameKeys.length <= t.BATCH_SIZE
          ? (this._processFrames(0),
            this._processAnimations(),
            this._parseComplete())
          : this._nextBatch();
    });
  }
  _processFrames(e) {
    let r = e;
    const i = t.BATCH_SIZE;
    for (; r - e < i && r < this._frameKeys.length; ) {
      const t = this._frameKeys[r],
        e = this._frames[t],
        i = e.frame;
      if (i) {
        let r = null,
          s = null;
        const n = !1 !== e.trimmed && e.sourceSize ? e.sourceSize : e.frame,
          o = new uo(
            0,
            0,
            Math.floor(n.w) / this.resolution,
            Math.floor(n.h) / this.resolution
          );
        (r = e.rotated
          ? new uo(
              Math.floor(i.x) / this.resolution,
              Math.floor(i.y) / this.resolution,
              Math.floor(i.h) / this.resolution,
              Math.floor(i.w) / this.resolution
            )
          : new uo(
              Math.floor(i.x) / this.resolution,
              Math.floor(i.y) / this.resolution,
              Math.floor(i.w) / this.resolution,
              Math.floor(i.h) / this.resolution
            )),
          !1 !== e.trimmed &&
            e.spriteSourceSize &&
            (s = new uo(
              Math.floor(e.spriteSourceSize.x) / this.resolution,
              Math.floor(e.spriteSourceSize.y) / this.resolution,
              Math.floor(i.w) / this.resolution,
              Math.floor(i.h) / this.resolution
            )),
          (this.textures[t] = new ha(
            this.baseTexture,
            r,
            o,
            s,
            e.rotated ? 2 : 0,
            e.anchor,
            e.borders
          )),
          ha.addToCache(this.textures[t], t.toString());
      }
      r++;
    }
  }
  _processAnimations() {
    const t = this.data.animations || {};
    for (const e in t) {
      this.animations[e] = [];
      for (let r = 0; r < t[e].length; r++) {
        const i = t[e][r];
        this.animations[e].push(this.textures[i]);
      }
    }
  }
  _parseComplete() {
    const t = this._callback;
    (this._callback = null),
      (this._batchIndex = 0),
      t.call(this, this.textures);
  }
  _nextBatch() {
    this._processFrames(this._batchIndex * t.BATCH_SIZE),
      this._batchIndex++,
      setTimeout(() => {
        this._batchIndex * t.BATCH_SIZE < this._frameKeys.length
          ? this._nextBatch()
          : (this._processAnimations(), this._parseComplete());
      }, 0);
  }
  destroy(t = !1) {
    var e;
    for (const r in this.textures) this.textures[r].destroy();
    (this._frames = null),
      (this._frameKeys = null),
      (this.data = null),
      (this.textures = null),
      t &&
        (null == (e = this._texture) || e.destroy(),
        this.baseTexture.destroy()),
      (this._texture = null),
      (this.baseTexture = null),
      (this.linkedSheets = []);
  }
};
$u.BATCH_SIZE = 1e3;
let Yu = $u;
const qu = ["jpg", "png", "jpeg", "avif", "webp"],
  Ku = {
    extension: Gs.Asset,
    cache: {
      test: (t) => t instanceof Yu,
      getCacheableAssets: (t, e) => Vt(t, e, !1),
    },
    resolver: {
      test: (t) => {
        const e = t.split("?")[0].split("."),
          r = e.pop(),
          i = e.pop();
        return "json" === r && qu.includes(i);
      },
      parse: (t) => {
        var e;
        const r = t.split(".");
        return {
          resolution: parseFloat(
            (null == (e = _n.RETINA_PREFIX.exec(t)) ? void 0 : e[1]) ?? "1"
          ),
          format: r[r.length - 2],
          src: t,
        };
      },
    },
    loader: {
      name: "spritesheetLoader",
      extension: { type: Gs.LoadParser, priority: Xs.Normal },
      testParse: async (t, e) =>
        ".json" === Tn.extname(e.src).toLowerCase() && !!t.frames,
      async parse(t, e, r) {
        var i, s;
        let n = Tn.dirname(e.src);
        n && n.lastIndexOf("/") !== n.length - 1 && (n += "/");
        let o = n + t.meta.image;
        o = sl(o, e.src);
        const a = (await r.load([o]))[o],
          h = new Yu(a.baseTexture, t, e.src);
        await h.parse();
        const l =
          null == (i = null == t ? void 0 : t.meta)
            ? void 0
            : i.related_multi_packs;
        if (Array.isArray(l)) {
          const t = [];
          for (const o of l) {
            if ("string" != typeof o) continue;
            let i = n + o;
            (null == (s = e.data) ? void 0 : s.ignoreMultiPack) ||
              ((i = sl(i, e.src)),
              t.push(r.load({ src: i, data: { ignoreMultiPack: !0 } })));
          }
          const i = await Promise.all(t);
          (h.linkedSheets = i),
            i.forEach((t) => {
              t.linkedSheets = [h].concat(
                h.linkedSheets.filter((e) => e !== t)
              );
            });
        }
        return h;
      },
      unload(t) {
        t.destroy(!0);
      },
    },
  };
kn.add(Ku);
class Zu {
  constructor() {
    (this.info = []),
      (this.common = []),
      (this.page = []),
      (this.char = []),
      (this.kerning = []),
      (this.distanceField = []);
  }
}
class Qu {
  static test(t) {
    return "string" == typeof t && t.startsWith("info face=");
  }
  static parse(t) {
    const e = t.match(/^[a-z]+\s+.+$/gm),
      r = {
        info: [],
        common: [],
        page: [],
        char: [],
        chars: [],
        kerning: [],
        kernings: [],
        distanceField: [],
      };
    for (const s in e) {
      const t = e[s].match(/^[a-z]+/gm)[0],
        i = e[s].match(/[a-zA-Z]+=([^\s"']+|"([^"]*)")/gm),
        n = {};
      for (const e in i) {
        const t = i[e].split("="),
          r = t[0],
          s = t[1].replace(/"/gm, ""),
          o = parseFloat(s),
          a = isNaN(o) ? s : o;
        n[r] = a;
      }
      r[t].push(n);
    }
    const i = new Zu();
    return (
      r.info.forEach((t) =>
        i.info.push({ face: t.face, size: parseInt(t.size, 10) })
      ),
      r.common.forEach((t) =>
        i.common.push({ lineHeight: parseInt(t.lineHeight, 10) })
      ),
      r.page.forEach((t) =>
        i.page.push({ id: parseInt(t.id, 10), file: t.file })
      ),
      r.char.forEach((t) =>
        i.char.push({
          id: parseInt(t.id, 10),
          page: parseInt(t.page, 10),
          x: parseInt(t.x, 10),
          y: parseInt(t.y, 10),
          width: parseInt(t.width, 10),
          height: parseInt(t.height, 10),
          xoffset: parseInt(t.xoffset, 10),
          yoffset: parseInt(t.yoffset, 10),
          xadvance: parseInt(t.xadvance, 10),
        })
      ),
      r.kerning.forEach((t) =>
        i.kerning.push({
          first: parseInt(t.first, 10),
          second: parseInt(t.second, 10),
          amount: parseInt(t.amount, 10),
        })
      ),
      r.distanceField.forEach((t) =>
        i.distanceField.push({
          distanceRange: parseInt(t.distanceRange, 10),
          fieldType: t.fieldType,
        })
      ),
      i
    );
  }
}
class Ju {
  static test(t) {
    const e = t;
    return (
      "string" != typeof t &&
      "getElementsByTagName" in t &&
      e.getElementsByTagName("page").length &&
      null !== e.getElementsByTagName("info")[0].getAttribute("face")
    );
  }
  static parse(t) {
    const e = new Zu(),
      r = t.getElementsByTagName("info"),
      i = t.getElementsByTagName("common"),
      s = t.getElementsByTagName("page"),
      n = t.getElementsByTagName("char"),
      o = t.getElementsByTagName("kerning"),
      a = t.getElementsByTagName("distanceField");
    for (let h = 0; h < r.length; h++)
      e.info.push({
        face: r[h].getAttribute("face"),
        size: parseInt(r[h].getAttribute("size"), 10),
      });
    for (let h = 0; h < i.length; h++)
      e.common.push({
        lineHeight: parseInt(i[h].getAttribute("lineHeight"), 10),
      });
    for (let h = 0; h < s.length; h++)
      e.page.push({
        id: parseInt(s[h].getAttribute("id"), 10) || 0,
        file: s[h].getAttribute("file"),
      });
    for (let h = 0; h < n.length; h++) {
      const t = n[h];
      e.char.push({
        id: parseInt(t.getAttribute("id"), 10),
        page: parseInt(t.getAttribute("page"), 10) || 0,
        x: parseInt(t.getAttribute("x"), 10),
        y: parseInt(t.getAttribute("y"), 10),
        width: parseInt(t.getAttribute("width"), 10),
        height: parseInt(t.getAttribute("height"), 10),
        xoffset: parseInt(t.getAttribute("xoffset"), 10),
        yoffset: parseInt(t.getAttribute("yoffset"), 10),
        xadvance: parseInt(t.getAttribute("xadvance"), 10),
      });
    }
    for (let h = 0; h < o.length; h++)
      e.kerning.push({
        first: parseInt(o[h].getAttribute("first"), 10),
        second: parseInt(o[h].getAttribute("second"), 10),
        amount: parseInt(o[h].getAttribute("amount"), 10),
      });
    for (let h = 0; h < a.length; h++)
      e.distanceField.push({
        fieldType: a[h].getAttribute("fieldType"),
        distanceRange: parseInt(a[h].getAttribute("distanceRange"), 10),
      });
    return e;
  }
}
class tc {
  static test(t) {
    return (
      !("string" != typeof t || !t.includes("<font>")) &&
      Ju.test(_n.ADAPTER.parseXML(t))
    );
  }
  static parse(t) {
    return Ju.parse(_n.ADAPTER.parseXML(t));
  }
}
const ec = [Qu, Ju, tc],
  rc = class t {
    constructor(t, e, r) {
      var i;
      const [s] = t.info,
        [n] = t.common,
        [o] = t.page,
        [a] = t.distanceField,
        h = ot(o.file),
        l = {};
      (this._ownsTextures = r),
        (this.font = s.face),
        (this.size = s.size),
        (this.lineHeight = n.lineHeight / h),
        (this.chars = {}),
        (this.pageTextures = l);
      for (let u = 0; u < t.page.length; u++) {
        const { id: r, file: i } = t.page[u];
        (l[r] = e instanceof Array ? e[u] : e[i]),
          (null == a ? void 0 : a.fieldType) &&
            "none" !== a.fieldType &&
            ((l[r].baseTexture.alphaMode = un.NO_PREMULTIPLIED_ALPHA),
            (l[r].baseTexture.mipmap = ln.OFF));
      }
      for (let u = 0; u < t.char.length; u++) {
        const { id: e, page: r } = t.char[u];
        let {
          x: i,
          y: s,
          width: n,
          height: o,
          xoffset: a,
          yoffset: c,
          xadvance: d,
        } = t.char[u];
        (i /= h), (s /= h), (n /= h), (o /= h), (a /= h), (c /= h), (d /= h);
        const p = new uo(i + l[r].frame.x / h, s + l[r].frame.y / h, n, o);
        this.chars[e] = {
          xOffset: a,
          yOffset: c,
          xAdvance: d,
          kerning: {},
          texture: new ha(l[r].baseTexture, p),
          page: r,
        };
      }
      for (let u = 0; u < t.kerning.length; u++) {
        let { first: e, second: r, amount: i } = t.kerning[u];
        (e /= h),
          (r /= h),
          (i /= h),
          this.chars[r] && (this.chars[r].kerning[e] = i);
      }
      (this.distanceFieldRange = null == a ? void 0 : a.distanceRange),
        (this.distanceFieldType =
          (null == (i = null == a ? void 0 : a.fieldType)
            ? void 0
            : i.toLowerCase()) ?? "none");
    }
    destroy() {
      for (const t in this.chars)
        this.chars[t].texture.destroy(), (this.chars[t].texture = null);
      for (const t in this.pageTextures)
        this._ownsTextures && this.pageTextures[t].destroy(!0),
          (this.pageTextures[t] = null);
      (this.chars = null), (this.pageTextures = null);
    }
    static install(e, r, i) {
      let s;
      if (e instanceof Zu) s = e;
      else {
        const t = (function (t) {
          for (let e = 0; e < ec.length; e++) if (ec[e].test(t)) return ec[e];
          return null;
        })(e);
        if (!t) throw new Error("Unrecognized data format for font.");
        s = t.parse(e);
      }
      r instanceof ha && (r = [r]);
      const n = new t(s, r, i);
      return (t.available[n.font] = n), n;
    }
    static uninstall(e) {
      const r = t.available[e];
      if (!r) throw new Error(`No font found named '${e}'`);
      r.destroy(), delete t.available[e];
    }
    static from(e, r, i) {
      if (!e) throw new Error("[BitmapFont] Property `name` is required.");
      const {
          chars: s,
          padding: n,
          resolution: o,
          textureWidth: a,
          textureHeight: h,
          ...l
        } = Object.assign({}, t.defaultOptions, i),
        u = (function (t) {
          "string" == typeof t && (t = [t]);
          const e = [];
          for (let r = 0, i = t.length; r < i; r++) {
            const i = t[r];
            if (Array.isArray(i)) {
              if (2 !== i.length)
                throw new Error(
                  `[BitmapFont]: Invalid character range length, expecting 2 got ${i.length}.`
                );
              const t = i[0].charCodeAt(0),
                r = i[1].charCodeAt(0);
              if (r < t)
                throw new Error("[BitmapFont]: Invalid character range.");
              for (let i = t, s = r; i <= s; i++)
                e.push(String.fromCharCode(i));
            } else e.push(...$t(i));
          }
          if (0 === e.length)
            throw new Error(
              "[BitmapFont]: Empty set when resolving characters."
            );
          return e;
        })(s),
        c = r instanceof Lu ? r : new Lu(r),
        d = a,
        p = new Zu();
      (p.info[0] = { face: c.fontFamily, size: c.fontSize }),
        (p.common[0] = { lineHeight: c.fontSize });
      let f,
        m,
        g,
        _ = 0,
        y = 0,
        v = 0;
      const x = [];
      for (let t = 0; t < u.length; t++) {
        f ||
          ((f = _n.ADAPTER.createCanvas()),
          (f.width = a),
          (f.height = h),
          (m = f.getContext("2d")),
          (g = new Yn(f, { resolution: o, ...l })),
          x.push(new ha(g)),
          p.page.push({ id: x.length - 1, file: "" }));
        const e = u[t],
          r = Bu.measureText(e, c, !1, f),
          i = r.width,
          s = Math.ceil(r.height),
          b = Math.ceil(("italic" === c.fontStyle ? 2 : 1) * i);
        if (y >= h - s * o) {
          if (0 === y)
            throw new Error(
              `[BitmapFont] textureHeight ${h}px is too small (fontFamily: '${c.fontFamily}', fontSize: ${c.fontSize}px, char: '${e}')`
            );
          --t, (f = null), (m = null), (g = null), (y = 0), (_ = 0), (v = 0);
          continue;
        }
        if (((v = Math.max(s + r.fontProperties.descent, v)), b * o + _ >= d)) {
          if (0 === _)
            throw new Error(
              `[BitmapFont] textureWidth ${a}px is too small (fontFamily: '${c.fontFamily}', fontSize: ${c.fontSize}px, char: '${e}')`
            );
          --t, (y += v * o), (y = Math.ceil(y)), (_ = 0), (v = 0);
          continue;
        }
        zt(f, m, r, _, y, o, c);
        const E = Wt(r.text);
        p.char.push({
          id: E,
          page: x.length - 1,
          x: _ / o,
          y: y / o,
          width: b,
          height: s,
          xoffset: 0,
          yoffset: 0,
          xadvance:
            i -
            (c.dropShadow ? c.dropShadowDistance : 0) -
            (c.stroke ? c.strokeThickness : 0),
        }),
          (_ += (b + 2 * n) * o),
          (_ = Math.ceil(_));
      }
      if (!(null == i ? void 0 : i.skipKerning))
        for (let t = 0, E = u.length; t < E; t++) {
          const e = u[t];
          for (let t = 0; t < E; t++) {
            const r = u[t],
              i = m.measureText(e).width,
              s = m.measureText(r).width,
              n = m.measureText(e + r).width - (i + s);
            n && p.kerning.push({ first: Wt(e), second: Wt(r), amount: n });
          }
        }
      const b = new t(p, x, !0);
      return (
        void 0 !== t.available[e] && t.uninstall(e), (t.available[e] = b), b
      );
    }
  };
(rc.ALPHA = [["a", "z"], ["A", "Z"], " "]),
  (rc.NUMERIC = [["0", "9"]]),
  (rc.ALPHANUMERIC = [["a", "z"], ["A", "Z"], ["0", "9"], " "]),
  (rc.ASCII = [[" ", "~"]]),
  (rc.defaultOptions = {
    resolution: 1,
    textureWidth: 512,
    textureHeight: 512,
    padding: 4,
    chars: rc.ALPHANUMERIC,
  }),
  (rc.available = {});
let ic = rc;
const sc = [],
  nc = [],
  oc = [],
  ac = class t extends Ih {
    constructor(e, r = {}) {
      super();
      const {
        align: i,
        tint: s,
        maxWidth: n,
        letterSpacing: o,
        fontName: a,
        fontSize: h,
      } = Object.assign({}, t.styleDefaults, r);
      if (!ic.available[a]) throw new Error(`Missing BitmapFont "${a}"`);
      (this._activePagesMeshData = []),
        (this._textWidth = 0),
        (this._textHeight = 0),
        (this._align = i),
        (this._tintColor = new Rn(s)),
        (this._font = void 0),
        (this._fontName = a),
        (this._fontSize = h),
        (this.text = e),
        (this._maxWidth = n),
        (this._maxLineHeight = 0),
        (this._letterSpacing = o),
        (this._anchor = new wo(
          () => {
            this.dirty = !0;
          },
          this,
          0,
          0
        )),
        (this._roundPixels = _n.ROUND_PIXELS),
        (this.dirty = !0),
        (this._resolution = _n.RESOLUTION),
        (this._autoResolution = !0),
        (this._textureCache = {});
    }
    updateText() {
      var t;
      const e = ic.available[this._fontName],
        r = this.fontSize,
        i = r / e.size,
        s = new ho(),
        n = [],
        o = [],
        a = [],
        h = $t(this._text.replace(/(?:\r\n|\r)/g, "\n") || " "),
        l = (this._maxWidth * e.size) / r,
        u = "none" === e.distanceFieldType ? sc : nc;
      let c = null,
        d = 0,
        p = 0,
        f = 0,
        m = -1,
        g = 0,
        _ = 0,
        y = 0,
        v = 0;
      for (let S = 0; S < h.length; S++) {
        const t = h[S],
          r = Wt(t);
        if (
          (/(?:\s)/.test(t) && ((m = S), (g = d), v++),
          "\r" === t || "\n" === t)
        ) {
          o.push(d),
            a.push(-1),
            (p = Math.max(p, d)),
            ++f,
            ++_,
            (s.x = 0),
            (s.y += e.lineHeight),
            (c = null),
            (v = 0);
          continue;
        }
        const i = e.chars[r];
        if (!i) continue;
        c && i.kerning[c] && (s.x += i.kerning[c]);
        const u = oc.pop() || {
          texture: ha.EMPTY,
          line: 0,
          charCode: 0,
          prevSpaces: 0,
          position: new ho(),
        };
        (u.texture = i.texture),
          (u.line = f),
          (u.charCode = r),
          (u.position.x = Math.round(
            s.x + i.xOffset + this._letterSpacing / 2
          )),
          (u.position.y = Math.round(s.y + i.yOffset)),
          (u.prevSpaces = v),
          n.push(u),
          (d =
            u.position.x +
            Math.max(i.xAdvance - i.xOffset, i.texture.orig.width)),
          (s.x += i.xAdvance + this._letterSpacing),
          (y = Math.max(y, i.yOffset + i.texture.height)),
          (c = r),
          -1 !== m &&
            l > 0 &&
            s.x > l &&
            (++_,
            et(n, 1 + m - _, 1 + S - m),
            (S = m),
            (m = -1),
            o.push(g),
            a.push(n.length > 0 ? n[n.length - 1].prevSpaces : 0),
            (p = Math.max(p, g)),
            f++,
            (s.x = 0),
            (s.y += e.lineHeight),
            (c = null),
            (v = 0));
      }
      const x = h[h.length - 1];
      "\r" !== x &&
        "\n" !== x &&
        (/(?:\s)/.test(x) && (d = g),
        o.push(d),
        (p = Math.max(p, d)),
        a.push(-1));
      const b = [];
      for (let S = 0; S <= f; S++) {
        let t = 0;
        "right" === this._align
          ? (t = p - o[S])
          : "center" === this._align
          ? (t = (p - o[S]) / 2)
          : "justify" === this._align && (t = a[S] < 0 ? 0 : (p - o[S]) / a[S]),
          b.push(t);
      }
      const E = n.length,
        T = {},
        A = [],
        w = this._activePagesMeshData;
      u.push(...w);
      for (let S = 0; S < E; S++) {
        const t = n[S].texture,
          r = t.baseTexture.uid;
        if (!T[r]) {
          let i = u.pop();
          if (!i) {
            const t = new Iu();
            let r, s;
            "none" === e.distanceFieldType
              ? ((r = new Cu(ha.EMPTY)), (s = tn.NORMAL))
              : ((r = new Cu(ha.EMPTY, {
                  program: Ho.from(
                    "// Mesh material default fragment\r\nattribute vec2 aVertexPosition;\r\nattribute vec2 aTextureCoord;\r\n\r\nuniform mat3 projectionMatrix;\r\nuniform mat3 translationMatrix;\r\nuniform mat3 uTextureMatrix;\r\n\r\nvarying vec2 vTextureCoord;\r\n\r\nvoid main(void)\r\n{\r\n    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\r\n\r\n    vTextureCoord = (uTextureMatrix * vec3(aTextureCoord, 1.0)).xy;\r\n}\r\n",
                    "// Pixi texture info\r\nvarying vec2 vTextureCoord;\r\nuniform sampler2D uSampler;\r\n\r\n// Tint\r\nuniform vec4 uColor;\r\n\r\n// on 2D applications fwidth is screenScale / glyphAtlasScale * distanceFieldRange\r\nuniform float uFWidth;\r\n\r\nvoid main(void) {\r\n\r\n  // To stack MSDF and SDF we need a non-pre-multiplied-alpha texture.\r\n  vec4 texColor = texture2D(uSampler, vTextureCoord);\r\n\r\n  // MSDF\r\n  float median = texColor.r + texColor.g + texColor.b -\r\n                  min(texColor.r, min(texColor.g, texColor.b)) -\r\n                  max(texColor.r, max(texColor.g, texColor.b));\r\n  // SDF\r\n  median = min(median, texColor.a);\r\n\r\n  float screenPxDistance = uFWidth * (median - 0.5);\r\n  float alpha = clamp(screenPxDistance + 0.5, 0.0, 1.0);\r\n  if (median < 0.01) {\r\n    alpha = 0.0;\r\n  } else if (median > 0.99) {\r\n    alpha = 1.0;\r\n  }\r\n\r\n  // Gamma correction for coverage-like alpha\r\n  float luma = dot(uColor.rgb, vec3(0.299, 0.587, 0.114));\r\n  float gamma = mix(1.0, 1.0 / 2.2, luma);\r\n  float coverage = pow(uColor.a * alpha, gamma);  \r\n\r\n  // NPM Textures, NPM outputs\r\n  gl_FragColor = vec4(uColor.rgb, coverage);\r\n}\r\n"
                  ),
                  uniforms: { uFWidth: 0 },
                })),
                (s = tn.NORMAL_NPM));
            const n = new Ru(t, r);
            (n.blendMode = s),
              (i = {
                index: 0,
                indexCount: 0,
                vertexCount: 0,
                uvsCount: 0,
                total: 0,
                mesh: n,
                vertices: null,
                uvs: null,
                indices: null,
              });
          }
          (i.index = 0),
            (i.indexCount = 0),
            (i.vertexCount = 0),
            (i.uvsCount = 0),
            (i.total = 0);
          const { _textureCache: s } = this;
          (s[r] = s[r] || new ha(t.baseTexture)),
            (i.mesh.texture = s[r]),
            (i.mesh.tint = this._tintColor.value),
            A.push(i),
            (T[r] = i);
        }
        T[r].total++;
      }
      for (let S = 0; S < w.length; S++)
        A.includes(w[S]) || this.removeChild(w[S].mesh);
      for (let S = 0; S < A.length; S++)
        A[S].mesh.parent !== this && this.addChild(A[S].mesh);
      this._activePagesMeshData = A;
      for (const S in T) {
        const e = T[S],
          r = e.total;
        if (
          !((null == (t = e.indices) ? void 0 : t.length) > 6 * r) ||
          e.vertices.length < 2 * Ru.BATCHABLE_SIZE
        )
          (e.vertices = new Float32Array(8 * r)),
            (e.uvs = new Float32Array(8 * r)),
            (e.indices = new Uint16Array(6 * r));
        else {
          const t = e.total,
            r = e.vertices;
          for (let e = 4 * t * 2; e < r.length; e++) r[e] = 0;
        }
        e.mesh.size = 6 * r;
      }
      for (let S = 0; S < E; S++) {
        const t = n[S];
        let e =
          t.position.x +
          b[t.line] * ("justify" === this._align ? t.prevSpaces : 1);
        this._roundPixels && (e = Math.round(e));
        const r = e * i,
          s = t.position.y * i,
          o = t.texture,
          a = T[o.baseTexture.uid],
          h = o.frame,
          l = o._uvs,
          u = a.index++;
        (a.indices[6 * u + 0] = 0 + 4 * u),
          (a.indices[6 * u + 1] = 1 + 4 * u),
          (a.indices[6 * u + 2] = 2 + 4 * u),
          (a.indices[6 * u + 3] = 0 + 4 * u),
          (a.indices[6 * u + 4] = 2 + 4 * u),
          (a.indices[6 * u + 5] = 3 + 4 * u),
          (a.vertices[8 * u + 0] = r),
          (a.vertices[8 * u + 1] = s),
          (a.vertices[8 * u + 2] = r + h.width * i),
          (a.vertices[8 * u + 3] = s),
          (a.vertices[8 * u + 4] = r + h.width * i),
          (a.vertices[8 * u + 5] = s + h.height * i),
          (a.vertices[8 * u + 6] = r),
          (a.vertices[8 * u + 7] = s + h.height * i),
          (a.uvs[8 * u + 0] = l.x0),
          (a.uvs[8 * u + 1] = l.y0),
          (a.uvs[8 * u + 2] = l.x1),
          (a.uvs[8 * u + 3] = l.y1),
          (a.uvs[8 * u + 4] = l.x2),
          (a.uvs[8 * u + 5] = l.y2),
          (a.uvs[8 * u + 6] = l.x3),
          (a.uvs[8 * u + 7] = l.y3);
      }
      (this._textWidth = p * i), (this._textHeight = (s.y + e.lineHeight) * i);
      for (const S in T) {
        const t = T[S];
        if (0 !== this.anchor.x || 0 !== this.anchor.y) {
          let e = 0;
          const r = this._textWidth * this.anchor.x,
            i = this._textHeight * this.anchor.y;
          for (let s = 0; s < t.total; s++)
            (t.vertices[e++] -= r),
              (t.vertices[e++] -= i),
              (t.vertices[e++] -= r),
              (t.vertices[e++] -= i),
              (t.vertices[e++] -= r),
              (t.vertices[e++] -= i),
              (t.vertices[e++] -= r),
              (t.vertices[e++] -= i);
        }
        this._maxLineHeight = y * i;
        const e = t.mesh.geometry.getBuffer("aVertexPosition"),
          r = t.mesh.geometry.getBuffer("aTextureCoord"),
          s = t.mesh.geometry.getIndex();
        (e.data = t.vertices),
          (r.data = t.uvs),
          (s.data = t.indices),
          e.update(),
          r.update(),
          s.update();
      }
      for (let S = 0; S < n.length; S++) oc.push(n[S]);
      (this._font = e), (this.dirty = !1);
    }
    updateTransform() {
      this.validate(), this.containerUpdateTransform();
    }
    _render(t) {
      this._autoResolution &&
        this._resolution !== t.resolution &&
        ((this._resolution = t.resolution), (this.dirty = !0));
      const {
        distanceFieldRange: e,
        distanceFieldType: r,
        size: i,
      } = ic.available[this._fontName];
      if ("none" !== r) {
        const { a: r, b: s, c: n, d: o } = this.worldTransform,
          a = Math.sqrt(r * r + s * s),
          h = Math.sqrt(n * n + o * o),
          l = (Math.abs(a) + Math.abs(h)) / 2,
          u = this.fontSize / i,
          c = t._view.resolution;
        for (const t of this._activePagesMeshData)
          t.mesh.shader.uniforms.uFWidth = l * e * u * c;
      }
      super._render(t);
    }
    getLocalBounds() {
      return this.validate(), super.getLocalBounds();
    }
    validate() {
      const t = ic.available[this._fontName];
      if (!t) throw new Error(`Missing BitmapFont "${this._fontName}"`);
      this._font !== t && (this.dirty = !0), this.dirty && this.updateText();
    }
    get tint() {
      return this._tintColor.value;
    }
    set tint(t) {
      if (this.tint !== t) {
        this._tintColor.setValue(t);
        for (let e = 0; e < this._activePagesMeshData.length; e++)
          this._activePagesMeshData[e].mesh.tint = t;
      }
    }
    get align() {
      return this._align;
    }
    set align(t) {
      this._align !== t && ((this._align = t), (this.dirty = !0));
    }
    get fontName() {
      return this._fontName;
    }
    set fontName(t) {
      if (!ic.available[t]) throw new Error(`Missing BitmapFont "${t}"`);
      this._fontName !== t && ((this._fontName = t), (this.dirty = !0));
    }
    get fontSize() {
      return this._fontSize ?? ic.available[this._fontName].size;
    }
    set fontSize(t) {
      this._fontSize !== t && ((this._fontSize = t), (this.dirty = !0));
    }
    get anchor() {
      return this._anchor;
    }
    set anchor(t) {
      "number" == typeof t ? this._anchor.set(t) : this._anchor.copyFrom(t);
    }
    get text() {
      return this._text;
    }
    set text(t) {
      (t = String(t ?? "")),
        this._text !== t && ((this._text = t), (this.dirty = !0));
    }
    get maxWidth() {
      return this._maxWidth;
    }
    set maxWidth(t) {
      this._maxWidth !== t && ((this._maxWidth = t), (this.dirty = !0));
    }
    get maxLineHeight() {
      return this.validate(), this._maxLineHeight;
    }
    get textWidth() {
      return this.validate(), this._textWidth;
    }
    get letterSpacing() {
      return this._letterSpacing;
    }
    set letterSpacing(t) {
      this._letterSpacing !== t &&
        ((this._letterSpacing = t), (this.dirty = !0));
    }
    get roundPixels() {
      return this._roundPixels;
    }
    set roundPixels(t) {
      t !== this._roundPixels && ((this._roundPixels = t), (this.dirty = !0));
    }
    get textHeight() {
      return this.validate(), this._textHeight;
    }
    get resolution() {
      return this._resolution;
    }
    set resolution(t) {
      (this._autoResolution = !1),
        this._resolution !== t && ((this._resolution = t), (this.dirty = !0));
    }
    destroy(t) {
      const { _textureCache: e } = this,
        r = "none" === ic.available[this._fontName].distanceFieldType ? sc : nc;
      r.push(...this._activePagesMeshData);
      for (const i of this._activePagesMeshData) this.removeChild(i.mesh);
      (this._activePagesMeshData = []),
        r
          .filter((t) => e[t.mesh.texture.baseTexture.uid])
          .forEach((t) => {
            t.mesh.texture = ha.EMPTY;
          });
      for (const i in e) e[i].destroy(), delete e[i];
      (this._font = null),
        (this._tintColor = null),
        (this._textureCache = null),
        super.destroy(t);
    }
  };
ac.styleDefaults = {
  align: "left",
  tint: 16777215,
  maxWidth: 0,
  letterSpacing: 0,
};
let hc = ac;
const lc = [".xml", ".fnt"],
  uc = {
    extension: { type: Gs.LoadParser, priority: Xs.Normal },
    name: "loadBitmapFont",
    test: (t) => lc.includes(Tn.extname(t).toLowerCase()),
    testParse: async (t) => Qu.test(t) || tc.test(t),
    async parse(t, e, r) {
      const i = Qu.test(t) ? Qu.parse(t) : tc.parse(t),
        { src: s } = e,
        { page: n } = i,
        o = [];
      for (let l = 0; l < n.length; ++l) {
        const t = n[l].file;
        let e = Tn.join(Tn.dirname(s), t);
        (e = sl(e, s)), o.push(e);
      }
      const a = await r.load(o),
        h = o.map((t) => a[t]);
      return ic.install(i, h, !0);
    },
    load: async (t, e) => (await _n.ADAPTER.fetch(t)).text(),
    unload(t) {
      t.destroy();
    },
  };
kn.add(uc);
const cc = class t extends Lu {
  constructor() {
    super(...arguments),
      (this._fonts = []),
      (this._overrides = []),
      (this._stylesheet = ""),
      (this.fontsDirty = !1);
  }
  static from(e) {
    return new t(
      Object.keys(t.defaultOptions).reduce((t, r) => ({ ...t, [r]: e[r] }), {})
    );
  }
  cleanFonts() {
    this._fonts.length > 0 &&
      (this._fonts.forEach((e) => {
        URL.revokeObjectURL(e.src),
          e.refs--,
          0 === e.refs &&
            (e.fontFace && document.fonts.delete(e.fontFace),
            delete t.availableFonts[e.originalUrl]);
      }),
      (this.fontFamily = "Arial"),
      (this._fonts.length = 0),
      this.styleID++,
      (this.fontsDirty = !0));
  }
  loadFont(e, r = {}) {
    const { availableFonts: i } = t;
    if (i[e]) {
      const t = i[e];
      return (
        this._fonts.push(t),
        t.refs++,
        this.styleID++,
        (this.fontsDirty = !0),
        Promise.resolve()
      );
    }
    return _n.ADAPTER.fetch(e)
      .then((t) => t.blob())
      .then(
        async (t) =>
          new Promise((e, r) => {
            const i = URL.createObjectURL(t),
              s = new FileReader();
            (s.onload = () => e([i, s.result])),
              (s.onerror = r),
              s.readAsDataURL(t);
          })
      )
      .then(async ([t, s]) => {
        const n = Object.assign(
          {
            family: Tn.basename(e, Tn.extname(e)),
            weight: "normal",
            style: "normal",
            display: "auto",
            src: t,
            dataSrc: s,
            refs: 1,
            originalUrl: e,
            fontFace: null,
          },
          r
        );
        (i[e] = n), this._fonts.push(n), this.styleID++;
        const o = new FontFace(n.family, `url(${n.src})`, {
          weight: n.weight,
          style: n.style,
          display: n.display,
        });
        (n.fontFace = o),
          await o.load(),
          document.fonts.add(o),
          await document.fonts.ready,
          this.styleID++,
          (this.fontsDirty = !0);
      });
  }
  addOverride(...t) {
    const e = t.filter((t) => !this._overrides.includes(t));
    e.length > 0 && (this._overrides.push(...e), this.styleID++);
  }
  removeOverride(...t) {
    const e = t.filter((t) => this._overrides.includes(t));
    e.length > 0 &&
      ((this._overrides = this._overrides.filter((t) => !e.includes(t))),
      this.styleID++);
  }
  toCSS(t) {
    return [
      `transform: scale(${t})`,
      "transform-origin: top left",
      "display: inline-block",
      `color: ${this.normalizeColor(this.fill)}`,
      `font-size: ${this.fontSize}px`,
      `font-family: ${this.fontFamily}`,
      `font-weight: ${this.fontWeight}`,
      `font-style: ${this.fontStyle}`,
      `font-variant: ${this.fontVariant}`,
      `letter-spacing: ${this.letterSpacing}px`,
      `text-align: ${this.align}`,
      `padding: ${this.padding}px`,
      `white-space: ${this.whiteSpace}`,
      ...(this.lineHeight ? [`line-height: ${this.lineHeight}px`] : []),
      ...(this.wordWrap
        ? [
            "word-wrap: " + (this.breakWords ? "break-all" : "break-word"),
            `max-width: ${this.wordWrapWidth}px`,
          ]
        : []),
      ...(this.strokeThickness
        ? [
            `-webkit-text-stroke-width: ${this.strokeThickness}px`,
            `-webkit-text-stroke-color: ${this.normalizeColor(this.stroke)}`,
            `text-stroke-width: ${this.strokeThickness}px`,
            `text-stroke-color: ${this.normalizeColor(this.stroke)}`,
            "paint-order: stroke",
          ]
        : []),
      ...(this.dropShadow ? [this.dropShadowToCSS()] : []),
      ...this._overrides,
    ].join(";");
  }
  toGlobalCSS() {
    return this._fonts.reduce(
      (t, e) =>
        `${t}\n            @font-face {\n                font-family: "${e.family}";\n                src: url('${e.dataSrc}');\n                font-weight: ${e.weight};\n                font-style: ${e.style};\n                font-display: ${e.display};\n            }`,
      this._stylesheet
    );
  }
  get stylesheet() {
    return this._stylesheet;
  }
  set stylesheet(t) {
    this._stylesheet !== t && ((this._stylesheet = t), this.styleID++);
  }
  normalizeColor(t) {
    return (
      Array.isArray(t) &&
        ((r = t),
        W(0, "utils.rgb2hex is deprecated, use Color#toNumber instead"),
        (t = Rn.shared.setValue(r).toNumber())),
      "number" == typeof t
        ? ((e = t),
          W(0, "utils.hex2string is deprecated, use Color#toHex instead"),
          Rn.shared.setValue(e).toHex())
        : t
    );
    var e, r;
  }
  dropShadowToCSS() {
    let t = this.normalizeColor(this.dropShadowColor);
    const e = this.dropShadowAlpha,
      r = Math.round(Math.cos(this.dropShadowAngle) * this.dropShadowDistance),
      i = Math.round(Math.sin(this.dropShadowAngle) * this.dropShadowDistance);
    t.startsWith("#") &&
      e < 1 &&
      (t += ((255 * e) | 0).toString(16).padStart(2, "0"));
    const s = `${r}px ${i}px`;
    return this.dropShadowBlur > 0
      ? `text-shadow: ${s} ${this.dropShadowBlur}px ${t}`
      : `text-shadow: ${s} ${t}`;
  }
  reset() {
    Object.assign(this, t.defaultOptions);
  }
  onBeforeDraw() {
    const { fontsDirty: t } = this;
    return (
      (this.fontsDirty = !1),
      this.isSafari && this._fonts.length > 0 && t
        ? new Promise((t) => setTimeout(t, 100))
        : Promise.resolve()
    );
  }
  get isSafari() {
    const { userAgent: t } = _n.ADAPTER.getNavigator();
    return /^((?!chrome|android).)*safari/i.test(t);
  }
  set fillGradientStops(t) {}
  get fillGradientStops() {
    return super.fillGradientStops;
  }
  set fillGradientType(t) {}
  get fillGradientType() {
    return super.fillGradientType;
  }
  set miterLimit(t) {}
  get miterLimit() {
    return super.miterLimit;
  }
  set trim(t) {}
  get trim() {
    return super.trim;
  }
  set textBaseline(t) {}
  get textBaseline() {
    return super.textBaseline;
  }
  set leading(t) {}
  get leading() {
    return super.leading;
  }
  set lineJoin(t) {}
  get lineJoin() {
    return super.lineJoin;
  }
};
(cc.availableFonts = {}),
  (cc.defaultOptions = {
    align: "left",
    breakWords: !1,
    dropShadow: !1,
    dropShadowAlpha: 1,
    dropShadowAngle: Math.PI / 6,
    dropShadowBlur: 0,
    dropShadowColor: "black",
    dropShadowDistance: 5,
    fill: "black",
    fontFamily: "Arial",
    fontSize: 26,
    fontStyle: "normal",
    fontVariant: "normal",
    fontWeight: "normal",
    letterSpacing: 0,
    lineHeight: 0,
    padding: 0,
    stroke: "black",
    strokeThickness: 0,
    whiteSpace: "normal",
    wordWrap: !1,
    wordWrapWidth: 100,
  });
let dc = cc;
const pc = class t extends Mh {
  constructor(e = "", r = {}) {
    super(ha.EMPTY),
      (this._text = null),
      (this._style = null),
      (this._autoResolution = !0),
      (this.localStyleID = -1),
      (this.dirty = !1),
      (this._updateID = 0),
      (this.ownsStyle = !1);
    const i = new Image(),
      s = ha.from(i, {
        scaleMode: _n.SCALE_MODE,
        resourceOptions: { autoLoad: !1 },
      });
    (s.orig = new uo()), (s.trim = new uo()), (this.texture = s);
    const n = "http://www.w3.org/2000/svg",
      o = "http://www.w3.org/1999/xhtml",
      a = document.createElementNS(n, "svg"),
      h = document.createElementNS(n, "foreignObject"),
      l = document.createElementNS(o, "div"),
      u = document.createElementNS(o, "style");
    h.setAttribute("width", "10000"),
      h.setAttribute("height", "10000"),
      (h.style.overflow = "hidden"),
      a.appendChild(h),
      (this.maxWidth = t.defaultMaxWidth),
      (this.maxHeight = t.defaultMaxHeight),
      (this._domElement = l),
      (this._styleElement = u),
      (this._svgRoot = a),
      (this._foreignObject = h),
      this._foreignObject.appendChild(u),
      this._foreignObject.appendChild(l),
      (this._image = i),
      (this._loadImage = new Image()),
      (this._autoResolution = t.defaultAutoResolution),
      (this._resolution = t.defaultResolution ?? _n.RESOLUTION),
      (this.text = e),
      (this.style = r);
  }
  measureText(t) {
    var e, r;
    const {
      text: i,
      style: s,
      resolution: n,
    } = Object.assign(
      { text: this._text, style: this._style, resolution: this._resolution },
      t
    );
    Object.assign(this._domElement, { innerHTML: i, style: s.toCSS(n) }),
      (this._styleElement.textContent = s.toGlobalCSS()),
      document.body.appendChild(this._svgRoot);
    const o = this._domElement.getBoundingClientRect();
    this._svgRoot.remove();
    const { width: a, height: h } = o;
    a > this.maxWidth || this.maxHeight;
    const l = Math.min(this.maxWidth, Math.ceil(a)),
      u = Math.min(this.maxHeight, Math.ceil(h));
    return (
      this._svgRoot.setAttribute("width", l.toString()),
      this._svgRoot.setAttribute("height", u.toString()),
      i !== this._text && (this._domElement.innerHTML = this._text),
      s !== this._style &&
        (Object.assign(this._domElement, {
          style: null == (e = this._style) ? void 0 : e.toCSS(n),
        }),
        (this._styleElement.textContent =
          null == (r = this._style) ? void 0 : r.toGlobalCSS())),
      { width: l + 2 * s.padding, height: u + 2 * s.padding }
    );
  }
  async updateText(t = !0) {
    const { style: e, _image: r, _loadImage: i } = this;
    if (
      (this.localStyleID !== e.styleID &&
        ((this.dirty = !0), (this.localStyleID = e.styleID)),
      !this.dirty && t)
    )
      return;
    const { width: s, height: n } = this.measureText();
    (r.width = i.width = Math.ceil(Math.max(1, s))),
      (r.height = i.height = Math.ceil(Math.max(1, n))),
      this._updateID++;
    const o = this._updateID;
    await new Promise((t) => {
      i.onload = async () => {
        o < this._updateID ||
          (await e.onBeforeDraw(),
          (r.src = i.src),
          (i.onload = null),
          (i.src = ""),
          this.updateTexture()),
          t();
      };
      const s = new XMLSerializer().serializeToString(this._svgRoot);
      i.src = `data:image/svg+xml;charset=utf8,${encodeURIComponent(s)}`;
    });
  }
  get source() {
    return this._image;
  }
  updateTexture() {
    const { style: t, texture: e, _image: r, resolution: i } = this,
      { padding: s } = t,
      { baseTexture: n } = e;
    (e.trim.width = e._frame.width = r.width / i),
      (e.trim.height = e._frame.height = r.height / i),
      (e.trim.x = -s),
      (e.trim.y = -s),
      (e.orig.width = e._frame.width - 2 * s),
      (e.orig.height = e._frame.height - 2 * s),
      this._onTextureUpdate(),
      n.setRealSize(r.width, r.height, i),
      (this.dirty = !1);
  }
  _render(t) {
    this._autoResolution &&
      this._resolution !== t.resolution &&
      ((this._resolution = t.resolution), (this.dirty = !0)),
      this.updateText(!0),
      super._render(t);
  }
  _renderCanvas(t) {
    this._autoResolution &&
      this._resolution !== t.resolution &&
      ((this._resolution = t.resolution), (this.dirty = !0)),
      this.updateText(!0),
      super._renderCanvas(t);
  }
  getLocalBounds(t) {
    return this.updateText(!0), super.getLocalBounds(t);
  }
  _calculateBounds() {
    this.updateText(!0),
      this.calculateVertices(),
      this._bounds.addQuad(this.vertexData);
  }
  _onStyleChange() {
    this.dirty = !0;
  }
  destroy(e) {
    var r, i, s, n, o;
    "boolean" == typeof e && (e = { children: e }),
      (e = Object.assign({}, t.defaultDestroyOptions, e)),
      super.destroy(e);
    const a = null;
    this.ownsStyle && (null == (r = this._style) || r.cleanFonts()),
      (this._style = a),
      null == (i = this._svgRoot) || i.remove(),
      (this._svgRoot = a),
      null == (s = this._domElement) || s.remove(),
      (this._domElement = a),
      null == (n = this._foreignObject) || n.remove(),
      (this._foreignObject = a),
      null == (o = this._styleElement) || o.remove(),
      (this._styleElement = a),
      (this._loadImage.src = ""),
      (this._loadImage.onload = null),
      (this._loadImage = a),
      (this._image.src = ""),
      (this._image = a);
  }
  get width() {
    return (
      this.updateText(!0),
      (Math.abs(this.scale.x) * this._image.width) / this.resolution
    );
  }
  set width(t) {
    this.updateText(!0);
    const e = rt(this.scale.x) || 1;
    (this.scale.x = (e * t) / this._image.width / this.resolution),
      (this._width = t);
  }
  get height() {
    return (
      this.updateText(!0),
      (Math.abs(this.scale.y) * this._image.height) / this.resolution
    );
  }
  set height(t) {
    this.updateText(!0);
    const e = rt(this.scale.y) || 1;
    (this.scale.y = (e * t) / this._image.height / this.resolution),
      (this._height = t);
  }
  get style() {
    return this._style;
  }
  set style(t) {
    this._style !== t &&
      ((t = t || {}) instanceof dc
        ? ((this.ownsStyle = !1), (this._style = t))
        : t instanceof Lu
        ? ((this.ownsStyle = !0), (this._style = dc.from(t)))
        : ((this.ownsStyle = !0), (this._style = new dc(t))),
      (this.localStyleID = -1),
      (this.dirty = !0));
  }
  get text() {
    return this._text;
  }
  set text(t) {
    (t = String("" === t || null == t ? " " : t)),
      (t = this.sanitiseText(t)),
      this._text !== t && ((this._text = t), (this.dirty = !0));
  }
  get resolution() {
    return this._resolution;
  }
  set resolution(t) {
    (this._autoResolution = !1),
      this._resolution !== t && ((this._resolution = t), (this.dirty = !0));
  }
  sanitiseText(t) {
    return t
      .replace(/<br>/gi, "<br/>")
      .replace(/<hr>/gi, "<hr/>")
      .replace(/&nbsp;/gi, "&#160;");
  }
};
(pc.defaultDestroyOptions = { texture: !0, children: !1, baseTexture: !0 }),
  (pc.defaultMaxWidth = 2024),
  (pc.defaultMaxHeight = 2024),
  (pc.defaultAutoResolution = !0);
export {
  Rl as A,
  hc as B,
  Ih as C,
  Ah as D,
  Eu as G,
  uo as R,
  Mh as S,
  ha as T,
  ic as a,
  Yn as b,
  an as c,
  Jh as d,
  Lu as e,
  Gu as f,
  _n as s,
};
