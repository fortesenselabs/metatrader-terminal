function t(t) {
  t.trigger(10);
}
function e(t, e, n) {
  t.trigger(11, { event: n, login: e });
}
function n(t, e) {
  t.trigger(15, e);
}
import {
  aZ as s,
  a_ as i,
  be as o,
  b1 as r,
  b5 as a,
  b2 as c,
  bf as h,
  aE as p,
} from "./00a24b22.js";
import { A as l, O as g } from "./04a8e93f.js";
class u {
  constructor() {
    (this.listeners = new Map()),
      (this.on = this.on.bind(this.listeners)),
      (this.off = this.off.bind(this.listeners));
  }
  trigger(t, e) {
    const n = this.listeners.get(t);
    n && n.forEach((t) => t(e));
  }
  on(t, e) {
    let n = this.get(t);
    n || ((n = new Set()), this.set(t, n)), n.add(e);
  }
  off(t, e) {
    if ("number" != typeof t) return void this.clear();
    if (!e) return void (this.has(t) && this.delete(t));
    const n = this.get(t);
    n && n.delete(e);
  }
}
class d extends l {
  constructor(t) {
    super(t),
      (this.listeners = new Set()),
      (this.onCheck = this.onCheck.bind(this)),
      (this.onState = this.onState.bind(this));
  }
  on(t) {
    this.listeners.add(t);
  }
  off(t) {
    t ? this.listeners.delete(t) : this.listeners.clear();
  }
  async login(t) {
    const e = (function (t) {
      const e = new URLSearchParams(window.self.location.search),
        n = e.get("utm_campaign") ?? "",
        o = e.get("utm_source") ?? "";
      return s.serialize([
        { propType: 6, propValue: t.version || 0 },
        {
          propType: 11,
          propValue: (t.password || "").substring(0, 32),
          propLength: 64,
        },
        {
          propType: 11,
          propValue: (t.otp || "").substring(0, 64),
          propLength: 128,
        },
        { propType: 12, propValue: t.cid || i(), propLength: 16 },
        { propType: 11, propValue: n.substring(0, 32), propLength: 64 },
        { propType: 11, propValue: o.substring(0, 32), propLength: 64 },
        { propType: 18, propValue: t.leadCookieId || BigInt(0) },
        {
          propType: 11,
          propValue: (t.leadAffiliateSite || "").substring(0, 64),
          propLength: 128,
        },
        { propType: 6, propValue: Math.min(t.url ? t.url.length : 0, 128) },
        {
          propType: 11,
          propValue: (t.url || "").substring(0, 128),
          propLength: 256,
        },
        { propType: 18, propValue: BigInt(t.login ?? 0) },
      ]);
    })(t);
    try {
      await this.socket
        .on(50, this.onCheck)
        .on(15, this.onState)
        .sendCommand(28, e);
    } catch (n) {
      throw n;
    }
  }
  destroy() {
    this.socket.off(50, this.onCheck).off(15, this.onState), this.off();
  }
  async logout() {
    return this.destroy(), await this.socket.sendCommand(2);
  }
  async changePass(t, e = !1) {
    const n =
      ((i = { password: t, isInvestor: e }),
      s.serialize([
        { propType: 4, propValue: Number(i.isInvestor ?? !1) },
        {
          propType: 11,
          propValue: (i.password ?? "").substring(0, 32),
          propLength: 64,
        },
      ]));
    var i;
    const { resCode: o } = await this.socket.sendCommand(24, n);
    return o;
  }
  onCheck(t) {
    const e =
      ((n = s.getCharString(t.resBody, 0, t.resBody.byteLength)),
      window.eval(n.substring(0, n.length - 2)));
    var n;
    this.socket.sendCommand(
      50,
      s.serialize([{ propType: 10, propValue: String(e) }]),
      !1
    );
  }
  onState(t) {
    const e = new Uint32Array(t.resBody)[0];
    this.listeners.forEach((t) => t(e));
  }
  async ping() {
    await this.socket.sendCommand(51);
  }
  hasSignalServerConnection() {
    return 1 === this.socket.readyState;
  }
  closeSocket() {
    return this.socket.close(!0);
  }
}
class m {
  constructor() {
    (this.state = 0), (this.lastSuccessPingDate = 0);
  }
  setState(t) {
    this.state = t;
  }
}
class y {
  constructor(t, e) {
    (this.lastSuccessPingDate = 0),
      (this.connectionPending = 0),
      (this.pingPromise = null),
      (this.pingTimeoutId = null),
      (this.onDisconnect = this.onDisconnect.bind(this)),
      (this.onState = this.onState.bind(this)),
      (this.onPing = this.onPing.bind(this)),
      (this.storage = new m()),
      (this.emitter = t),
      (this.api = e),
      this.emitter.on(11, this.onDisconnect),
      this.api.on(this.onState);
  }
  onDisconnect() {
    this.pingTimeoutId &&
      (window.clearTimeout(this.pingTimeoutId), (this.pingTimeoutId = null));
  }
  onState(t) {
    this.storage.setState(t), this.emitter.trigger(16, t);
  }
  async login(t) {
    await this.api.login(t),
      this.pingTimeoutId && clearTimeout(this.pingTimeoutId),
      this.onPing();
  }
  async changePassword(t, e, n) {
    const s = o(t, e);
    return 0 !== s ? s : this.api.changePass(t, n);
  }
  async logout() {
    "number" == typeof this.pingTimeoutId && clearTimeout(this.pingTimeoutId),
      await this.api.logout(),
      "number" == typeof this.pingTimeoutId && clearTimeout(this.pingTimeoutId);
  }
  destroy() {
    this.api.destroy();
  }
  onPing() {
    if (
      (this.pingPromise && (this.connectionPending = this.lastSuccessPingDate),
      this.connectionPending && Date.now() - this.connectionPending > 15e3)
    )
      return (
        this.api.closeSocket(),
        (this.connectionPending = 0),
        void (this.lastSuccessPingDate = 0)
      );
    (this.pingPromise = this.api.ping()),
      this.pingPromise
        .then(() => {
          (this.pingPromise = null),
            (this.connectionPending = 0),
            (this.lastSuccessPingDate = Date.now());
        })
        .catch((t) => {}),
      (this.pingTimeoutId = window.setTimeout(this.onPing, 5e3));
  }
  hasTradeServerConnection() {
    return 0 === this.storage.state;
  }
  hasSignalServerConnection() {
    return this.api.hasSignalServerConnection();
  }
}
class w {
  constructor(t) {
    this.controller = t;
  }
  async logout() {
    return this.controller.logout();
  }
  async changePassword(t, e, n) {
    return this.controller.changePassword(t, e, n);
  }
}
class f {
  constructor(t, e) {
    (this.controller = new y(t, new d(e))),
      (this.view = new w(this.controller));
  }
}
let b = 0;
const S = {
  login: async function (s) {
    const i = await r(a, s.server, s.login);
    return async function () {
      b += 1;
      const o = c(i, b);
      return (
        await o.connectToServer(),
        async function () {
          const i = new u();
          o.subscribe(h.Close, e.bind(null, i, s.login)),
            o.subscribe(h.Open, t.bind(null, i)),
            o.subscribe(h.Error, n.bind(null, i));
          const r = new f(i, o);
          return (
            await r.controller.login(s),
            (async function (t, e, n, s) {
              const { NextApi: i } = await p(
                () => import("./909a8246.js"),
                [
                  "909a8246.js",
                  "00a24b22.js",
                  "6f913017.css",
                  "917f94f7.js",
                  "f54151ac.js",
                  "02c71ccc.css",
                  "7313b880.css",
                  "04a8e93f.js",
                ]
              );
              return await i.create(t, e, n, s);
            })(i, o, r, s.login)
          );
        }
      );
    };
  },
  connectOtp: async function (t) {
    await g.connect(t);
  },
};
export { S as authApi };
