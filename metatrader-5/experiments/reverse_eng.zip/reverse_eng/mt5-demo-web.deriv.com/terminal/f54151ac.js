function t(t, e) {
  return t.substr(0, e.length) === e;
}
function e(t) {
  return "*" === t[0];
}
function n(t) {
  return t.replace(/(^\/+|\/+$)/g, "").split("/");
}
function a(t) {
  return t.replace(/(^\/+|\/+$)/g, "");
}
function o(t, a) {
  return {
    route: t,
    score: t.default
      ? 0
      : n(t.path).reduce((t, n) => {
          let a = t;
          return (
            (a += at),
            (function (t) {
              return "" === t;
            })(n)
              ? (a += ct)
              : (function (t) {
                  return nt.test(t);
                })(n)
              ? (a += st)
              : e(n)
              ? (a -= at + rt)
              : (a += ot),
            a
          );
        }, 0),
    index: a,
  };
}
function s(t, a) {
  let s = null,
    r = null;
  const [c] = a.split("?"),
    i = n(c),
    l = "" === i[0],
    u = (function (t) {
      return t
        .map(o)
        .sort((t, e) =>
          t.score < e.score ? 1 : t.score > e.score ? -1 : t.index - e.index
        );
    })(t);
  for (let o = 0, p = u.length; o < p; o++) {
    const t = u[o].route;
    let c = !1;
    if (t.default) {
      r = { route: t, params: {}, uri: a };
      continue;
    }
    const p = n(t.path),
      f = {},
      $ = Math.max(i.length, p.length);
    let d = 0;
    for (; d < $; d++) {
      const t = p[d],
        n = i[d];
      if (void 0 !== t && e(t)) {
        f["*" === t ? "*" : t.slice(1)] = i
          .slice(d)
          .map(decodeURIComponent)
          .join("/");
        break;
      }
      if (void 0 === n) {
        c = !0;
        break;
      }
      const a = nt.exec(t);
      if (a && !l) {
        const t = decodeURIComponent(n);
        f[a[1]] = t;
      } else if (t !== n) {
        c = !0;
        break;
      }
    }
    if (!c) {
      s = { route: t, params: f, uri: `/${i.slice(0, d).join("/")}` };
      break;
    }
  }
  return s || r;
}
function r(t, e) {
  return t + (e ? `?${e}` : "");
}
function c(t, e = "") {
  return `${a("/" === e ? t : `${a(t)}/${a(e)}`)}/`;
}
function i(t = 440) {
  (it = !0),
    clearTimeout(ut),
    setTimeout(() => {
      it = !1;
    }, t);
}
function l() {
  const t = history.state;
  return {
    ...window.self.location,
    state: t,
    key: String((null == t ? void 0 : t.key) ?? "initial"),
  };
}
function u(t) {
  let e;
  const n = t[9].default,
    a = v(n, t, t[8], null);
  return {
    c() {
      a && a.c();
    },
    m(t, n) {
      a && a.m(t, n), (e = !0);
    },
    p(t, [o]) {
      a &&
        a.p &&
        (!e || 256 & o) &&
        x(a, n, t, t[8], e ? j(n, t[8], o, null) : R(t[8]), null);
    },
    i(t) {
      e || (T(a, t), (e = !0));
    },
    o(t) {
      E(a, t), (e = !1);
    },
    d(t) {
      a && a.d(t);
    },
  };
}
function p(t, e, n) {
  let a,
    o,
    r,
    { $$slots: i = {}, $$scope: l } = e,
    { basepath: u = "/" } = e,
    { url: p = null } = e;
  const f = P($t),
    $ = P(dt),
    d = K([]);
  S(t, d, (t) => n(6, (o = t)));
  const h = K(null);
  let m = !1;
  const b = f || K(p ? { pathname: p } : pt.location);
  S(t, b, (t) => n(5, (a = t)));
  const g = $ ? $.routerBase : K({ path: u, uri: u });
  S(t, g, (t) => n(7, (r = t)));
  const y = O([g, h], ([t, e]) => {
    if (null === e) return t;
    const { route: n, uri: a } = e;
    return { path: n.default ? t.path : n.path.replace(/\*.*$/, ""), uri: a };
  });
  return (
    f ||
      (B(() =>
        pt.listen((t) => {
          b.set(t.location);
        })
      ),
      L($t, b)),
    L(dt, {
      activeRoute: h,
      base: g,
      routerBase: y,
      registerRoute: function (t) {
        const { path: e } = t;
        if (
          ((t._path = e), (t.path = c(r.path, e)), "undefined" == typeof window)
        ) {
          if (m) return;
          const e = (function (t, e) {
            return s([t], e);
          })(t, a.pathname);
          e && (h.set(e), (m = !0));
        } else d.update((e) => (e.push(t), e));
      },
      unregisterRoute: function (t) {
        d.update((e) => {
          const n = e.indexOf(t);
          return e.splice(n, 1), e;
        });
      },
    }),
    (t.$$set = (t) => {
      "basepath" in t && n(3, (u = t.basepath)),
        "url" in t && n(4, (p = t.url)),
        "$$scope" in t && n(8, (l = t.$$scope));
    }),
    (t.$$.update = () => {
      if (128 & t.$$.dirty) {
        const { path: t } = r;
        d.update(
          (e) => (
            e.forEach((e) => {
              e.path = c(t, e._path);
            }),
            e
          )
        );
      }
      if (96 & t.$$.dirty) {
        const t = s(o, a.pathname);
        h.set(t);
      }
    }),
    [d, b, g, u, p, a, o, r, l, i]
  );
}
function f(t) {
  function e(t, e) {
    return null !== t[0] ? 0 : 1;
  }
  let n, a, o, s;
  const r = [d, $],
    c = [];
  return (
    (n = e(t)),
    (a = c[n] = r[n](t)),
    {
      c() {
        a.c(), (o = N());
      },
      m(t, e) {
        c[n].m(t, e), U(t, o, e), (s = !0);
      },
      p(t, s) {
        let i = n;
        (n = e(t)),
          n === i
            ? c[n].p(t, s)
            : (C(),
              E(c[i], 1, 1, () => {
                c[i] = null;
              }),
              D(),
              (a = c[n]),
              a ? a.p(t, s) : ((a = c[n] = r[n](t)), a.c()),
              T(a, 1),
              a.m(o.parentNode, o));
      },
      i(t) {
        s || (T(a), (s = !0));
      },
      o(t) {
        E(a), (s = !1);
      },
      d(t) {
        t && I(o), c[n].d(t);
      },
    }
  );
}
function $(t) {
  let e;
  const n = t[10].default,
    a = v(n, t, t[9], bt);
  return {
    c() {
      a && a.c();
    },
    m(t, n) {
      a && a.m(t, n), (e = !0);
    },
    p(t, o) {
      a &&
        a.p &&
        (!e || 532 & o) &&
        x(a, n, t, t[9], e ? j(n, t[9], o, mt) : R(t[9]), bt);
    },
    i(t) {
      e || (T(a, t), (e = !0));
    },
    o(t) {
      E(a, t), (e = !1);
    },
    d(t) {
      a && a.d(t);
    },
  };
}
function d(t) {
  function e(t, e) {
    let n = {};
    if (void 0 !== e && 28 & e)
      n = F(s, [
        16 & e && { location: t[4] },
        4 & e && G(t[2]),
        8 & e && G(t[3]),
      ]);
    else for (let a = 0; a < s.length; a += 1) n = _(n, s[a]);
    return { props: n };
  }
  let n, a, o;
  const s = [{ location: t[4] }, t[2], t[3]];
  var r = t[0];
  return (
    r && (n = z(r, e(t))),
    {
      c() {
        n && A(n.$$.fragment), (a = N());
      },
      m(t, e) {
        n && H(n, t, e), U(t, a, e), (o = !0);
      },
      p(t, o) {
        if (1 & o && r !== (r = t[0])) {
          if (n) {
            C();
            const t = n;
            E(t.$$.fragment, 1, 0, () => {
              Q(t, 1);
            }),
              D();
          }
          r
            ? ((n = z(r, e(t, o))),
              A(n.$$.fragment),
              T(n.$$.fragment, 1),
              H(n, a.parentNode, a))
            : (n = null);
        } else if (r) {
          const e =
            28 & o
              ? F(s, [
                  16 & o && { location: t[4] },
                  4 & o && G(t[2]),
                  8 & o && G(t[3]),
                ])
              : {};
          n.$set(e);
        }
      },
      i(t) {
        o || (n && T(n.$$.fragment, t), (o = !0));
      },
      o(t) {
        n && E(n.$$.fragment, t), (o = !1);
      },
      d(t) {
        t && I(a), n && Q(n, t);
      },
    }
  );
}
function h(t) {
  let e,
    n,
    a = null !== t[1] && t[1].route === t[7] && f(t);
  return {
    c() {
      a && a.c(), (e = N());
    },
    m(t, o) {
      a && a.m(t, o), U(t, e, o), (n = !0);
    },
    p(t, [n]) {
      null !== t[1] && t[1].route === t[7]
        ? a
          ? (a.p(t, n), 2 & n && T(a, 1))
          : ((a = f(t)), a.c(), T(a, 1), a.m(e.parentNode, e))
        : a &&
          (C(),
          E(a, 1, 1, () => {
            a = null;
          }),
          D());
    },
    i(t) {
      n || (T(a), (n = !0));
    },
    o(t) {
      E(a), (n = !1);
    },
    d(t) {
      t && I(e), a && a.d(t);
    },
  };
}
function m(t, e, n) {
  let a,
    o,
    { $$slots: s = {}, $$scope: r } = e,
    { path: c = "" } = e,
    { component: i = null } = e;
  const { registerRoute: l, unregisterRoute: u, activeRoute: p } = P(dt);
  S(t, p, (t) => n(1, (a = t)));
  const f = P($t);
  S(t, f, (t) => n(4, (o = t)));
  const $ = { path: c, default: "" === c };
  let d = {},
    h = {};
  return (
    l($),
    "undefined" != typeof window && M(() => u($)),
    (t.$$set = (t) => {
      n(13, (e = _(_({}, e), q(t)))),
        "path" in t && n(8, (c = t.path)),
        "component" in t && n(0, (i = t.component)),
        "$$scope" in t && n(9, (r = t.$$scope));
    }),
    (t.$$.update = () => {
      2 & t.$$.dirty && a && a.route === $ && n(2, (d = a.params));
      {
        const { ...t } = e;
        delete t.path, delete t.component, n(3, (h = t));
      }
    }),
    (e = q(e)),
    [i, a, d, h, o, p, f, $, c, r, s]
  );
}
function b(t) {
  let e, n, a, o;
  const s = t[17].default,
    r = v(s, t, t[16], kt);
  let c = [{ href: t[0] }, { "aria-current": t[3] }, t[7], { class: "link" }],
    i = {};
  for (let l = 0; l < c.length; l += 1) i = _(i, c[l]);
  return {
    c() {
      (e = J("a")),
        r && r.c(),
        V(e, i),
        W(e, "current", t[1]),
        W(e, "partial", t[2]),
        W(e, "svelte-1b1olas", !0);
    },
    m(s, c) {
      U(s, e, c),
        r && r.m(e, null),
        (n = !0),
        a || ((o = [X(e, "click", t[6]), X(e, "click", t[18])]), (a = !0));
    },
    p(t, [a]) {
      r &&
        r.p &&
        (!n || 65542 & a) &&
        x(r, s, t, t[16], n ? j(s, t[16], a, yt) : R(t[16]), kt),
        V(
          e,
          (i = F(c, [
            (!n || 1 & a) && { href: t[0] },
            (!n || 8 & a) && { "aria-current": t[3] },
            128 & a && t[7],
            { class: "link" },
          ]))
        ),
        W(e, "current", t[1]),
        W(e, "partial", t[2]),
        W(e, "svelte-1b1olas", !0);
    },
    i(t) {
      n || (T(r, t), (n = !0));
    },
    o(t) {
      E(r, t), (n = !1);
    },
    d(t) {
      t && I(e), r && r.d(t), (a = !1), Y(o);
    },
  };
}
function g(e, a, o) {
  const s = ["to", "replace", "back", "state", "baseTo"];
  let c,
    l,
    u = Z(a, s),
    { $$slots: p = {}, $$scope: f } = a,
    { to: $ = "#" } = a,
    { replace: d = !1 } = a,
    { back: h = !1 } = a,
    { state: m = {} } = a,
    { baseTo: b = null } = a;
  const { base: g } = P(dt);
  S(e, g, (t) => o(15, (l = t)));
  const y = P($t);
  S(e, y, (t) => o(14, (c = t)));
  const k = tt();
  let w, v, x, R, j;
  return (
    (e.$$set = (t) => {
      (a = _(_({}, a), q(t))),
        o(7, (u = Z(a, s))),
        "to" in t && o(8, ($ = t.to)),
        "replace" in t && o(9, (d = t.replace)),
        "back" in t && o(10, (h = t.back)),
        "state" in t && o(11, (m = t.state)),
        "baseTo" in t && o(12, (b = t.baseTo)),
        "$$scope" in t && o(16, (f = t.$$scope));
    }),
    (e.$$.update = () => {
      33024 & e.$$.dirty &&
        o(
          0,
          (w =
            "/" === $
              ? l.uri
              : (function (e, a) {
                  if (t(e, "/")) return e;
                  const [o, s] = e.split("?"),
                    [c] = a.split("?"),
                    i = n(o),
                    l = n(c);
                  if ("" === i[0]) return r(c, s);
                  if (!t(i[0], "."))
                    return r(("/" === c ? "" : "/") + l.concat(i).join("/"), s);
                  const u = l.concat(i),
                    p = [];
                  return (
                    u.forEach((t) => {
                      ".." === t ? p.pop() : "." !== t && p.push(t);
                    }),
                    r(`/${p.join("/")}`, s)
                  );
                })($, l.uri))
        ),
        4097 & e.$$.dirty && o(13, (v = b || w)),
        24576 & e.$$.dirty && o(2, (x = t(c.pathname, v))),
        24576 & e.$$.dirty && o(1, (R = v === c.pathname)),
        2 & e.$$.dirty && o(3, (j = R ? "page" : void 0));
    }),
    [
      w,
      R,
      x,
      j,
      g,
      y,
      function (t) {
        if (
          (k("click", t),
          (function (t) {
            return (
              !t.defaultPrevented &&
              0 === t.button &&
              !(t.metaKey || t.altKey || t.ctrlKey || t.shiftKey)
            );
          })(t))
        ) {
          t.preventDefault(), i();
          const e = c.pathname === w || d;
          ft(w, { state: m, replace: e, back: h });
        }
      },
      u,
      $,
      d,
      h,
      m,
      b,
      v,
      c,
      l,
      f,
      p,
      function (t) {
        et.call(this, e, t);
      },
    ]
  );
}
import {
  S as y,
  i as k,
  s as w,
  x as v,
  y as x,
  z as R,
  A as j,
  t as T,
  h as E,
  E as P,
  ai as S,
  aj as K,
  ak as O,
  a5 as B,
  aa as L,
  B as N,
  d as U,
  g as C,
  j as D,
  k as I,
  a6 as M,
  al as _,
  am as q,
  an as z,
  c as A,
  m as H,
  l as Q,
  ao as F,
  ap as G,
  e as J,
  aq as V,
  M as W,
  O as X,
  P as Y,
  ar as Z,
  a1 as tt,
  Q as et,
} from "./00a24b22.js";
const nt = /^:(.+)/,
  at = 4,
  ot = 3,
  st = 2,
  rt = 1,
  ct = 1;
let it = !1;
const lt = () => it;
let ut;
const pt = (function () {
    const t = [];
    let e = l();
    return {
      get location() {
        return e;
      },
      listen(n) {
        t.push(n);
        const a = () => {
          (e = l()), n({ location: e, action: "POP" });
        };
        return (
          window.addEventListener("popstate", a),
          () => {
            window.removeEventListener("popstate", a);
            const e = t.indexOf(n);
            t.splice(e, 1);
          }
        );
      },
      navigate(n, a = {}) {
        const { replace: o, back: s } = a;
        let { state: r } = a;
        (r = { ...r, key: `${Date.now()}` }), i();
        try {
          s
            ? window.self.history.back()
            : o
            ? window.self.history.replaceState(r, "", n)
            : window.self.history.pushState(r, "", n);
        } catch (c) {
          window.self.location[o ? "replace" : "assign"](n);
        }
        (e = l()), t.forEach((t) => t({ location: e, action: "PUSH" }));
      },
    };
  })(),
  ft = pt.navigate,
  $t = {},
  dt = {};
class ht extends y {
  constructor(t) {
    super(), k(this, t, p, u, w, { basepath: 3, url: 4 });
  }
}
const mt = (t) => ({ params: 4 & t, location: 16 & t, search: 16 & t }),
  bt = (t) => ({ params: t[2], location: t[4], search: t[4].search });
class gt extends y {
  constructor(t) {
    super(), k(this, t, m, h, w, { path: 8, component: 0 });
  }
}
const yt = (t) => ({ current: 2 & t, partial: 4 & t }),
  kt = (t) => ({ current: t[1], partial: t[2] });
class wt extends y {
  constructor(t) {
    super(),
      k(this, t, g, b, w, {
        to: 8,
        replace: 9,
        back: 10,
        state: 11,
        baseTo: 12,
      });
  }
}
export { wt as L, ht as R, gt as a, lt as i, ft as n, i as p };
