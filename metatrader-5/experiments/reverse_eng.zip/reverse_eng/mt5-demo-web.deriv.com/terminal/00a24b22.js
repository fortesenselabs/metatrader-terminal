function e() {}
function t(e, t) {
  for (const o in t) e[o] = t[o];
  return e;
}
function o(e) {
  return e();
}
function n() {
  return Object.create(null);
}
function r(e) {
  e.forEach(o);
}
function i(e) {
  return "function" == typeof e;
}
function s(e, t) {
  return e != e
    ? t == t
    : e !== t || (e && "object" == typeof e) || "function" == typeof e;
}
function a(t, ...o) {
  if (null == t) {
    for (const e of o) e(void 0);
    return e;
  }
  const n = t.subscribe(...o);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function l(e, t, o) {
  e.$$.on_destroy.push(a(t, o));
}
function c(e, t, o, n) {
  if (e) {
    const r = u(e, t, o, n);
    return e[0](r);
  }
}
function u(e, o, n, r) {
  return e[1] && r ? t(n.ctx.slice(), e[1](r(o))) : n.ctx;
}
function d(e, t, o, n) {
  if (e[2] && n) {
    const r = e[2](n(o));
    if (void 0 === t.dirty) return r;
    if ("object" == typeof r) {
      const e = [],
        o = Math.max(t.dirty.length, r.length);
      for (let n = 0; n < o; n += 1) e[n] = t.dirty[n] | r[n];
      return e;
    }
    return t.dirty | r;
  }
  return t.dirty;
}
function h(e, t, o, n, r, i) {
  if (r) {
    const s = u(t, o, n, i);
    e.p(s, r);
  }
}
function p(e) {
  if (e.ctx.length > 32) {
    const t = [],
      o = e.ctx.length / 32;
    for (let e = 0; e < o; e++) t[e] = -1;
    return t;
  }
  return -1;
}
function g(e) {
  const t = {};
  for (const o in e) "$" !== o[0] && (t[o] = e[o]);
  return t;
}
function m(e, t) {
  const o = {};
  t = new Set(t);
  for (const n in e) t.has(n) || "$" === n[0] || (o[n] = e[n]);
  return o;
}
function f(e) {
  const t = {};
  for (const o in e) t[o] = !0;
  return t;
}
function w(e) {
  return e ?? "";
}
function b(e, t, o) {
  return e.set(o), t;
}
function v(t) {
  return t && i(t.destroy) ? t.destroy : e;
}
function y(e) {
  const t = "string" == typeof e && e.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return t ? [parseFloat(t[1]), t[2] || "px"] : [e, "px"];
}
function $(e) {
  ta.forEach((t) => {
    t.c(e) || (ta.delete(t), t.f());
  }),
    0 !== ta.size && ea($);
}
function C(e) {
  let t;
  return (
    0 === ta.size && ea($),
    {
      promise: new Promise((o) => {
        ta.add((t = { c: e, f: o }));
      }),
      abort() {
        ta.delete(t);
      },
    }
  );
}
function x(e, t) {
  e.appendChild(t);
}
function S(e) {
  if (!e) return document;
  const t = e.getRootNode ? e.getRootNode() : e.ownerDocument;
  return t && t.host ? t : e.ownerDocument;
}
function k(e) {
  const t = P("style");
  return (
    (t.textContent = "/* empty */"),
    (function (e, t) {
      x(e.head || e, t), t.sheet;
    })(S(e), t),
    t.sheet
  );
}
function A(e, t, o) {
  e.insertBefore(t, o || null);
}
function T(e) {
  e.parentNode && e.parentNode.removeChild(e);
}
function O(e, t) {
  for (let o = 0; o < e.length; o += 1) e[o] && e[o].d(t);
}
function P(e) {
  return document.createElement(e);
}
function M(e) {
  return document.createElementNS("http://www.w3.org/2000/svg", e);
}
function L(e) {
  return document.createTextNode(e);
}
function E() {
  return L(" ");
}
function D() {
  return L("");
}
function _(e, t, o, n) {
  return e.addEventListener(t, o, n), () => e.removeEventListener(t, o, n);
}
function U(e) {
  return function (t) {
    return t.stopPropagation(), e.call(this, t);
  };
}
function B(e, t, o) {
  null == o
    ? e.removeAttribute(t)
    : e.getAttribute(t) !== o && e.setAttribute(t, o);
}
function V(e, t) {
  const o = Object.getOwnPropertyDescriptors(e.__proto__);
  for (const n in t)
    null == t[n]
      ? e.removeAttribute(n)
      : "style" === n
      ? (e.style.cssText = t[n])
      : "__value" === n
      ? (e.value = e[n] = t[n])
      : o[n] && o[n].set && -1 === na.indexOf(n)
      ? (e[n] = t[n])
      : B(e, n, t[n]);
}
function j(e, t) {
  Object.keys(t).forEach((o) => {
    !(function (e, t, o) {
      t in e
        ? (e[t] = ("boolean" == typeof e[t] && "" === o) || o)
        : B(e, t, o);
    })(e, o, t[o]);
  });
}
function z(e) {
  return /-/.test(e) ? j : V;
}
function I(e, t, o) {
  e.setAttributeNS("http://www.w3.org/1999/xlink", t, o);
}
function H(e) {
  let t;
  return {
    p(...o) {
      (t = o), t.forEach((t) => e.push(t));
    },
    r() {
      t.forEach((t) => e.splice(e.indexOf(t), 1));
    },
  };
}
function N(e) {
  return "" === e ? null : +e;
}
function R(e, t) {
  (t = "" + t), e.data !== t && (e.data = t);
}
function q(e, t) {
  e.value = t ?? "";
}
function F(e, t) {
  try {
    e.type = t;
  } catch (o) {}
}
function W(e, t, o, n) {
  null == o
    ? e.style.removeProperty(t)
    : e.style.setProperty(t, o, n ? "important" : "");
}
function K(e, t, o) {
  for (let n = 0; n < e.options.length; n += 1) {
    const o = e.options[n];
    if (o.__value === t) return void (o.selected = !0);
  }
  (o && void 0 === t) || (e.selectedIndex = -1);
}
function G(e, t) {
  "static" === getComputedStyle(e).position && (e.style.position = "relative");
  const o = P("iframe");
  o.setAttribute(
    "style",
    "display: block; position: absolute; top: 0; left: 0; width: 100%; height: 100%; overflow: hidden; border: 0; opacity: 0; pointer-events: none; z-index: -1;"
  ),
    o.setAttribute("aria-hidden", "true"),
    (o.tabIndex = -1);
  const n = (function () {
    if (void 0 === ra) {
      ra = !1;
      try {
        "undefined" != typeof window && window.parent && window.parent.document;
      } catch (e) {
        ra = !0;
      }
    }
    return ra;
  })();
  let r;
  return (
    n
      ? ((o.src =
          "data:text/html,<script>onresize=function(){parent.postMessage(0,'*')}</script>"),
        (r = _(window, "message", (e) => {
          e.source === o.contentWindow && t();
        })))
      : ((o.src = "about:blank"),
        (o.onload = () => {
          (r = _(o.contentWindow, "resize", t)), t();
        })),
    x(e, o),
    () => {
      (n || (r && o.contentWindow)) && r(), T(o);
    }
  );
}
function Z(e, t, o) {
  e.classList.toggle(t, !!o);
}
function Y(e, t, { bubbles: o = !1, cancelable: n = !1 } = {}) {
  return new CustomEvent(e, { detail: t, bubbles: o, cancelable: n });
}
function J(e, t) {
  return new e(t);
}
function Q(e, t, o, n, r, i, s, a = 0) {
  const l = 16.666 / n;
  let c = "{\n";
  for (let f = 0; f <= 1; f += l) {
    const e = t + (o - t) * i(f);
    c += 100 * f + `%{${s(e, 1 - e)}}\n`;
  }
  const u = c + `100% {${s(o, 1 - o)}}\n}`,
    d = `__svelte_${(function (e) {
      let t = 5381,
        o = e.length;
      for (; o--; ) t = ((t << 5) - t) ^ e.charCodeAt(o);
      return t >>> 0;
    })(u)}_${a}`,
    h = S(e),
    { stylesheet: p, rules: g } =
      ia.get(h) ||
      (function (e, t) {
        const o = { stylesheet: k(t), rules: {} };
        return ia.set(e, o), o;
      })(h, e);
  g[d] ||
    ((g[d] = !0), p.insertRule(`@keyframes ${d} ${u}`, p.cssRules.length));
  const m = e.style.animation || "";
  return (
    (e.style.animation = `${
      m ? `${m}, ` : ""
    }${d} ${n}ms linear ${r}ms 1 both`),
    (aa += 1),
    d
  );
}
function X(e, t) {
  const o = (e.style.animation || "").split(", "),
    n = o.filter(
      t ? (e) => e.indexOf(t) < 0 : (e) => -1 === e.indexOf("__svelte")
    ),
    r = o.length - n.length;
  r &&
    ((e.style.animation = n.join(", ")),
    (aa -= r),
    aa ||
      ea(() => {
        aa ||
          (ia.forEach((e) => {
            const { ownerNode: t } = e.stylesheet;
            t && T(t);
          }),
          ia.clear());
      }));
}
function ee(t, o, n, r) {
  function i() {
    p && X(t, g), (m = !1);
  }
  if (!o) return e;
  const s = t.getBoundingClientRect();
  if (
    o.left === s.left &&
    o.right === s.right &&
    o.top === s.top &&
    o.bottom === s.bottom
  )
    return e;
  const {
    delay: a = 0,
    duration: l = 300,
    easing: c = Js,
    start: u = Xs() + a,
    end: d = u + l,
    tick: h = e,
    css: p,
  } = n(t, { from: o, to: s }, r);
  let g,
    m = !0,
    f = !1;
  return (
    C((e) => {
      if ((!f && e >= u && (f = !0), f && e >= d && (h(1, 0), i()), !m))
        return !1;
      if (f) {
        const t = 0 + 1 * c((e - u) / l);
        h(t, 1 - t);
      }
      return !0;
    }),
    p && (g = Q(t, 0, 1, l, a, c, p)),
    a || (f = !0),
    h(0, 1),
    i
  );
}
function te(e) {
  const t = getComputedStyle(e);
  if ("absolute" !== t.position && "fixed" !== t.position) {
    const { width: o, height: n } = t,
      r = e.getBoundingClientRect();
    (e.style.position = "absolute"),
      (e.style.width = o),
      (e.style.height = n),
      oe(e, r);
  }
}
function oe(e, t) {
  const o = e.getBoundingClientRect();
  if (t.left !== o.left || t.top !== o.top) {
    const n = getComputedStyle(e),
      r = "none" === n.transform ? "" : n.transform;
    e.style.transform = `${r} translate(${t.left - o.left}px, ${
      t.top - o.top
    }px)`;
  }
}
function ne(e) {
  sa = e;
}
function re() {
  if (!sa) throw new Error("Function called outside component initialization");
  return sa;
}
function ie(e) {
  re().$$.on_mount.push(e);
}
function se(e) {
  re().$$.on_destroy.push(e);
}
function ae() {
  const e = re();
  return (t, o, { cancelable: n = !1 } = {}) => {
    const r = e.$$.callbacks[t];
    if (r) {
      const i = Y(t, o, { cancelable: n });
      return (
        r.slice().forEach((t) => {
          t.call(e, i);
        }),
        !i.defaultPrevented
      );
    }
    return !0;
  };
}
function le(e, t) {
  return re().$$.context.set(e, t), t;
}
function ce(e) {
  return re().$$.context.get(e);
}
function ue(e, t) {
  const o = e.$$.callbacks[t.type];
  o && o.slice().forEach((e) => e.call(this, t));
}
function de() {
  pa || ((pa = !0), ha.then(me));
}
function he() {
  return de(), ha;
}
function pe(e) {
  ua.push(e);
}
function ge(e) {
  da.push(e);
}
function me() {
  if (0 !== fa) return;
  const e = sa;
  do {
    try {
      for (; fa < la.length; ) {
        const e = la[fa];
        fa++, ne(e), fe(e.$$);
      }
    } catch (t) {
      throw ((la.length = 0), (fa = 0), t);
    }
    for (ne(null), la.length = 0, fa = 0; ca.length; ) ca.pop()();
    for (let e = 0; e < ua.length; e += 1) {
      const t = ua[e];
      ga.has(t) || (ga.add(t), t());
    }
    ua.length = 0;
  } while (la.length);
  for (; da.length; ) da.pop()();
  (pa = !1), ga.clear(), ne(e);
}
function fe(e) {
  if (null !== e.fragment) {
    e.update(), r(e.before_update);
    const t = e.dirty;
    (e.dirty = [-1]),
      e.fragment && e.fragment.p(e.ctx, t),
      e.after_update.forEach(pe);
  }
}
function we() {
  return (
    ma ||
      ((ma = Promise.resolve()),
      ma.then(() => {
        ma = null;
      })),
    ma
  );
}
function be(e, t, o) {
  e.dispatchEvent(Y(`${t ? "intro" : "outro"}${o}`));
}
function ve() {
  ba = { r: 0, c: [], p: ba };
}
function ye() {
  ba.r || r(ba.c), (ba = ba.p);
}
function $e(e, t) {
  e && e.i && (wa.delete(e), e.i(t));
}
function Ce(e, t, o, n) {
  if (e && e.o) {
    if (wa.has(e)) return;
    wa.add(e),
      ba.c.push(() => {
        wa.delete(e), n && (o && e.d(1), n());
      }),
      e.o(t);
  } else n && n();
}
function xe(t, o, n) {
  function r() {
    l && X(t, l);
  }
  function s() {
    const {
      delay: o = 0,
      duration: n = 300,
      easing: i = Js,
      tick: s = e,
      css: a,
    } = u || va;
    a && (l = Q(t, 0, 1, n, o, i, a, h++)), s(0, 1);
    const p = Xs() + o,
      g = p + n;
    c && c.abort(),
      (d = !0),
      pe(() => be(t, !0, "start")),
      (c = C((e) => {
        if (d) {
          if (e >= g) return s(1, 0), be(t, !0, "end"), r(), (d = !1);
          if (e >= p) {
            const t = i((e - p) / n);
            s(t, 1 - t);
          }
        }
        return d;
      }));
  }
  const a = { direction: "in" };
  let l,
    c,
    u = o(t, n, a),
    d = !1,
    h = 0,
    p = !1;
  return {
    start() {
      p || ((p = !0), X(t), i(u) ? ((u = u(a)), we().then(s)) : s());
    },
    invalidate() {
      p = !1;
    },
    end() {
      d && (r(), (d = !1));
    },
  };
}
function Se(t, o, n) {
  function s() {
    const {
      delay: o = 0,
      duration: n = 300,
      easing: i = Js,
      tick: s = e,
      css: a,
    } = c || va;
    a && (l = Q(t, 1, 0, n, o, i, a));
    const p = Xs() + o,
      g = p + n;
    pe(() => be(t, !1, "start")),
      "inert" in t && ((h = t.inert), (t.inert = !0)),
      C((e) => {
        if (u) {
          if (e >= g) return s(0, 1), be(t, !1, "end"), --d.r || r(d.c), !1;
          if (e >= p) {
            const t = i((e - p) / n);
            s(1 - t, t);
          }
        }
        return u;
      });
  }
  const a = { direction: "out" };
  let l,
    c = o(t, n, a),
    u = !0;
  const d = ba;
  let h;
  return (
    (d.r += 1),
    i(c)
      ? we().then(() => {
          (c = c(a)), s();
        })
      : s(),
    {
      end(e) {
        e && "inert" in t && (t.inert = h),
          e && c.tick && c.tick(1, 0),
          u && (l && X(t, l), (u = !1));
      },
    }
  );
}
function ke(t, o, n, s) {
  function a() {
    m && X(t, m);
  }
  function l(e, t) {
    const o = e.b - h;
    return (
      (t *= Math.abs(o)),
      {
        a: h,
        b: e.b,
        d: o,
        duration: t,
        start: e.start,
        end: e.start + t,
        group: e.group,
      }
    );
  }
  function c(o) {
    const {
        delay: n = 0,
        duration: i = 300,
        easing: s = Js,
        tick: c = e,
        css: f,
      } = d || va,
      w = { start: Xs() + n, b: o };
    o || ((w.group = ba), (ba.r += 1)),
      "inert" in t &&
        (o ? void 0 !== u && (t.inert = u) : ((u = t.inert), (t.inert = !0))),
      p || g
        ? (g = w)
        : (f && (a(), (m = Q(t, h, o, i, n, s, f))),
          o && c(0, 1),
          (p = l(w, i)),
          pe(() => be(t, o, "start")),
          C((e) => {
            if (
              (g &&
                e > g.start &&
                ((p = l(g, i)),
                (g = null),
                be(t, p.b, "start"),
                f && (a(), (m = Q(t, h, p.b, p.duration, 0, s, d.css)))),
              p)
            )
              if (e >= p.end)
                c((h = p.b), 1 - h),
                  be(t, p.b, "end"),
                  g || (p.b ? a() : --p.group.r || r(p.group.c)),
                  (p = null);
              else if (e >= p.start) {
                const t = e - p.start;
                (h = p.a + p.d * s(t / p.duration)), c(h, 1 - h);
              }
            return !(!p && !g);
          }));
  }
  let u,
    d = o(t, n, { direction: "both" }),
    h = s ? 0 : 1,
    p = null,
    g = null,
    m = null;
  return {
    run(e) {
      i(d)
        ? we().then(() => {
            (d = d({ direction: e ? "in" : "out" })), c(e);
          })
        : c(e);
    },
    end() {
      a(), (p = g = null);
    },
  };
}
function Ae(e, t) {
  function o(e, o, r, i) {
    if (t.token !== n) return;
    t.resolved = i;
    let s = t.ctx;
    void 0 !== r && ((s = s.slice()), (s[r] = i));
    const a = e && (t.current = e)(s);
    let l = !1;
    t.block &&
      (t.blocks
        ? t.blocks.forEach((e, n) => {
            n !== o &&
              e &&
              (ve(),
              Ce(e, 1, 1, () => {
                t.blocks[n] === e && (t.blocks[n] = null);
              }),
              ye());
          })
        : t.block.d(1),
      a.c(),
      $e(a, 1),
      a.m(t.mount(), t.anchor),
      (l = !0)),
      (t.block = a),
      t.blocks && (t.blocks[o] = a),
      l && me();
  }
  const n = (t.token = {});
  if (
    !(r = e) ||
    ("object" != typeof r && "function" != typeof r) ||
    "function" != typeof r.then
  ) {
    if (t.current !== t.then) return o(t.then, 1, t.value, e), !0;
    t.resolved = e;
  } else {
    const n = re();
    if (
      (e.then(
        (e) => {
          ne(n), o(t.then, 1, t.value, e), ne(null);
        },
        (e) => {
          if ((ne(n), o(t.catch, 2, t.error, e), ne(null), !t.hasCatch))
            throw e;
        }
      ),
      t.current !== t.pending)
    )
      return o(t.pending, 0), !0;
  }
  var r;
}
function Te(e, t, o) {
  const n = t.slice(),
    { resolved: r } = e;
  e.current === e.then && (n[e.value] = r),
    e.current === e.catch && (n[e.error] = r),
    e.block.p(n, o);
}
function Oe(e) {
  return void 0 !== (null == e ? void 0 : e.length) ? e : Array.from(e);
}
function Pe(e, t) {
  Ce(e, 1, 1, () => {
    t.delete(e.key);
  });
}
function Me(e, t) {
  e.f(), Pe(e, t);
}
function Le(e, t, o, n, i, s, a, l, c, u, d, h) {
  function p(e) {
    $e(e, 1), e.m(l, d), a.set(e.key, e), (d = e.first), m--;
  }
  let g = e.length,
    m = s.length,
    f = g;
  const w = {};
  for (; f--; ) w[e[f].key] = f;
  const b = [],
    v = new Map(),
    y = new Map(),
    $ = [];
  for (f = m; f--; ) {
    const e = h(i, s, f),
      r = o(e);
    let l = a.get(r);
    l ? n && $.push(() => l.p(e, t)) : ((l = u(r, e)), l.c()),
      v.set(r, (b[f] = l)),
      r in w && y.set(r, Math.abs(f - w[r]));
  }
  const C = new Set(),
    x = new Set();
  for (; g && m; ) {
    const t = b[m - 1],
      o = e[g - 1],
      n = t.key,
      r = o.key;
    t === o
      ? ((d = t.first), g--, m--)
      : v.has(r)
      ? !a.has(n) || C.has(n)
        ? p(t)
        : x.has(r)
        ? g--
        : y.get(n) > y.get(r)
        ? (x.add(n), p(t))
        : (C.add(r), g--)
      : (c(o, a), g--);
  }
  for (; g--; ) {
    const t = e[g];
    v.has(t.key) || c(t, a);
  }
  for (; m; ) p(b[m - 1]);
  return r($), b;
}
function Ee(e, t) {
  const o = {},
    n = {},
    r = { $$scope: 1 };
  let i = e.length;
  for (; i--; ) {
    const s = e[i],
      a = t[i];
    if (a) {
      for (const e in s) e in a || (n[e] = 1);
      for (const e in a) r[e] || ((o[e] = a[e]), (r[e] = 1));
      e[i] = a;
    } else for (const e in s) r[e] = 1;
  }
  for (const s in n) s in o || (o[s] = void 0);
  return o;
}
function De(e) {
  return "object" == typeof e && null !== e ? e : {};
}
function _e(e, t, o) {
  const n = e.$$.props[t];
  void 0 !== n && ((e.$$.bound[n] = o), o(e.$$.ctx[n]));
}
function Ue(e) {
  e && e.c();
}
function Be(e, t, n) {
  const { fragment: s, after_update: a } = e.$$;
  s && s.m(t, n),
    pe(() => {
      const t = e.$$.on_mount.map(o).filter(i);
      e.$$.on_destroy ? e.$$.on_destroy.push(...t) : r(t), (e.$$.on_mount = []);
    }),
    a.forEach(pe);
}
function Ve(e, t) {
  const o = e.$$;
  null !== o.fragment &&
    ((function (e) {
      const t = [],
        o = [];
      ua.forEach((n) => (-1 === e.indexOf(n) ? t.push(n) : o.push(n))),
        o.forEach((e) => e()),
        (ua = t);
    })(o.after_update),
    r(o.on_destroy),
    o.fragment && o.fragment.d(t),
    (o.on_destroy = o.fragment = null),
    (o.ctx = []));
}
function je(t, o, i, s, a, l, c = null, u = [-1]) {
  const d = sa;
  ne(t);
  const h = (t.$$ = {
    fragment: null,
    ctx: [],
    props: l,
    update: e,
    not_equal: a,
    bound: n(),
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(o.context || (d ? d.$$.context : [])),
    callbacks: n(),
    dirty: u,
    skip_bound: !1,
    root: o.target || d.$$.root,
  });
  c && c(h.root);
  let p = !1;
  if (
    ((h.ctx = i
      ? i(t, o.props || {}, (e, o, ...n) => {
          const r = n.length ? n[0] : o;
          return (
            h.ctx &&
              a(h.ctx[e], (h.ctx[e] = r)) &&
              (!h.skip_bound && h.bound[e] && h.bound[e](r),
              p &&
                (function (e, t) {
                  -1 === e.$$.dirty[0] &&
                    (la.push(e), de(), e.$$.dirty.fill(0)),
                    (e.$$.dirty[(t / 31) | 0] |= 1 << t % 31);
                })(t, e)),
            o
          );
        })
      : []),
    h.update(),
    (p = !0),
    r(h.before_update),
    (h.fragment = !!s && s(h.ctx)),
    o.target)
  ) {
    if (o.hydrate) {
      const e = ((g = o.target), Array.from(g.childNodes));
      h.fragment && h.fragment.l(e), e.forEach(T);
    } else h.fragment && h.fragment.c();
    o.intro && $e(t.$$.fragment), Be(t, o.target, o.anchor), me();
  }
  var g;
  ne(d);
}
function ze(t) {
  let o, n;
  return {
    c() {
      (o = P("div")),
        (n = P("div")),
        B(n, "class", "spinner svelte-1uh5wo3"),
        W(n, "animation-duration", t[0] + "ms"),
        W(n, "width", t[2] + "px"),
        W(n, "height", t[2] + "px"),
        B(o, "class", "fade svelte-1uh5wo3"),
        W(o, "animation-duration", 2 * t[1] + "ms");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p(e, [t]) {
      1 & t && W(n, "animation-duration", e[0] + "ms"),
        4 & t && W(n, "width", e[2] + "px"),
        4 & t && W(n, "height", e[2] + "px"),
        2 & t && W(o, "animation-duration", 2 * e[1] + "ms");
    },
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function Ie(e, t, o) {
  let { duration: n = 1200 } = t,
    { delay: r = 0 } = t,
    { size: i = 32 } = t,
    s = i;
  return (
    (e.$$set = (e) => {
      "duration" in e && o(0, (n = e.duration)),
        "delay" in e && o(1, (r = e.delay)),
        "size" in e && o(3, (i = e.size));
    }),
    (e.$$.update = () => {
      8 & e.$$.dirty && o(2, (s = Math.max(16, Math.min(64, i))));
    }),
    [n, r, s, i]
  );
}
function He(e) {
  let t;
  return {
    c() {
      (t = P("div")), B(t, "class", "bg svelte-1ad52mp");
    },
    m(e, o) {
      A(e, t, o);
    },
    d(e) {
      e && T(t);
    },
  };
}
function Ne(e) {
  let t, o;
  return (
    (t = new $a({})),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Re(e) {
  let t, o;
  const n = e[5].default,
    r = c(n, e, e[4], null);
  return {
    c() {
      (t = P("div")), r && r.c(), B(t, "class", "content svelte-1ad52mp");
    },
    m(e, n) {
      A(e, t, n), r && r.m(t, null), (o = !0);
    },
    p(e, t) {
      r &&
        r.p &&
        (!o || 16 & t) &&
        h(r, n, e, e[4], o ? d(n, e[4], t, null) : p(e[4]), null);
    },
    i(e) {
      o || ($e(r, e), (o = !0));
    },
    o(e) {
      Ce(r, e), (o = !1);
    },
    d(e) {
      e && T(t), r && r.d(e);
    },
  };
}
function qe(e) {
  let t,
    o,
    n,
    r,
    i,
    s,
    a,
    l = `${e[1]}ms`,
    c = e[0] && He(),
    u = !e[3].default && Ne(),
    d = e[3].default && Re(e);
  return {
    c() {
      (t = P("div")),
        c && c.c(),
        (o = E()),
        u && u.c(),
        (n = E()),
        (r = P("div")),
        (i = L(e[2])),
        (s = E()),
        d && d.c(),
        B(r, "class", "label svelte-1ad52mp"),
        B(t, "class", "loading svelte-1ad52mp"),
        B(t, "role", "progressbar"),
        Z(t, "delay", Boolean(e[1])),
        Z(t, "overlay", e[0]),
        W(t, "animation-duration", l);
    },
    m(e, l) {
      A(e, t, l),
        c && c.m(t, null),
        x(t, o),
        u && u.m(t, null),
        x(t, n),
        x(t, r),
        x(r, i),
        x(t, s),
        d && d.m(t, null),
        (a = !0);
    },
    p(e, [r]) {
      e[0] ? c || ((c = He()), c.c(), c.m(t, o)) : c && (c.d(1), (c = null)),
        e[3].default
          ? u &&
            (ve(),
            Ce(u, 1, 1, () => {
              u = null;
            }),
            ye())
          : u
          ? 8 & r && $e(u, 1)
          : ((u = Ne()), u.c(), $e(u, 1), u.m(t, n)),
        (!a || 4 & r) && R(i, e[2]),
        e[3].default
          ? d
            ? (d.p(e, r), 8 & r && $e(d, 1))
            : ((d = Re(e)), d.c(), $e(d, 1), d.m(t, null))
          : d &&
            (ve(),
            Ce(d, 1, 1, () => {
              d = null;
            }),
            ye()),
        (!a || 2 & r) && Z(t, "delay", Boolean(e[1])),
        (!a || 1 & r) && Z(t, "overlay", e[0]),
        2 & r && l !== (l = `${e[1]}ms`) && W(t, "animation-duration", l);
    },
    i(e) {
      a || ($e(u), $e(d), (a = !0));
    },
    o(e) {
      Ce(u), Ce(d), (a = !1);
    },
    d(e) {
      e && T(t), c && c.d(), u && u.d(), d && d.d();
    },
  };
}
function Fe(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t;
  const i = f(n);
  let { overlay: s = !1 } = t,
    { delay: a = 150 } = t,
    { label: l = "" } = t;
  return (
    (e.$$set = (e) => {
      "overlay" in e && o(0, (s = e.overlay)),
        "delay" in e && o(1, (a = e.delay)),
        "label" in e && o(2, (l = e.label)),
        "$$scope" in e && o(4, (r = e.$$scope));
    }),
    [s, a, l, i, r, n]
  );
}
function We() {
  return Boolean(window.devicePixelRatio && window.devicePixelRatio > 1.3);
}
function Ke() {
  return (
    void 0 === xa &&
      (xa =
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
          navigator.userAgent
        )),
    xa
  );
}
function Ge() {
  return void 0 === navigator.maxTouchPoints
    ? Ke()
    : navigator.maxTouchPoints > 1;
}
function Ze() {
  return (
    (e = "win"),
    (null == (t = null == navigator ? void 0 : navigator.platform)
      ? void 0
      : t.toLowerCase().indexOf(e)) >= 0 ||
      (null == (o = navigator.appVersion)
        ? void 0
        : o.toLowerCase().indexOf(e)) >= 0 ||
      (null == (r = null == (n = navigator.userAgentData) ? void 0 : n.platform)
        ? void 0
        : r.toLowerCase().indexOf(e)) >= 0 ||
      (null == (i = navigator.userAgent)
        ? void 0
        : i.toLowerCase().indexOf(e)) >= 0
  );
  var e, t, o, n, r, i;
}
function Ye() {
  return void 0 === Sa && (Sa = !!~navigator.userAgent.indexOf("Mac")), Sa;
}
function Je(e) {
  const t = (65280 & e) >> 8,
    o = 255 & e;
  return `#${((16711680 & e) >> 16).toString(16).padStart(2, "0")}${t
    .toString(16)
    .padStart(2, "0")}${o.toString(16).padStart(2, "0")}`;
}
function Qe(e) {
  return [(16711680 & e) >> 16, (65280 & e) >> 8, 255 & e].join(",");
}
function Xe(e, t, o, n, r) {
  (Aa = e),
    (Ta = t),
    (Oa = o),
    (Pa = n),
    (Ma = r),
    null == localStorage ||
      localStorage.setItem(
        "journal",
        `${String(Number(Aa))}${String(Number(Ta))}${String(
          Number(Oa)
        )}${String(Number(Pa))}`
      ),
    null == localStorage || localStorage.setItem("f", String(Ma.toLowerCase()));
}
function et(e, t = !1) {
  let o = 0;
  if (0 === e.length) return [0, 0, 0, 1];
  for (let r = 0; r < e.length; r++)
    (o = e.charCodeAt(r) + ((o << 5) - o)), (o &= o);
  const n = [0, 0, 0, t ? 0.4 : 1];
  for (let r = 0; r < 3; r++) {
    const e = (o >> (8 * r)) & 255;
    n[r] = e;
  }
  return n;
}
function tt() {
  null == localStorage || localStorage.setItem("tags", JSON.stringify(Ea));
}
function ot(e) {
  return Math.round((299 * e[0] + 587 * e[1] + 114 * e[2]) / 1e3) > 125
    ? "black"
    : "white";
}
function nt() {}
function rt(e, t, o) {
  const n = o.value;
  o.value = function (...e) {
    const t = n.apply(this, e);
    return (
      t instanceof Promise ? t.then(() => this.set(this)) : this.set(this), t
    );
  };
}
function it() {
  try {
    return (
      !!window.localStorage &&
      ((window.localStorage.a = "b"), window.localStorage.removeItem("a"), !0)
    );
  } catch (e) {
    return !1;
  }
}
function st(
  e,
  t = !1,
  o = 13,
  n = 400,
  r = "Trebuchet MS,Roboto,Ubuntu,sans-serif"
) {
  let i = String(e);
  if (
    (t && (i = i.replace(/\w/g, "0")),
    Qa[o] && Qa[o][n] && Qa[o][n][r] && Qa[o][n][r][i])
  )
    return Qa[o][n][r][i];
  (Qa[o] = Qa[o] ?? {}),
    (Qa[o][n] = Qa[o][n] ?? {}),
    (Qa[o][n][r] = Qa[o][n][r] ?? {}),
    (Xa.innerText = i),
    (Xa.style.position = "absolute"),
    (Xa.style.fontSize = `${o}px`),
    (Xa.style.fontWeight = String(n)),
    (Xa.style.fontFamily = r),
    document.body.appendChild(Xa);
  const s = Xa.clientWidth;
  return (
    (Qa[o][n][r][i] = s), document.body.removeChild(Xa), (Xa.innerText = ""), s
  );
}
function at(e, t) {
  const o = Math.min(Math.max(t, 0), 8),
    n = sl[o];
  return e >= 0
    ? Math.floor(e * n + 0.5000001) / n
    : Math.ceil(e * n - 0.5000001) / n;
}
function lt(e, t = 0, o = 0) {
  return at(e + t, o);
}
function ct(e, t) {
  const o = at(e, t).toFixed(t).split(".");
  return (
    (o[0] = o[0].replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, "$1 ")), o.join(".")
  );
}
function ut(e, t, o) {
  return Math.abs(e - t) < 10 ** -(o + 1) ? 0 : e > t ? 1 : -1;
}
function dt(e, t = 0) {
  const o = Math.min(t, 8);
  return at(e / 10 ** o, o);
}
function ht(e, t) {
  return e - Math.floor(e / t) * t;
}
function pt(e, t = 2) {
  if (e < 0) return 8;
  if (0 === e) return t;
  let o = at(e, 8),
    n = 5e-9,
    r = 0;
  for (; r < 8 && Math.abs(o - Math.round(o)) > n; )
    (o *= 10), (n *= 10), (r += 1);
  return r < t && (r = t), r;
}
function gt(e, t) {
  if (0 === t) return 0n;
  const {
      sgn: o,
      exponent: n,
      mantissa: r,
    } = (function (e) {
      if (!isFinite(e)) throw new Error(`Input must be finite: ${e}`);
      const t = new DataView(new ArrayBuffer(8));
      t.setFloat64(0, e, !0);
      const o = t.getBigUint64(0, !0),
        n = (-1n) ** (o >> 63n),
        r = (o & ~(1n << 63n)) >> 52n;
      if (0n === r) throw new Error(`Subnormal floats not supported: ${e}`);
      return { sgn: n, exponent: r - 1023n, mantissa: o & ((1n << 52n) - 1n) };
    })(t),
    i = 2n ** (1023n + 52n);
  return (
    (2n * (o * 2n ** (n + 1023n) * (2n ** 52n + r)) * e + o * i) / (2n * i)
  );
}
function mt(e) {
  switch (e) {
    case 0:
      return { title: window.tr(window.lang.trade.table.columns.symbol) };
    case 1:
      return { title: window.tr(window.lang.trade.table.columns.ticket) };
    case 2:
      return { title: window.tr(window.lang.trade.table.columns.time) };
    case 3:
      return { title: window.tr(window.lang.trade.table.columns.type) };
    case 4:
      return { title: window.tr(window.lang.trade.table.columns.volume) };
    case 5:
      return {
        title: window.tr(window.lang.trade.table.columns.priceOpen),
        description: window.tr(
          window.lang.trade.table.columns.priceOpenDescription
        ),
      };
    case 6:
      return {
        title: "S / L",
        description: window.tr(window.lang.trade.table.columns.slDescription),
      };
    case 7:
      return {
        title: "T / P",
        description: window.tr(window.lang.trade.table.columns.tpDescription),
      };
    case 8:
      return {
        title: window.tr(window.lang.trade.table.columns.priceClose),
        description: window.tr(
          window.lang.trade.table.columns.priceCloseDescription
        ),
      };
    case 9:
      return { title: window.tr(window.lang.trade.table.columns.swap) };
    case 10:
      return { title: window.tr(window.lang.trade.table.columns.profit) };
    case 11:
      return { title: window.tr(window.lang.trade.table.columns.comment) };
    default:
      return { title: "" };
  }
}
function ft(e, t, o) {
  let n = (function (e) {
    const t = e + ul;
    return {
      0: st(window.tr(window.lang.trade.table.columns.symbol), !1, 12) + t,
      1: st(window.tr(window.lang.trade.table.columns.ticket), !1, 12) + t,
      2: st(window.tr(window.lang.trade.table.columns.time), !1, 12) + t,
      3: st(window.tr(window.lang.trade.table.columns.type), !1, 12) + t,
      4: st(window.tr(window.lang.trade.table.columns.volume), !1, 12) + t,
      5: st(window.tr(window.lang.trade.table.columns.priceOpen), !1, 12) + t,
      6: st("S / L", !1, 12) + t,
      7: st("T / P", !1, 12) + t,
      8: st(window.tr(window.lang.trade.table.columns.priceClose), !1, 12) + t,
      9: st(window.tr(window.lang.trade.table.columns.swap), !1, 12) + t,
      10: st(window.tr(window.lang.trade.table.columns.profit), !1, 12) + t,
      11: st(window.tr(window.lang.trade.table.columns.comment), !1, 12) + t,
      12: 40 + t,
    };
  })(o);
  return (
    (n = (function (e, t, o = 0) {
      return (
        t.forEach(({ value: t }) => {
          const n = t;
          (e[0] = Math.max(st(n.symbol) + o, e[0])),
            (e[1] = Math.max(st(n.id, !0) + o, e[0])),
            (e[2] = 100),
            (e[3] = Math.max(st(n.typeName) + o, e[3])),
            (e[4] = Math.max(st(n.volume) + o, e[4])),
            (e[5] = Math.max(st(ct(n.priceOpen, n.digits), !0) + o, e[5])),
            (e[6] = Math.max(st(ct(n.sl, n.digits), !0) + o, e[6])),
            (e[7] = Math.max(st(ct(n.tp, n.digits), !0) + o, e[7])),
            (e[8] = Math.max(st(ct(n.priceClose, n.digits), !0) + o, e[8])),
            (e[9] = Math.max((n.storage ? st(n.storage, !0) : 0) + o, e[9])),
            (e[10] = Math.max(
              st(ct(n.profit, n.digitsCurrency), !0) + o,
              e[10]
            )),
            (e[11] = Math.max(st(n.comment) + o, e[11])),
            (e[12] = 40 + o);
        }),
        { ...e }
      );
    })(n, e, o)),
    (n = (function (e, t, o = 0) {
      return (
        t.forEach(({ value: t }) => {
          const n = t;
          (e[0] = Math.max(st(n.symbol) + o, e[0])),
            (e[1] = Math.max(st(n.order, !0) + o, e[0])),
            (e[2] = 100),
            (e[3] = Math.max(st(n.typeName) + o, e[3])),
            (e[4] = Math.max(st(n.volume) + o, e[4])),
            (e[5] = Math.max(st(ct(n.price, n.digits), !0) + o, e[5])),
            (e[6] = Math.max(
              (n.sl ? st(ct(n.sl, n.digits), !0) : 0) + o,
              e[6]
            )),
            (e[7] = Math.max(
              (n.tp ? st(ct(n.tp, n.digits), !0) : 0) + o,
              e[7]
            )),
            (e[8] = Math.max(st(ct(n.priceCurrent, n.digits), !0) + o, e[8])),
            (e[9] = Math.max(o, e[9])),
            (e[10] = Math.max(st(n.state) + o, e[10])),
            (e[11] = Math.max(st(n.comment) + o, e[11])),
            (e[12] = 40 + o);
        }),
        e
      );
    })(n, t, o)),
    n
  );
}
function wt(e, t = "DD.MM.YY hhhh:mm:ss", o = !0) {
  function n(e, o) {
    let n,
      r = 4;
    for (; r > 1; ) {
      if (((n = new Array(r + 1).join(o)), t.substring(e, e + r) === n))
        return n;
      r -= 1;
    }
    return o;
  }
  const r = new Date(e),
    i = o,
    s = i ? r.getUTCDate() : r.getDate(),
    a = i ? r.getUTCMonth() : r.getMonth(),
    l = i ? r.getUTCFullYear() : r.getFullYear(),
    c = i ? r.getUTCMinutes() : r.getMinutes(),
    u = i ? r.getUTCSeconds() : r.getSeconds(),
    d = i ? r.getUTCHours() : r.getHours(),
    h = i ? r.getUTCDay() : r.getDay(),
    p = i ? r.getUTCMilliseconds() : r.getMilliseconds(),
    g = new Map();
  g.set("sss", p.toString().padStart(3, "0")),
    g.set("ss", u.toString().padStart(2, "0")),
    g.set("s", u),
    g.set("mm", c.toString().padStart(2, "0")),
    g.set("m", c),
    g.set("hhhh", d.toString().padStart(2, "0")),
    g.set("hhh", d),
    g.set(
      "hh",
      d > 12
        ? `${(24 - d).toString().padStart(2, "0")}PM`
        : `${d.toString().padStart(2, "0")}AM`
    ),
    g.set("h", d > 12 ? 24 - d + "PM" : `${d}AM`),
    g.set("DDDD", pl[h]),
    g.set("DDD", gl[h]),
    g.set("DD", s.toString().padStart(2, "0")),
    g.set("D", s),
    g.set("MMMM", dl[a]),
    g.set("MMM", hl[a]),
    g.set("MM", (a + 1).toString().padStart(2, "0")),
    g.set("M", a + 1),
    g.set("YY", l),
    g.set("Y", l.toString().substring(2));
  let m,
    f,
    w = "";
  for (let b = 0, v = t.length; b < v; b++)
    (m = t.charAt(b)),
      (f = n(b, m)),
      g.has(f) ? ((w += g.get(f)), (b += f.length - 1)) : (w += m);
  return w;
}
function bt(e) {
  switch (e) {
    case 0:
      return "buy";
    case 1:
      return "sell";
    case 2:
      return "balance";
    case 3:
      return "credit";
    case 4:
      return "charge";
    case 5:
      return "correction";
    case 6:
      return "bonus";
    case 7:
      return "commission";
    case 8:
      return "daily commission";
    case 9:
      return "monthly commission";
    case 10:
      return "daily agent commission";
    case 11:
      return "monthly agent commission";
    case 12:
      return "interest rate";
    case 13:
      return "canceled buy";
    case 14:
      return "canceled sell";
    case 15:
      return "dividend";
    case 16:
      return "franked dividend";
    case 17:
      return "tax";
    default:
      return "";
  }
}
function vt(e) {
  return 0 === e;
}
function yt(e) {
  return 1 === e;
}
function $t(e) {
  return (
    2 === e ||
    3 === e ||
    4 === e ||
    5 === e ||
    6 === e ||
    7 === e ||
    8 === e ||
    9 === e ||
    10 === e ||
    11 === e ||
    12 === e ||
    15 === e ||
    16 === e ||
    17 === e ||
    18 === e
  );
}
function Ct(e) {
  return (
    2 === e ||
    3 === e ||
    4 === e ||
    5 === e ||
    6 === e ||
    7 === e ||
    15 === e ||
    16 === e ||
    17 === e ||
    18 === e
  );
}
function xt(e) {
  return 0 === e || 4 === e || 2 === e || 6 === e;
}
function St(e) {
  return 1 === e || 3 === e || 5 === e || 7 === e;
}
function kt(e) {
  return 0 === e || 1 === e;
}
function At(e) {
  return 4 === e || 5 === e || 2 === e || 3 === e || 6 === e || 7 === e;
}
function Tt(e) {
  return 2 === e || 3 === e;
}
function Ot(e) {
  return 4 === e || 5 === e;
}
function Pt(e) {
  return 6 === e || 7 === e;
}
function Mt(e) {
  switch (e) {
    case 0:
      return "buy";
    case 1:
      return "sell";
    case 2:
      return "buy limit";
    case 3:
      return "sell limit";
    case 4:
      return "buy stop";
    case 5:
      return "sell stop";
    case 6:
      return "buy stop limit";
    case 7:
      return "sell stop limit";
    case 8:
      return "close by";
    default:
      return "unknown";
  }
}
function Lt(e) {
  switch (e) {
    case 0:
      return "B";
    case 1:
      return "S";
    case 2:
      return "BL";
    case 3:
      return "SL";
    case 4:
      return "BS";
    case 5:
      return "SS";
    case 6:
      return "BSL";
    case 7:
      return "SSL";
    case 8:
      return "CB";
    default:
      return "unknown";
  }
}
function Et(e) {
  switch (e) {
    case 0:
      return "Started";
    case 1:
      return "Placed";
    case 2:
      return "Canceled";
    case 3:
      return "Partial";
    case 4:
      return "Filled";
    case 5:
      return "Rejected";
    case 6:
      return "Expired";
    case 7:
      return "Request adding";
    case 8:
      return "Request modifying";
    case 9:
      return "Request cancelling";
    default:
      return "unknown";
  }
}
function Dt(e) {
  switch (e) {
    case "timeOpen":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.timeOpen),
        description: window.tr(
          window.lang.trade.history.positions.columns.timeOpenDescription
        ),
      };
    case "id":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.ticket),
      };
    case "type":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.type),
      };
    case "volumeValue":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.volume),
      };
    case "symbol":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.symbol),
      };
    case "priceOpen":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.priceOpen),
        description: window.tr(
          window.lang.trade.history.positions.columns.priceOpenDescription
        ),
      };
    case "sl":
      return {
        title: "S / L",
        description: window.tr(
          window.lang.trade.history.positions.columns.slDescription
        ),
      };
    case "tp":
      return {
        title: "T / P",
        description: window.tr(
          window.lang.trade.history.positions.columns.tpDescription
        ),
      };
    case "timeClose":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.timeClose),
        description: window.tr(
          window.lang.trade.history.positions.columns.timeCloseDescription
        ),
      };
    case "priceClose":
      return {
        title: window.tr(
          window.lang.trade.history.positions.columns.priceClose
        ),
        description: window.tr(
          window.lang.trade.history.positions.columns.priceCloseDescription
        ),
      };
    case "commission":
      return {
        title: window.tr(
          window.lang.trade.history.positions.columns.commission
        ),
      };
    case "commissionFee":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.fee),
      };
    case "storage":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.swap),
      };
    case "profit":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.profit),
      };
    case "comment":
      return {
        title: window.tr(window.lang.trade.history.positions.columns.comment),
      };
    default:
      return { title: "" };
  }
}
function _t(e) {
  switch (e) {
    case "timeSetup":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.timeSetup),
        description: window.tr(
          window.lang.trade.history.orders.columns.timeSetupDescription
        ),
      };
    case "order":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.ticket),
      };
    case "symbol":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.symbol),
      };
    case "type":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.type),
      };
    case "volumeValue":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.volume),
      };
    case "price":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.price),
      };
    case "sl":
      return {
        title: "S / L",
        description: window.tr(
          window.lang.trade.history.orders.columns.slDescription
        ),
      };
    case "tp":
      return {
        title: "T / P",
        description: window.tr(
          window.lang.trade.history.orders.columns.tpDescription
        ),
      };
    case "timeDone":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.timeDone),
        description: window.tr(
          window.lang.trade.history.orders.columns.timeDoneDescription
        ),
      };
    case "state":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.state),
      };
    case "comment":
      return {
        title: window.tr(window.lang.trade.history.orders.columns.comment),
      };
    default:
      return { title: "" };
  }
}
function Ut(e) {
  switch (e) {
    case "timeCreate":
      return { title: window.tr(window.lang.trade.history.deals.columns.time) };
    case "deal":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.ticket),
      };
    case "order":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.order),
      };
    case "symbol":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.symbol),
      };
    case "action":
      return { title: window.tr(window.lang.trade.history.deals.columns.type) };
    case "entry":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.direction),
      };
    case "volume":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.volume),
      };
    case "priceClose":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.price),
      };
    case "commission":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.commission),
      };
    case "commissionFee":
      return { title: window.tr(window.lang.trade.history.deals.columns.fee) };
    case "storage":
      return { title: window.tr(window.lang.trade.history.deals.columns.swap) };
    case "profit":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.profit),
      };
    case "comment":
      return {
        title: window.tr(window.lang.trade.history.deals.columns.comment),
      };
    default:
      return { title: "" };
  }
}
function Bt(e) {
  return e ? wt(new Date(e), "YY.MM.DD hhhh:mm:ss") : "";
}
function Vt(e) {
  return {
    [ks.TimeOpen]: st(Dt(ks.TimeOpen).title, !1, 12) + e,
    [ks.Id]: st(Dt(ks.Id).title, !1, 12) + e,
    [ks.Type]: st(Dt(ks.Type).title, !1, 12) + e,
    [ks.VolumeValue]: st(Dt(ks.VolumeValue).title, !1, 12) + e,
    [ks.Symbol]: st(Dt(ks.Symbol).title, !1, 12) + e,
    [ks.PriceOpen]: st(Dt(ks.PriceOpen).title, !1, 12) + e,
    [ks.Sl]: st(Dt(ks.Sl).title, !1, 12) + e,
    [ks.Tp]: st(Dt(ks.Tp).title, !1, 12) + e,
    [ks.TimeClose]: st(Dt(ks.TimeClose).title, !1, 12) + e,
    [ks.PriceClose]: st(Dt(ks.PriceClose).title, !1, 12) + e,
    [ks.Commission]: st(Dt(ks.Commission).title, !1, 12) + e,
    [ks.CommissionFee]: st(Dt(ks.CommissionFee).title, !1, 12) + e,
    [ks.Storage]: st(Dt(ks.Storage).title, !1, 12) + e,
    [ks.Profit]: st(Dt(ks.Profit).title, !1, 12) + e,
    [ks.Comment]: st(Dt(ks.Comment).title, !1, 12) + e,
  };
}
function jt(e, t = 0) {
  const o = { ...Vt(t) };
  return (
    e.forEach(({ value: e }) => {
      (o[ks.TimeOpen] = Math.max(st(Bt(e.timeOpen), !0) + t, o[ks.TimeOpen])),
        (o[ks.Id] = Math.max(st(e.id, !0) + t, o[ks.Id])),
        (o[ks.Type] = Math.max(st(bt(e.type)) + t, o[ks.Type])),
        (o[ks.VolumeValue] = Math.max(st(e.volume, !0) + t, o[ks.VolumeValue])),
        (o[ks.Symbol] = Math.max(st(e.symbol) + t, o[ks.Symbol])),
        (o[ks.PriceOpen] = Math.max(
          st(ct(e.priceOpen, e.digits), !0) + t,
          o[ks.PriceOpen]
        )),
        (o[ks.Sl] = Math.max(
          st(e.sl ? ct(e.sl, e.digits) : "", !0) + t,
          o[ks.Sl]
        )),
        (o[ks.Tp] = Math.max(
          st(e.tp ? ct(e.tp, e.digits) : "", !0) + t,
          o[ks.Tp]
        )),
        (o[ks.TimeClose] = Math.max(
          st(Bt(e.timeClose), !0) + t,
          o[ks.TimeClose]
        )),
        (o[ks.PriceClose] = Math.max(
          st(ct(e.priceClose, e.digits), !0) + t,
          o[ks.PriceClose]
        )),
        (o[ks.Commission] = Math.max(
          st(e.commission ? ct(e.commission, e.digitsCurrency) : "", !0) + t,
          o[ks.Commission]
        )),
        (o[ks.CommissionFee] = Math.max(
          st(e.commissionFee ? ct(e.commissionFee, e.digitsCurrency) : "", !0) +
            t,
          o[ks.CommissionFee]
        )),
        (o[ks.Storage] = Math.max(
          st(e.storage ? ct(e.storage, e.digitsCurrency) : "", !0) + t,
          o[ks.Storage]
        )),
        (o[ks.Profit] = Math.max(
          st(ct(e.profit ?? 0, e.digitsCurrency), !0) + t,
          o[ks.Profit]
        )),
        (o[ks.Comment] = Math.max(st(e.comment) + t, o[ks.Comment]));
    }),
    o
  );
}
function zt() {
  return {
    [ks.TimeOpen]: !0,
    [ks.Id]: !0,
    [ks.Type]: !0,
    [ks.VolumeValue]: !0,
    [ks.PriceOpen]: !0,
    [ks.Sl]: !0,
    [ks.Tp]: !0,
    [ks.TimeClose]: !0,
    [ks.PriceClose]: !0,
    [ks.Commission]: !0,
    [ks.CommissionFee]: !0,
    [ks.Storage]: !0,
  };
}
function It(e) {
  return {
    [As.TimeSetup]: st(_t(As.TimeSetup).title, !1, 12) + e,
    [As.Order]: st(_t(As.Order).title, !1, 12) + e,
    [As.Symbol]: st(_t(As.Symbol).title, !1, 12) + e,
    [As.Type]: st(_t(As.Type).title, !1, 12) + e,
    [As.VolumeValue]: st(_t(As.VolumeValue).title, !1, 12) + e,
    [As.Price]: st(_t(As.Price).title, !1, 12) + e,
    [As.Sl]: st(_t(As.Sl).title, !1, 12) + e,
    [As.Tp]: st(_t(As.Tp).title, !1, 12) + e,
    [As.TimeDone]: st(_t(As.TimeDone).title, !1, 12) + e,
    [As.State]: st(_t(As.State).title, !1, 12) + e,
    [As.Comment]: st(_t(As.Comment).title, !1, 12) + e,
  };
}
function Ht(e, t = 0) {
  const o = { ...It(t) };
  return (
    e.forEach(({ value: e }) => {
      (o[As.TimeSetup] = Math.max(
        st(Bt(e.timeSetup), !0) + t,
        o[As.TimeSetup]
      )),
        (o[As.Order] = Math.max(st(e.order, !0) + t, o[As.Order])),
        (o[As.Symbol] = Math.max(st(e.symbol) + t, o[As.Symbol])),
        (o[As.Type] = Math.max(st(Mt(e.type)) + t, o[As.Type])),
        (o[As.VolumeValue] = Math.max(
          st(e.volumeSize, !0) + t,
          o[As.VolumeValue]
        )),
        (o[As.Price] = Math.max(
          st(e.price ? ct(e.price, e.digits) : "", !0) + t,
          o[As.Price]
        )),
        (o[As.Sl] = Math.max(
          st(e.sl ? ct(e.sl, e.digits) : "", !0) + t,
          o[As.Sl]
        )),
        (o[As.Tp] = Math.max(
          st(e.tp ? ct(e.tp, e.digits) : "", !0) + t,
          o[As.Tp]
        )),
        (o[As.TimeDone] = Math.max(st(Bt(e.timeDone), !0) + t, o[As.TimeDone])),
        (o[As.State] = Math.max(st(Et(e.state)) + t, o[As.State])),
        (o[As.Comment] = Math.max(st(e.comment) + t, o[As.Comment]));
    }),
    o
  );
}
function Nt() {
  return {
    [As.TimeSetup]: !0,
    [As.Order]: !0,
    [As.VolumeValue]: !0,
    [As.Sl]: !0,
    [As.Tp]: !0,
    [As.TimeDone]: !0,
    [As.State]: !0,
    [As.Comment]: !0,
  };
}
function Rt(e) {
  return {
    [Ts.TimeCreate]: st(Ut(Ts.TimeCreate).title, !1, 12) + e,
    [Ts.Deal]: st(Ut(Ts.Deal).title, !1, 12) + e,
    [Ts.Order]: st(Ut(Ts.Order).title, !1, 12) + e,
    [Ts.Symbol]: st(Ut(Ts.Symbol).title, !1, 12) + e,
    [Ts.Action]: st(Ut(Ts.Action).title, !1, 12) + e,
    [Ts.Entry]: st(Ut(Ts.Entry).title, !1, 12) + e,
    [Ts.Volume]: st(Ut(Ts.Volume).title, !1, 12) + e,
    [Ts.PriceClose]: st(Ut(Ts.PriceClose).title, !1, 12) + e,
    [Ts.Commission]: st(Ut(Ts.Commission).title, !1, 12) + e,
    [Ts.CommissionFee]: st(Ut(Ts.CommissionFee).title, !1, 12) + e,
    [Ts.Storage]: st(Ut(Ts.Storage).title, !1, 12) + e,
    [Ts.Profit]: st(Ut(Ts.Profit).title, !1, 12) + e,
    [Ts.Comment]: st(Ut(Ts.Comment).title, !1, 12) + e,
  };
}
function qt(e, t = 0) {
  const o = { ...Rt(t) };
  return (
    e.forEach(({ value: e }) => {
      (o[Ts.TimeCreate] = Math.max(
        st(Bt(e.timeCreate), !0) + t,
        o[Ts.TimeCreate]
      )),
        (o[Ts.Deal] = Math.max(st(e.deal, !0) + t, o[Ts.Deal])),
        (o[Ts.Order] = Math.max(st(e.order, !0) + t, o[Ts.Order])),
        (o[Ts.Symbol] = Math.max(st(e.symbol) + t, o[Ts.Symbol])),
        (o[Ts.Action] = Math.max(st(bt(e.action)) + t, o[Ts.Action])),
        (o[Ts.Entry] = Math.max(st(e.entry) + t, o[Ts.Entry])),
        (o[Ts.Volume] = Math.max(st(e.volume) + t, o[Ts.Volume])),
        (o[Ts.PriceClose] = Math.max(
          st(ct(e.priceOpen, e.digits), !0) + t,
          o[Ts.PriceClose]
        )),
        (o[Ts.Commission] = Math.max(
          st(e.commission ? ct(e.commission, e.digitsCurrency) : "", !0) + t,
          o[Ts.Commission]
        )),
        (o[Ts.CommissionFee] = Math.max(
          st(e.commissionFee ? ct(e.commissionFee, e.digitsCurrency) : "", !0) +
            t,
          o[Ts.CommissionFee]
        )),
        (o[Ts.Storage] = Math.max(
          st(e.storage ? ct(e.storage, e.digitsCurrency) : "", !0) + t,
          o[Ts.Storage]
        )),
        (o[Ts.Profit] = Math.max(
          st(ct(e.profit ?? 0, e.digitsCurrency), !0) + t,
          o[Ts.Profit]
        )),
        (o[Ts.Comment] = Math.max(st(e.comment) + t, o[Ts.Comment]));
    }),
    o
  );
}
function Ft() {
  return {
    [Ts.TimeCreate]: !0,
    [Ts.Deal]: !0,
    [Ts.Order]: !0,
    [Ts.Action]: !0,
    [Ts.Entry]: !0,
    [Ts.Volume]: !0,
    [Ts.PriceClose]: !0,
    [Ts.Commission]: !0,
    [Ts.CommissionFee]: !0,
    [Ts.Storage]: !0,
    [Ts.Comment]: !0,
  };
}
function Wt() {
  return {
    [Ss.Ticket]: !0,
    [Ss.Time]: !0,
    [Ss.Type]: !0,
    [Ss.Volume]: !0,
    [Ss.Sl]: !0,
    [Ss.Tp]: !0,
    [Ss.MarketPrice]: !0,
    [Ss.Swap]: !0,
    [Ss.Comment]: !0,
    [Ss.Controls]: !0,
  };
}
function Kt(e) {
  return (
    e.objectStoreNames.contains(vl.layout) && e.deleteObjectStore(vl.layout),
    e.createObjectStore(vl.layout, { keyPath: bl })
  );
}
function Gt(e) {
  return (
    e.objectStoreNames.contains(vl.uiSettings) &&
      e.deleteObjectStore(vl.uiSettings),
    e.createObjectStore(vl.uiSettings, { keyPath: bl })
  );
}
function Zt(e) {
  return (
    e.objectStoreNames.contains(vl.users) && e.deleteObjectStore(vl.users),
    e.createObjectStore(vl.users, { keyPath: "id" })
  );
}
function Yt(e) {
  const t = new Date(),
    o = t.toLocaleString("en-US", { timeZone: e }),
    n = t.toLocaleString("en-US"),
    r = (Date.parse(n) - Date.parse(o)) / 6e4 + t.getTimezoneOffset();
  return 0 === r ? r : -r;
}
function Jt(e) {
  if (0 === e) return "(UTC)";
  const t = e % 60,
    o = e > 0 ? "+" : "",
    n = Math.floor(e / 60);
  return 0 === t ? `(UTC${o}${n})` : `(UTC${o}${n}:${t < 10 ? `0${t}` : t})`;
}
function Qt(e) {
  if ("UTC" === e) return "UTC";
  switch (e) {
    case Pl.africa.cairo:
      return window.tr(window.lang.ui.timezone.city.cairo);
    case Pl.africa.casablanca:
      return window.tr(window.lang.ui.timezone.city.casablanca);
    case Pl.africa.johannesburg:
      return window.tr(window.lang.ui.timezone.city.johannesburg);
    case Pl.africa.lagos:
      return window.tr(window.lang.ui.timezone.city.lagos);
    case Pl.africa.nairobi:
      return window.tr(window.lang.ui.timezone.city.nairobi);
    case Pl.africa.tunis:
      return window.tr(window.lang.ui.timezone.city.tunis);
    case Pl.america.anchorage:
      return window.tr(window.lang.ui.timezone.city.anchorage);
    case Pl.america.bogota:
      return window.tr(window.lang.ui.timezone.city.bogota);
    case Pl.america.buenosAires:
      return window.tr(window.lang.ui.timezone.city.buenosAires);
    case Pl.america.caracas:
      return window.tr(window.lang.ui.timezone.city.caracas);
    case Pl.america.chicago:
      return window.tr(window.lang.ui.timezone.city.chicago);
    case Pl.america.denver:
      return window.tr(window.lang.ui.timezone.city.denver);
    case Pl.america.elSalvador:
      return window.tr(window.lang.ui.timezone.city.elSalvador);
    case Pl.america.juneau:
      return window.tr(window.lang.ui.timezone.city.juneau);
    case Pl.america.lima:
      return window.tr(window.lang.ui.timezone.city.lima);
    case Pl.america.losAngeles:
      return window.tr(window.lang.ui.timezone.city.losAngeles);
    case Pl.america.mexicoCity:
      return window.tr(window.lang.ui.timezone.city.mexicoCity);
    case Pl.america.newYork:
      return window.tr(window.lang.ui.timezone.city.newYork);
    case Pl.america.phoenix:
      return window.tr(window.lang.ui.timezone.city.phoenix);
    case Pl.america.santiago:
      return window.tr(window.lang.ui.timezone.city.santiago);
    case Pl.america.saoPaulo:
      return window.tr(window.lang.ui.timezone.city.saoPaulo);
    case Pl.america.toronto:
      return window.tr(window.lang.ui.timezone.city.toronto);
    case Pl.america.vancouver:
      return window.tr(window.lang.ui.timezone.city.vancouver);
    case Pl.asia.almaty:
      return window.tr(window.lang.ui.timezone.city.almaty);
    case Pl.asia.ashgabat:
      return window.tr(window.lang.ui.timezone.city.ashgabat);
    case Pl.asia.bahrain:
      return window.tr(window.lang.ui.timezone.city.bahrain);
    case Pl.asia.bangkok:
      return window.tr(window.lang.ui.timezone.city.bangkok);
    case Pl.asia.calcutta:
      return window.tr(window.lang.ui.timezone.city.kolkata);
    case Pl.asia.colombo:
      return window.tr(window.lang.ui.timezone.city.colombo);
    case Pl.asia.dhaka:
      return window.tr(window.lang.ui.timezone.city.dhaka);
    case Pl.asia.dubai:
      return window.tr(window.lang.ui.timezone.city.dubai);
    case Pl.asia.hongKong:
      return window.tr(window.lang.ui.timezone.city.hongKong);
    case Pl.asia.jakarta:
      return window.tr(window.lang.ui.timezone.city.jakarta);
    case Pl.asia.jerusalem:
      return window.tr(window.lang.ui.timezone.city.jerusalem);
    case Pl.asia.karachi:
      return window.tr(window.lang.ui.timezone.city.karachi);
    case Pl.asia.katmandu:
      return window.tr(window.lang.ui.timezone.city.kathmandu);
    case Pl.asia.kuwait:
      return window.tr(window.lang.ui.timezone.city.kuwait);
    case Pl.asia.manila:
      return window.tr(window.lang.ui.timezone.city.manila);
    case Pl.asia.muscat:
      return window.tr(window.lang.ui.timezone.city.muscat);
    case Pl.asia.nicosia:
      return window.tr(window.lang.ui.timezone.city.nicosia);
    case Pl.asia.qatar:
      return window.tr(window.lang.ui.timezone.city.qatar);
    case Pl.asia.rangoon:
      return window.tr(window.lang.ui.timezone.city.rangoon);
    case Pl.asia.riyadh:
      return window.tr(window.lang.ui.timezone.city.riyadh);
    case Pl.asia.saigon:
      return window.tr(window.lang.ui.timezone.city.saigon);
    case Pl.asia.seoul:
      return window.tr(window.lang.ui.timezone.city.seoul);
    case Pl.asia.shanghai:
      return window.tr(window.lang.ui.timezone.city.shanghai);
    case Pl.asia.singapore:
      return window.tr(window.lang.ui.timezone.city.singapore);
    case Pl.asia.taipei:
      return window.tr(window.lang.ui.timezone.city.taipei);
    case Pl.asia.tehran:
      return window.tr(window.lang.ui.timezone.city.tehran);
    case Pl.asia.tokyo:
      return window.tr(window.lang.ui.timezone.city.tokyo);
    case Pl.atlantic.reykjavik:
      return window.tr(window.lang.ui.timezone.city.reykjavik);
    case Pl.australia.adelaide:
      return window.tr(window.lang.ui.timezone.city.adelaide);
    case Pl.australia.brisbane:
      return window.tr(window.lang.ui.timezone.city.brisbane);
    case Pl.australia.perth:
      return window.tr(window.lang.ui.timezone.city.perth);
    case Pl.australia.sydney:
      return window.tr(window.lang.ui.timezone.city.sydney);
    case Pl.europe.amsterdam:
      return window.tr(window.lang.ui.timezone.city.amsterdam);
    case Pl.europe.athens:
      return window.tr(window.lang.ui.timezone.city.athens);
    case Pl.europe.belgrade:
      return window.tr(window.lang.ui.timezone.city.belgrade);
    case Pl.europe.berlin:
      return window.tr(window.lang.ui.timezone.city.berlin);
    case Pl.europe.bratislava:
      return window.tr(window.lang.ui.timezone.city.bratislava);
    case Pl.europe.brussels:
      return window.tr(window.lang.ui.timezone.city.brussels);
    case Pl.europe.bucharest:
      return window.tr(window.lang.ui.timezone.city.bucharest);
    case Pl.europe.budapest:
      return window.tr(window.lang.ui.timezone.city.budapest);
    case Pl.europe.copenhagen:
      return window.tr(window.lang.ui.timezone.city.copenhagen);
    case Pl.europe.dublin:
      return window.tr(window.lang.ui.timezone.city.dublin);
    case Pl.europe.helsinki:
      return window.tr(window.lang.ui.timezone.city.helsinki);
    case Pl.europe.istanbul:
      return window.tr(window.lang.ui.timezone.city.istanbul);
    case Pl.europe.lisbon:
      return window.tr(window.lang.ui.timezone.city.lisbon);
    case Pl.europe.london:
      return window.tr(window.lang.ui.timezone.city.london);
    case Pl.europe.luxembourg:
      return window.tr(window.lang.ui.timezone.city.luxembourg);
    case Pl.europe.madrid:
      return window.tr(window.lang.ui.timezone.city.madrid);
    case Pl.europe.malta:
      return window.tr(window.lang.ui.timezone.city.malta);
    case Pl.europe.moscow:
      return window.tr(window.lang.ui.timezone.city.moscow);
    case Pl.europe.oslo:
      return window.tr(window.lang.ui.timezone.city.oslo);
    case Pl.europe.paris:
      return window.tr(window.lang.ui.timezone.city.paris);
    case Pl.europe.prague:
      return window.tr(window.lang.ui.timezone.city.prague);
    case Pl.europe.riga:
      return window.tr(window.lang.ui.timezone.city.riga);
    case Pl.europe.rome:
      return window.tr(window.lang.ui.timezone.city.rome);
    case Pl.europe.stockholm:
      return window.tr(window.lang.ui.timezone.city.stockholm);
    case Pl.europe.tallinn:
      return window.tr(window.lang.ui.timezone.city.tallinn);
    case Pl.europe.vienna:
      return window.tr(window.lang.ui.timezone.city.vienna);
    case Pl.europe.vilnius:
      return window.tr(window.lang.ui.timezone.city.vilnius);
    case Pl.europe.warsaw:
      return window.tr(window.lang.ui.timezone.city.warsaw);
    case Pl.europe.zurich:
      return window.tr(window.lang.ui.timezone.city.zurich);
    case Pl.pacific.auckland:
      return window.tr(window.lang.ui.timezone.city.auckland);
    case Pl.pacific.chatham:
      return window.tr(window.lang.ui.timezone.city.chatham);
    case Pl.pacific.fakaofo:
      return window.tr(window.lang.ui.timezone.city.fakaofo);
    case Pl.pacific.honolulu:
      return window.tr(window.lang.ui.timezone.city.honolulu);
    case Pl.pacific.norfolk:
      return window.tr(window.lang.ui.timezone.city.norfolk);
    default:
      return "";
  }
}
function Xt(e) {
  switch (e) {
    case 1:
      return "Client agreement";
    case 2:
      return "Risk disclosure";
    case 3:
      return "Client agreement and risk disclosure";
    case 4:
      return "Complaints handling procedure";
    case 5:
      return "Order execution policy";
    case 6:
      return "Client categorisation notice";
    case 7:
      return "Conflicts of interest policy";
    case 8:
      return "Data Protection Policy";
    default:
      return "";
  }
}
function eo(e) {
  const t = e.some((e) => 2 === e.account_type),
    o = e.some((e) => 2 !== e.account_type);
  return t && !o ? 1 : !t && o ? 0 : -1;
}
function to(e, t) {
  return -1 !== eo(e) ? e : e.filter((e) => (t ? oo(e) : !oo(e)));
}
function oo(e) {
  return 2 === e.account_type;
}
function no(e, t, o = !1) {
  return e.filter((e) => {
    const n = Boolean(e.real) === o;
    return t && e.countries.length ? n && e.countries.includes(t) : n;
  });
}
function ro(e) {
  const t = [];
  for (let o = 0, n = e.length / 2; o < n; o++)
    t.push(Number(`0x${e.substring(2 * o, 2 * o + 2)}`));
  return new Uint8Array(t).buffer;
}
function io(e) {
  let t = "";
  for (let o = 0, n = e.length; o < n; o++)
    t += e.charCodeAt(o).toString(16).padStart(2, "0");
  return t;
}
function so(e) {
  const t = [];
  for (let o = 0; o < e.length; o++)
    28 === e.charCodeAt(o)
      ? t.push("&")
      : 23 === e.charCodeAt(o)
      ? t.push("!")
      : t.push(String.fromCharCode(e.charCodeAt(o) - 1));
  return t.join("");
}
function ao(e, t) {
  let o = e,
    n = o.length,
    r = 0;
  for (; n > 0 && "0" === o.charAt(n - 1) && r < t; ) (n -= 1), (r += 1);
  return (
    (o = o.substring(0, n)),
    n > 0 && "." === o.charAt(n - 1) && (o = o.substring(0, n - 1)),
    o
  );
}
function lo(e) {
  const t = [],
    o = new DataView(e);
  for (let n = 0; n < e.byteLength; n++) {
    let e = o.getUint8(n).toString(16);
    e.length < 2 && (e = ["0", e].join("")), t.push(e);
  }
  return t.join("");
}
async function co(e) {
  if (!Nl) throw new Error("Error initializing crypto api");
  const t = { name: ql };
  return Nl.importKey("raw", e, t, !0, ["encrypt", "decrypt"]);
}
function uo(e, t) {
  const o = { name: ql, iv: new Uint8Array(Rl) };
  return Nl.encrypt(o, t, e);
}
function ho(e, t) {
  const o = { name: ql, iv: new Uint8Array(Rl) };
  return Nl.decrypt(o, t, e);
}
function po() {
  const { name: e } = window;
  if (e && Boolean(e.split("").find((e) => isNaN(parseInt(e, 10)))))
    return e.substring(0, 12);
  let t = document.cookie;
  if (
    t &&
    ((t = t.split(";").find((e) => 0 === e.indexOf("uniq="))),
    t && ((t = t.split("=")[1]), t))
  ) {
    if (((t = t.split("-")), 1 === t.length && t[0].length >= 12))
      return t[0].substring(0, 12);
    if (t.length > 1) return t[0] + t[1];
  }
  return "";
}
function go(e) {
  let t, o;
  const n = e[4].default,
    r = c(n, e, e[3], null);
  return {
    c() {
      (t = P("div")), r && r.c(), B(t, "class", "_portal"), B(t, "style", e[0]);
    },
    m(n, i) {
      A(n, t, i), r && r.m(t, null), e[5](t), (o = !0);
    },
    p(e, [i]) {
      r &&
        r.p &&
        (!o || 8 & i) &&
        h(r, n, e, e[3], o ? d(n, e[3], i, null) : p(e[3]), null),
        (!o || 1 & i) && B(t, "style", e[0]);
    },
    i(e) {
      o || ($e(r, e), (o = !0));
    },
    o(e) {
      Ce(r, e), (o = !1);
    },
    d(o) {
      o && T(t), r && r.d(o), e[5](null);
    },
  };
}
function mo() {
  return (
    oc ||
    ((oc = document.createElement("div")),
    (oc.style.zIndex = "10"),
    (oc.style.position = "fixed"),
    (oc.style.top = "0"),
    (oc.style.left = "0"),
    (oc.style.width = "100%"),
    (oc.style.height = "100%"),
    (oc.style.pointerEvents = "none"),
    document.body.appendChild(oc),
    oc)
  );
}
function fo(e, t, o) {
  let n,
    r,
    { $$slots: i = {}, $$scope: s } = t,
    { parent: a = mo() } = t,
    { style: l = "" } = t;
  return (
    ie(() => {
      (r = null == n ? void 0 : n.parentNode), r && n && a.appendChild(n);
    }),
    se(() => (null == r ? void 0 : r.appendChild(n))),
    (e.$$set = (e) => {
      "parent" in e && o(2, (a = e.parent)),
        "style" in e && o(0, (l = e.style)),
        "$$scope" in e && o(3, (s = e.$$scope));
    }),
    [
      l,
      n,
      a,
      s,
      i,
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (n = e), o(1, n);
        });
      },
    ]
  );
}
function wo(t) {
  let o, n;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        B(
          n,
          "d",
          "M6.46399 7.46738L6.96398 7.46461L6.52445 7.22625C6.6541 6.9872 6.78149 6.79785 6.929 6.66892C7.00918 6.59884 7.09969 6.54246 7.20305 6.50664C7.30598 6.47096 7.397 6.46435 7.46185 6.46399L7.46461 6.46397C7.7204 6.46397 7.97751 6.5633 8.17172 6.75751L12 10.5858L15.8283 6.75751C16.0236 6.56222 16.2796 6.46539 16.5326 6.46399L16.5354 6.96398L16.7737 6.52446C17.0128 6.6541 17.2021 6.78149 17.3311 6.92901C17.4011 7.00918 17.4575 7.09969 17.4934 7.20305C17.529 7.30598 17.5356 7.397 17.536 7.46185L17.536 7.46461C17.536 7.7204 17.4367 7.97751 17.2425 8.17172L13.4142 12L17.2425 15.8283C17.4378 16.0236 17.5346 16.2796 17.536 16.5326L17.536 16.5354C17.536 16.7912 17.4367 17.0483 17.2425 17.2425C17.0472 17.4378 16.7911 17.5346 16.5381 17.536L16.5354 17.536C16.2796 17.536 16.0225 17.4367 15.8283 17.2425L12 13.4142L8.17172 17.2425C7.97644 17.4378 7.72035 17.5346 7.46738 17.536L7.46461 17.536C7.20882 17.536 6.95171 17.4367 6.75751 17.2425C6.56223 17.0472 6.46539 16.7911 6.46399 16.5381L6.46398 16.5354C6.46398 16.2796 6.5633 16.0225 6.75751 15.8283L10.5858 12L6.7575 8.17172C6.56222 7.97644 6.46538 7.72035 6.46399 7.46738Z"
        ),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function bo(e) {
  let t, o, n;
  var r = e[0];
  return (
    r && (o = J(r, {})),
    {
      c() {
        (t = P("div")),
          o && Ue(o.$$.fragment),
          B(t, "class", "icon svelte-14kqgfa"),
          W(t, "width", "calc(var(--indent-half) * " + e[1] + ")"),
          W(t, "height", "calc(var(--indent-half) * " + e[2] + ")");
      },
      m(e, r) {
        A(e, t, r), o && Be(o, t, null), (n = !0);
      },
      p(e, [i]) {
        if (1 & i && r !== (r = e[0])) {
          if (o) {
            ve();
            const e = o;
            Ce(e.$$.fragment, 1, 0, () => {
              Ve(e, 1);
            }),
              ye();
          }
          r
            ? ((o = J(r, {})),
              Ue(o.$$.fragment),
              $e(o.$$.fragment, 1),
              Be(o, t, null))
            : (o = null);
        }
        (!n || 2 & i) &&
          W(t, "width", "calc(var(--indent-half) * " + e[1] + ")"),
          (!n || 4 & i) &&
            W(t, "height", "calc(var(--indent-half) * " + e[2] + ")");
      },
      i(e) {
        n || (o && $e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        o && Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        e && T(t), o && Ve(o);
      },
    }
  );
}
function vo(e, t, o) {
  let { name: n } = t,
    { width: r = 6 } = t,
    { height: i = 6 } = t;
  return (
    (e.$$set = (e) => {
      "name" in e && o(0, (n = e.name)),
        "width" in e && o(1, (r = e.width)),
        "height" in e && o(2, (i = e.height));
    }),
    [n, r, i]
  );
}
function yo(e, t, o) {
  let n,
    r = "error";
  switch (e) {
    case 1:
      n = " Internal Error";
      break;
    case 2:
      n = " Server is not available";
      break;
    case 3:
      n = " Invalid account or password";
      break;
    case 4:
      n = " ";
      break;
    case 5:
      5 === t
        ? (n = " Invalid account OTP")
        : ((n = " Enter account OTP"), (r = "warning"));
      break;
    case 6:
      (n = " Enable 2FA/TOTP"), (r = "warning");
      break;
    case 201:
      n = " Invalid account OTP";
      break;
    case 7:
      n = " Invalid e-mail";
      break;
    case 8:
      n = " Invalid phone";
      break;
    case 9:
      n = " Authorization using SSL certificates is not supported";
      break;
    case 100:
      n = " No connection";
      break;
    case 104:
      n = cc
        ? "No connection, try to disable AdBlockers"
        : "Connection closed or not established";
      break;
    case 408:
      n = " Server is not response, please try again";
      break;
    case 1031:
      n = " Invalid verification code";
      break;
    case 2e3:
      n = ` Use ${o ?? 8} or more characters.`;
      break;
    case 2001:
      n =
        " Password must include lower- and uppercase letters, numbers, and special symbols.";
      break;
    case 2005:
      n = " Current password is incorrect.";
      break;
    case 2006:
      n = " Passwords do not match.";
      break;
    case 2007:
      n = " Please enter the password.";
      break;
    default:
      n = `Error (${e})`;
  }
  return { message: n, type: r, code: e };
}
function $o(e) {
  const t = e.indexOf("//"),
    o = -1 !== t ? t + 2 : 0;
  return e.slice(o);
}
function Co(e) {
  let t, o;
  const n = e[2].default,
    r = c(n, e, e[1], null);
  return {
    c() {
      (t = P("div")),
        r && r.c(),
        B(t, "class", "error svelte-7dwjfn"),
        Z(t, "warning", e[0]);
    },
    m(e, n) {
      A(e, t, n), r && r.m(t, null), (o = !0);
    },
    p(e, [i]) {
      r &&
        r.p &&
        (!o || 2 & i) &&
        h(r, n, e, e[1], o ? d(n, e[1], i, null) : p(e[1]), null),
        (!o || 1 & i) && Z(t, "warning", e[0]);
    },
    i(e) {
      o || ($e(r, e), (o = !0));
    },
    o(e) {
      Ce(r, e), (o = !1);
    },
    d(e) {
      e && T(t), r && r.d(e);
    },
  };
}
function xo(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { warning: i = !1 } = t;
  return (
    (e.$$set = (e) => {
      "warning" in e && o(0, (i = e.warning)),
        "$$scope" in e && o(1, (r = e.$$scope));
    }),
    [i, r, n]
  );
}
function So(e) {
  return e < 0.5 ? 4 * e * e * e : 0.5 * Math.pow(2 * e - 2, 3) + 1;
}
function ko(e) {
  const t = e - 1;
  return t * t * t + 1;
}
function Ao(e) {
  return Math.pow(e - 1, 3) * (1 - e) + 1;
}
function To(
  e,
  {
    delay: t = 0,
    duration: o = 400,
    easing: n = ko,
    x: r = 0,
    y: i = 0,
    opacity: s = 0,
  } = {}
) {
  const a = getComputedStyle(e),
    l = +a.opacity,
    c = "none" === a.transform ? "" : a.transform,
    u = l * (1 - s),
    [d, h] = y(r),
    [p, g] = y(i);
  return {
    delay: t,
    duration: o,
    easing: n,
    css: (e, t) =>
      `\n\t\t\ttransform: ${c} translate(${(1 - e) * d}${h}, ${
        (1 - e) * p
      }${g});\n\t\t\topacity: ${l - u * t}`,
  };
}
function Oo(
  e,
  { delay: t = 0, duration: o = 400, easing: n = ko, axis: r = "y" } = {}
) {
  const i = getComputedStyle(e),
    s = +i.opacity,
    a = "y" === r ? "height" : "width",
    l = parseFloat(i[a]),
    c = "y" === r ? ["top", "bottom"] : ["left", "right"],
    u = c.map((e) => `${e[0].toUpperCase()}${e.slice(1)}`),
    d = parseFloat(i[`padding${u[0]}`]),
    h = parseFloat(i[`padding${u[1]}`]),
    p = parseFloat(i[`margin${u[0]}`]),
    g = parseFloat(i[`margin${u[1]}`]),
    m = parseFloat(i[`border${u[0]}Width`]),
    f = parseFloat(i[`border${u[1]}Width`]);
  return {
    delay: t,
    duration: o,
    easing: n,
    css: (e) =>
      `overflow: hidden;opacity: ${Math.min(20 * e, 1) * s};${a}: ${
        e * l
      }px;padding-${c[0]}: ${e * d}px;padding-${c[1]}: ${e * h}px;margin-${
        c[0]
      }: ${e * p}px;margin-${c[1]}: ${e * g}px;border-${c[0]}-width: ${
        e * m
      }px;border-${c[1]}-width: ${e * f}px;`,
  };
}
function Po(
  e,
  {
    delay: t = 0,
    duration: o = 400,
    easing: n = ko,
    start: r = 0,
    opacity: i = 0,
  } = {}
) {
  const s = getComputedStyle(e),
    a = +s.opacity,
    l = "none" === s.transform ? "" : s.transform,
    c = 1 - r,
    u = a * (1 - i);
  return {
    delay: t,
    duration: o,
    easing: n,
    css: (e, t) =>
      `\n\t\t\ttransform: ${l} scale(${1 - c * t});\n\t\t\topacity: ${
        a - u * t
      }\n\t\t`,
  };
}
function Mo({ fallback: e, ...o }) {
  function n(n, r, s) {
    return (a, l) => (
      n.set(l.key, a),
      () => {
        if (r.has(l.key)) {
          const e = r.get(l.key);
          return (
            r.delete(l.key),
            (function (e, n, r) {
              const {
                  delay: s = 0,
                  duration: a = (e) => 30 * Math.sqrt(e),
                  easing: l = ko,
                } = t(t({}, o), r),
                c = e.getBoundingClientRect(),
                u = n.getBoundingClientRect(),
                d = c.left - u.left,
                h = c.top - u.top,
                p = c.width / u.width,
                g = c.height / u.height,
                m = Math.sqrt(d * d + h * h),
                f = getComputedStyle(n),
                w = "none" === f.transform ? "" : f.transform,
                b = +f.opacity;
              return {
                delay: s,
                duration: i(a) ? a(m) : a,
                easing: l,
                css: (e, t) =>
                  `\n\t\t\t\topacity: ${
                    e * b
                  };\n\t\t\t\ttransform-origin: top left;\n\t\t\t\ttransform: ${w} translate(${
                    t * d
                  }px,${t * h}px) scale(${e + (1 - e) * p}, ${
                    e + (1 - e) * g
                  });\n\t\t\t`,
              };
            })(e, a, l)
          );
        }
        return n.delete(l.key), e && e(a, l, s);
      }
    );
  }
  const r = new Map(),
    s = new Map();
  return [n(s, r, !1), n(r, s, !0)];
}
function Lo(e) {
  let t, o, n, r;
  return (
    (o = new uc({
      props: { warning: e[1], $$slots: { default: [Eo] }, $$scope: { ctx: e } },
    })),
    {
      c() {
        (t = P("div")), Ue(o.$$.fragment), B(t, "class", "error svelte-u99fnt");
      },
      m(e, n) {
        A(e, t, n), Be(o, t, null), (r = !0);
      },
      p(e, t) {
        const n = {};
        2 & t && (n.warning = e[1]),
          5 & t && (n.$$scope = { dirty: t, ctx: e }),
          o.$set(n);
      },
      i(e) {
        r ||
          ($e(o.$$.fragment, e),
          pe(() => {
            r && (n || (n = ke(t, Oo, { duration: 250 }, !0)), n.run(1));
          }),
          (r = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e),
          n || (n = ke(t, Oo, { duration: 250 }, !1)),
          n.run(0),
          (r = !1);
      },
      d(e) {
        e && T(t), Ve(o), e && n && n.end();
      },
    }
  );
}
function Eo(e) {
  let t;
  return {
    c() {
      t = L(e[0]);
    },
    m(e, o) {
      A(e, t, o);
    },
    p(e, o) {
      1 & o && R(t, e[0]);
    },
    d(e) {
      e && T(t);
    },
  };
}
function Do(e) {
  let t,
    o,
    n = e[0] && Lo(e);
  return {
    c() {
      n && n.c(), (t = D());
    },
    m(e, r) {
      n && n.m(e, r), A(e, t, r), (o = !0);
    },
    p(e, [o]) {
      e[0]
        ? n
          ? (n.p(e, o), 1 & o && $e(n, 1))
          : ((n = Lo(e)), n.c(), $e(n, 1), n.m(t.parentNode, t))
        : n &&
          (ve(),
          Ce(n, 1, 1, () => {
            n = null;
          }),
          ye());
    },
    i(e) {
      o || ($e(n), (o = !0));
    },
    o(e) {
      Ce(n), (o = !1);
    },
    d(e) {
      e && T(t), n && n.d(e);
    },
  };
}
function _o(e, t, o) {
  let { message: n = "" } = t,
    { warning: r = !1 } = t;
  return (
    (e.$$set = (e) => {
      "message" in e && o(0, (n = e.message)),
        "warning" in e && o(1, (r = e.warning));
    }),
    [n, r]
  );
}
function Uo(e) {
  let t, o, n;
  const r = e[6].default,
    i = c(r, e, e[5], null);
  return {
    c() {
      (t = P("div")),
        i && i.c(),
        B(t, "class", "layout svelte-1bpvxjz"),
        B(
          t,
          "style",
          (o =
            "gap: calc(var(--indent) * " +
            e[2] +
            "); grid-template-columns: repeat(" +
            (e[0] ? 1 : e[1]) +
            ", auto); margin-bottom: calc(var(--indent) * " +
            e[3] +
            "); " +
            e[4] +
            ";")
        );
    },
    m(e, o) {
      A(e, t, o), i && i.m(t, null), (n = !0);
    },
    p(e, [s]) {
      i &&
        i.p &&
        (!n || 32 & s) &&
        h(i, r, e, e[5], n ? d(r, e[5], s, null) : p(e[5]), null),
        (!n ||
          (31 & s &&
            o !==
              (o =
                "gap: calc(var(--indent) * " +
                e[2] +
                "); grid-template-columns: repeat(" +
                (e[0] ? 1 : e[1]) +
                ", auto); margin-bottom: calc(var(--indent) * " +
                e[3] +
                "); " +
                e[4] +
                ";"))) &&
          B(t, "style", o);
    },
    i(e) {
      n || ($e(i, e), (n = !0));
    },
    o(e) {
      Ce(i, e), (n = !1);
    },
    d(e) {
      e && T(t), i && i.d(e);
    },
  };
}
function Bo(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { mobile: i = window.innerWidth < 500 || window.innerHeight < 500 } = t,
    { cols: s = 1 } = t,
    { gap: a = 1.5 } = t,
    { marginBottom: l = 0 } = t,
    { style: c = "" } = t;
  return (
    (e.$$set = (e) => {
      "mobile" in e && o(0, (i = e.mobile)),
        "cols" in e && o(1, (s = e.cols)),
        "gap" in e && o(2, (a = e.gap)),
        "marginBottom" in e && o(3, (l = e.marginBottom)),
        "style" in e && o(4, (c = e.style)),
        "$$scope" in e && o(5, (r = e.$$scope));
    }),
    [i, s, a, l, c, r, n]
  );
}
function Vo(e) {
  let t, o, n;
  return (
    (o = new ic({ props: { name: e[3] } })),
    {
      c() {
        (t = P("div")), Ue(o.$$.fragment), B(t, "class", "icon svelte-jbwzmd");
      },
      m(e, r) {
        A(e, t, r), Be(o, t, null), (n = !0);
      },
      p(e, t) {
        const n = {};
        8 & t && (n.name = e[3]), o.$set(n);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        e && T(t), Ve(o);
      },
    }
  );
}
function jo(e) {
  let t, o, n, r, i;
  const s = e[8].icon,
    a = c(s, e, e[7], gc),
    l =
      a ||
      (function (e) {
        let t,
          o,
          n = e[3] && Vo(e);
        return {
          c() {
            n && n.c(), (t = D());
          },
          m(e, r) {
            n && n.m(e, r), A(e, t, r), (o = !0);
          },
          p(e, o) {
            e[3]
              ? n
                ? (n.p(e, o), 8 & o && $e(n, 1))
                : ((n = Vo(e)), n.c(), $e(n, 1), n.m(t.parentNode, t))
              : n &&
                (ve(),
                Ce(n, 1, 1, () => {
                  n = null;
                }),
                ye());
          },
          i(e) {
            o || ($e(n), (o = !0));
          },
          o(e) {
            Ce(n), (o = !1);
          },
          d(e) {
            e && T(t), n && n.d(e);
          },
        };
      })(e),
    u = e[8].default,
    g = c(u, e, e[7], null);
  return {
    c() {
      (t = P("button")),
        l && l.c(),
        (o = E()),
        g && g.c(),
        B(t, "style", e[6]),
        B(t, "title", e[2]),
        (t.disabled = e[0]),
        B(t, "type", e[4]),
        B(t, "class", "button svelte-jbwzmd"),
        Z(t, "active", e[1]),
        Z(t, "red", e[5]);
    },
    m(s, a) {
      A(s, t, a),
        l && l.m(t, null),
        x(t, o),
        g && g.m(t, null),
        (n = !0),
        r || ((i = _(t, "click", e[9])), (r = !0));
    },
    p(e, [o]) {
      a
        ? a.p &&
          (!n || 128 & o) &&
          h(a, s, e, e[7], n ? d(s, e[7], o, pc) : p(e[7]), gc)
        : l && l.p && (!n || 8 & o) && l.p(e, n ? o : -1),
        g &&
          g.p &&
          (!n || 128 & o) &&
          h(g, u, e, e[7], n ? d(u, e[7], o, null) : p(e[7]), null),
        (!n || 64 & o) && B(t, "style", e[6]),
        (!n || 4 & o) && B(t, "title", e[2]),
        (!n || 1 & o) && (t.disabled = e[0]),
        (!n || 16 & o) && B(t, "type", e[4]),
        (!n || 2 & o) && Z(t, "active", e[1]),
        (!n || 32 & o) && Z(t, "red", e[5]);
    },
    i(e) {
      n || ($e(l, e), $e(g, e), (n = !0));
    },
    o(e) {
      Ce(l, e), Ce(g, e), (n = !1);
    },
    d(e) {
      e && T(t), l && l.d(e), g && g.d(e), (r = !1), i();
    },
  };
}
function zo(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { disabled: i = !1 } = t,
    { active: s = !1 } = t,
    { title: a = "" } = t,
    { icon: l = null } = t,
    { type: c = "button" } = t,
    { red: u = !1 } = t,
    { style: d = "" } = t;
  return (
    (e.$$set = (e) => {
      "disabled" in e && o(0, (i = e.disabled)),
        "active" in e && o(1, (s = e.active)),
        "title" in e && o(2, (a = e.title)),
        "icon" in e && o(3, (l = e.icon)),
        "type" in e && o(4, (c = e.type)),
        "red" in e && o(5, (u = e.red)),
        "style" in e && o(6, (d = e.style)),
        "$$scope" in e && o(7, (r = e.$$scope));
    }),
    [
      i,
      s,
      a,
      l,
      c,
      u,
      d,
      r,
      n,
      function (t) {
        ue.call(this, e, t);
      },
    ]
  );
}
function Io(e) {
  let t, o, n, r;
  const i = e[36].close,
    s = c(i, e, e[43], yc);
  return {
    c() {
      (t = P("button")),
        s && s.c(),
        B(t, "class", "close svelte-1eljjld"),
        B(t, "title", "Close");
    },
    m(i, a) {
      A(i, t, a),
        s && s.m(t, null),
        (o = !0),
        n || ((r = _(t, "click", e[27])), (n = !0));
    },
    p(e, t) {
      s &&
        s.p &&
        (!o || 4096 & t[1]) &&
        h(s, i, e, e[43], o ? d(i, e[43], t, vc) : p(e[43]), yc);
    },
    i(e) {
      o || ($e(s, e), (o = !0));
    },
    o(e) {
      Ce(s, e), (o = !1);
    },
    d(e) {
      e && T(t), s && s.d(e), (n = !1), r();
    },
  };
}
function Ho(t) {
  let o, n, i;
  return {
    c() {
      (o = P("button")),
        (o.innerHTML =
          '<svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-1eljjld"><path d="M0.851638 7.35359L7.35164 0.853591L6.64453 0.146484L0.144531 6.64648L0.851638 7.35359Z" fill="#534C49"></path><path d="M4.35164 7.35359L7.35164 4.35359L6.64453 3.64648L3.64453 6.64648L4.35164 7.35359Z" fill="#534C49"></path></svg>'),
        B(o, "class", "resize svelte-1eljjld"),
        B(o, "type", "button");
    },
    m(e, r) {
      A(e, o, r),
        n ||
          ((i = [_(o, "pointerdown", t[28]), _(o, "dblclick", t[31])]),
          (n = !0));
    },
    p: e,
    d(e) {
      e && T(o), (n = !1), r(i);
    },
  };
}
function No(e) {
  let t,
    o,
    n,
    s,
    a,
    l,
    u,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $,
    C,
    S,
    k = `calc(100% - ${e[17]}px)`;
  const O = e[36].title,
    M = c(O, e, e[43], Cc),
    D =
      M ||
      (function (e) {
        let t;
        return {
          c() {
            t = L(e[1]);
          },
          m(e, o) {
            A(e, t, o);
          },
          p(e, o) {
            2 & o[0] && R(t, e[1]);
          },
          d(e) {
            e && T(t);
          },
        };
      })(e);
  let U = !e[6] && e[32].close && Io(e);
  const V = e[36].default,
    j = c(V, e, e[43], bc);
  let z = e[3] && !e[0] && Ho(e);
  return {
    c() {
      (t = P("div")),
        (o = P("div")),
        (n = E()),
        (s = P("div")),
        (a = P("div")),
        (l = P("div")),
        (u = P("div")),
        D && D.c(),
        (g = E()),
        U && U.c(),
        (f = E()),
        (w = P("div")),
        j && j.c(),
        (b = E()),
        z && z.c(),
        B(o, "class", "layout svelte-1eljjld"),
        B(o, "role", "presentation"),
        B(u, "role", "dialog"),
        B(u, "class", "header-content svelte-1eljjld"),
        Z(u, "draggable", e[2]),
        B(l, "class", "header svelte-1eljjld"),
        pe(() => e[39].call(l)),
        B(w, "class", "body svelte-1eljjld"),
        W(w, "height", k),
        B(a, "class", "content svelte-1eljjld"),
        W(a, "width", qo(e[19])),
        W(a, "height", e[0] ? "100%" : qo(e[20])),
        B(s, "class", "window svelte-1eljjld"),
        W(s, "left", e[9] + "px"),
        W(s, "top", e[10] + "px"),
        pe(() => e[42].call(s)),
        Z(s, "draggable", !e[0] && e[2]),
        Z(s, "move", !e[0] && e[2] && e[11]),
        Z(s, "moved", !e[0] && e[2] && !e[11] && e[12]),
        B(t, "class", "popup svelte-1eljjld"),
        Z(t, "hasClose", !e[6]);
    },
    m(r, c) {
      A(r, t, c),
        x(t, o),
        x(t, n),
        x(t, s),
        x(s, a),
        x(a, l),
        x(l, u),
        D && D.m(u, null),
        x(l, g),
        U && U.m(l, null),
        (m = G(l, e[39].bind(l))),
        x(a, f),
        x(a, w),
        j && j.m(w, null),
        x(a, b),
        z && z.m(a, null),
        e[40](a),
        e[41](s),
        (v = G(s, e[42].bind(s))),
        ($ = !0),
        C ||
          ((S = [
            _(o, "click", function () {
              i(e[4] ? e[21] : void 0) &&
                (e[4] ? e[21] : void 0).apply(this, arguments);
            }),
            _(u, "pointerdown", function () {
              i(e[2] ? e[23] : void 0) &&
                (e[2] ? e[23] : void 0).apply(this, arguments);
            }),
            _(u, "pointerup", function () {
              i(e[2] ? e[24] : void 0) &&
                (e[2] ? e[24] : void 0).apply(this, arguments);
            }),
            _(u, "contextmenu", function () {
              i(e[2] ? e[24] : void 0) &&
                (e[2] ? e[24] : void 0).apply(this, arguments);
            }),
            _(u, "pointercancel", function () {
              i(e[2] ? e[24] : void 0) &&
                (e[2] ? e[24] : void 0).apply(this, arguments);
            }),
            _(u, "dblclick", e[30]),
            _(s, "scroll", e[37]),
          ]),
          (C = !0));
    },
    p(o, n) {
      (e = o),
        M
          ? M.p &&
            (!$ || 4096 & n[1]) &&
            h(M, O, e, e[43], $ ? d(O, e[43], n, $c) : p(e[43]), Cc)
          : D && D.p && (!$ || 2 & n[0]) && D.p(e, $ ? n : [-1, -1]),
        (!$ || 4 & n[0]) && Z(u, "draggable", e[2]),
        !e[6] && e[32].close
          ? U
            ? (U.p(e, n), (64 & n[0]) | (2 & n[1]) && $e(U, 1))
            : ((U = Io(e)), U.c(), $e(U, 1), U.m(l, null))
          : U &&
            (ve(),
            Ce(U, 1, 1, () => {
              U = null;
            }),
            ye()),
        j &&
          j.p &&
          (!$ || (147456 & n[0]) | (4096 & n[1])) &&
          h(j, V, e, e[43], $ ? d(V, e[43], n, wc) : p(e[43]), bc),
        131072 & n[0] &&
          k !== (k = `calc(100% - ${e[17]}px)`) &&
          W(w, "height", k),
        e[3] && !e[0]
          ? z
            ? z.p(e, n)
            : ((z = Ho(e)), z.c(), z.m(a, null))
          : z && (z.d(1), (z = null)),
        524288 & n[0] && W(a, "width", qo(e[19])),
        1048577 & n[0] && W(a, "height", e[0] ? "100%" : qo(e[20])),
        (!$ || 512 & n[0]) && W(s, "left", e[9] + "px"),
        (!$ || 1024 & n[0]) && W(s, "top", e[10] + "px"),
        (!$ || 5 & n[0]) && Z(s, "draggable", !e[0] && e[2]),
        (!$ || 2053 & n[0]) && Z(s, "move", !e[0] && e[2] && e[11]),
        (!$ || 6149 & n[0]) && Z(s, "moved", !e[0] && e[2] && !e[11] && e[12]),
        (!$ || 64 & n[0]) && Z(t, "hasClose", !e[6]);
    },
    i(o) {
      $ ||
        ($e(D, o),
        $e(U),
        $e(j, o),
        y ||
          pe(() => {
            (y = xe(t, To, {
              y: e[0] ? 120 : 0,
              duration: e[0] ? 300 : 0,
              easing: So,
            })),
              y.start();
          }),
        ($ = !0));
    },
    o(e) {
      Ce(D, e), Ce(U), Ce(j, e), ($ = !1);
    },
    d(o) {
      o && T(t),
        D && D.d(o),
        U && U.d(),
        m(),
        j && j.d(o),
        z && z.d(),
        e[40](null),
        e[41](null),
        v(),
        (C = !1),
        r(S);
    },
  };
}
function Ro(e) {
  let t, o, n, s;
  return (
    pe(e[38]),
    (t = new nc({
      props: {
        parent: document.body,
        $$slots: { default: [No] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(r, a) {
        Be(t, r, a),
          (o = !0),
          n ||
            ((s = [
              _(fc, "keydown", function () {
                i(e[5] ? e[22] : void 0) &&
                  (e[5] ? e[22] : void 0).apply(this, arguments);
              }),
              _(fc, "resize", e[26]),
              _(fc, "pointermove", function () {
                i(e[11] || e[18] ? e[25] : void 0) &&
                  (e[11] || e[18] ? e[25] : void 0).apply(this, arguments);
              }),
              _(fc, "pointerup", function () {
                i(e[18] ? e[29] : void 0) &&
                  (e[18] ? e[29] : void 0).apply(this, arguments);
              }),
              _(fc, "resize", e[38]),
            ]),
            (n = !0));
      },
      p(o, n) {
        e = o;
        const r = {};
        (1826783 & n[0]) | (4098 & n[1]) && (r.$$scope = { dirty: n, ctx: e }),
          t.$set(r);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e), (n = !1), r(s);
      },
    }
  );
}
function qo(e) {
  return "string" == typeof e
    ? e
    : "number" == typeof e
    ? `${e}px`
    : "object" == typeof e
    ? `${e.min}px`
    : "";
}
function Fo(e, t, o) {
  function n(e, t) {
    e < 0
      ? o(9, (L = 0))
      : e >
          window.innerWidth - ((null == v ? void 0 : v.clientWidth) ?? 0) - 0 &&
        o(
          9,
          (L =
            window.innerWidth - ((null == v ? void 0 : v.clientWidth) ?? 0) - 0)
        ),
      t < 0
        ? o(10, (E = 0))
        : t >
            window.innerHeight -
              ((null == v ? void 0 : v.clientHeight) ?? 0) -
              0 &&
          o(
            10,
            (E =
              window.innerHeight -
              ((null == v ? void 0 : v.clientHeight) ?? 0) -
              0)
          );
  }
  function r() {
    o(9, (L = window.innerWidth / 2 - v.clientWidth / 2)),
      o(10, (E = window.innerHeight / 2 - v.clientHeight / 2));
  }
  let { $$slots: i = {}, $$scope: s } = t;
  const a = f(i);
  let { mobile: l } = t,
    { title: c = "" } = t,
    { draggable: u = !1 } = t,
    { resizable: d = !1 } = t,
    { closeOnOverlayClick: h = !0 } = t,
    { closeOnEsc: p = !0 } = t,
    { hideCloseButton: g = !1 } = t,
    { width: m = "auto" } = t,
    { height: w = "auto" } = t;
  const b = ae();
  let v,
    y,
    $,
    C,
    x,
    S,
    k,
    A,
    T,
    O,
    P = 0,
    M = 0,
    L = 0,
    E = 0,
    D = !1,
    _ = !1,
    U = !1,
    B = m,
    V = w;
  const j = Ge() ? 50 : 100;
  return (
    ie(() => {
      r();
    }),
    (e.$$set = (e) => {
      "mobile" in e && o(0, (l = e.mobile)),
        "title" in e && o(1, (c = e.title)),
        "draggable" in e && o(2, (u = e.draggable)),
        "resizable" in e && o(3, (d = e.resizable)),
        "closeOnOverlayClick" in e && o(4, (h = e.closeOnOverlayClick)),
        "closeOnEsc" in e && o(5, (p = e.closeOnEsc)),
        "hideCloseButton" in e && o(6, (g = e.hideCloseButton)),
        "width" in e && o(33, (m = e.width)),
        "height" in e && o(34, (w = e.height)),
        "$$scope" in e && o(43, (s = e.$$scope));
    }),
    (e.$$.update = () => {
      var t, r;
      8192 & e.$$.dirty[0] && (T = k - j),
        16384 & e.$$.dirty[0] && (O = A - j),
        7680 & e.$$.dirty[0] && !D && _ && n(L, E),
        384 & e.$$.dirty[0] &&
          ((r = $),
          (t = y) + E > A && o(10, (E = A - t)),
          r + L > k && o(9, (L = k - r)));
    }),
    [
      l,
      c,
      u,
      d,
      h,
      p,
      g,
      y,
      $,
      L,
      E,
      D,
      _,
      k,
      A,
      v,
      C,
      x,
      U,
      B,
      V,
      function () {
        b("close");
      },
      function (e) {
        "Escape" === e.code && b("close");
      },
      function (e) {
        if (!e.isPrimary) return;
        o(11, (D = !0));
        const { top: t, left: n } = v.getBoundingClientRect(),
          { clientX: r, clientY: i } = e;
        (P = r - n), (M = i - t), o(9, (L = r - P)), o(10, (E = i - M));
      },
      function () {
        o(11, (D = !1)), o(12, (_ = !0));
      },
      function (e) {
        let { clientX: t, clientY: n } = e;
        if (
          (t < 0 && (t = 0),
          t > k && (t = k),
          n < 0 && (n = 0),
          n > A && (n = A),
          D && (o(9, (L = t - P)), o(10, (E = n - M))),
          U)
        ) {
          const e = S.x - t,
            r = S.y - n,
            i = S.width - e,
            s = S.height - r;
          "string" == typeof m && o(19, (B = i > 375 ? i : 375)),
            "number" == typeof m && o(19, (B = i > m ? i : m)),
            "object" == typeof m &&
              (i < m.min
                ? o(19, (B = m.min))
                : i > m.max
                ? o(19, (B = m.max))
                : o(19, (B = i))),
            "string" == typeof w && o(20, (V = s > 150 ? s : 150)),
            "number" == typeof w && o(20, (V = s > w ? s : w)),
            "object" == typeof w &&
              (s < w.min
                ? o(20, (V = w.min))
                : s > w.max
                ? o(20, (V = w.max))
                : o(20, (V = s))),
            "number" == typeof B && B > T && o(19, (B = T)),
            "number" == typeof V && V > O && o(20, (V = O));
        }
      },
      function () {
        n(L, E),
          "number" == typeof B && B > T && o(19, (B = T)),
          "number" == typeof V && V > O && o(20, (V = O));
      },
      function () {
        b("close");
      },
      function (e) {
        o(18, (U = !0)),
          (S = {
            x: e.clientX,
            y: e.clientY,
            width: C.clientWidth,
            height: C.clientHeight,
          });
      },
      function () {
        o(18, (U = !1)), b("resize", [C.clientWidth, C.clientHeight]);
      },
      r,
      async function () {
        o(19, (B = m)), o(20, (V = w)), await he(), r();
      },
      a,
      m,
      w,
      n,
      i,
      function (t) {
        ue.call(this, e, t);
      },
      function () {
        o(13, (k = fc.innerWidth)), o(14, (A = fc.innerHeight));
      },
      function () {
        (x = this.clientHeight), o(17, x);
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (C = e), o(16, C);
        });
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (v = e), o(15, v);
        });
      },
      function () {
        (y = this.clientHeight), ($ = this.clientWidth), o(7, y), o(8, $);
      },
      s,
    ]
  );
}
function Wo() {
  try {
    let e = localStorage.getItem("u");
    return (
      e ||
        ((e = String(Math.round(1e6 * Math.random()))),
        localStorage.setItem("u", e)),
      e
    );
  } catch (e) {
    return "";
  }
}
async function Ko() {
  const { navigator: e } = window,
    t = e.language || "",
    o = window.screen,
    n = [
      e.platform,
      window.devicePixelRatio,
      t,
      o ? `${Math.max(o.width, o.height)}x${Math.min(o.width, o.height)}` : "",
      Wo(),
    ].join(";"),
    r = new TextEncoder().encode(n);
  Tc = (await crypto.subtle.digest("SHA-1", r)).slice(0, 16);
}
function Go() {
  return Tc;
}
function Zo(e, t) {
  return `incorrect type ${e}, expected ${t}`;
}
function Yo(e, t = "", o = 0) {
  if (!e) return;
  const n = new DataView(e);
  for (let r = 0, i = t.length; r < i; r++)
    n.setInt8(o, t.charCodeAt(r)), (o += 1);
}
function Jo(e, t = 0, o = 0) {
  const n = new Uint8Array(e.slice(t, t + o));
  return String.fromCharCode(...n);
}
function Qo(e) {
  let t = 0;
  return (
    e.forEach((e) => {
      var o, n;
      switch (e.propType) {
        case 1:
        case 4:
          t += 1;
          break;
        case 2:
        case 5:
          t += 2;
          break;
        case 3:
        case 6:
        case 7:
          t += 4;
          break;
        case 8:
        case 9:
        case 17:
        case 18:
          t += 8;
          break;
        case 10:
          e.propLength
            ? (t += e.propLength)
            : "string" == typeof e.propValue && (t += e.propValue.length);
          break;
        case 11:
          if (e.propLength) t += e.propLength;
          else {
            if ("string" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "string");
              throw new Error(t);
            }
            t += 2 * e.propValue.length;
          }
          break;
        case 12:
          if (e.propLength) t += e.propLength;
          else {
            if (
              (null == (o = e.propValue) ? void 0 : o.constructor) !==
              ArrayBuffer
            ) {
              const t = Zo(typeof e.propValue, "ArrayBuffer");
              throw new Error(t);
            }
            t +=
              e.propLength ||
              (null == (n = e.propValue) ? void 0 : n.byteLength) ||
              0;
          }
      }
    }),
    t
  );
}
function Xo(e) {
  return Ec.has(e);
}
function en(e) {
  const t = new DataView(e);
  return {
    resCommand: t.getUint16(2, !0),
    resCode: t.getUint8(4),
    resBody: e.slice(5),
  };
}
async function tn(e, t, o) {
  let n;
  try {
    const r = new URLSearchParams();
    r.append("trade_server", t),
      r.append("version", String(5)),
      o && r.append("login", String(o)),
      (n = await fetch(e, {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        body: r,
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      }));
  } catch (i) {
    throw new sc({ code: 100, command: -1, count: -1 });
  }
  if (200 !== n.status) {
    if (503 === n.status) throw new sc({ code: 503, command: -1, count: -1 });
    throw new sc({ code: 1e3, command: -1, count: -1 });
  }
  const r = await n.json();
  return {
    company: r.company,
    enabled: r.enabled,
    key: r.key,
    login: r.login,
    signal_server: r.signal_server,
    trade_server: r.trade_server,
    version: r.version,
    token: r.token,
  };
}
function on(e, t) {
  if (!e.enabled) throw new sc({ code: 101, command: -1, count: t });
  return new Dc(
    {
      signal_server: (o = { ...e }).signal_server,
      token: o.token,
      apiKey: o.key,
    },
    t
  );
  var o;
}
function nn(e, t) {
  const o = [e.firstName || "", e.secondName || ""].join(" "),
    n = new URLSearchParams(window.self.location.search),
    r = n.get("utm_campaign") ?? "",
    i = n.get("utm_source") ?? "";
  return Oc.serialize([
    { propType: 11, propValue: o.substring(0, 128), propLength: 256 },
    { propType: 11, propValue: t.name.substring(0, 64), propLength: 128 },
    {
      propType: 11,
      propValue: (e.phonePassword || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (e.country || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (e.city || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (e.state || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (e.zipcode || "").substring(0, 16),
      propLength: 32,
    },
    {
      propType: 11,
      propValue: (e.address || "").substring(0, 128),
      propLength: 256,
    },
    {
      propType: 11,
      propValue: (e.phone || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (e.email || "").substring(0, 64),
      propLength: 128,
    },
    { propType: 8, propValue: e.deposit || 1e5 },
    { propType: 6, propValue: e.leverage || 100 },
    { propType: 6, propValue: 0 },
    { propType: 6, propValue: 1 },
    {
      propType: 11,
      propValue: (e.domain || "").substring(0, 64),
      propLength: 128,
    },
    { propType: 11, propValue: r.substring(0, 32), propLength: 64 },
    { propType: 11, propValue: i.substring(0, 32), propLength: 64 },
    { propType: 6, propValue: e.emailConfirmCode || 0 },
    { propType: 6, propValue: e.phoneConfirmCode || 0 },
    {
      propType: 11,
      propValue: (e.firstName || "").substring(0, 64),
      propLength: 128,
    },
    {
      propType: 11,
      propValue: (e.secondName || "").substring(0, 64),
      propLength: 128,
    },
    { propType: 6, propValue: e.agreements || 0 },
  ]);
}
function rn(e) {
  return Oc.serialize([
    { propType: 6, propValue: e.version || 0 },
    {
      propType: 11,
      propValue: (e.password || "").substring(0, 32),
      propLength: 64,
    },
    {
      propType: 11,
      propValue: (e.otp || "").substring(0, 64),
      propLength: 128,
    },
    { propType: 12, propValue: e.cid || Go(), propLength: 16 },
    { propType: 11, propValue: "", propLength: 64 },
    { propType: 11, propValue: "", propLength: 64 },
    { propType: 18, propValue: BigInt(0) },
    { propType: 11, propValue: "", propLength: 128 },
    { propType: 6, propValue: 0 },
    { propType: 11, propValue: "", propLength: 256 },
    { propType: 18, propValue: BigInt(0) },
  ]);
}
function sn(e) {
  const t = Oc.parse(e, Uc);
  return [t[0], t[1].toString(), t[2], t[3]];
}
function an(e) {
  return Oc.parse(e, Bc);
}
function ln(e, t) {
  const o = new Date(e);
  if (0 !== o.getUTCMilliseconds() || 0 !== o.getUTCSeconds()) return !1;
  switch (t) {
    case 1:
      return !0;
    case 5:
      return o.getUTCMinutes() % 5 == 0;
    case 15:
      return o.getUTCMinutes() % 15 == 0;
    case 30:
      return o.getUTCMinutes() % 30 == 0;
  }
  if (t >= 60) {
    if (0 !== o.getUTCMinutes()) return !1;
    switch (t) {
      case 60:
        return !0;
      case 240:
        return o.getUTCHours() % 4 == 0;
    }
  }
  return !(
    (t >= 1440 && 0 !== o.getUTCHours()) ||
    (t >= 43200 && 1 !== o.getUTCDate())
  );
}
function cn(e, t) {
  const o = new Date(e);
  switch (
    (o.setUTCMilliseconds(0),
    o.setUTCSeconds(0),
    t && t >= 60 && o.setUTCMinutes(0),
    t && t >= 1440 && o.setUTCHours(0),
    t && t >= 43200 && o.setUTCDate(1),
    t)
  ) {
    case 5:
      o.setUTCMinutes(5 * Math.floor(o.getUTCMinutes() / 5));
      break;
    case 15:
      o.setUTCMinutes(15 * Math.floor(o.getUTCMinutes() / 15));
      break;
    case 30:
      o.setUTCMinutes(30 * Math.floor(o.getUTCMinutes() / 30));
      break;
    case 240:
      o.setUTCHours(4 * Math.floor(o.getUTCHours() / 4));
      break;
    case 10080:
      for (; 0 !== o.getUTCDay(); ) o.setUTCDate(o.getUTCDate() - 1);
  }
  return o.getTime();
}
function un(e, t, o) {
  if (e === t) return 0;
  const n = (e > t ? e : t) - (e < t ? e : t);
  return Math.round(n / (60 * o * 1e3));
}
function dn(e, t, o) {
  if (-1 === "YMDhm".indexOf(o)) return 0;
  if (e === t) return 0;
  const n = e < t ? e : t,
    r = e > t ? e : t;
  switch (o) {
    case "Y":
      return un(n, r, 518400);
    case "M":
      return un(n, r, 43200);
    case "D":
      return un(n, r, 1440);
    case "h":
      return un(n, r, 60);
    case "m":
      return un(n, r, 1);
    default:
      return 0;
  }
}
function hn(e, t = 1, o = 0) {
  const n = new Date(e);
  return pn(n, t, o), n.getTime();
}
function pn(e, t = 1, o = 1) {
  switch (t) {
    case 1:
      e.setUTCMinutes(e.getUTCMinutes() + 1 * o);
      break;
    case 5:
      e.setUTCMinutes(e.getUTCMinutes() + 5 * o);
      break;
    case 15:
      e.setUTCMinutes(e.getUTCMinutes() + 15 * o);
      break;
    case 30:
      e.setUTCMinutes(e.getUTCMinutes() + 30 * o);
      break;
    case 60:
      e.setUTCHours(e.getUTCHours() + 1 * o);
      break;
    case 240:
      e.setUTCHours(e.getUTCHours() + 4 * o);
      break;
    case 1440:
      e.setUTCDate(e.getUTCDate() + 1 * o);
      break;
    case 10080:
      e.setUTCDate(e.getUTCDate() + 7 * o);
      break;
    case 43200:
      e.setUTCMonth(e.getUTCMonth() + 1 * o);
  }
}
function gn(t) {
  let o,
    n,
    r,
    i,
    s,
    a =
      _l.broker.name &&
      (function (t) {
        let o, n, r;
        return {
          c() {
            (o = P("div")),
              (o.textContent = `${window.tr(
                window.lang.login.brokerInformation.company
              )}`),
              (n = E()),
              (r = P("div")),
              (r.textContent = `${_l.broker.name}`),
              B(o, "class", "secondary svelte-afvpdv");
          },
          m(e, t) {
            A(e, o, t), A(e, n, t), A(e, r, t);
          },
          p: e,
          d(e) {
            e && (T(o), T(n), T(r));
          },
        };
      })(),
    l =
      _l.broker.address &&
      (function (t) {
        let o, n, r;
        return {
          c() {
            (o = P("div")),
              (o.textContent = `${window.tr(
                window.lang.login.brokerInformation.registrationAddress
              )}`),
              (n = E()),
              (r = P("div")),
              (r.textContent = `${_l.broker.address}`),
              B(o, "class", "secondary svelte-afvpdv");
          },
          m(e, t) {
            A(e, o, t), A(e, n, t), A(e, r, t);
          },
          p: e,
          d(e) {
            e && (T(o), T(n), T(r));
          },
        };
      })(),
    c =
      _l.broker.url &&
      (function (t) {
        let o, n, r;
        return {
          c() {
            (o = P("div")),
              (o.textContent = `${window.tr(
                window.lang.login.brokerInformation.website
              )}`),
              (n = E()),
              (r = P("a")),
              (r.textContent = `${$o(_l.broker.url)}`),
              B(o, "class", "secondary svelte-afvpdv"),
              B(r, "href", _l.broker.url),
              B(r, "target", "_blank"),
              B(r, "rel", "noreferrer"),
              B(r, "class", "svelte-afvpdv");
          },
          m(e, t) {
            A(e, o, t), A(e, n, t), A(e, r, t);
          },
          p: e,
          d(e) {
            e && (T(o), T(n), T(r));
          },
        };
      })(),
    u =
      _l.broker.email &&
      (function (t) {
        let o, n, r;
        return {
          c() {
            (o = P("div")),
              (o.textContent = `${window.tr(
                window.lang.login.brokerInformation.email
              )}`),
              (n = E()),
              (r = P("a")),
              (r.textContent = `${_l.broker.email}`),
              B(o, "class", "secondary svelte-afvpdv"),
              B(r, "href", "mailto:" + _l.broker.email),
              B(r, "class", "svelte-afvpdv");
          },
          m(e, t) {
            A(e, o, t), A(e, n, t), A(e, r, t);
          },
          p: e,
          d(e) {
            e && (T(o), T(n), T(r));
          },
        };
      })(),
    d =
      _l.broker.phone &&
      (function (t) {
        let o, n, r;
        return {
          c() {
            (o = P("div")),
              (o.textContent = `${window.tr(
                window.lang.login.brokerInformation.phone
              )}`),
              (n = E()),
              (r = P("a")),
              (r.textContent = `${_l.broker.phone}`),
              B(o, "class", "secondary svelte-afvpdv"),
              B(r, "href", "tel:" + _l.broker.phone),
              B(r, "class", "svelte-afvpdv");
          },
          m(e, t) {
            A(e, o, t), A(e, n, t), A(e, r, t);
          },
          p: e,
          d(e) {
            e && (T(o), T(n), T(r));
          },
        };
      })();
  return {
    c() {
      (o = P("div")),
        a && a.c(),
        (n = E()),
        l && l.c(),
        (r = E()),
        c && c.c(),
        (i = E()),
        u && u.c(),
        (s = E()),
        d && d.c(),
        B(o, "class", "content svelte-afvpdv");
    },
    m(e, t) {
      A(e, o, t),
        a && a.m(o, null),
        x(o, n),
        l && l.m(o, null),
        x(o, r),
        c && c.m(o, null),
        x(o, i),
        u && u.m(o, null),
        x(o, s),
        d && d.m(o, null);
    },
    p(e, [t]) {
      _l.broker.name && a.p(e, t),
        _l.broker.address && l.p(e, t),
        _l.broker.url && c.p(e, t),
        _l.broker.email && u.p(e, t),
        _l.broker.phone && d.p(e, t);
    },
    i: e,
    o: e,
    d(e) {
      e && T(o), a && a.d(), l && l.d(), c && c.d(), u && u.d(), d && d.d();
    },
  };
}
function mn(e) {
  return [];
}
function fn(t, o = e) {
  function n(e) {
    if (s(t, e) && ((t = e), i)) {
      const e = !jc.length;
      for (const o of a) o[1](), jc.push(o, t);
      if (e) {
        for (let e = 0; e < jc.length; e += 2) jc[e][0](jc[e + 1]);
        jc.length = 0;
      }
    }
  }
  function r(e) {
    n(e(t));
  }
  let i;
  const a = new Set();
  return {
    set: n,
    update: r,
    subscribe: function (s, l = e) {
      const c = [s, l];
      return (
        a.add(c),
        1 === a.size && (i = o(n, r) || e),
        s(t),
        () => {
          a.delete(c), 0 === a.size && i && (i(), (i = null));
        }
      );
    },
  };
}
function wn(t, o, n) {
  const s = !Array.isArray(t),
    l = s ? [t] : t;
  if (!l.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const c = o.length < 2;
  return {
    subscribe: fn(n, (t, n) => {
      let u = !1;
      const d = [];
      let h = 0,
        p = e;
      const g = () => {
          if (h) return;
          p();
          const r = o(s ? d[0] : d, t, n);
          c ? t(r) : (p = i(r) ? r : e);
        },
        m = l.map((e, t) =>
          a(
            e,
            (e) => {
              (d[t] = e), (h &= ~(1 << t)), u && g();
            },
            () => {
              h |= 1 << t;
            }
          )
        );
      return (
        (u = !0),
        g(),
        function () {
          r(m), p(), (u = !1);
        }
      );
    }).subscribe,
  };
}
function bn(t) {
  let o, n, r;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        (r = M("path")),
        B(n, "d", "M0 0h24v24H0z"),
        B(n, "fill", "none"),
        B(
          r,
          "d",
          "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
        ),
        B(o, "xmlns", "http://www.w3.org/2000/svg"),
        B(o, "height", "18px"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "width", "18px");
    },
    m(e, t) {
      A(e, o, t), x(o, n), x(o, r);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function vn(e) {
  let t, o, n;
  return {
    c() {
      (t = P("input")),
        F(t, "checkbox"),
        B(t, "id", e[6]),
        (t.disabled = e[5]),
        B(t, "class", "svelte-139im29");
    },
    m(r, i) {
      A(r, t, i),
        (t.checked = e[0]),
        o || ((n = [_(t, "change", e[13]), _(t, "change", e[14])]), (o = !0));
    },
    p(e, o) {
      64 & o && B(t, "id", e[6]),
        32 & o && (t.disabled = e[5]),
        1 & o && (t.checked = e[0]);
    },
    d(e) {
      e && T(t), (o = !1), r(n);
    },
  };
}
function yn(e) {
  let t, o, n, r;
  return {
    c() {
      (t = P("input")),
        F(t, "checkbox"),
        B(t, "id", e[6]),
        (t.disabled = e[5]),
        (t.checked = o = -1 !== e[1].indexOf(e[4])),
        (t.value = e[4]),
        B(t, "class", "svelte-139im29");
    },
    m(o, i) {
      A(o, t, i), n || ((r = _(t, "change", e[12])), (n = !0));
    },
    p(e, n) {
      64 & n && B(t, "id", e[6]),
        32 & n && (t.disabled = e[5]),
        18 & n && o !== (o = -1 !== e[1].indexOf(e[4])) && (t.checked = o),
        16 & n && (t.value = e[4]);
    },
    d(e) {
      e && T(t), (n = !1), r();
    },
  };
}
function $n(e) {
  function t(e, t) {
    return null !== e[1] && null !== e[4] ? yn : vn;
  }
  let o,
    n,
    r,
    i,
    s,
    a = t(e),
    l = a(e);
  const u = e[11].default,
    g = c(u, e, e[10], null);
  return {
    c() {
      (o = P("label")),
        l.c(),
        (n = E()),
        (r = P("span")),
        g && g.c(),
        B(r, "class", (i = w(e[7]) + " svelte-139im29")),
        B(o, "class", "checkbox svelte-139im29"),
        Z(o, "invalid", !e[5] && e[3] && e[3] in e[2]);
    },
    m(e, t) {
      A(e, o, t), l.m(o, null), x(o, n), x(o, r), g && g.m(r, null), (s = !0);
    },
    p(e, [c]) {
      a === (a = t(e)) && l
        ? l.p(e, c)
        : (l.d(1), (l = a(e)), l && (l.c(), l.m(o, n))),
        g &&
          g.p &&
          (!s || 1024 & c) &&
          h(g, u, e, e[10], s ? d(u, e[10], c, null) : p(e[10]), null),
        (!s || (128 & c && i !== (i = w(e[7]) + " svelte-139im29"))) &&
          B(r, "class", i),
        (!s || 44 & c) && Z(o, "invalid", !e[5] && e[3] && e[3] in e[2]);
    },
    i(e) {
      s || ($e(g, e), (s = !0));
    },
    o(e) {
      Ce(g, e), (s = !1);
    },
    d(e) {
      e && T(o), l.d(), g && g.d(e);
    },
  };
}
function Cn(e, t, o) {
  function n() {
    s && (delete p[s], o(2, p));
  }
  let { $$slots: r = {}, $$scope: i } = t,
    { name: s } = t,
    { checked: a = !1 } = t,
    { value: l = null } = t,
    { group: c = null } = t,
    { disabled: u = !1 } = t,
    { id: d = `checkbox-${Math.ceil(1e5 * Math.random())}` } = t,
    { checkboxPosition: h = "middle" } = t,
    { errors: p = {} } = t;
  const g = ae();
  return (
    (e.$$set = (e) => {
      "name" in e && o(3, (s = e.name)),
        "checked" in e && o(0, (a = e.checked)),
        "value" in e && o(4, (l = e.value)),
        "group" in e && o(1, (c = e.group)),
        "disabled" in e && o(5, (u = e.disabled)),
        "id" in e && o(6, (d = e.id)),
        "checkboxPosition" in e && o(7, (h = e.checkboxPosition)),
        "errors" in e && o(2, (p = e.errors)),
        "$$scope" in e && o(10, (i = e.$$scope));
    }),
    [
      a,
      c,
      p,
      s,
      l,
      u,
      d,
      h,
      g,
      n,
      i,
      r,
      (e) => {
        if ((n(), !c || null === l)) return;
        const t = c.indexOf(l);
        -1 === t ? c.push(l) : c.splice(t, 1),
          o(1, c),
          g("change", { originEvent: e, checked: e.currentTarget.checked });
      },
      function () {
        (a = this.checked), o(0, a);
      },
      (e) => {
        n(), g("change", { originEvent: e, checked: e.currentTarget.checked });
      },
    ]
  );
}
function xn(t) {
  let o, n, r, i, s, a, l, c, u;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        (r = M("path")),
        (i = M("path")),
        (s = M("path")),
        (a = M("path")),
        (l = M("path")),
        (c = M("path")),
        (u = M("path")),
        B(n, "fill", "#FC0"),
        B(n, "fill-rule", "evenodd"),
        B(
          n,
          "d",
          "M14.5 13.103c1.836 0 3.667.723 5.5 2.14V19l-10.5.5-.5-4.257c1.833-1.417 3.664-2.14 5.5-2.14Z"
        ),
        B(n, "clip-rule", "evenodd"),
        B(r, "fill", "#CE8200"),
        B(r, "fill-rule", "evenodd"),
        B(
          r,
          "d",
          "M9.53 15.469 9.5 19l10-.477v-3.032c-1.703-1.27-3.365-1.888-5-1.888-1.626 0-3.277.611-4.97 1.866Zm-.836-.622c1.895-1.465 3.83-2.244 5.806-2.244 1.975 0 3.91.78 5.806 2.244l.194.15v4.48l-12.03.545V15.02l.224-.173Z"
        ),
        B(r, "clip-rule", "evenodd"),
        B(i, "fill", "#FC0"),
        B(i, "fill-rule", "evenodd"),
        B(
          i,
          "d",
          "m7.736 13.701-.734 2.345L7.001 20H4.5a1 1 0 0 1-1-1v-4c1.412-.669 2.824-1.102 4.236-1.299Z"
        ),
        B(i, "clip-rule", "evenodd"),
        B(s, "fill", "#CE8200"),
        B(s, "fill-rule", "evenodd"),
        B(
          s,
          "d",
          "m7.913 13.678-.475 1.086c-.988.111-1.87.308-2.646.59l-.29.11v3.529H7L7.002 20H4.5a1 1 0 0 1-1-1v-4c1.471-.697 2.942-1.138 4.413-1.322Z"
        ),
        B(s, "clip-rule", "evenodd"),
        B(a, "fill", "#FC0"),
        B(a, "d", "M14.5 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z"),
        B(l, "fill", "#CE8200"),
        B(l, "fill-rule", "evenodd"),
        B(
          l,
          "d",
          "M14.5 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"
        ),
        B(l, "clip-rule", "evenodd"),
        B(c, "fill", "#CE8200"),
        B(
          c,
          "d",
          "M11.471 11.979A4.992 4.992 0 0 1 9.5 8c0-.67.131-1.308.37-1.891a3.5 3.5 0 1 0 1.601 5.87Z"
        ),
        B(u, "fill", "#FC0"),
        B(
          u,
          "d",
          "M9.586 7.07a2.5 2.5 0 1 0 1.153 4.226A4.981 4.981 0 0 1 9.5 8c0-.318.03-.63.086-.93Z"
        ),
        B(o, "xmlns", "http://www.w3.org/2000/svg"),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "fill", "none");
    },
    m(e, t) {
      A(e, o, t),
        x(o, n),
        x(o, r),
        x(o, i),
        x(o, s),
        x(o, a),
        x(o, l),
        x(o, c),
        x(o, u);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function Sn(t) {
  let o, n, r, i, s, a, l, c, u;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        (r = M("path")),
        (i = M("path")),
        (s = M("path")),
        (a = M("path")),
        (l = M("path")),
        (c = M("path")),
        (u = M("path")),
        B(n, "fill", "#CDFDDA"),
        B(n, "fill-rule", "evenodd"),
        B(
          n,
          "d",
          "M14.5 13.103c1.836 0 3.667.723 5.5 2.14V19l-10.5.5-.5-4.257c1.833-1.417 3.664-2.14 5.5-2.14Z"
        ),
        B(n, "clip-rule", "evenodd"),
        B(r, "fill", "#00AC00"),
        B(r, "fill-rule", "evenodd"),
        B(
          r,
          "d",
          "M9.53 15.469 9.5 19l10-.477v-3.032c-1.703-1.27-3.365-1.888-5-1.888-1.626 0-3.277.611-4.97 1.866Zm-.836-.622c1.895-1.465 3.83-2.244 5.806-2.244 1.975 0 3.91.78 5.806 2.244l.194.15v4.48l-12.03.545V15.02l.224-.173Z"
        ),
        B(r, "clip-rule", "evenodd"),
        B(i, "fill", "#CDFDDA"),
        B(i, "fill-rule", "evenodd"),
        B(
          i,
          "d",
          "m7.736 13.701-.734 2.345L7.001 20H4.5a1 1 0 0 1-1-1v-4c1.412-.669 2.824-1.102 4.236-1.299Z"
        ),
        B(i, "clip-rule", "evenodd"),
        B(s, "fill", "#00AC00"),
        B(s, "fill-rule", "evenodd"),
        B(
          s,
          "d",
          "m7.913 13.678-.475 1.086c-.988.111-1.87.308-2.646.59l-.29.11v3.529H7L7.002 20H4.5a1 1 0 0 1-1-1v-4c1.471-.697 2.942-1.138 4.413-1.322Z"
        ),
        B(s, "clip-rule", "evenodd"),
        B(a, "fill", "#CDFDDA"),
        B(a, "d", "M14.5 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z"),
        B(l, "fill", "#00AC00"),
        B(l, "fill-rule", "evenodd"),
        B(
          l,
          "d",
          "M14.5 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"
        ),
        B(l, "clip-rule", "evenodd"),
        B(c, "fill", "#00AC00"),
        B(
          c,
          "d",
          "M11.471 11.979A4.992 4.992 0 0 1 9.5 8c0-.67.131-1.308.37-1.891a3.5 3.5 0 1 0 1.601 5.87Z"
        ),
        B(u, "fill", "#CDFDDA"),
        B(
          u,
          "d",
          "M9.586 7.07a2.5 2.5 0 1 0 1.153 4.226A4.981 4.981 0 0 1 9.5 8c0-.318.03-.63.086-.93Z"
        ),
        B(o, "xmlns", "http://www.w3.org/2000/svg"),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "fill", "none");
    },
    m(e, t) {
      A(e, o, t),
        x(o, n),
        x(o, r),
        x(o, i),
        x(o, s),
        x(o, a),
        x(o, l),
        x(o, c),
        x(o, u);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function kn(t) {
  let o, n, r;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        (r = M("path")),
        B(
          n,
          "d",
          "M20.0921 3.8288C18.53 2.2667 15.9973 2.2667 14.4352 3.8288L10.8997 7.36433C10.554 7.98502 11.8307 9.26173 12.9872 8.1052L15.8494 5.24301C16.6305 4.46196 17.8968 4.46196 18.6778 5.24301C19.4589 6.02406 19.4589 7.29039 18.6779 8.07144L14.4352 12.3141L14.3258 12.4157C13.54 13.0935 12.3523 13.0596 11.6068 12.3141C11.5718 12.2791 11.5383 12.2431 11.5064 12.2062L11.5025 12.2169C11.0464 11.6653 9.59431 11.5962 9.64587 13.0482C9.7997 13.2894 9.98194 13.5177 10.1926 13.7283C11.7547 15.2904 14.2873 15.2904 15.8494 13.7283L20.0921 9.48565C21.6542 7.92356 21.6542 5.3909 20.0921 3.8288Z"
        ),
        B(
          r,
          "d",
          "M13.7283 10.1928C12.1662 8.63065 9.63354 8.63065 8.07144 10.1928L3.8288 14.4354C2.2667 15.9975 2.2667 18.5301 3.8288 20.0922C5.3909 21.6543 7.92356 21.6543 9.48565 20.0922L13.0748 16.505C13.238 15.9221 12.5638 14.9332 11.2475 15.5024L8.07144 18.678L7.96202 18.7797C7.17627 19.4575 5.98856 19.4236 5.24301 18.678C4.46196 17.897 4.46196 16.6307 5.24301 15.8496L9.48565 11.607C10.1892 10.9034 11.2866 10.8336 12.0681 11.3947L12.0848 11.4097C12.1544 11.461 12.2214 11.5173 12.2853 11.5787C12.2825 11.5767 12.2796 11.5747 12.2768 11.5727L12.3141 11.607C12.3046 11.5974 12.295 11.588 12.2853 11.5787C13.1577 12.1968 14.2497 11.6386 14.2437 10.8971L14.3318 10.9647C14.1667 10.6895 13.9655 10.4299 13.7283 10.1928Z"
        ),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n), x(o, r);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function An(t) {
  let o, n;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        B(
          n,
          "d",
          "M12.997 6.09707h-1.994V11.003H6.09709v1.994H11.003v4.9059h1.994V12.997h4.9059v-1.994H12.997V6.09707z"
        ),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function Tn(t) {
  let o, n;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        B(n, "d", "M11.003 11.003H7.09693v1.994h9.80617v-1.994H11.003z"),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function On(t) {
  let o, n;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        B(
          n,
          "d",
          "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"
        ),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function Pn(e, { from: t, to: o }, n = {}) {
  const r = getComputedStyle(e),
    s = "none" === r.transform ? "" : r.transform,
    [a, l] = r.transformOrigin.split(" ").map(parseFloat),
    c = t.left + (t.width * a) / o.width - (o.left + a),
    u = t.top + (t.height * l) / o.height - (o.top + l),
    {
      delay: d = 0,
      duration: h = (e) => 120 * Math.sqrt(e),
      easing: p = ko,
    } = n;
  return {
    delay: d,
    duration: i(h) ? h(Math.sqrt(c * c + u * u)) : h,
    easing: p,
    css: (e, n) => {
      const r = n * c,
        i = n * u,
        a = e + (n * t.width) / o.width,
        l = e + (n * t.height) / o.height;
      return `transform: ${s} translate(${r}px, ${i}px) scale(${a}, ${l});`;
    },
  };
}
function Mn(e) {
  let t, o, n;
  return {
    c() {
      (t = P("input")),
        B(t, "maxlength", e[5]),
        F(t, e[3]),
        B(t, "style", e[15]),
        B(t, "autocomplete", e[11]),
        (t.value = e[0]),
        B(t, "placeholder", e[9]),
        (t.disabled = e[12]),
        (t.readOnly = e[13]),
        B(t, "name", e[10]),
        B(t, "class", "svelte-13q4tj3");
    },
    m(r, i) {
      A(r, t, i),
        e[70](t),
        o ||
          ((n = [
            _(t, "input", e[59]),
            _(t, "input", e[19]),
            _(t, "focus", e[60]),
            _(t, "focus", e[23]),
            _(t, "blur", e[61]),
            _(t, "blur", e[22]),
            _(t, "mousedown", e[62]),
            _(t, "keydown", e[63]),
            _(t, "change", e[64]),
            _(t, "click", e[65]),
          ]),
          (o = !0));
    },
    p(e, o) {
      32 & o[0] && B(t, "maxlength", e[5]),
        8 & o[0] && F(t, e[3]),
        32768 & o[0] && B(t, "style", e[15]),
        2048 & o[0] && B(t, "autocomplete", e[11]),
        1 & o[0] && t.value !== e[0] && (t.value = e[0]),
        512 & o[0] && B(t, "placeholder", e[9]),
        4096 & o[0] && (t.disabled = e[12]),
        8192 & o[0] && (t.readOnly = e[13]),
        1024 & o[0] && B(t, "name", e[10]);
    },
    d(i) {
      i && T(t), e[70](null), (o = !1), r(n);
    },
  };
}
function Ln(e) {
  let t, o, n;
  return {
    c() {
      (t = P("input")),
        B(t, "maxlength", e[5]),
        B(t, "style", e[15]),
        B(t, "autocomplete", e[11]),
        F(t, "password"),
        (t.value = e[0]),
        B(t, "placeholder", e[9]),
        (t.disabled = e[12]),
        (t.readOnly = e[13]),
        B(t, "name", e[10]),
        B(t, "class", "svelte-13q4tj3");
    },
    m(r, i) {
      A(r, t, i),
        e[69](t),
        o ||
          ((n = [
            _(t, "input", e[52]),
            _(t, "input", e[19]),
            _(t, "focus", e[53]),
            _(t, "focus", e[23]),
            _(t, "blur", e[54]),
            _(t, "blur", e[22]),
            _(t, "mousedown", e[55]),
            _(t, "keydown", e[56]),
            _(t, "change", e[57]),
            _(t, "click", e[58]),
          ]),
          (o = !0));
    },
    p(e, o) {
      32 & o[0] && B(t, "maxlength", e[5]),
        32768 & o[0] && B(t, "style", e[15]),
        2048 & o[0] && B(t, "autocomplete", e[11]),
        1 & o[0] && t.value !== e[0] && (t.value = e[0]),
        512 & o[0] && B(t, "placeholder", e[9]),
        4096 & o[0] && (t.disabled = e[12]),
        8192 & o[0] && (t.readOnly = e[13]),
        1024 & o[0] && B(t, "name", e[10]);
    },
    d(i) {
      i && T(t), e[69](null), (o = !1), r(n);
    },
  };
}
function En(e) {
  let t, o, n;
  return {
    c() {
      (t = P("input")),
        B(t, "style", e[15]),
        B(t, "autocomplete", e[11]),
        F(t, "datetime-local"),
        B(t, "min", e[4]),
        B(t, "max", e[6]),
        B(t, "placeholder", e[9]),
        (t.disabled = e[12]),
        (t.readOnly = e[13]),
        B(t, "name", e[10]),
        B(t, "class", "svelte-13q4tj3");
    },
    m(r, i) {
      A(r, t, i),
        e[68](t),
        o ||
          ((n = [
            _(t, "input", e[45]),
            _(t, "input", e[19]),
            _(t, "focus", e[46]),
            _(t, "focus", e[23]),
            _(t, "blur", e[47]),
            _(t, "blur", e[22]),
            _(t, "mousedown", e[48]),
            _(t, "keydown", e[49]),
            _(t, "change", e[50]),
            _(t, "click", e[51]),
          ]),
          (o = !0));
    },
    p(e, o) {
      32768 & o[0] && B(t, "style", e[15]),
        2048 & o[0] && B(t, "autocomplete", e[11]),
        16 & o[0] && B(t, "min", e[4]),
        64 & o[0] && B(t, "max", e[6]),
        512 & o[0] && B(t, "placeholder", e[9]),
        4096 & o[0] && (t.disabled = e[12]),
        8192 & o[0] && (t.readOnly = e[13]),
        1024 & o[0] && B(t, "name", e[10]);
    },
    d(i) {
      i && T(t), e[68](null), (o = !1), r(n);
    },
  };
}
function Dn(e) {
  let t, o, n;
  return {
    c() {
      (t = P("input")),
        B(t, "style", e[15]),
        B(t, "autocomplete", e[11]),
        F(t, "date"),
        B(t, "min", e[4]),
        B(t, "max", e[6]),
        B(t, "placeholder", e[9]),
        (t.disabled = e[12]),
        (t.readOnly = e[13]),
        B(t, "name", e[10]),
        B(t, "class", "svelte-13q4tj3");
    },
    m(r, i) {
      A(r, t, i),
        e[67](t),
        o ||
          ((n = [
            _(t, "input", e[38]),
            _(t, "input", e[19]),
            _(t, "focus", e[39]),
            _(t, "focus", e[23]),
            _(t, "blur", e[40]),
            _(t, "blur", e[22]),
            _(t, "mousedown", e[41]),
            _(t, "keydown", e[42]),
            _(t, "change", e[43]),
            _(t, "click", e[44]),
          ]),
          (o = !0));
    },
    p(e, o) {
      32768 & o[0] && B(t, "style", e[15]),
        2048 & o[0] && B(t, "autocomplete", e[11]),
        16 & o[0] && B(t, "min", e[4]),
        64 & o[0] && B(t, "max", e[6]),
        512 & o[0] && B(t, "placeholder", e[9]),
        4096 & o[0] && (t.disabled = e[12]),
        8192 & o[0] && (t.readOnly = e[13]),
        1024 & o[0] && B(t, "name", e[10]);
    },
    d(i) {
      i && T(t), e[67](null), (o = !1), r(n);
    },
  };
}
function _n(e) {
  let t, o, n;
  return {
    c() {
      (t = P("input")),
        B(t, "style", e[15]),
        B(t, "autocomplete", e[11]),
        F(t, "number"),
        (t.value = e[20]),
        B(t, "placeholder", e[9]),
        (t.disabled = e[12]),
        (t.readOnly = e[13]),
        B(t, "min", e[4]),
        B(t, "max", e[6]),
        B(t, "step", e[7]),
        B(t, "name", e[10]),
        B(t, "class", "svelte-13q4tj3");
    },
    m(r, i) {
      A(r, t, i),
        e[66](t),
        o ||
          ((n = [
            _(t, "input", e[31]),
            _(t, "input", e[19]),
            _(t, "focus", e[32]),
            _(t, "focus", e[23]),
            _(t, "blur", e[33]),
            _(t, "blur", e[22]),
            _(t, "mousedown", e[34]),
            _(t, "keydown", e[35]),
            _(t, "change", e[36]),
            _(t, "change", e[21]),
            _(t, "click", e[37]),
          ]),
          (o = !0));
    },
    p(e, o) {
      32768 & o[0] && B(t, "style", e[15]),
        2048 & o[0] && B(t, "autocomplete", e[11]),
        1048576 & o[0] && t.value !== e[20] && (t.value = e[20]),
        512 & o[0] && B(t, "placeholder", e[9]),
        4096 & o[0] && (t.disabled = e[12]),
        8192 & o[0] && (t.readOnly = e[13]),
        16 & o[0] && B(t, "min", e[4]),
        64 & o[0] && B(t, "max", e[6]),
        128 & o[0] && B(t, "step", e[7]),
        1024 & o[0] && B(t, "name", e[10]);
    },
    d(i) {
      i && T(t), e[66](null), (o = !1), r(n);
    },
  };
}
function Un(e) {
  function t(e, t) {
    return "number" === e[3]
      ? _n
      : "date" === e[3]
      ? Dn
      : "datetime-local" === e[3]
      ? En
      : "password" === e[3]
      ? Ln
      : Mn;
  }
  let o, n, r, i, s;
  const a = e[30].left,
    l = c(a, e, e[29], Yc);
  let u = t(e),
    g = u(e);
  const m = e[30].right,
    f = c(m, e, e[29], Gc);
  return {
    c() {
      (o = P("span")),
        l && l.c(),
        (n = E()),
        g.c(),
        (r = E()),
        f && f.c(),
        B(o, "class", "input svelte-13q4tj3"),
        B(o, "title", (i = e[18] || e[9])),
        Z(o, "large", e[14]),
        Z(o, "invalid", !e[12] && (e[8] || (e[10] && e[10] in e[2]))),
        Z(o, "left", e[24].left),
        Z(o, "right", e[24].right),
        W(
          o,
          "width",
          "number" == typeof e[16]
            ? `calc(var(--indent-half) * ${String(e[16])})`
            : e[16]
        ),
        W(
          o,
          "max-width",
          "number" == typeof e[17]
            ? `calc(var(--indent-half) * ${String(e[17])})`
            : e[17]
        );
    },
    m(e, t) {
      A(e, o, t),
        l && l.m(o, null),
        x(o, n),
        g.m(o, null),
        x(o, r),
        f && f.m(o, null),
        (s = !0);
    },
    p(e, n) {
      l &&
        l.p &&
        (!s || 536870912 & n[0]) &&
        h(l, a, e, e[29], s ? d(a, e[29], n, Zc) : p(e[29]), Yc),
        u === (u = t(e)) && g
          ? g.p(e, n)
          : (g.d(1), (g = u(e)), g && (g.c(), g.m(o, r))),
        f &&
          f.p &&
          (!s || 536870912 & n[0]) &&
          h(f, m, e, e[29], s ? d(m, e[29], n, Kc) : p(e[29]), Gc),
        (!s || (262656 & n[0] && i !== (i = e[18] || e[9]))) &&
          B(o, "title", i),
        (!s || 16384 & n[0]) && Z(o, "large", e[14]),
        (!s || 5380 & n[0]) &&
          Z(o, "invalid", !e[12] && (e[8] || (e[10] && e[10] in e[2]))),
        (!s || 16777216 & n[0]) && Z(o, "left", e[24].left),
        (!s || 16777216 & n[0]) && Z(o, "right", e[24].right),
        65536 & n[0] &&
          W(
            o,
            "width",
            "number" == typeof e[16]
              ? `calc(var(--indent-half) * ${String(e[16])})`
              : e[16]
          ),
        131072 & n[0] &&
          W(
            o,
            "max-width",
            "number" == typeof e[17]
              ? `calc(var(--indent-half) * ${String(e[17])})`
              : e[17]
          );
    },
    i(e) {
      s || ($e(l, e), $e(f, e), (s = !0));
    },
    o(e) {
      Ce(l, e), Ce(f, e), (s = !1);
    },
    d(e) {
      e && T(o), l && l.d(e), g.d(), f && f.d(e);
    },
  };
}
function Bn(e, t, o) {
  function n() {
    r(c);
  }
  function r(e) {
    o(20, (L = ""));
    const t = Number(d),
      n = Number(p),
      r = isNaN(t) ? -1 / 0 : t,
      i = isNaN(n) ? 1 / 0 : n,
      s = Math.max(r ?? -1 / 0, Math.min(i ?? 1 / 0, Number(e)));
    "" === e || null === e || isNaN(s)
      ? o(20, (L = ""))
      : o(20, (L = void 0 === m ? String(s) : at(s, m).toFixed(m)));
  }
  function i() {
    v && (delete M[v], o(2, M)),
      x &&
        ("number" === u || "date" === u || "datetime-local" === u
          ? "number" != typeof x.valueAsNumber || isNaN(x.valueAsNumber)
            ? o(0, (c = null))
            : o(0, (c = x.valueAsNumber))
          : o(0, (c = x.value)));
  }
  let { $$slots: s = {}, $$scope: a } = t;
  const l = f(s);
  let { value: c = "" } = t,
    { type: u = "text" } = t,
    { min: d } = t,
    { maxlength: h } = t,
    { max: p } = t,
    { step: g = 1 } = t,
    { digits: m } = t,
    { invalid: w = !1 } = t,
    { placeholder: b = "" } = t,
    { name: v } = t,
    { autocomplete: y = "off" } = t,
    { disabled: $ = !1 } = t,
    { readonly: C = !1 } = t,
    { element: x = null } = t,
    { large: S = !1 } = t,
    { style: k = "" } = t,
    { width: A = "auto" } = t,
    { maxWidth: T = "auto" } = t,
    { title: O = "" } = t,
    { focus: P = "" } = t,
    { errors: M = {} } = t,
    L = "";
  if ("number" === u && void 0 === m && void 0 !== g) {
    const e = g.toString(),
      t = e.indexOf(".");
    ~t && (m = e.length - t - 1);
  }
  return (
    ie(() => {
      ("date" !== u && "datetime-local" !== u) ||
        !x ||
        null == c ||
        o(1, (x.valueAsNumber = c), x);
    }),
    (e.$$set = (e) => {
      "value" in e && o(0, (c = e.value)),
        "type" in e && o(3, (u = e.type)),
        "min" in e && o(4, (d = e.min)),
        "maxlength" in e && o(5, (h = e.maxlength)),
        "max" in e && o(6, (p = e.max)),
        "step" in e && o(7, (g = e.step)),
        "digits" in e && o(26, (m = e.digits)),
        "invalid" in e && o(8, (w = e.invalid)),
        "placeholder" in e && o(9, (b = e.placeholder)),
        "name" in e && o(10, (v = e.name)),
        "autocomplete" in e && o(11, (y = e.autocomplete)),
        "disabled" in e && o(12, ($ = e.disabled)),
        "readonly" in e && o(13, (C = e.readonly)),
        "element" in e && o(1, (x = e.element)),
        "large" in e && o(14, (S = e.large)),
        "style" in e && o(15, (k = e.style)),
        "width" in e && o(16, (A = e.width)),
        "maxWidth" in e && o(17, (T = e.maxWidth)),
        "title" in e && o(18, (O = e.title)),
        "focus" in e && o(25, (P = e.focus)),
        "errors" in e && o(2, (M = e.errors)),
        "$$scope" in e && o(29, (a = e.$$scope));
    }),
    (e.$$.update = () => {
      33555458 & e.$$.dirty[0] &&
        x &&
        (function (e, t = "") {
          e && !$ && t === e && x && x.focus();
        })(v, P),
        3 & e.$$.dirty[0] && document.activeElement !== x && r(c);
    }),
    [
      c,
      x,
      M,
      u,
      d,
      h,
      p,
      g,
      w,
      b,
      v,
      y,
      $,
      C,
      S,
      k,
      A,
      T,
      O,
      i,
      L,
      n,
      function () {
        o(25, (P = "")), n();
      },
      function () {
        v && o(25, (P = v));
      },
      l,
      P,
      m,
      function () {
        x && "number" === u && (x.stepUp(), i(), r(c));
      },
      function () {
        x && "number" === u && (x.stepDown(), i(), r(c));
      },
      a,
      s,
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (x = e), o(1, x);
        });
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (x = e), o(1, x);
        });
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (x = e), o(1, x);
        });
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (x = e), o(1, x);
        });
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (x = e), o(1, x);
        });
      },
    ]
  );
}
function Vn(e, t, o) {
  const n = e.slice();
  return (n[26] = t[o]), n;
}
function jn(e) {
  let t, o;
  return {
    c() {
      (t = P("option")),
        (o = L(e[8])),
        (t.__value = ""),
        q(t, t.__value),
        (t.disabled = !0),
        (t.selected = !0),
        B(t, "class", "svelte-10dlr8e");
    },
    m(e, n) {
      A(e, t, n), x(t, o);
    },
    p(e, t) {
      256 & t && R(o, e[8]);
    },
    d(e) {
      e && T(t);
    },
  };
}
function zn(e) {
  let t;
  const o = e[18].default,
    n = c(o, e, e[17], null);
  return {
    c() {
      n && n.c();
    },
    m(e, o) {
      n && n.m(e, o), (t = !0);
    },
    p(e, r) {
      n &&
        n.p &&
        (!t || 131072 & r) &&
        h(n, o, e, e[17], t ? d(o, e[17], r, null) : p(e[17]), null);
    },
    i(e) {
      t || ($e(n, e), (t = !0));
    },
    o(e) {
      Ce(n, e), (t = !1);
    },
    d(e) {
      n && n.d(e);
    },
  };
}
function In(t) {
  let o,
    n = Oe(t[6]),
    r = [];
  for (let e = 0; e < n.length; e += 1) r[e] = Hn(Vn(t, n, e));
  return {
    c() {
      for (let e = 0; e < r.length; e += 1) r[e].c();
      o = D();
    },
    m(e, t) {
      for (let o = 0; o < r.length; o += 1) r[o] && r[o].m(e, t);
      A(e, o, t);
    },
    p(e, t) {
      if (64 & t) {
        let i;
        for (n = Oe(e[6]), i = 0; i < n.length; i += 1) {
          const s = Vn(e, n, i);
          r[i]
            ? r[i].p(s, t)
            : ((r[i] = Hn(s)), r[i].c(), r[i].m(o.parentNode, o));
        }
        for (; i < r.length; i += 1) r[i].d(1);
        r.length = n.length;
      }
    },
    i: e,
    o: e,
    d(e) {
      e && T(o), O(r, e);
    },
  };
}
function Hn(e) {
  let t,
    o,
    n,
    r = e[26].name + "";
  return {
    c() {
      (t = P("option")),
        (o = L(r)),
        (t.__value = n = e[26].id),
        q(t, t.__value),
        B(t, "class", "svelte-10dlr8e");
    },
    m(e, n) {
      A(e, t, n), x(t, o);
    },
    p(e, i) {
      64 & i && r !== (r = e[26].name + "") && R(o, r),
        64 & i && n !== (n = e[26].id) && ((t.__value = n), q(t, t.__value));
    },
    d(e) {
      e && T(t);
    },
  };
}
function Nn(e) {
  function t(e, t) {
    return !e[14].default && e[6].length ? 0 : 1;
  }
  let o,
    n,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p = e[8] && jn(e);
  const g = [In, zn],
    m = [];
  return (
    (s = t(e)),
    (a = m[s] = g[s](e)),
    {
      c() {
        (o = P("div")),
          (n = P("select")),
          p && p.c(),
          (i = D()),
          a.c(),
          (l = E()),
          (c = P("div")),
          (c.innerHTML =
            '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="svelte-10dlr8e"><path d="M16.2951 8.29508L11.7051 12.8751L7.11508 8.29508L5.70508 9.70508L11.7051 15.7051L17.7051 9.70508L16.2951 8.29508Z"></path></svg>'),
          B(n, "style", e[9]),
          (n.disabled = e[4]),
          B(n, "class", "svelte-10dlr8e"),
          void 0 === e[0] && pe(() => e[22].call(n)),
          Z(n, "placeholder", e[8] && "" === e[0]),
          B(c, "class", "arrow svelte-10dlr8e"),
          B(o, "class", "select-wrapper svelte-10dlr8e"),
          Z(o, "large", "large" === e[7]),
          Z(o, "header", "header" === e[7]),
          Z(o, "disabled", e[4]),
          Z(o, "invalid", !e[4] && (e[5] || (e[3] && e[3] in e[1]))),
          W(
            o,
            "width",
            "number" == typeof e[10]
              ? `calc(var(--indent-half) * ${String(e[10])})`
              : e[10]
          ),
          W(
            o,
            "max-width",
            "number" == typeof e[11]
              ? `calc(var(--indent-half) * ${String(e[11])})`
              : e[11]
          );
      },
      m(t, r) {
        A(t, o, r),
          x(o, n),
          p && p.m(n, null),
          x(n, i),
          m[s].m(n, null),
          K(n, e[0], !0),
          e[23](n),
          x(o, l),
          x(o, c),
          (u = !0),
          d ||
            ((h = [
              _(n, "change", e[22]),
              _(n, "change", e[19]),
              _(n, "change", e[12]),
              _(n, "blur", e[20]),
              _(n, "blur", e[13]),
              _(n, "input", e[21]),
            ]),
            (d = !0));
      },
      p(e, [r]) {
        e[8]
          ? p
            ? p.p(e, r)
            : ((p = jn(e)), p.c(), p.m(n, i))
          : p && (p.d(1), (p = null));
        let l = s;
        (s = t(e)),
          s === l
            ? m[s].p(e, r)
            : (ve(),
              Ce(m[l], 1, 1, () => {
                m[l] = null;
              }),
              ye(),
              (a = m[s]),
              a ? a.p(e, r) : ((a = m[s] = g[s](e)), a.c()),
              $e(a, 1),
              a.m(n, null)),
          (!u || 512 & r) && B(n, "style", e[9]),
          (!u || 16 & r) && (n.disabled = e[4]),
          1 & r && K(n, e[0]),
          (!u || 257 & r) && Z(n, "placeholder", e[8] && "" === e[0]),
          (!u || 128 & r) && Z(o, "large", "large" === e[7]),
          (!u || 128 & r) && Z(o, "header", "header" === e[7]),
          (!u || 16 & r) && Z(o, "disabled", e[4]),
          (!u || 58 & r) &&
            Z(o, "invalid", !e[4] && (e[5] || (e[3] && e[3] in e[1]))),
          1024 & r &&
            W(
              o,
              "width",
              "number" == typeof e[10]
                ? `calc(var(--indent-half) * ${String(e[10])})`
                : e[10]
            ),
          2048 & r &&
            W(
              o,
              "max-width",
              "number" == typeof e[11]
                ? `calc(var(--indent-half) * ${String(e[11])})`
                : e[11]
            );
      },
      i(e) {
        u || ($e(a), (u = !0));
      },
      o(e) {
        Ce(a), (u = !1);
      },
      d(t) {
        t && T(o), p && p.d(), m[s].d(), e[23](null), (d = !1), r(h);
      },
    }
  );
}
function Rn(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t;
  const i = f(n);
  let { name: s } = t,
    { value: a = "" } = t,
    { disabled: l = !1 } = t,
    { invalid: c = !1 } = t,
    { options: u = [] } = t,
    { focus: d = "" } = t,
    { errors: h = {} } = t,
    { element: p = null } = t,
    { type: g = "small" } = t,
    { placeholder: m = "" } = t,
    { style: w = "" } = t,
    { width: b = "auto" } = t,
    { maxWidth: v = "auto" } = t,
    { selectFirst: y = !1 } = t,
    $ = d;
  return (
    y && (a = u[0].id),
    (e.$$set = (e) => {
      "name" in e && o(3, (s = e.name)),
        "value" in e && o(0, (a = e.value)),
        "disabled" in e && o(4, (l = e.disabled)),
        "invalid" in e && o(5, (c = e.invalid)),
        "options" in e && o(6, (u = e.options)),
        "focus" in e && o(15, (d = e.focus)),
        "errors" in e && o(1, (h = e.errors)),
        "element" in e && o(2, (p = e.element)),
        "type" in e && o(7, (g = e.type)),
        "placeholder" in e && o(8, (m = e.placeholder)),
        "style" in e && o(9, (w = e.style)),
        "width" in e && o(10, (b = e.width)),
        "maxWidth" in e && o(11, (v = e.maxWidth)),
        "selectFirst" in e && o(16, (y = e.selectFirst)),
        "$$scope" in e && o(17, (r = e.$$scope));
    }),
    (e.$$.update = () => {
      32776 & e.$$.dirty &&
        (s || d) &&
        (l || (d === s && d !== $ && p && p.focus(), ($ = d)));
    }),
    [
      a,
      h,
      p,
      s,
      l,
      c,
      u,
      g,
      m,
      w,
      b,
      v,
      function () {
        s && (delete h[s], o(1, h));
      },
      function () {
        o(15, (d = ""));
      },
      i,
      d,
      y,
      r,
      n,
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function () {
        (a = (function (e) {
          const t = e.querySelector(":checked");
          return t && t.__value;
        })(this)),
          o(0, a);
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (p = e), o(2, p), o(6, u);
        });
      },
    ]
  );
}
function qn(t) {
  let o, n;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        B(n, "fill-rule", "evenodd"),
        B(n, "clip-rule", "evenodd"),
        B(
          n,
          "d",
          "M20 11H7.83L13.42 5.41L12 4L4 12L12 20L13.41 18.59L7.83 13H20V11Z"
        ),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function Fn(e) {
  return /\d/gm.test(e[0]);
}
function Wn(e) {
  return !Fn(e) && e[0].toLowerCase() === e[0];
}
function Kn(e, t) {
  let o = 0,
    n = 0,
    r = 0,
    i = 0;
  if (!e) return 2007;
  if (e.length < t) return 2e3;
  for (let a = 0; a < e.length; a++) {
    const t = e[a],
      l = Number(Fn(t));
    let c = Number(!Fn((s = t)) && s[0].toUpperCase() === s[0]),
      u = Number(Wn(t));
    const d = Number((c && u) || (!l && !c && !u));
    if (
      (c && u && ((c = 0), (u = 0)),
      (o += l),
      (i += d),
      (n += c),
      (r += u),
      o && n && r && i)
    )
      return 0;
  }
  var s;
  return r && n && o && i ? 0 : 2001;
}
function Gn(t) {
  let o, n, r, i, s, a, l, c, u, d, h;
  return (
    (r = new ic({ props: { name: Xc } })),
    (c = new Vc({})),
    {
      c() {
        (o = P("div")),
          (n = P("button")),
          Ue(r.$$.fragment),
          (i = E()),
          (s = P("div")),
          (s.textContent = `${window.tr(
            window.lang.login.brokerInformation.title
          )}`),
          (a = E()),
          (l = P("div")),
          Ue(c.$$.fragment),
          B(n, "class", "back svelte-1rsx3m1"),
          B(n, "title", window.tr(window.lang.ui.screen.back)),
          B(s, "class", "title svelte-1rsx3m1"),
          B(o, "class", "header svelte-1rsx3m1"),
          B(l, "class", "bi-content svelte-1rsx3m1");
      },
      m(e, p) {
        A(e, o, p),
          x(o, n),
          Be(r, n, null),
          x(o, i),
          x(o, s),
          A(e, a, p),
          A(e, l, p),
          Be(c, l, null),
          (u = !0),
          d || ((h = _(n, "click", t[1])), (d = !0));
      },
      p: e,
      i(e) {
        u || ($e(r.$$.fragment, e), $e(c.$$.fragment, e), (u = !0));
      },
      o(e) {
        Ce(r.$$.fragment, e), Ce(c.$$.fragment, e), (u = !1);
      },
      d(e) {
        e && (T(o), T(a), T(l)), Ve(r), Ve(c), (d = !1), h();
      },
    }
  );
}
function Zn(e) {
  const t = ae();
  return [t, () => t("back")];
}
function Yn(e) {
  let t,
    o,
    n,
    r,
    i,
    s,
    a,
    l,
    u = `calc(var(--indent-half) * ${e[0]}) 1fr`;
  const g = e[3].title,
    m = c(g, e, e[2], iu),
    f = e[3].default,
    w = c(f, e, e[2], null),
    b = e[3].footer,
    v = c(b, e, e[2], nu);
  return {
    c() {
      (t = P("form")),
        (o = P("div")),
        m && m.c(),
        (n = E()),
        w && w.c(),
        (r = E()),
        (i = P("div")),
        v && v.c(),
        B(o, "class", "title svelte-1h6ohe8"),
        B(i, "class", "footer svelte-1h6ohe8"),
        B(t, "autocomplete", e[1]),
        B(t, "class", "form svelte-1h6ohe8"),
        W(t, "grid-template-columns", u);
    },
    m(c, u) {
      var d;
      A(c, t, u),
        x(t, o),
        m && m.m(o, null),
        x(t, n),
        w && w.m(t, null),
        x(t, r),
        x(t, i),
        v && v.m(i, null),
        (s = !0),
        a ||
          ((l = _(
            t,
            "submit",
            ((d = e[4]),
            function (e) {
              return e.preventDefault(), d.call(this, e);
            })
          )),
          (a = !0));
    },
    p(e, [o]) {
      m &&
        m.p &&
        (!s || 4 & o) &&
        h(m, g, e, e[2], s ? d(g, e[2], o, ru) : p(e[2]), iu),
        w &&
          w.p &&
          (!s || 4 & o) &&
          h(w, f, e, e[2], s ? d(f, e[2], o, null) : p(e[2]), null),
        v &&
          v.p &&
          (!s || 4 & o) &&
          h(v, b, e, e[2], s ? d(b, e[2], o, ou) : p(e[2]), nu),
        (!s || 2 & o) && B(t, "autocomplete", e[1]),
        1 & o &&
          u !== (u = `calc(var(--indent-half) * ${e[0]}) 1fr`) &&
          W(t, "grid-template-columns", u);
    },
    i(e) {
      s || ($e(m, e), $e(w, e), $e(v, e), (s = !0));
    },
    o(e) {
      Ce(m, e), Ce(w, e), Ce(v, e), (s = !1);
    },
    d(e) {
      e && T(t), m && m.d(e), w && w.d(e), v && v.d(e), (a = !1), l();
    },
  };
}
function Jn(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { labelWidth: i = 28 } = t,
    { autocomplete: s = "off" } = t;
  return (
    (e.$$set = (e) => {
      "labelWidth" in e && o(0, (i = e.labelWidth)),
        "autocomplete" in e && o(1, (s = e.autocomplete)),
        "$$scope" in e && o(2, (r = e.$$scope));
    }),
    [
      i,
      s,
      r,
      n,
      function (t) {
        ue.call(this, e, t);
      },
    ]
  );
}
function Qn(e) {
  var t;
  let o,
    n,
    r = (null == (t = e[5]) ? void 0 : t.isHedgedMargin) ? "Hedge" : "Netting";
  return {
    c() {
      (o = L("- ")), (n = L(r));
    },
    m(e, t) {
      A(e, o, t), A(e, n, t);
    },
    p(e, t) {
      var o;
      32 & t &&
        r !==
          (r = (null == (o = e[5]) ? void 0 : o.isHedgedMargin)
            ? "Hedge"
            : "Netting") &&
        R(n, r);
    },
    d(e) {
      e && (T(o), T(n));
    },
  };
}
function Xn(e) {
  function t(t) {
    e[14](t);
  }
  function o(t) {
    e[15](t);
  }
  function n(t) {
    e[16](t);
  }
  function r(t) {
    e[17](t);
  }
  let i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g,
    m,
    f = {
      name: "password",
      type: "password",
      placeholder: window.tr(window.lang.login.connect.passwordPlaceholder),
    };
  void 0 !== e[1] && (f.focus = e[1]),
    void 0 !== e[2] && (f.errors = e[2]),
    void 0 !== e[3] && (f.value = e[3]),
    (l = new Jc({ props: f })),
    ca.push(() => _e(l, "focus", t)),
    ca.push(() => _e(l, "errors", o)),
    ca.push(() => _e(l, "value", n));
  let w = { $$slots: { default: [er] }, $$scope: { ctx: e } };
  return (
    void 0 !== e[4] && (w.checked = e[4]),
    (p = new Ic({ props: w })),
    ca.push(() => _e(p, "checked", r)),
    {
      c() {
        (i = P("div")),
          (i.textContent = `${window.tr(window.lang.login.form.password)}`),
          (s = E()),
          (a = P("div")),
          Ue(l.$$.fragment),
          (h = E()),
          Ue(p.$$.fragment),
          B(i, "class", "field-large svelte-1k90a21"),
          B(a, "class", "password field-large svelte-1k90a21");
      },
      m(e, t) {
        A(e, i, t),
          A(e, s, t),
          A(e, a, t),
          Be(l, a, null),
          x(a, h),
          Be(p, a, null),
          (m = !0);
      },
      p(e, t) {
        const o = {};
        !c && 2 & t && ((c = !0), (o.focus = e[1]), ge(() => (c = !1))),
          !u && 4 & t && ((u = !0), (o.errors = e[2]), ge(() => (u = !1))),
          !d && 8 & t && ((d = !0), (o.value = e[3]), ge(() => (d = !1))),
          l.$set(o);
        const n = {};
        2097152 & t && (n.$$scope = { dirty: t, ctx: e }),
          !g && 16 & t && ((g = !0), (n.checked = e[4]), ge(() => (g = !1))),
          p.$set(n);
      },
      i(e) {
        m || ($e(l.$$.fragment, e), $e(p.$$.fragment, e), (m = !0));
      },
      o(e) {
        Ce(l.$$.fragment, e), Ce(p.$$.fragment, e), (m = !1);
      },
      d(e) {
        e && (T(i), T(s), T(a)), Ve(l), Ve(p);
      },
    }
  );
}
function er(t) {
  let o,
    n = window.tr(window.lang.login.connect.savePassword) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function tr(e) {
  function t(t) {
    e[18](t);
  }
  function o(t) {
    e[19](t);
  }
  function n(t) {
    e[20](t);
  }
  let r,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h = {
      name: "otp",
      placeholder: window.tr(window.lang.login.otp.placeholder),
    };
  return (
    void 0 !== e[0] && (h.value = e[0]),
    void 0 !== e[2] && (h.errors = e[2]),
    void 0 !== e[1] && (h.focus = e[1]),
    (a = new Jc({ props: h })),
    ca.push(() => _e(a, "value", t)),
    ca.push(() => _e(a, "errors", o)),
    ca.push(() => _e(a, "focus", n)),
    {
      c() {
        (r = P("div")),
          (r.textContent = "OTP"),
          (i = E()),
          (s = P("div")),
          Ue(a.$$.fragment),
          B(r, "class", "field svelte-1k90a21");
      },
      m(e, t) {
        A(e, r, t), A(e, i, t), A(e, s, t), Be(a, s, null), (d = !0);
      },
      p(e, t) {
        const o = {};
        !l && 1 & t && ((l = !0), (o.value = e[0]), ge(() => (l = !1))),
          !c && 4 & t && ((c = !0), (o.errors = e[2]), ge(() => (c = !1))),
          !u && 2 & t && ((u = !0), (o.focus = e[1]), ge(() => (u = !1))),
          a.$set(o);
      },
      i(e) {
        d || ($e(a.$$.fragment, e), (d = !0));
      },
      o(e) {
        Ce(a.$$.fragment, e), (d = !1);
      },
      d(e) {
        e && (T(r), T(i), T(s)), Ve(a);
      },
    }
  );
}
function or(e) {
  let t,
    o,
    n,
    r,
    i,
    s,
    a,
    l,
    u,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $,
    C,
    S = e[5].name + "",
    k = e[5].server + "",
    O = e[5].login + "";
  const M = e[13].default,
    _ = c(M, e, e[21], null),
    U =
      _ ||
      (function (e) {
        let t,
          o,
          n = e[9] && !e[6] && Xn(e);
        return {
          c() {
            n && n.c(), (t = D());
          },
          m(e, r) {
            n && n.m(e, r), A(e, t, r), (o = !0);
          },
          p(e, o) {
            e[9] && !e[6]
              ? n
                ? (n.p(e, o), 576 & o && $e(n, 1))
                : ((n = Xn(e)), n.c(), $e(n, 1), n.m(t.parentNode, t))
              : n &&
                (ve(),
                Ce(n, 1, 1, () => {
                  n = null;
                }),
                ye());
          },
          i(e) {
            o || ($e(n), (o = !0));
          },
          o(e) {
            Ce(n), (o = !1);
          },
          d(e) {
            e && T(t), n && n.d(e);
          },
        };
      })(e);
  let V = e[6] && tr(e);
  return {
    c() {
      (t = P("div")),
        (t.textContent = `${window.tr(window.lang.login.form.name.title)}`),
        (o = E()),
        (n = P("div")),
        (r = L(S)),
        (i = E()),
        (s = P("div")),
        (s.textContent = `${window.tr(window.lang.login.form.server)}`),
        (a = E()),
        (l = P("div")),
        (u = L(k)),
        (g = E()),
        (m = P("div")),
        (m.textContent = `${window.tr(window.lang.login.form.login)}`),
        (f = E()),
        (w = P("div")),
        (b = L(O)),
        (v = E()),
        U && U.c(),
        (y = E()),
        V && V.c(),
        ($ = D()),
        B(t, "class", "field-slim svelte-1k90a21"),
        B(n, "class", "field-slim svelte-1k90a21"),
        B(s, "class", "field-slim svelte-1k90a21"),
        B(l, "class", "field-slim svelte-1k90a21"),
        B(m, "class", "field-slim svelte-1k90a21"),
        B(w, "class", "field-slim svelte-1k90a21");
    },
    m(e, c) {
      A(e, t, c),
        A(e, o, c),
        A(e, n, c),
        x(n, r),
        A(e, i, c),
        A(e, s, c),
        A(e, a, c),
        A(e, l, c),
        x(l, u),
        A(e, g, c),
        A(e, m, c),
        A(e, f, c),
        A(e, w, c),
        x(w, b),
        A(e, v, c),
        U && U.m(e, c),
        A(e, y, c),
        V && V.m(e, c),
        A(e, $, c),
        (C = !0);
    },
    p(e, t) {
      (!C || 32 & t) && S !== (S = e[5].name + "") && R(r, S),
        (!C || 32 & t) && k !== (k = e[5].server + "") && R(u, k),
        (!C || 32 & t) && O !== (O = e[5].login + "") && R(b, O),
        _
          ? _.p &&
            (!C || 2097152 & t) &&
            h(_, M, e, e[21], C ? d(M, e[21], t, null) : p(e[21]), null)
          : U && U.p && (!C || 606 & t) && U.p(e, C ? t : -1),
        e[6]
          ? V
            ? (V.p(e, t), 64 & t && $e(V, 1))
            : ((V = tr(e)), V.c(), $e(V, 1), V.m($.parentNode, $))
          : V &&
            (ve(),
            Ce(V, 1, 1, () => {
              V = null;
            }),
            ye());
    },
    i(e) {
      C || ($e(U, e), $e(V), (C = !0));
    },
    o(e) {
      Ce(U, e), Ce(V), (C = !1);
    },
    d(e) {
      e &&
        (T(t),
        T(o),
        T(n),
        T(i),
        T(s),
        T(a),
        T(l),
        T(g),
        T(m),
        T(f),
        T(w),
        T(v),
        T(y),
        T($)),
        U && U.d(e),
        V && V.d(e);
    },
  };
}
function nr(t) {
  let o,
    n = window.tr(window.lang.login.connect.btnConnect) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function rr(e) {
  let t, o;
  return (
    (t = new mc({
      props: { red: !0, $$slots: { default: [sr] }, $$scope: { ctx: e } },
    })),
    t.$on("click", e[12]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        2097152 & o && (n.$$scope = { dirty: o, ctx: e }), t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function ir(e) {
  let t, o;
  return (
    (t = new mc({
      props: { red: !0, $$slots: { default: [ar] }, $$scope: { ctx: e } },
    })),
    t.$on("click", e[11]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        2097152 & o && (n.$$scope = { dirty: o, ctx: e }), t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function sr(t) {
  let o,
    n = window.tr(window.lang.login.form.btn.remove) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function ar(t) {
  let o,
    n = window.tr(window.lang.login.form.btn.signOut) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function lr(e) {
  function t(e, t) {
    return e[7] ? 0 : 1;
  }
  let o, n, r, i, s, a, l;
  const u = e[13].footer,
    g = c(u, e, e[21], lu);
  r = new mc({
    props: {
      active: !0,
      type: "submit",
      disabled: e[7] && !e[6],
      $$slots: { default: [nr] },
      $$scope: { ctx: e },
    },
  });
  const m = [ir, rr],
    f = [];
  return (
    (s = t(e)),
    (a = f[s] = m[s](e)),
    {
      c() {
        (o = P("div")),
          g && g.c(),
          (n = E()),
          Ue(r.$$.fragment),
          (i = E()),
          a.c(),
          B(o, "class", "footer svelte-1k90a21"),
          B(o, "slot", "footer");
      },
      m(e, t) {
        A(e, o, t),
          g && g.m(o, null),
          x(o, n),
          Be(r, o, null),
          x(o, i),
          f[s].m(o, null),
          (l = !0);
      },
      p(e, n) {
        g &&
          g.p &&
          (!l || 2097152 & n) &&
          h(g, u, e, e[21], l ? d(u, e[21], n, au) : p(e[21]), lu);
        const i = {};
        192 & n && (i.disabled = e[7] && !e[6]),
          2097152 & n && (i.$$scope = { dirty: n, ctx: e }),
          r.$set(i);
        let c = s;
        (s = t(e)),
          s === c
            ? f[s].p(e, n)
            : (ve(),
              Ce(f[c], 1, 1, () => {
                f[c] = null;
              }),
              ye(),
              (a = f[s]),
              a ? a.p(e, n) : ((a = f[s] = m[s](e)), a.c()),
              $e(a, 1),
              a.m(o, null));
      },
      i(e) {
        l || ($e(g, e), $e(r.$$.fragment, e), $e(a), (l = !0));
      },
      o(e) {
        Ce(g, e), Ce(r.$$.fragment, e), Ce(a), (l = !1);
      },
      d(e) {
        e && T(o), g && g.d(e), Ve(r), f[s].d();
      },
    }
  );
}
function cr(e) {
  var t, o;
  let n,
    r,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $,
    C,
    S,
    k = (e[5].name ?? "") + "",
    O = ct((null == (t = e[5]) ? void 0 : t.balance) ?? 0, 2) + "",
    M = (e[5].currency ?? "") + "",
    D = e[5].login + "",
    _ = e[5].server + "",
    U = void 0 !== (null == (o = e[5]) ? void 0 : o.isHedgedMargin) && Qn(e);
  return (
    (C = new su({
      props: { $$slots: { footer: [lr], default: [or] }, $$scope: { ctx: e } },
    })),
    C.$on("submit", e[10]),
    {
      c() {
        (n = P("div")),
          (r = P("h2")),
          (i = P("div")),
          (s = L(k)),
          (l = E()),
          (c = P("div")),
          (u = L(O)),
          (d = E()),
          (h = L(M)),
          (p = E()),
          (g = P("div")),
          (m = P("div")),
          (f = L(D)),
          (w = L(" - ")),
          (b = L(_)),
          (v = E()),
          U && U.c(),
          (y = E()),
          ($ = P("div")),
          Ue(C.$$.fragment),
          B(i, "class", "name svelte-1k90a21"),
          B(i, "title", (a = e[5].name ?? "")),
          B(r, "class", "title svelte-1k90a21"),
          B(g, "class", "info svelte-1k90a21"),
          B(n, "class", "header"),
          B($, "class", "layout svelte-1k90a21"),
          Z($, "mobile", e[8]);
      },
      m(e, t) {
        A(e, n, t),
          x(n, r),
          x(r, i),
          x(i, s),
          x(r, l),
          x(r, c),
          x(c, u),
          x(c, d),
          x(c, h),
          x(n, p),
          x(n, g),
          x(g, m),
          x(m, f),
          x(m, w),
          x(m, b),
          x(m, v),
          U && U.m(m, null),
          A(e, y, t),
          A(e, $, t),
          Be(C, $, null),
          (S = !0);
      },
      p(e, [t]) {
        var o, n;
        (!S || 32 & t) && k !== (k = (e[5].name ?? "") + "") && R(s, k),
          (!S || (32 & t && a !== (a = e[5].name ?? ""))) && B(i, "title", a),
          (!S || 32 & t) &&
            O !==
              (O =
                ct((null == (o = e[5]) ? void 0 : o.balance) ?? 0, 2) + "") &&
            R(u, O),
          (!S || 32 & t) && M !== (M = (e[5].currency ?? "") + "") && R(h, M),
          (!S || 32 & t) && D !== (D = e[5].login + "") && R(f, D),
          (!S || 32 & t) && _ !== (_ = e[5].server + "") && R(b, _),
          void 0 !== (null == (n = e[5]) ? void 0 : n.isHedgedMargin)
            ? U
              ? U.p(e, t)
              : ((U = Qn(e)), U.c(), U.m(m, null))
            : U && (U.d(1), (U = null));
        const r = {};
        2097919 & t && (r.$$scope = { dirty: t, ctx: e }),
          C.$set(r),
          (!S || 256 & t) && Z($, "mobile", e[8]);
      },
      i(e) {
        S || ($e(C.$$.fragment, e), (S = !0));
      },
      o(e) {
        Ce(C.$$.fragment, e), (S = !1);
      },
      d(e) {
        e && (T(n), T(y), T($)), U && U.d(), Ve(C);
      },
    }
  );
}
function ur(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { user: i } = t,
    { otp: s = "" } = t,
    { showOtp: a = !1 } = t,
    { focus: l = "" } = t,
    { errors: c } = t,
    { current: u } = t,
    { password: d } = t,
    { savePassword: h } = t,
    { mobile: p = !1 } = t,
    g = !1;
  const m = ae();
  return (
    ie(() => {
      h && o(3, (d = i.password)), h || o(1, (l = "password"));
    }),
    (e.$$set = (e) => {
      "user" in e && o(5, (i = e.user)),
        "otp" in e && o(0, (s = e.otp)),
        "showOtp" in e && o(6, (a = e.showOtp)),
        "focus" in e && o(1, (l = e.focus)),
        "errors" in e && o(2, (c = e.errors)),
        "current" in e && o(7, (u = e.current)),
        "password" in e && o(3, (d = e.password)),
        "savePassword" in e && o(4, (h = e.savePassword)),
        "mobile" in e && o(8, (p = e.mobile)),
        "$$scope" in e && o(21, (r = e.$$scope));
    }),
    (e.$$.update = () => {
      32 & e.$$.dirty && o(9, (g = !i.savePassword));
    }),
    [
      s,
      l,
      c,
      d,
      h,
      i,
      a,
      u,
      p,
      g,
      function () {
        m("login");
      },
      function () {
        m("logout");
      },
      function () {
        m("remove");
      },
      n,
      function (e) {
        (l = e), o(1, l);
      },
      function (e) {
        (c = e), o(2, c);
      },
      function (e) {
        (d = e), o(3, d);
      },
      function (e) {
        (h = e), o(4, h);
      },
      function (e) {
        (s = e), o(0, s);
      },
      function (e) {
        (c = e), o(2, c);
      },
      function (e) {
        (l = e), o(1, l);
      },
      r,
    ]
  );
}
function dr(e) {
  let t;
  return {
    c() {
      (t = P("div")),
        (t.textContent = "Not Saved"),
        B(t, "class", "status off svelte-11m958e");
    },
    m(e, o) {
      A(e, t, o);
    },
    d(e) {
      e && T(t);
    },
  };
}
function hr(e) {
  let t;
  return {
    c() {
      (t = P("div")),
        (t.textContent = "Saved"),
        B(t, "class", "status on svelte-11m958e");
    },
    m(e, o) {
      A(e, t, o);
    },
    d(e) {
      e && T(t);
    },
  };
}
function pr(t) {
  let o, n, r;
  return {
    c() {
      (o = P("button")),
        (o.textContent = "Change password"),
        B(o, "class", "otp svelte-11m958e"),
        B(o, "type", "button");
    },
    m(e, i) {
      A(e, o, i), n || ((r = _(o, "click", t[12])), (n = !0));
    },
    p: e,
    d(e) {
      e && T(o), (n = !1), r();
    },
  };
}
function gr(e) {
  function t(e, t) {
    return e[9] ? fr : mr;
  }
  let o,
    n,
    r,
    i = t(e),
    s = i(e);
  return {
    c() {
      (o = P("div")),
        (o.textContent = "2FA/TOTP"),
        (n = E()),
        (r = P("div")),
        s.c(),
        B(r, "class", "settings svelte-11m958e");
    },
    m(e, t) {
      A(e, o, t), A(e, n, t), A(e, r, t), s.m(r, null);
    },
    p(e, o) {
      i === (i = t(e)) && s
        ? s.p(e, o)
        : (s.d(1), (s = i(e)), s && (s.c(), s.m(r, null)));
    },
    d(e) {
      e && (T(o), T(n), T(r)), s.d();
    },
  };
}
function mr(t) {
  let o, n, r, i, s;
  return {
    c() {
      (o = P("div")),
        (o.textContent = "Disabled"),
        (n = E()),
        (r = P("button")),
        (r.textContent = "Enable 2FA/TOTP"),
        B(o, "class", "status off svelte-11m958e"),
        B(r, "class", "otp svelte-11m958e"),
        B(r, "type", "button");
    },
    m(e, a) {
      A(e, o, a),
        A(e, n, a),
        A(e, r, a),
        i || ((s = _(r, "click", t[14])), (i = !0));
    },
    p: e,
    d(e) {
      e && (T(o), T(n), T(r)), (i = !1), s();
    },
  };
}
function fr(t) {
  let o, n, r, i, s;
  return {
    c() {
      (o = P("div")),
        (o.textContent = "Enabled"),
        (n = E()),
        (r = P("button")),
        (r.textContent = "Disable 2FA/TOTP"),
        B(o, "class", "status on svelte-11m958e"),
        B(r, "class", "otp svelte-11m958e"),
        B(r, "type", "button");
    },
    m(e, a) {
      A(e, o, a),
        A(e, n, a),
        A(e, r, a),
        i || ((s = _(r, "click", t[13])), (i = !0));
    },
    p: e,
    d(e) {
      e && (T(o), T(n), T(r)), (i = !1), s();
    },
  };
}
function wr(e) {
  function t(e, t) {
    return e[5].savePassword ? hr : dr;
  }
  let o,
    n,
    r,
    i,
    s,
    a,
    l = !e[8].isInvestor && !e[8].isReadOnly(),
    c = t(e),
    u = c(e),
    d = l && pr(e),
    h = e[7] && e[5].login === e[8].login && 0 !== e[8].otpStatus && gr(e);
  return {
    c() {
      (o = P("div")),
        (o.textContent = "Password"),
        (n = E()),
        (r = P("div")),
        u.c(),
        (i = E()),
        d && d.c(),
        (s = E()),
        h && h.c(),
        (a = D()),
        B(r, "class", "settings svelte-11m958e");
    },
    m(e, t) {
      A(e, o, t),
        A(e, n, t),
        A(e, r, t),
        u.m(r, null),
        x(r, i),
        d && d.m(r, null),
        A(e, s, t),
        h && h.m(e, t),
        A(e, a, t);
    },
    p(e, o) {
      c !== (c = t(e)) && (u.d(1), (u = c(e)), u && (u.c(), u.m(r, i))),
        256 & o && (l = !e[8].isInvestor && !e[8].isReadOnly()),
        l
          ? d
            ? d.p(e, o)
            : ((d = pr(e)), d.c(), d.m(r, null))
          : d && (d.d(1), (d = null)),
        e[7] && e[5].login === e[8].login && 0 !== e[8].otpStatus
          ? h
            ? h.p(e, o)
            : ((h = gr(e)), h.c(), h.m(a.parentNode, a))
          : h && (h.d(1), (h = null));
    },
    d(e) {
      e && (T(o), T(n), T(r), T(s), T(a)), u.d(), d && d.d(), h && h.d(e);
    },
  };
}
function br(e) {
  let t;
  return {
    c() {
      t = L("Save password");
    },
    m(e, o) {
      A(e, t, o);
    },
    d(e) {
      e && T(t);
    },
  };
}
function vr(e) {
  let t, o, n;
  return (
    (o = new Ic({
      props: {
        checked: e[5].savePassword,
        $$slots: { default: [br] },
        $$scope: { ctx: e },
      },
    })),
    o.$on("change", e[11]),
    {
      c() {
        (t = P("div")),
          Ue(o.$$.fragment),
          B(t, "slot", "footer"),
          B(t, "class", "save-password svelte-11m958e");
      },
      m(e, r) {
        A(e, t, r), Be(o, t, null), (n = !0);
      },
      p(e, t) {
        const n = {};
        32 & t && (n.checked = e[5].savePassword),
          8388608 & t && (n.$$scope = { dirty: t, ctx: e }),
          o.$set(n);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        e && T(t), Ve(o);
      },
    }
  );
}
function yr(e) {
  function t(t) {
    e[15](t);
  }
  function o(t) {
    e[16](t);
  }
  function n(t) {
    e[17](t);
  }
  function r(t) {
    e[18](t);
  }
  let i,
    s,
    a,
    l,
    c,
    u,
    d = {
      user: e[5],
      savePassword: !0,
      showOtp: e[6],
      current: e[7],
      $$slots: { footer: [vr], default: [wr] },
      $$scope: { ctx: e },
    };
  return (
    void 0 !== e[3] && (d.password = e[3]),
    void 0 !== e[0] && (d.otp = e[0]),
    void 0 !== e[1] && (d.focus = e[1]),
    void 0 !== e[2] && (d.errors = e[2]),
    (i = new cu({ props: d })),
    ca.push(() => _e(i, "password", t)),
    ca.push(() => _e(i, "otp", o)),
    ca.push(() => _e(i, "focus", n)),
    ca.push(() => _e(i, "errors", r)),
    i.$on("login", e[19]),
    i.$on("logout", e[20]),
    i.$on("remove", e[21]),
    i.$on("removePassword", e[22]),
    {
      c() {
        Ue(i.$$.fragment);
      },
      m(e, t) {
        Be(i, e, t), (u = !0);
      },
      p(e, [t]) {
        const o = {};
        32 & t && (o.user = e[5]),
          64 & t && (o.showOtp = e[6]),
          128 & t && (o.current = e[7]),
          8389536 & t && (o.$$scope = { dirty: t, ctx: e }),
          !s && 8 & t && ((s = !0), (o.password = e[3]), ge(() => (s = !1))),
          !a && 1 & t && ((a = !0), (o.otp = e[0]), ge(() => (a = !1))),
          !l && 2 & t && ((l = !0), (o.focus = e[1]), ge(() => (l = !1))),
          !c && 4 & t && ((c = !0), (o.errors = e[2]), ge(() => (c = !1))),
          i.$set(o);
      },
      i(e) {
        u || ($e(i.$$.fragment, e), (u = !0));
      },
      o(e) {
        Ce(i.$$.fragment, e), (u = !1);
      },
      d(e) {
        Ve(i, e);
      },
    }
  );
}
function $r(t, o, n) {
  let r,
    i = e,
    s = () => (i(), (i = a(l, (e) => n(8, (r = e)))), l);
  t.$$.on_destroy.push(() => i());
  let { accountStore: l } = o;
  s();
  const c = ae();
  let { user: u } = o,
    { otp: d = "" } = o,
    { showOtp: h = !1 } = o,
    { focus: p = "" } = o,
    { errors: g } = o,
    { current: m } = o,
    { password: f } = o,
    w = !1;
  return (
    (t.$$set = (e) => {
      "accountStore" in e && s(n(4, (l = e.accountStore))),
        "user" in e && n(5, (u = e.user)),
        "otp" in e && n(0, (d = e.otp)),
        "showOtp" in e && n(6, (h = e.showOtp)),
        "focus" in e && n(1, (p = e.focus)),
        "errors" in e && n(2, (g = e.errors)),
        "current" in e && n(7, (m = e.current)),
        "password" in e && n(3, (f = e.password));
    }),
    (t.$$.update = () => {
      256 & t.$$.dirty && n(9, (w = 2 === r.otpStatus));
    }),
    [
      d,
      p,
      g,
      f,
      l,
      u,
      h,
      m,
      r,
      w,
      c,
      function (e) {
        e.detail.checked ? c("savePassword") : c("removePassword");
      },
      () => c("changePassword"),
      () => c("otpDisable"),
      () => c("otpEnable"),
      function (e) {
        (f = e), n(3, f);
      },
      function (e) {
        (d = e), n(0, d);
      },
      function (e) {
        (p = e), n(1, p);
      },
      function (e) {
        (g = e), n(2, g);
      },
      function (e) {
        ue.call(this, t, e);
      },
      function (e) {
        ue.call(this, t, e);
      },
      function (e) {
        ue.call(this, t, e);
      },
      function (e) {
        ue.call(this, t, e);
      },
    ]
  );
}
function Cr(e) {
  let t,
    o,
    n,
    r,
    i = e[1].group + "";
  return {
    c() {
      (t = P("div")),
        (t.textContent = `${window.tr(window.lang.login.form.accountType)}`),
        (o = E()),
        (n = P("div")),
        (r = L(i)),
        B(t, "class", "label svelte-lxq1k6");
    },
    m(e, i) {
      A(e, t, i), A(e, o, i), A(e, n, i), x(n, r);
    },
    p(e, t) {
      2 & t && i !== (i = e[1].group + "") && R(r, i);
    },
    d(e) {
      e && (T(t), T(o), T(n));
    },
  };
}
function xr(e) {
  var t;
  let o,
    n,
    r,
    i = ct((null == (t = e[1]) ? void 0 : t.balance) ?? 0, 0) + "",
    s = e[1].currency + "";
  return {
    c() {
      (o = L(i)), (n = E()), (r = L(s));
    },
    m(e, t) {
      A(e, o, t), A(e, n, t), A(e, r, t);
    },
    p(e, t) {
      var n;
      2 & t &&
        i !==
          (i = ct((null == (n = e[1]) ? void 0 : n.balance) ?? 0, 0) + "") &&
        R(o, i),
        2 & t && s !== (s = e[1].currency + "") && R(r, s);
    },
    d(e) {
      e && (T(o), T(n), T(r));
    },
  };
}
function Sr(e) {
  let t,
    o,
    n,
    r,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $,
    C,
    S,
    k,
    O,
    M,
    D,
    _,
    U,
    V,
    j,
    z,
    I,
    H,
    N = e[1].name + "",
    q = e[1].server + "",
    F = e[1].login + "",
    W = e[1].password + "",
    K = (e[2] ?? "") + "",
    G = window.tr(window.lang.login.form.passwordReadOnly) + "",
    Z = void 0 !== e[1].group && e[1].currency && Cr(e);
  return (
    (g = new hc({
      props: {
        marginBottom: e[0] ? 2 : 3,
        $$slots: { default: [xr] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        (t = P("div")),
          (t.textContent = `${window.tr(window.lang.login.form.name.title)}`),
          (o = E()),
          (n = P("div")),
          (r = L(N)),
          (i = E()),
          (s = P("div")),
          (s.textContent = `${window.tr(window.lang.login.form.server)}`),
          (a = E()),
          (l = P("div")),
          (c = L(q)),
          (u = E()),
          Z && Z.c(),
          (d = E()),
          (h = P("div")),
          (h.textContent = `${window.tr(window.lang.login.form.deposit)}`),
          (p = E()),
          Ue(g.$$.fragment),
          (m = E()),
          (f = P("div")),
          (f.textContent = `${window.tr(window.lang.login.form.login)}`),
          (w = E()),
          (b = P("div")),
          (v = L(F)),
          (y = E()),
          ($ = P("div")),
          ($.textContent = `${window.tr(window.lang.login.form.password)}`),
          (C = E()),
          (S = P("div")),
          (k = L(W)),
          (O = E()),
          (M = P("div")),
          (M.textContent = `${window.tr(window.lang.login.form.investor)}`),
          (D = E()),
          (_ = P("div")),
          (U = P("span")),
          (V = L(K)),
          (j = L("\r\n         (")),
          (z = L(G)),
          (I = L(")")),
          B(t, "class", "label svelte-lxq1k6"),
          B(s, "class", "label svelte-lxq1k6"),
          B(h, "class", "label svelte-lxq1k6"),
          B(f, "class", "label svelte-lxq1k6"),
          B(b, "class", "private svelte-lxq1k6"),
          B($, "class", "label svelte-lxq1k6"),
          B(S, "class", "private svelte-lxq1k6"),
          B(M, "class", "label svelte-lxq1k6"),
          B(U, "class", "private svelte-lxq1k6");
      },
      m(e, T) {
        A(e, t, T),
          A(e, o, T),
          A(e, n, T),
          x(n, r),
          A(e, i, T),
          A(e, s, T),
          A(e, a, T),
          A(e, l, T),
          x(l, c),
          A(e, u, T),
          Z && Z.m(e, T),
          A(e, d, T),
          A(e, h, T),
          A(e, p, T),
          Be(g, e, T),
          A(e, m, T),
          A(e, f, T),
          A(e, w, T),
          A(e, b, T),
          x(b, v),
          A(e, y, T),
          A(e, $, T),
          A(e, C, T),
          A(e, S, T),
          x(S, k),
          A(e, O, T),
          A(e, M, T),
          A(e, D, T),
          A(e, _, T),
          x(_, U),
          x(U, V),
          x(_, j),
          x(_, z),
          x(_, I),
          (H = !0);
      },
      p(e, t) {
        (!H || 2 & t) && N !== (N = e[1].name + "") && R(r, N),
          (!H || 2 & t) && q !== (q = e[1].server + "") && R(c, q),
          void 0 !== e[1].group && e[1].currency
            ? Z
              ? Z.p(e, t)
              : ((Z = Cr(e)), Z.c(), Z.m(d.parentNode, d))
            : Z && (Z.d(1), (Z = null));
        const o = {};
        1 & t && (o.marginBottom = e[0] ? 2 : 3),
          34 & t && (o.$$scope = { dirty: t, ctx: e }),
          g.$set(o),
          (!H || 2 & t) && F !== (F = e[1].login + "") && R(v, F),
          (!H || 2 & t) && W !== (W = e[1].password + "") && R(k, W),
          (!H || 4 & t) && K !== (K = (e[2] ?? "") + "") && R(V, K);
      },
      i(e) {
        H || ($e(g.$$.fragment, e), (H = !0));
      },
      o(e) {
        Ce(g.$$.fragment, e), (H = !1);
      },
      d(e) {
        e &&
          (T(t),
          T(o),
          T(n),
          T(i),
          T(s),
          T(a),
          T(l),
          T(u),
          T(d),
          T(h),
          T(p),
          T(m),
          T(f),
          T(w),
          T(b),
          T(y),
          T($),
          T(C),
          T(S),
          T(O),
          T(M),
          T(D),
          T(_)),
          Z && Z.d(e),
          Ve(g, e);
      },
    }
  );
}
function kr(t) {
  let o,
    n = window.tr(window.lang.login.accountInfo.newAccountOpened) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Ar(t) {
  let o,
    n = window.tr(window.lang.login.accountInfo.btnStart) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Tr(e) {
  let t, o;
  return (
    (t = new mc({
      props: { active: !0, $$slots: { default: [Ar] }, $$scope: { ctx: e } },
    })),
    t.$on("click", e[3]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        32 & o && (n.$$scope = { dirty: o, ctx: e }), t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Or(e) {
  let t, o;
  return (
    (t = new su({
      props: {
        $$slots: { footer: [Tr], title: [kr], default: [Sr] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, [o]) {
        const n = {};
        39 & o && (n.$$scope = { dirty: o, ctx: e }), t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Pr(e, t, o) {
  let { mobile: n } = t,
    { user: r } = t,
    { investor: i } = t;
  const s = ae();
  return (
    (e.$$set = (e) => {
      "mobile" in e && o(0, (n = e.mobile)),
        "user" in e && o(1, (r = e.user)),
        "investor" in e && o(2, (i = e.investor));
    }),
    [
      n,
      r,
      i,
      async function () {
        s("login");
      },
    ]
  );
}
function Mr(e) {
  let t,
    o,
    n,
    r,
    i = e[6].login + "";
  return {
    c() {
      (t = P("div")),
        (t.textContent = `${window.tr(window.lang.login.form.login)}`),
        (o = E()),
        (n = P("div")),
        (r = L(i));
    },
    m(e, i) {
      A(e, t, i), A(e, o, i), A(e, n, i), x(n, r);
    },
    p(e, t) {
      64 & t && i !== (i = e[6].login + "") && R(r, i);
    },
    d(e) {
      e && (T(t), T(o), T(n));
    },
  };
}
function Lr(e) {
  function t(t) {
    e[10](t);
  }
  function o(t) {
    e[11](t);
  }
  function n(t) {
    e[12](t);
  }
  function r(t) {
    e[13](t);
  }
  function i(t) {
    e[14](t);
  }
  function s(t) {
    e[15](t);
  }
  function a(t) {
    e[16](t);
  }
  function l(t) {
    e[17](t);
  }
  function c(t) {
    e[18](t);
  }
  let u,
    d,
    h,
    p,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $,
    C,
    x,
    S,
    k,
    O,
    M,
    L,
    D,
    _,
    U,
    V,
    j,
    z = e[6].login && Mr(e),
    I = {
      name: "current",
      type: "password",
      autocomplete: "current-password",
      placeholder: "Enter current password",
      width: e[0] ? "100%" : 60,
    };
  void 0 !== e[3].current && (I.value = e[3].current),
    void 0 !== e[4] && (I.focus = e[4]),
    void 0 !== e[5] && (I.errors = e[5]),
    (g = new Jc({ props: I })),
    ca.push(() => _e(g, "value", t)),
    ca.push(() => _e(g, "focus", o)),
    ca.push(() => _e(g, "errors", n));
  let H = {
    name: "password",
    type: "password",
    autocomplete: "new-password",
    placeholder: "Enter new password",
    width: e[0] ? "100%" : 60,
  };
  void 0 !== e[3].password && (H.value = e[3].password),
    void 0 !== e[4] && (H.focus = e[4]),
    void 0 !== e[5] && (H.errors = e[5]),
    ($ = new Jc({ props: H })),
    ca.push(() => _e($, "value", r)),
    ca.push(() => _e($, "focus", i)),
    ca.push(() => _e($, "errors", s));
  let N = {
    name: "confirm",
    autocomplete: "new-password",
    placeholder: "Confirm password",
    type: "password",
    width: e[0] ? "100%" : 60,
  };
  return (
    void 0 !== e[3].confirm && (N.value = e[3].confirm),
    void 0 !== e[4] && (N.focus = e[4]),
    void 0 !== e[5] && (N.errors = e[5]),
    (D = new Jc({ props: N })),
    ca.push(() => _e(D, "value", a)),
    ca.push(() => _e(D, "focus", l)),
    ca.push(() => _e(D, "errors", c)),
    {
      c() {
        z && z.c(),
          (u = E()),
          (d = P("div")),
          (d.textContent = "Current Password"),
          (h = E()),
          (p = P("div")),
          Ue(g.$$.fragment),
          (b = E()),
          (v = P("div")),
          (v.textContent = `${window.tr(
            window.lang.login.changePassword.newPassword
          )}`),
          (y = E()),
          Ue($.$$.fragment),
          (k = E()),
          (O = P("div")),
          (O.textContent = `${window.tr(
            window.lang.login.changePassword.confirmPassword
          )}`),
          (M = E()),
          (L = P("div")),
          Ue(D.$$.fragment),
          B(d, "class", "field svelte-17jpk2n"),
          B(p, "class", "current svelte-17jpk2n"),
          B(v, "class", "field svelte-17jpk2n"),
          B(O, "class", "field svelte-17jpk2n"),
          B(L, "class", "last svelte-17jpk2n");
      },
      m(e, t) {
        z && z.m(e, t),
          A(e, u, t),
          A(e, d, t),
          A(e, h, t),
          A(e, p, t),
          Be(g, p, null),
          A(e, b, t),
          A(e, v, t),
          A(e, y, t),
          Be($, e, t),
          A(e, k, t),
          A(e, O, t),
          A(e, M, t),
          A(e, L, t),
          Be(D, L, null),
          (j = !0);
      },
      p(e, t) {
        e[6].login
          ? z
            ? z.p(e, t)
            : ((z = Mr(e)), z.c(), z.m(u.parentNode, u))
          : z && (z.d(1), (z = null));
        const o = {};
        1 & t && (o.width = e[0] ? "100%" : 60),
          !m &&
            8 & t &&
            ((m = !0), (o.value = e[3].current), ge(() => (m = !1))),
          !f && 16 & t && ((f = !0), (o.focus = e[4]), ge(() => (f = !1))),
          !w && 32 & t && ((w = !0), (o.errors = e[5]), ge(() => (w = !1))),
          g.$set(o);
        const n = {};
        1 & t && (n.width = e[0] ? "100%" : 60),
          !C &&
            8 & t &&
            ((C = !0), (n.value = e[3].password), ge(() => (C = !1))),
          !x && 16 & t && ((x = !0), (n.focus = e[4]), ge(() => (x = !1))),
          !S && 32 & t && ((S = !0), (n.errors = e[5]), ge(() => (S = !1))),
          $.$set(n);
        const r = {};
        1 & t && (r.width = e[0] ? "100%" : 60),
          !_ &&
            8 & t &&
            ((_ = !0), (r.value = e[3].confirm), ge(() => (_ = !1))),
          !U && 16 & t && ((U = !0), (r.focus = e[4]), ge(() => (U = !1))),
          !V && 32 & t && ((V = !0), (r.errors = e[5]), ge(() => (V = !1))),
          D.$set(r);
      },
      i(e) {
        j ||
          ($e(g.$$.fragment, e),
          $e($.$$.fragment, e),
          $e(D.$$.fragment, e),
          (j = !0));
      },
      o(e) {
        Ce(g.$$.fragment, e),
          Ce($.$$.fragment, e),
          Ce(D.$$.fragment, e),
          (j = !1);
      },
      d(e) {
        e && (T(u), T(d), T(h), T(p), T(b), T(v), T(y), T(k), T(O), T(M), T(L)),
          z && z.d(e),
          Ve(g),
          Ve($, e),
          Ve(D);
      },
    }
  );
}
function Er(t) {
  let o,
    n = window.tr(window.lang.login.changePassword.title) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Dr(t) {
  let o,
    n = window.tr(window.lang.login.changePassword.btnChange) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function _r(t) {
  let o,
    n = window.tr(window.lang.login.form.btn.cancel) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Ur(e) {
  var t;
  let o, n, r, i, s;
  return (
    (n = new mc({
      props: {
        active: !0,
        type: "submit",
        $$slots: { default: [Dr] },
        $$scope: { ctx: e },
      },
    })),
    (i = new mc({
      props: {
        disabled: !(null == (t = e[2]) ? void 0 : t.id),
        $$slots: { default: [_r] },
        $$scope: { ctx: e },
      },
    })),
    i.$on("click", e[8]),
    {
      c() {
        (o = P("div")),
          Ue(n.$$.fragment),
          (r = E()),
          Ue(i.$$.fragment),
          B(o, "class", "footer1"),
          B(o, "slot", "footer");
      },
      m(e, t) {
        A(e, o, t), Be(n, o, null), x(o, r), Be(i, o, null), (s = !0);
      },
      p(e, t) {
        var o;
        const r = {};
        4194304 & t && (r.$$scope = { dirty: t, ctx: e }), n.$set(r);
        const s = {};
        4 & t && (s.disabled = !(null == (o = e[2]) ? void 0 : o.id)),
          4194304 & t && (s.$$scope = { dirty: t, ctx: e }),
          i.$set(s);
      },
      i(e) {
        s || ($e(n.$$.fragment, e), $e(i.$$.fragment, e), (s = !0));
      },
      o(e) {
        Ce(n.$$.fragment, e), Ce(i.$$.fragment, e), (s = !1);
      },
      d(e) {
        e && T(o), Ve(n), Ve(i);
      },
    }
  );
}
function Br(e) {
  let t, o, n;
  return (
    (o = new su({
      props: {
        $$slots: { footer: [Ur], title: [Er], default: [Lr] },
        $$scope: { ctx: e },
      },
    })),
    o.$on("submit", e[7]),
    {
      c() {
        (t = P("div")),
          Ue(o.$$.fragment),
          B(t, "class", "layout svelte-17jpk2n");
      },
      m(e, r) {
        A(e, t, r), Be(o, t, null), (n = !0);
      },
      p(e, [t]) {
        const n = {};
        4194429 & t && (n.$$scope = { dirty: t, ctx: e }), o.$set(n);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        e && T(t), Ve(o);
      },
    }
  );
}
function Vr(t, o, n) {
  let r,
    i = e,
    s = () => (i(), (i = a(d, (e) => n(6, (r = e)))), d);
  t.$$.on_destroy.push(() => i());
  const l = ae();
  let { mobile: c } = o,
    { accountController: u } = o,
    { accountStore: d } = o;
  s();
  let { user: h } = o;
  const p = {
      current: { value: "", validators: ["required"] },
      password: { value: "", validators: ["required"] },
      confirm: { value: "", validators: ["required"] },
    },
    g = new eu(p).getValues(p);
  let m = "current",
    f = {};
  return (
    (t.$$set = (e) => {
      "mobile" in e && n(0, (c = e.mobile)),
        "accountController" in e && n(9, (u = e.accountController)),
        "accountStore" in e && s(n(1, (d = e.accountStore))),
        "user" in e && n(2, (h = e.user));
    }),
    [
      c,
      d,
      h,
      g,
      m,
      f,
      r,
      async function () {
        if (g.current !== h.password)
          return (
            n(4, (m = "current")),
            n(5, (f = { current: "Error" })),
            void l("error", 2005)
          );
        const e = Kn(g.password, r.passwordMin);
        if (e)
          return (
            n(4, (m = "password")),
            n(5, (f = { password: "Error" })),
            void l("error", e)
          );
        if (g.password !== g.confirm)
          return (
            n(4, (m = "confirm")),
            n(5, (f = { confirm: "Error" })),
            void l("error", 2006)
          );
        const t = await u.changePassword(g.password, r.passwordMin);
        hu.includes(t)
          ? (n(3, (g.confirm = ""), g),
            n(5, (f.password = window.tr(window.lang.login.errors.error)), f),
            n(4, (m = "password")),
            l("error", t))
          : 0 === t && h && l("success", g.password);
      },
      function () {
        l("cancel");
      },
      u,
      function (e) {
        t.$$.not_equal(g.current, e) && ((g.current = e), n(3, g));
      },
      function (e) {
        (m = e), n(4, m);
      },
      function (e) {
        (f = e), n(5, f);
      },
      function (e) {
        t.$$.not_equal(g.password, e) && ((g.password = e), n(3, g));
      },
      function (e) {
        (m = e), n(4, m);
      },
      function (e) {
        (f = e), n(5, f);
      },
      function (e) {
        t.$$.not_equal(g.confirm, e) && ((g.confirm = e), n(3, g));
      },
      function (e) {
        (m = e), n(4, m);
      },
      function (e) {
        (f = e), n(5, f);
      },
    ]
  );
}
function jr(e) {
  e[41] = e[40].default;
}
function zr(e) {
  e[39] = e[40].default;
}
function Ir(e) {
  function t(e, t) {
    var o;
    return e[3].modules &&
      e[3].modules.account.accountStore.login === e[0].login &&
      (e[3].modules.account.accountStore.isResetPass ||
        e[3].existing[e[0].login].showChangePassword)
      ? 0
      : e[3].existing[e[0].login].showOtpConnect
      ? 1
      : e[3].existing[e[0].login].showOtpDisconnect && e[3].modules
      ? 2
      : (null == (o = e[3].createdUser) ? void 0 : o.investor) &&
        e[3].createdUser.id === e[0].id
      ? 3
      : e[3].modules && e[3].modules.account.accountStore.login === e[0].login
      ? 4
      : 5;
  }
  let o, n, r, i;
  const s = [Wr, Fr, qr, Rr, Nr, Hr],
    a = [];
  return (
    (o = t(e)),
    (n = a[o] = s[o](e)),
    {
      c() {
        n.c(), (r = D());
      },
      m(e, t) {
        a[o].m(e, t), A(e, r, t), (i = !0);
      },
      p(e, i) {
        let l = o;
        (o = t(e)),
          o === l
            ? a[o].p(e, i)
            : (ve(),
              Ce(a[l], 1, 1, () => {
                a[l] = null;
              }),
              ye(),
              (n = a[o]),
              n ? n.p(e, i) : ((n = a[o] = s[o](e)), n.c()),
              $e(n, 1),
              n.m(r.parentNode, r));
      },
      i(e) {
        i || ($e(n), (i = !0));
      },
      o(e) {
        Ce(n), (i = !1);
      },
      d(e) {
        e && T(r), a[o].d(e);
      },
    }
  );
}
function Hr(e) {
  function t(t) {
    e[26](t);
  }
  function o(t) {
    e[27](t);
  }
  function n(t) {
    e[28](t);
  }
  function r(t) {
    e[29](t);
  }
  function i(t) {
    e[30](t);
  }
  let s,
    a,
    l,
    c,
    u,
    d,
    h,
    p = {
      mobile: e[1],
      user: e[0],
      showOtp: e[3].existing[e[0].login].showOtp,
      current: e[2],
    };
  return (
    void 0 !== e[3].existing[e[0].login].values.otp &&
      (p.otp = e[3].existing[e[0].login].values.otp),
    void 0 !== e[3].existing[e[0].login].focus &&
      (p.focus = e[3].existing[e[0].login].focus),
    void 0 !== e[3].existing[e[0].login].errors &&
      (p.errors = e[3].existing[e[0].login].errors),
    void 0 !== e[3].existing[e[0].login].values.password &&
      (p.password = e[3].existing[e[0].login].values.password),
    void 0 !== e[3].existing[e[0].login].values.savePassword &&
      (p.savePassword = e[3].existing[e[0].login].values.savePassword),
    (s = new cu({ props: p })),
    ca.push(() => _e(s, "otp", t)),
    ca.push(() => _e(s, "focus", o)),
    ca.push(() => _e(s, "errors", n)),
    ca.push(() => _e(s, "password", r)),
    ca.push(() => _e(s, "savePassword", i)),
    s.$on("login", e[8]),
    s.$on("logout", e[6]),
    s.$on("remove", e[7]),
    {
      c() {
        Ue(s.$$.fragment);
      },
      m(e, t) {
        Be(s, e, t), (h = !0);
      },
      p(e, t) {
        const o = {};
        2 & t[0] && (o.mobile = e[1]),
          1 & t[0] && (o.user = e[0]),
          9 & t[0] && (o.showOtp = e[3].existing[e[0].login].showOtp),
          4 & t[0] && (o.current = e[2]),
          !a &&
            9 & t[0] &&
            ((a = !0),
            (o.otp = e[3].existing[e[0].login].values.otp),
            ge(() => (a = !1))),
          !l &&
            9 & t[0] &&
            ((l = !0),
            (o.focus = e[3].existing[e[0].login].focus),
            ge(() => (l = !1))),
          !c &&
            9 & t[0] &&
            ((c = !0),
            (o.errors = e[3].existing[e[0].login].errors),
            ge(() => (c = !1))),
          !u &&
            9 & t[0] &&
            ((u = !0),
            (o.password = e[3].existing[e[0].login].values.password),
            ge(() => (u = !1))),
          !d &&
            9 & t[0] &&
            ((d = !0),
            (o.savePassword = e[3].existing[e[0].login].values.savePassword),
            ge(() => (d = !1))),
          s.$set(o);
      },
      i(e) {
        h || ($e(s.$$.fragment, e), (h = !0));
      },
      o(e) {
        Ce(s.$$.fragment, e), (h = !1);
      },
      d(e) {
        Ve(s, e);
      },
    }
  );
}
function Nr(e) {
  function t(t) {
    e[22](t);
  }
  function o(t) {
    e[23](t);
  }
  function n(t) {
    e[24](t);
  }
  function r(t) {
    e[25](t);
  }
  let i,
    s,
    a,
    l,
    c,
    u,
    d = {
      accountStore: e[3].modules.account.accountStore,
      user: e[0],
      showOtp: e[3].existing[e[0].login].showOtp,
      current: e[2],
    };
  return (
    void 0 !== e[3].existing[e[0].login].values.otp &&
      (d.otp = e[3].existing[e[0].login].values.otp),
    void 0 !== e[3].existing[e[0].login].focus &&
      (d.focus = e[3].existing[e[0].login].focus),
    void 0 !== e[3].existing[e[0].login].errors &&
      (d.errors = e[3].existing[e[0].login].errors),
    void 0 !== e[3].existing[e[0].login].values.password &&
      (d.password = e[3].existing[e[0].login].values.password),
    (i = new uu({ props: d })),
    ca.push(() => _e(i, "otp", t)),
    ca.push(() => _e(i, "focus", o)),
    ca.push(() => _e(i, "errors", n)),
    ca.push(() => _e(i, "password", r)),
    i.$on("login", e[8]),
    i.$on("logout", e[6]),
    i.$on("remove", e[7]),
    i.$on("otpEnable", e[17]),
    i.$on("otpDisable", e[18]),
    i.$on("removePassword", e[19]),
    i.$on("savePassword", e[20]),
    i.$on("changePassword", e[12]),
    {
      c() {
        Ue(i.$$.fragment);
      },
      m(e, t) {
        Be(i, e, t), (u = !0);
      },
      p(e, t) {
        const o = {};
        8 & t[0] && (o.accountStore = e[3].modules.account.accountStore),
          1 & t[0] && (o.user = e[0]),
          9 & t[0] && (o.showOtp = e[3].existing[e[0].login].showOtp),
          4 & t[0] && (o.current = e[2]),
          !s &&
            9 & t[0] &&
            ((s = !0),
            (o.otp = e[3].existing[e[0].login].values.otp),
            ge(() => (s = !1))),
          !a &&
            9 & t[0] &&
            ((a = !0),
            (o.focus = e[3].existing[e[0].login].focus),
            ge(() => (a = !1))),
          !l &&
            9 & t[0] &&
            ((l = !0),
            (o.errors = e[3].existing[e[0].login].errors),
            ge(() => (l = !1))),
          !c &&
            9 & t[0] &&
            ((c = !0),
            (o.password = e[3].existing[e[0].login].values.password),
            ge(() => (c = !1))),
          i.$set(o);
      },
      i(e) {
        u || ($e(i.$$.fragment, e), (u = !0));
      },
      o(e) {
        Ce(i.$$.fragment, e), (u = !1);
      },
      d(e) {
        Ve(i, e);
      },
    }
  );
}
function Rr(e) {
  let t, o;
  return (
    (t = new du({
      props: { user: e[0], mobile: e[1], investor: e[3].createdUser.investor },
    })),
    t.$on("login", e[8]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        1 & o[0] && (n.user = e[0]),
          2 & o[0] && (n.mobile = e[1]),
          8 & o[0] && (n.investor = e[3].createdUser.investor),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function qr(e) {
  let t,
    o,
    n = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: Zr,
      then: Gr,
      catch: Kr,
      value: 40,
      blocks: [, , ,],
    };
  return (
    Ae(
      Ys(() => import("./3c5839d5.js"), ["3c5839d5.js", "96f8c273.css"]),
      n
    ),
    {
      c() {
        (t = D()), n.block.c();
      },
      m(e, r) {
        A(e, t, r),
          n.block.m(e, (n.anchor = r)),
          (n.mount = () => t.parentNode),
          (n.anchor = t),
          (o = !0);
      },
      p(t, o) {
        Te(n, (e = t), o);
      },
      i(e) {
        o || ($e(n.block), (o = !0));
      },
      o(e) {
        for (let t = 0; t < 3; t += 1) Ce(n.blocks[t]);
        o = !1;
      },
      d(e) {
        e && T(t), n.block.d(e), (n.token = null), (n = null);
      },
    }
  );
}
function Fr(e) {
  let t,
    o,
    n = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: Qr,
      then: Jr,
      catch: Yr,
      value: 40,
      blocks: [, , ,],
    };
  return (
    Ae(
      Ys(() => import("./0c47227d.js"), ["0c47227d.js", "917b70f1.css"]),
      n
    ),
    {
      c() {
        (t = D()), n.block.c();
      },
      m(e, r) {
        A(e, t, r),
          n.block.m(e, (n.anchor = r)),
          (n.mount = () => t.parentNode),
          (n.anchor = t),
          (o = !0);
      },
      p(t, o) {
        Te(n, (e = t), o);
      },
      i(e) {
        o || ($e(n.block), (o = !0));
      },
      o(e) {
        for (let t = 0; t < 3; t += 1) Ce(n.blocks[t]);
        o = !1;
      },
      d(e) {
        e && T(t), n.block.d(e), (n.token = null), (n = null);
      },
    }
  );
}
function Wr(e) {
  let t, o;
  return (
    (t = new pu({
      props: {
        mobile: e[1],
        user: e[0],
        accountController: e[3].modules.account.accountController,
        accountStore: e[3].modules.account.accountStore,
      },
    })),
    t.$on("success", e[9]),
    t.$on("error", e[10]),
    t.$on("cancel", e[11]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        2 & o[0] && (n.mobile = e[1]),
          1 & o[0] && (n.user = e[0]),
          8 & o[0] &&
            (n.accountController = e[3].modules.account.accountController),
          8 & o[0] && (n.accountStore = e[3].modules.account.accountStore),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Kr(t) {
  return { c: e, m: e, p: e, i: e, o: e, d: e };
}
function Gr(e) {
  let t, o;
  return (
    jr(e),
    (t = new e[41]({
      props: {
        accountController: e[3].modules.account.accountController,
        accountStore: e[3].modules.account.accountStore,
        user: e[0],
      },
    })),
    t.$on("success", e[14]),
    t.$on("cancel", e[15]),
    t.$on("error", ei),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        jr(e);
        const n = {};
        8 & o[0] &&
          (n.accountController = e[3].modules.account.accountController),
          8 & o[0] && (n.accountStore = e[3].modules.account.accountStore),
          1 & o[0] && (n.user = e[0]),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Zr(t) {
  let o, n;
  return (
    (o = new Ca({})),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p: e,
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function Yr(t) {
  return { c: e, m: e, p: e, i: e, o: e, d: e };
}
function Jr(e) {
  let t, o;
  return (
    zr(e),
    (t = new e[39]({
      props: {
        login: e[0].login,
        server: e[0].server,
        password: e[0].password,
      },
    })),
    t.$on("success", e[13]),
    t.$on("cancel", e[16]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        zr(e);
        const n = {};
        1 & o[0] && (n.login = e[0].login),
          1 & o[0] && (n.server = e[0].server),
          1 & o[0] && (n.password = e[0].password),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Qr(t) {
  let o, n;
  return (
    (o = new Ca({})),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p: e,
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function Xr(e) {
  let t,
    o,
    n = e[3].existing[e[0].login] && Ir(e);
  return {
    c() {
      n && n.c(), (t = D());
    },
    m(e, r) {
      n && n.m(e, r), A(e, t, r), (o = !0);
    },
    p(e, o) {
      e[3].existing[e[0].login]
        ? n
          ? (n.p(e, o), 9 & o[0] && $e(n, 1))
          : ((n = Ir(e)), n.c(), $e(n, 1), n.m(t.parentNode, t))
        : n &&
          (ve(),
          Ce(n, 1, 1, () => {
            n = null;
          }),
          ye());
    },
    i(e) {
      o || ($e(n), (o = !0));
    },
    o(e) {
      Ce(n), (o = !1);
    },
    d(e) {
      e && T(t), n && n.d(e);
    },
  };
}
function ei() {}
function ti(e, t, o) {
  async function n() {
    var e;
    h.savePassword
      ? b(
          s,
          (r.existing[h.login].errors = f.validate(r.existing[h.login].values)),
          r
        )
      : b(
          s,
          (r.existing[h.login].errors = w.validate(r.existing[h.login].values)),
          r
        ),
      Object.keys(r.existing[h.login].errors).length > 0
        ? b(
            s,
            (r.existing[h.login].focus = Object.keys(
              r.existing[h.login].errors
            )[0]),
            r
          )
        : (await g.existing(h)) &&
          ((null == (e = r.modules)
            ? void 0
            : e.account.accountStore.isResetPass) ||
            (Ga.remove("login"), i.setLayout({ auth: Vl.None })),
          b(s, (r.existing[h.login].showChangePassword = !1), r));
  }
  let r, i;
  const { authStore: s } = Ac;
  l(e, s, (e) => o(3, (r = e)));
  const { layoutStore: a } = tc.layout;
  l(e, a, (e) => o(31, (i = e)));
  const { usersController: c } = tc.users;
  let { autoConnect: u } = t,
    { mobile: d = !1 } = t,
    { user: h } = t,
    { current: p } = t;
  const { authController: g } = Ac,
    m = ae(),
    f = new eu({ otp: { validators: ["required"], disabled: !0 } }),
    w = new eu({
      otp: { validators: ["required"], disabled: !0 },
      password: { validators: ["required"] },
      savePassword: { value: !1 },
    });
  return (
    ie(() => {
      r.setExisting(h.login, { values: { savePassword: !!h.savePassword } }),
        u && (o(21, (u = !1)), h.savePassword && n());
    }),
    (e.$$set = (e) => {
      "autoConnect" in e && o(21, (u = e.autoConnect)),
        "mobile" in e && o(1, (d = e.mobile)),
        "user" in e && o(0, (h = e.user)),
        "current" in e && o(2, (p = e.current));
    }),
    [
      h,
      d,
      p,
      r,
      s,
      a,
      function () {
        m("logout", h.id);
      },
      function () {
        m("remove", h.id);
      },
      n,
      function (e) {
        o(0, (h.password = e.detail), h), c.addUser(h), n();
      },
      function (e) {
        b(s, (r.existing[h.login].error = yo(e.detail)), r);
      },
      function () {
        var e;
        (null == (e = r.modules)
          ? void 0
          : e.account.accountStore.isResetPass) && m("logout"),
          b(s, (r.existing[h.login].showChangePassword = !1), r);
      },
      function () {
        b(s, (r.existing[h.login].showChangePassword = !0), r);
      },
      function () {
        b(s, (r.existing[h.login].showOtpConnect = !1), r),
          b(s, (r.createdUser = null), r),
          n();
      },
      function () {
        b(s, (r.existing[h.login].showOtpDisconnect = !1), r),
          b(s, (r.createdUser = null), r),
          n();
      },
      function () {
        b(s, (r.existing[h.login].showOtpDisconnect = !1), r);
      },
      function () {
        b(s, (r.existing[h.login].showOtpConnect = !1), r);
      },
      function () {
        b(s, (r.existing[h.login].showOtpConnect = !0), r);
      },
      function () {
        b(s, (r.existing[h.login].showOtpDisconnect = !0), r);
      },
      async function () {
        await c.addUser({
          login: h.login,
          server: h.server,
          password: h.password,
          savePassword: !1,
        });
      },
      async function () {
        await c.addUser({
          login: h.login,
          server: h.server,
          password: h.password,
          savePassword: !0,
        });
      },
      u,
      function (t) {
        e.$$.not_equal(r.existing[h.login].values.otp, t) &&
          ((r.existing[h.login].values.otp = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].focus, t) &&
          ((r.existing[h.login].focus = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].errors, t) &&
          ((r.existing[h.login].errors = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].values.password, t) &&
          ((r.existing[h.login].values.password = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].values.otp, t) &&
          ((r.existing[h.login].values.otp = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].focus, t) &&
          ((r.existing[h.login].focus = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].errors, t) &&
          ((r.existing[h.login].errors = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].values.password, t) &&
          ((r.existing[h.login].values.password = t), s.set(r));
      },
      function (t) {
        e.$$.not_equal(r.existing[h.login].values.savePassword, t) &&
          ((r.existing[h.login].values.savePassword = t), s.set(r));
      },
    ]
  );
}
function oi(t) {
  let o, n, r, i, s;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        (r = M("path")),
        (i = M("path")),
        (s = M("path")),
        B(n, "fill", "#FACE00"),
        B(
          n,
          "d",
          "M17.287 8a3.429 3.429 0 1 1-6.857 0 3.429 3.429 0 0 1 6.857 0ZM8.145 16v3.429h11.428V16c-.571-.762-2.514-2.286-5.714-2.286-3.2 0-5.143 1.524-5.714 2.286Z"
        ),
        B(r, "fill", "#D7FCDD"),
        B(
          r,
          "d",
          "M8.823 6.939a5.127 5.127 0 0 0 1.416 4.716A2.857 2.857 0 1 1 8.823 6.94ZM3.57 16.343v3.085h2.857V15.15l.087-.139a3.48 3.48 0 0 1 .48-.591c-1.872.362-3.03 1.367-3.424 1.923Z"
        ),
        B(i, "fill", "#C2850C"),
        B(i, "fill-rule", "evenodd"),
        B(
          i,
          "d",
          "M9.855 8a4 4 0 1 1 8 0 4 4 0 0 1-8 0Zm4-2.857a2.857 2.857 0 1 0 0 5.714 2.857 2.857 0 0 0 0-5.714ZM7.685 15.657c.68-.907 2.793-2.514 6.171-2.514s5.491 1.607 6.171 2.514c.075.1.115.22.115.343v3.429a.571.571 0 0 1-.572.571H8.142a.571.571 0 0 1-.572-.571V16c0-.123.04-.244.115-.343Zm1.028.548v2.652H19v-2.652c-.599-.67-2.33-1.92-5.143-1.92-2.813 0-4.544 1.25-5.143 1.92Z"
        ),
        B(i, "clip-rule", "evenodd"),
        B(s, "fill", "#00A91C"),
        B(
          s,
          "d",
          "M9.855 11.23a2.286 2.286 0 1 1-1.117-3.723c.037-.388.117-.763.235-1.12a3.429 3.429 0 1 0 1.695 5.648 5.18 5.18 0 0 1-.813-.806ZM3.105 16.013c.548-.774 2.162-2.096 4.726-2.278-.631.427-1.072.887-1.316 1.277l-.086.138c-1.179.366-1.945.991-2.286 1.39v2.317h2.286V20H3.57A.571.571 0 0 1 3 19.429v-3.086c0-.118.037-.234.105-.33Z"
        ),
        B(o, "xmlns", "http://www.w3.org/2000/svg"),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "fill", "none");
    },
    m(e, t) {
      A(e, o, t), x(o, n), x(o, r), x(o, i), x(o, s);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function ni(e) {
  let t,
    o,
    n,
    i,
    s,
    a,
    l,
    u,
    g,
    m,
    f,
    w = !1;
  a = new ic({ props: { name: e[4] } });
  const b = e[6].default,
    v = c(b, e, e[5], null);
  return (
    (g = H(e[10][0])),
    {
      c() {
        (t = P("label")),
          (o = P("input")),
          (n = E()),
          (i = P("div")),
          (s = P("div")),
          Ue(a.$$.fragment),
          (l = E()),
          v && v.c(),
          (o.disabled = e[2]),
          B(o, "name", "type"),
          F(o, "radio"),
          (o.__value = e[1]),
          q(o, o.__value),
          B(o, "class", "svelte-1ycj9sv"),
          B(s, "class", "icon svelte-1ycj9sv"),
          B(i, "class", "label svelte-1ycj9sv"),
          Z(i, "selected", e[3]),
          B(t, "class", "link svelte-1ycj9sv"),
          Z(t, "active", e[0] === e[1]),
          Z(t, "disabled", e[2]),
          g.p(o);
      },
      m(r, c) {
        A(r, t, c),
          x(t, o),
          (o.checked = o.__value === e[0]),
          x(t, n),
          x(t, i),
          x(i, s),
          Be(a, s, null),
          x(i, l),
          v && v.m(i, null),
          (u = !0),
          m ||
            ((f = [
              _(o, "change", e[9]),
              _(o, "change", e[8]),
              _(t, "dblclick", e[7]),
            ]),
            (m = !0));
      },
      p(e, [n]) {
        (!u || 4 & n) && (o.disabled = e[2]),
          (!u || 2 & n) && ((o.__value = e[1]), q(o, o.__value), (w = !0)),
          (w || 1 & n) && (o.checked = o.__value === e[0]);
        const r = {};
        16 & n && (r.name = e[4]),
          a.$set(r),
          v &&
            v.p &&
            (!u || 32 & n) &&
            h(v, b, e, e[5], u ? d(b, e[5], n, null) : p(e[5]), null),
          (!u || 8 & n) && Z(i, "selected", e[3]),
          (!u || 3 & n) && Z(t, "active", e[0] === e[1]),
          (!u || 4 & n) && Z(t, "disabled", e[2]);
      },
      i(e) {
        u || ($e(a.$$.fragment, e), $e(v, e), (u = !0));
      },
      o(e) {
        Ce(a.$$.fragment, e), Ce(v, e), (u = !1);
      },
      d(e) {
        e && T(t), Ve(a), v && v.d(e), g.r(), (m = !1), r(f);
      },
    }
  );
}
function ri(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { value: i } = t,
    { disabled: s = !1 } = t,
    { group: a } = t,
    { selected: l = !1 } = t,
    { icon: c } = t;
  return (
    (e.$$set = (e) => {
      "value" in e && o(1, (i = e.value)),
        "disabled" in e && o(2, (s = e.disabled)),
        "group" in e && o(0, (a = e.group)),
        "selected" in e && o(3, (l = e.selected)),
        "icon" in e && o(4, (c = e.icon)),
        "$$scope" in e && o(5, (r = e.$$scope));
    }),
    [
      a,
      i,
      s,
      l,
      c,
      r,
      n,
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function () {
        (a = this.__value), o(0, a);
      },
      [[]],
    ]
  );
}
function ii(t) {
  let o, n;
  return {
    c() {
      (o = M("svg")),
        (n = M("path")),
        B(
          n,
          "d",
          "M7 8V10C6.48716 10 6.06449 10.386 6.00673 10.8834L6 11V18C6 18.5128 6.38604 18.9355 6.88338 18.9933L7 19H12C12.5128 19 12.9355 18.614 12.9933 18.1166L13 18H15V19C15 20.1046 14.1046 21 13 21H6C4.89543 21 4 20.1046 4 19V10C4 8.89543 4.89543 8 6 8H7ZM18 3C19.1046 3 20 3.89543 20 5V14C20 15.1046 19.1046 16 18 16H11C9.89543 16 9 15.1046 9 14V5C9 3.89543 9.89543 3 11 3H18ZM17 5H12C11.4872 5 11.0645 5.38604 11.0067 5.88338L11 6V13C11 13.5128 11.386 13.9355 11.8834 13.9933L12 14H17C17.5128 14 17.9355 13.614 17.9933 13.1166L18 13V6C18 5.48716 17.614 5.06449 17.1166 5.00673L17 5Z"
        ),
        B(o, "width", "24"),
        B(o, "height", "24"),
        B(o, "viewBox", "0 0 24 24"),
        B(o, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(e, t) {
      A(e, o, t), x(o, n);
    },
    p: e,
    i: e,
    o: e,
    d(e) {
      e && T(o);
    },
  };
}
function si(e) {
  let t, o, n, r;
  const i = e[6].default,
    s = c(i, e, e[5], null);
  return {
    c() {
      (t = P("span")),
        s && s.c(),
        (o = E()),
        (n = L(e[1])),
        B(t, "class", "error svelte-7fm1hd"),
        B(t, "title", e[1]);
    },
    m(e, i) {
      A(e, t, i), s && s.m(t, null), x(t, o), x(t, n), (r = !0);
    },
    p(e, o) {
      s &&
        s.p &&
        (!r || 32 & o) &&
        h(s, i, e, e[5], r ? d(i, e[5], o, null) : p(e[5]), null),
        (!r || 2 & o) && R(n, e[1]),
        (!r || 2 & o) && B(t, "title", e[1]);
    },
    i(e) {
      r || ($e(s, e), (r = !0));
    },
    o(e) {
      Ce(s, e), (r = !1);
    },
    d(e) {
      e && T(t), s && s.d(e);
    },
  };
}
function ai(e) {
  let t, o, n, r, i, s;
  const a = e[6].default,
    l = c(a, e, e[5], null);
  return {
    c() {
      (t = P("button")),
        l && l.c(),
        (o = E()),
        (n = L(e[0])),
        B(t, "class", "button svelte-7fm1hd"),
        B(t, "type", "button"),
        B(t, "title", e[0]);
    },
    m(a, c) {
      A(a, t, c),
        l && l.m(t, null),
        x(t, o),
        x(t, n),
        (r = !0),
        i || ((s = _(t, "click", e[3])), (i = !0));
    },
    p(e, o) {
      l &&
        l.p &&
        (!r || 32 & o) &&
        h(l, a, e, e[5], r ? d(a, e[5], o, null) : p(e[5]), null),
        (!r || 1 & o) && R(n, e[0]),
        (!r || 1 & o) && B(t, "title", e[0]);
    },
    i(e) {
      r || ($e(l, e), (r = !0));
    },
    o(e) {
      Ce(l, e), (r = !1);
    },
    d(e) {
      e && T(t), l && l.d(e), (i = !1), s();
    },
  };
}
function li(e) {
  function t(e, t) {
    return e[2] ? 1 : 0;
  }
  let o, n, r, i;
  const s = [ai, si],
    a = [];
  return (
    (o = t(e)),
    (n = a[o] = s[o](e)),
    {
      c() {
        n.c(), (r = D());
      },
      m(e, t) {
        a[o].m(e, t), A(e, r, t), (i = !0);
      },
      p(e, [i]) {
        let l = o;
        (o = t(e)),
          o === l
            ? a[o].p(e, i)
            : (ve(),
              Ce(a[l], 1, 1, () => {
                a[l] = null;
              }),
              ye(),
              (n = a[o]),
              n ? n.p(e, i) : ((n = a[o] = s[o](e)), n.c()),
              $e(n, 1),
              n.m(r.parentNode, r));
      },
      i(e) {
        i || ($e(n), (i = !0));
      },
      o(e) {
        Ce(n), (i = !1);
      },
      d(e) {
        e && T(r), a[o].d(e);
      },
    }
  );
}
function ci(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t;
  const i = ae();
  let s = !1,
    { copyText: a = window.tr(window.lang.login.copyToClipboard.copy) } = t,
    {
      errorText: l = window.tr(window.lang.login.copyToClipboard.unsupported),
    } = t;
  return (
    (e.$$set = (e) => {
      "copyText" in e && o(0, (a = e.copyText)),
        "errorText" in e && o(1, (l = e.errorText)),
        "$$scope" in e && o(5, (r = e.$$scope));
    }),
    [
      a,
      l,
      s,
      function () {
        i("copy");
      },
      async function (e) {
        try {
          await navigator.clipboard.writeText(e);
        } catch (t) {
          o(2, (s = !0));
        }
      },
      r,
      n,
    ]
  );
}
function ui(t) {
  let o, n;
  return (
    (o = new ic({ props: { name: bu } })),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p: e,
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function di(e) {
  let t, o, n, r, i;
  return (
    (r = new vu({
      props: { $$slots: { default: [ui] }, $$scope: { ctx: e } },
    })),
    e[4](r),
    r.$on("copy", e[1]),
    {
      c() {
        (t = P("div")),
          (o = P("div")),
          (o.textContent =
            "Please keep your username and passwords in a safe place"),
          (n = E()),
          Ue(r.$$.fragment),
          B(o, "class", "text svelte-1oeb727"),
          B(t, "class", "copy svelte-1oeb727");
      },
      m(e, s) {
        A(e, t, s), x(t, o), x(t, n), Be(r, t, null), (i = !0);
      },
      p(e, [t]) {
        const o = {};
        32 & t && (o.$$scope = { dirty: t, ctx: e }), r.$set(o);
      },
      i(e) {
        i || ($e(r.$$.fragment, e), (i = !0));
      },
      o(e) {
        Ce(r.$$.fragment, e), (i = !1);
      },
      d(o) {
        o && T(t), e[4](null), Ve(r);
      },
    }
  );
}
function hi(e, t, o) {
  let n,
    { user: r } = t,
    { investor: i } = t;
  return (
    (e.$$set = (e) => {
      "user" in e && o(2, (r = e.user)),
        "investor" in e && o(3, (i = e.investor));
    }),
    [
      n,
      async function () {
        if (!r) return;
        let e = "";
        const {
          name: t,
          server: o,
          group: s,
          currency: a,
          login: l,
          password: c,
        } = r;
        (e += t ? `${window.tr(window.lang.login.form.name.title)}: ${t}` : ""),
          (e += `\n${window.tr(window.lang.login.form.server)}: ${o}`),
          (e +=
            void 0 !== s && a
              ? `\n${window.tr(window.lang.login.form.type)}: ${s}`
              : ""),
          (e += `\n${window.tr(window.lang.login.form.login)}: ${l}`),
          (e += `\n${window.tr(window.lang.login.form.password)}: ${c}`),
          (e += i
            ? `\n${window.tr(window.lang.login.form.investor)}: ${i}`
            : ""),
          n.copy(e);
      },
      r,
      i,
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (n = e), o(0, n);
        });
      },
    ]
  );
}
function pi(e) {
  let t,
    o,
    n,
    i,
    s,
    a,
    l,
    u,
    g,
    m,
    f,
    w,
    b = !1;
  a = new ic({ props: { name: e[5] } });
  const v = e[7].default,
    y = c(v, e, e[6], null);
  return (
    (m = H(e[11][0])),
    {
      c() {
        (t = P("label")),
          (o = P("input")),
          (n = E()),
          (i = P("div")),
          (s = P("div")),
          Ue(a.$$.fragment),
          (l = E()),
          (u = P("div")),
          y && y.c(),
          (o.disabled = e[3]),
          B(o, "name", "type"),
          F(o, "radio"),
          (o.__value = e[1]),
          q(o, o.__value),
          B(o, "class", "svelte-1r40nf8"),
          B(s, "class", "icon svelte-1r40nf8"),
          B(u, "class", "title svelte-1r40nf8"),
          B(i, "class", "label svelte-1r40nf8"),
          Z(i, "selected", e[4]),
          B(t, "class", "link svelte-1r40nf8"),
          Z(t, "active", e[0] === e[1] || e[2]),
          Z(t, "disabled", e[3]),
          m.p(o);
      },
      m(r, c) {
        A(r, t, c),
          x(t, o),
          (o.checked = o.__value === e[0]),
          x(t, n),
          x(t, i),
          x(i, s),
          Be(a, s, null),
          x(i, l),
          x(i, u),
          y && y.m(u, null),
          (g = !0),
          f ||
            ((w = [
              _(o, "change", e[10]),
              _(o, "change", e[9]),
              _(t, "dblclick", e[8]),
            ]),
            (f = !0));
      },
      p(e, [n]) {
        (!g || 8 & n) && (o.disabled = e[3]),
          (!g || 2 & n) && ((o.__value = e[1]), q(o, o.__value), (b = !0)),
          (b || 1 & n) && (o.checked = o.__value === e[0]);
        const r = {};
        32 & n && (r.name = e[5]),
          a.$set(r),
          y &&
            y.p &&
            (!g || 64 & n) &&
            h(y, v, e, e[6], g ? d(v, e[6], n, null) : p(e[6]), null),
          (!g || 16 & n) && Z(i, "selected", e[4]),
          (!g || 7 & n) && Z(t, "active", e[0] === e[1] || e[2]),
          (!g || 8 & n) && Z(t, "disabled", e[3]);
      },
      i(e) {
        g || ($e(a.$$.fragment, e), $e(y, e), (g = !0));
      },
      o(e) {
        Ce(a.$$.fragment, e), Ce(y, e), (g = !1);
      },
      d(e) {
        e && T(t), Ve(a), y && y.d(e), m.r(), (f = !1), r(w);
      },
    }
  );
}
function gi(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { value: i } = t,
    { checked: s = !1 } = t,
    { disabled: a = !1 } = t,
    { group: l } = t,
    { selected: c = !1 } = t,
    { icon: u } = t;
  return (
    (e.$$set = (e) => {
      "value" in e && o(1, (i = e.value)),
        "checked" in e && o(2, (s = e.checked)),
        "disabled" in e && o(3, (a = e.disabled)),
        "group" in e && o(0, (l = e.group)),
        "selected" in e && o(4, (c = e.selected)),
        "icon" in e && o(5, (u = e.icon)),
        "$$scope" in e && o(6, (r = e.$$scope));
    }),
    [
      l,
      i,
      s,
      a,
      c,
      u,
      r,
      n,
      function (t) {
        ue.call(this, e, t);
      },
      function (t) {
        ue.call(this, e, t);
      },
      function () {
        (l = this.__value), o(0, l);
      },
      [[]],
    ]
  );
}
function mi(e) {
  e[29] = e[30].default;
}
function fi(e) {
  let t, o;
  return (
    (t = new su({
      props: {
        $$slots: { footer: [Ti], title: [ki], default: [Si] },
        $$scope: { ctx: e },
      },
    })),
    t.$on("submit", e[7]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        (5 & o[0]) | (1 & o[1]) && (n.$$scope = { dirty: o, ctx: e }),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function wi(t) {
  let o, n;
  return (
    (o = new tu({})),
    o.$on("back", t[6]),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p: e,
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function bi(e) {
  let t,
    o,
    n = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: Mi,
      then: Pi,
      catch: Oi,
      value: 30,
      blocks: [, , ,],
    };
  return (
    Ae(
      Ys(() => import("./0c47227d.js"), ["0c47227d.js", "917b70f1.css"]),
      n
    ),
    {
      c() {
        (t = D()), n.block.c();
      },
      m(e, r) {
        A(e, t, r),
          n.block.m(e, (n.anchor = r)),
          (n.mount = () => t.parentNode),
          (n.anchor = t),
          (o = !0);
      },
      p(t, o) {
        Te(n, (e = t), o);
      },
      i(e) {
        o || ($e(n.block), (o = !0));
      },
      o(e) {
        for (let t = 0; t < 3; t += 1) Ce(n.blocks[t]);
        o = !1;
      },
      d(e) {
        e && T(t), n.block.d(e), (n.token = null), (n = null);
      },
    }
  );
}
function vi(t) {
  let o,
    n = window.tr(window.lang.login.connect.savePassword) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function yi(e) {
  function t(t) {
    e[14](t);
  }
  function o(t) {
    e[15](t);
  }
  function n(t) {
    e[16](t);
  }
  function r(t) {
    e[17](t);
  }
  let i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g = {
      width: e[0] ? "100%" : 41,
      name: "password",
      type: "password",
      placeholder: window.tr(window.lang.login.connect.passwordPlaceholder),
    };
  void 0 !== e[2].connect.values.password &&
    (g.value = e[2].connect.values.password),
    void 0 !== e[2].connect.errors && (g.errors = e[2].connect.errors),
    void 0 !== e[2].connect.focus && (g.focus = e[2].connect.focus),
    (s = new Jc({ props: g })),
    ca.push(() => _e(s, "value", t)),
    ca.push(() => _e(s, "errors", o)),
    ca.push(() => _e(s, "focus", n)),
    s.$on("input", Ei);
  let m = { $$slots: { default: [vi] }, $$scope: { ctx: e } };
  return (
    void 0 !== e[2].connect.values.savePassword &&
      (m.checked = e[2].connect.values.savePassword),
    (d = new Ic({ props: m })),
    ca.push(() => _e(d, "checked", r)),
    {
      c() {
        (i = P("div")),
          Ue(s.$$.fragment),
          (u = E()),
          Ue(d.$$.fragment),
          B(i, "class", "password svelte-eod3wu");
      },
      m(e, t) {
        A(e, i, t), Be(s, i, null), x(i, u), Be(d, i, null), (p = !0);
      },
      p(e, t) {
        const o = {};
        1 & t[0] && (o.width = e[0] ? "100%" : 41),
          !a &&
            4 & t[0] &&
            ((a = !0),
            (o.value = e[2].connect.values.password),
            ge(() => (a = !1))),
          !l &&
            4 & t[0] &&
            ((l = !0), (o.errors = e[2].connect.errors), ge(() => (l = !1))),
          !c &&
            4 & t[0] &&
            ((c = !0), (o.focus = e[2].connect.focus), ge(() => (c = !1))),
          s.$set(o);
        const n = {};
        1 & t[1] && (n.$$scope = { dirty: t, ctx: e }),
          !h &&
            4 & t[0] &&
            ((h = !0),
            (n.checked = e[2].connect.values.savePassword),
            ge(() => (h = !1))),
          d.$set(n);
      },
      i(e) {
        p || ($e(s.$$.fragment, e), $e(d.$$.fragment, e), (p = !0));
      },
      o(e) {
        Ce(s.$$.fragment, e), Ce(d.$$.fragment, e), (p = !1);
      },
      d(e) {
        e && T(i), Ve(s), Ve(d);
      },
    }
  );
}
function $i(t) {
  let o, n, r, i, s, a;
  return {
    c() {
      (o = P("div")),
        (n = P("span")),
        (n.textContent = `${window.tr(
          window.lang.login.connect.forgotPassword
        )}`),
        (r = E()),
        (i = P("button")),
        (i.textContent = `${window.tr(
          window.lang.login.connect.contactBroker
        )}`),
        B(n, "class", "secondary svelte-eod3wu"),
        B(i, "type", "button"),
        B(i, "class", "svelte-eod3wu"),
        B(o, "class", "recovery svelte-eod3wu");
    },
    m(e, l) {
      A(e, o, l),
        x(o, n),
        x(o, r),
        x(o, i),
        s || ((a = _(i, "click", t[6])), (s = !0));
    },
    p: e,
    d(e) {
      e && T(o), (s = !1), a();
    },
  };
}
function Ci(e) {
  let t, o, n, r;
  return (
    (t = new hc({
      props: { $$slots: { default: [yi] }, $$scope: { ctx: e } },
    })),
    (n = new hc({
      props: { $$slots: { default: [$i] }, $$scope: { ctx: e } },
    })),
    {
      c() {
        Ue(t.$$.fragment), (o = E()), Ue(n.$$.fragment);
      },
      m(e, i) {
        Be(t, e, i), A(e, o, i), Be(n, e, i), (r = !0);
      },
      p(e, o) {
        const r = {};
        (5 & o[0]) | (1 & o[1]) && (r.$$scope = { dirty: o, ctx: e }),
          t.$set(r);
        const i = {};
        1 & o[1] && (i.$$scope = { dirty: o, ctx: e }), n.$set(i);
      },
      i(e) {
        r || ($e(t.$$.fragment, e), $e(n.$$.fragment, e), (r = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), Ce(n.$$.fragment, e), (r = !1);
      },
      d(e) {
        e && T(o), Ve(t, e), Ve(n, e);
      },
    }
  );
}
function xi(e) {
  function t(t) {
    e[18](t);
  }
  function o(t) {
    e[19](t);
  }
  function n(t) {
    e[20](t);
  }
  let r,
    i,
    s,
    a,
    l,
    c,
    u,
    d = {
      name: "otp",
      placeholder: window.tr(window.lang.login.otp.placeholder),
    };
  return (
    void 0 !== e[2].connect.values.otp && (d.value = e[2].connect.values.otp),
    void 0 !== e[2].connect.errors && (d.errors = e[2].connect.errors),
    void 0 !== e[2].connect.focus && (d.focus = e[2].connect.focus),
    (s = new Jc({ props: d })),
    ca.push(() => _e(s, "value", t)),
    ca.push(() => _e(s, "errors", o)),
    ca.push(() => _e(s, "focus", n)),
    {
      c() {
        (r = P("div")),
          (r.textContent = "OTP"),
          (i = E()),
          Ue(s.$$.fragment),
          B(r, "class", "field svelte-eod3wu");
      },
      m(e, t) {
        A(e, r, t), A(e, i, t), Be(s, e, t), (u = !0);
      },
      p(e, t) {
        const o = {};
        !a &&
          4 & t[0] &&
          ((a = !0), (o.value = e[2].connect.values.otp), ge(() => (a = !1))),
          !l &&
            4 & t[0] &&
            ((l = !0), (o.errors = e[2].connect.errors), ge(() => (l = !1))),
          !c &&
            4 & t[0] &&
            ((c = !0), (o.focus = e[2].connect.focus), ge(() => (c = !1))),
          s.$set(o);
      },
      i(e) {
        u || ($e(s.$$.fragment, e), (u = !0));
      },
      o(e) {
        Ce(s.$$.fragment, e), (u = !1);
      },
      d(e) {
        e && (T(r), T(i)), Ve(s, e);
      },
    }
  );
}
function Si(e) {
  function t(t) {
    e[11](t);
  }
  function o(t) {
    e[12](t);
  }
  function n(t) {
    e[13](t);
  }
  let r,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $,
    C = e[2].connect.values.server + "",
    S = {
      name: "login",
      autocomplete: "username",
      width: e[0] ? "100%" : 41,
      placeholder: window.tr(window.lang.login.connect.loginPlaceholder),
    };
  void 0 !== e[2].connect.values.login && (S.value = e[2].connect.values.login),
    void 0 !== e[2].connect.errors && (S.errors = e[2].connect.errors),
    void 0 !== e[2].connect.focus && (S.focus = e[2].connect.focus),
    (s = new Jc({ props: S })),
    ca.push(() => _e(s, "value", t)),
    ca.push(() => _e(s, "errors", o)),
    ca.push(() => _e(s, "focus", n)),
    s.$on("input", Ei),
    (p = new hc({
      props: { gap: 1, $$slots: { default: [Ci] }, $$scope: { ctx: e } },
    }));
  let k = e[2].connect.showOtp && xi(e);
  return {
    c() {
      (r = P("div")),
        (r.textContent = `${window.tr(window.lang.login.form.login)}`),
        (i = E()),
        Ue(s.$$.fragment),
        (u = E()),
        (d = P("div")),
        (d.textContent = `${window.tr(window.lang.login.form.password)}`),
        (h = E()),
        Ue(p.$$.fragment),
        (g = E()),
        (m = P("div")),
        (m.textContent = `${window.tr(window.lang.login.form.server)}`),
        (f = E()),
        (w = P("div")),
        (b = L(C)),
        (v = E()),
        k && k.c(),
        (y = D()),
        B(r, "class", "field svelte-eod3wu"),
        B(d, "class", "field svelte-eod3wu"),
        B(m, "class", "field svelte-eod3wu"),
        B(w, "class", "field svelte-eod3wu");
    },
    m(e, t) {
      A(e, r, t),
        A(e, i, t),
        Be(s, e, t),
        A(e, u, t),
        A(e, d, t),
        A(e, h, t),
        Be(p, e, t),
        A(e, g, t),
        A(e, m, t),
        A(e, f, t),
        A(e, w, t),
        x(w, b),
        A(e, v, t),
        k && k.m(e, t),
        A(e, y, t),
        ($ = !0);
    },
    p(e, t) {
      const o = {};
      1 & t[0] && (o.width = e[0] ? "100%" : 41),
        !a &&
          4 & t[0] &&
          ((a = !0), (o.value = e[2].connect.values.login), ge(() => (a = !1))),
        !l &&
          4 & t[0] &&
          ((l = !0), (o.errors = e[2].connect.errors), ge(() => (l = !1))),
        !c &&
          4 & t[0] &&
          ((c = !0), (o.focus = e[2].connect.focus), ge(() => (c = !1))),
        s.$set(o);
      const n = {};
      (5 & t[0]) | (1 & t[1]) && (n.$$scope = { dirty: t, ctx: e }),
        p.$set(n),
        (!$ || 4 & t[0]) &&
          C !== (C = e[2].connect.values.server + "") &&
          R(b, C),
        e[2].connect.showOtp
          ? k
            ? (k.p(e, t), 4 & t[0] && $e(k, 1))
            : ((k = xi(e)), k.c(), $e(k, 1), k.m(y.parentNode, y))
          : k &&
            (ve(),
            Ce(k, 1, 1, () => {
              k = null;
            }),
            ye());
    },
    i(e) {
      $ || ($e(s.$$.fragment, e), $e(p.$$.fragment, e), $e(k), ($ = !0));
    },
    o(e) {
      Ce(s.$$.fragment, e), Ce(p.$$.fragment, e), Ce(k), ($ = !1);
    },
    d(e) {
      e && (T(r), T(i), T(u), T(d), T(h), T(g), T(m), T(f), T(w), T(v), T(y)),
        Ve(s, e),
        Ve(p, e),
        k && k.d(e);
    },
  };
}
function ki(t) {
  let o,
    n = window.tr(window.lang.login.connect.title) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Ai(t) {
  let o,
    n = window.tr(window.lang.login.connect.btnConnect) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Ti(e) {
  let t, o, n;
  return (
    (o = new mc({
      props: {
        type: "submit",
        disabled: !1,
        active: !0,
        $$slots: { default: [Ai] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        (t = P("div")),
          Ue(o.$$.fragment),
          B(t, "class", "footer svelte-eod3wu");
      },
      m(e, r) {
        A(e, t, r), Be(o, t, null), (n = !0);
      },
      p(e, t) {
        const n = {};
        1 & t[1] && (n.$$scope = { dirty: t, ctx: e }), o.$set(n);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        e && T(t), Ve(o);
      },
    }
  );
}
function Oi(t) {
  return { c: e, m: e, p: e, i: e, o: e, d: e };
}
function Pi(e) {
  let t, o;
  return (
    mi(e),
    (t = new e[29]({
      props: {
        login: e[2].connect.values.login,
        server: e[2].connect.values.server,
        password: e[2].connect.values.password,
      },
    })),
    t.$on("success", e[8]),
    t.$on("error", e[9]),
    t.$on("cancel", e[10]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        mi(e);
        const n = {};
        4 & o[0] && (n.login = e[2].connect.values.login),
          4 & o[0] && (n.server = e[2].connect.values.server),
          4 & o[0] && (n.password = e[2].connect.values.password),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Mi(t) {
  let o, n;
  return (
    (o = new Ca({})),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p: e,
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function Li(e) {
  function t(e, t) {
    return e[2].connect.showOtpConnect ? 0 : e[1] ? 1 : 2;
  }
  let o, n, r, i;
  const s = [bi, wi, fi],
    a = [];
  return (
    (o = t(e)),
    (n = a[o] = s[o](e)),
    {
      c() {
        n.c(), (r = D());
      },
      m(e, t) {
        a[o].m(e, t), A(e, r, t), (i = !0);
      },
      p(e, i) {
        let l = o;
        (o = t(e)),
          o === l
            ? a[o].p(e, i)
            : (ve(),
              Ce(a[l], 1, 1, () => {
                a[l] = null;
              }),
              ye(),
              (n = a[o]),
              n ? n.p(e, i) : ((n = a[o] = s[o](e)), n.c()),
              $e(n, 1),
              n.m(r.parentNode, r));
      },
      i(e) {
        i || ($e(n), (i = !0));
      },
      o(e) {
        Ce(n), (i = !1);
      },
      d(e) {
        e && T(r), a[o].d(e);
      },
    }
  );
}
function Ei() {}
function Di(e, t, o) {
  async function n() {
    b(d, (r.connect.errors = v.validate(r.connect.values)), r),
      Object.keys(r.connect.errors).length > 0
        ? b(d, (r.connect.focus = Object.keys(r.connect.errors)[0]), r)
        : (await u.connect()) &&
          (i.setLayout({ auth: Vl.None }), Ga.remove("login"), h("submit"));
  }
  let r, i, s;
  const a = tc.users.usersStore;
  l(e, a, (e) => o(22, (s = e)));
  const c = tc.layout.layoutStore;
  l(e, c, (e) => o(21, (i = e)));
  const u = Ac.authController,
    d = Ac.authStore;
  l(e, d, (e) => o(2, (r = e)));
  const h = ae();
  let { mobile: p } = t,
    g = !1;
  const m = s.getCurrentUser(),
    f = Ga.get("login"),
    w = {
      login: { value: f || _l.login || "", validators: ["required", "number"] },
      password: { value: "", validators: ["required"] },
      server: {
        value: f
          ? _l.tradeServerReal
          : (null == m ? void 0 : m.server) ?? _l.tradeServerReal,
        validators: ["required"],
      },
      otp: { validators: ["required"], disabled: !0 },
    },
    v = new eu(w);
  return (
    b(d, (r.connect.values = v.getValues(w)), r),
    b(
      d,
      (r.connect.values.savePassword = m
        ? Boolean(null == m ? void 0 : m.password)
        : r.connect.values.savePassword),
      r
    ),
    se(() => {
      b(d, (r.connect.showOtp = !1), r),
        b(d, (r.connect.showOtpConnect = !1), r);
    }),
    (e.$$set = (e) => {
      "mobile" in e && o(0, (p = e.mobile));
    }),
    [
      p,
      g,
      r,
      a,
      c,
      d,
      function () {
        o(1, (g = !g));
      },
      n,
      function () {
        b(d, (r.connect.showOtpConnect = !1), r), n();
      },
      function (e) {
        b(d, (r.connect.error = e.detail), r);
      },
      function () {
        b(d, (r.connect.showOtpConnect = !1), r);
      },
      function (t) {
        e.$$.not_equal(r.connect.values.login, t) &&
          ((r.connect.values.login = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.errors, t) &&
          ((r.connect.errors = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.focus, t) && ((r.connect.focus = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.values.password, t) &&
          ((r.connect.values.password = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.errors, t) &&
          ((r.connect.errors = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.focus, t) && ((r.connect.focus = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.values.savePassword, t) &&
          ((r.connect.values.savePassword = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.values.otp, t) &&
          ((r.connect.values.otp = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.errors, t) &&
          ((r.connect.errors = t), d.set(r));
      },
      function (t) {
        e.$$.not_equal(r.connect.focus, t) && ((r.connect.focus = t), d.set(r));
      },
    ]
  );
}
function _i(e) {
  e[37] = e[36].default;
}
function Ui(e) {
  e[35] = e[36].default;
}
function Bi(e, t, o) {
  const n = e.slice();
  return (n[38] = t[o]), n;
}
function Vi(t) {
  let o,
    n = window.tr(window.lang.login.connect.title) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function ji(t) {
  let o,
    n = window.tr(window.lang.login.demo.title) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function zi(t) {
  let o,
    n = window.tr(window.lang.login.real.title) + "";
  return {
    c() {
      o = L(n);
    },
    m(e, t) {
      A(e, o, t);
    },
    p: e,
    d(e) {
      e && T(o);
    },
  };
}
function Ii(e) {
  let t,
    o,
    n = Oe(e[10]),
    r = [];
  for (let s = 0; s < n.length; s += 1) r[s] = Ni(Bi(e, n, s));
  const i = (e) =>
    Ce(r[e], 1, 1, () => {
      r[e] = null;
    });
  return {
    c() {
      t = P("div");
      for (let e = 0; e < r.length; e += 1) r[e].c();
      B(t, "class", "accounts svelte-jdc7pc");
    },
    m(e, n) {
      A(e, t, n);
      for (let o = 0; o < r.length; o += 1) r[o] && r[o].m(t, null);
      o = !0;
    },
    p(e, o) {
      if (263360 & o[0]) {
        let s;
        for (n = Oe(e[10]), s = 0; s < n.length; s += 1) {
          const i = Bi(e, n, s);
          r[s]
            ? (r[s].p(i, o), $e(r[s], 1))
            : ((r[s] = Ni(i)), r[s].c(), $e(r[s], 1), r[s].m(t, null));
        }
        for (ve(), s = n.length; s < r.length; s += 1) i(s);
        ye();
      }
    },
    i(e) {
      if (!o) {
        for (let e = 0; e < n.length; e += 1) $e(r[e]);
        o = !0;
      }
    },
    o(e) {
      r = r.filter(xu);
      for (let t = 0; t < r.length; t += 1) Ce(r[t]);
      o = !1;
    },
    d(e) {
      e && T(t), O(r, e);
    },
  };
}
function Hi(e) {
  var t;
  let o,
    n,
    r,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g = e[38].name + "",
    m = e[38].login + "",
    f = ct((null == (t = e[38]) ? void 0 : t.balance) ?? 0, 2) + "",
    w = e[38].currency + "";
  return {
    c() {
      (o = P("div")),
        (n = P("div")),
        (r = L(g)),
        (s = E()),
        (a = P("div")),
        (l = L(m)),
        (c = E()),
        (u = L(f)),
        (d = E()),
        (h = L(w)),
        (p = E()),
        B(n, "class", "account-name svelte-jdc7pc"),
        B(n, "title", (i = e[38].name)),
        B(a, "class", "account-info svelte-jdc7pc"),
        B(o, "class", "account-item svelte-jdc7pc");
    },
    m(e, t) {
      A(e, o, t),
        x(o, n),
        x(n, r),
        x(o, s),
        x(o, a),
        x(a, l),
        x(a, c),
        x(a, u),
        x(a, d),
        x(a, h),
        A(e, p, t);
    },
    p(e, t) {
      var o;
      1024 & t[0] && g !== (g = e[38].name + "") && R(r, g),
        1024 & t[0] && i !== (i = e[38].name) && B(n, "title", i),
        1024 & t[0] && m !== (m = e[38].login + "") && R(l, m),
        1024 & t[0] &&
          f !==
            (f = ct((null == (o = e[38]) ? void 0 : o.balance) ?? 0, 2) + "") &&
          R(u, f),
        1024 & t[0] && w !== (w = e[38].currency + "") && R(h, w);
    },
    d(e) {
      e && (T(o), T(p));
    },
  };
}
function Ni(e) {
  function t(t) {
    e[28](t);
  }
  var o;
  let n,
    r,
    i,
    s = {
      value: e[38].id,
      icon: ls(e[38].type),
      disabled: e[6].otpForm,
      selected:
        (null == (o = e[7].modules) ? void 0 : o.account.accountStore.login) ===
        e[38].login,
      $$slots: { default: [Hi] },
      $$scope: { ctx: e },
    };
  return (
    void 0 !== e[6].auth && (s.group = e[6].auth),
    (n = new wu({ props: s })),
    ca.push(() => _e(n, "group", t)),
    n.$on("change", e[18]),
    {
      c() {
        Ue(n.$$.fragment);
      },
      m(e, t) {
        Be(n, e, t), (i = !0);
      },
      p(e, t) {
        var o;
        const i = {};
        1024 & t[0] && (i.value = e[38].id),
          1024 & t[0] && (i.icon = ls(e[38].type)),
          64 & t[0] && (i.disabled = e[6].otpForm),
          1152 & t[0] &&
            (i.selected =
              (null == (o = e[7].modules)
                ? void 0
                : o.account.accountStore.login) === e[38].login),
          (1024 & t[0]) | (1024 & t[1]) && (i.$$scope = { dirty: t, ctx: e }),
          !r &&
            64 & t[0] &&
            ((r = !0), (i.group = e[6].auth), ge(() => (r = !1))),
          n.$set(i);
      },
      i(e) {
        i || ($e(n.$$.fragment, e), (i = !0));
      },
      o(e) {
        Ce(n.$$.fragment, e), (i = !1);
      },
      d(e) {
        Ve(n, e);
      },
    }
  );
}
function Ri(e) {
  let t, o, n, r, i;
  return (
    (o = new Cu({ props: { mobile: e[6].isMobile } })),
    o.$on("submit", e[16]),
    {
      c() {
        (t = P("div")),
          Ue(o.$$.fragment),
          B(t, "class", "wrap-connect svelte-jdc7pc");
      },
      m(e, n) {
        A(e, t, n), Be(o, t, null), (i = !0);
      },
      p(t, n) {
        e = t;
        const r = {};
        64 & n[0] && (r.mobile = e[6].isMobile), o.$set(r);
      },
      i(s) {
        i ||
          ($e(o.$$.fragment, s),
          s &&
            pe(() => {
              i &&
                (r && r.end(1),
                (n = xe(t, cs, { duration: e[8], main: !0 })),
                n.start());
            }),
          (i = !0));
      },
      o(s) {
        Ce(o.$$.fragment, s),
          n && n.invalidate(),
          s && (r = Se(t, cs, { duration: e[8] })),
          (i = !1);
      },
      d(e) {
        e && T(t), Ve(o), e && r && r.end();
      },
    }
  );
}
function qi(t) {
  let o,
    n,
    r = t[5].id,
    i = Ki(t);
  return {
    c() {
      i.c(), (o = D());
    },
    m(e, t) {
      i.m(e, t), A(e, o, t), (n = !0);
    },
    p(t, n) {
      32 & n[0] && s(r, (r = t[5].id))
        ? (ve(),
          Ce(i, 1, 1, e),
          ye(),
          (i = Ki(t)),
          i.c(),
          $e(i, 1),
          i.m(o.parentNode, o))
        : i.p(t, n);
    },
    i(e) {
      n || ($e(i), (n = !0));
    },
    o(e) {
      Ce(i), (n = !1);
    },
    d(e) {
      e && T(o), i.d(e);
    },
  };
}
function Fi(e) {
  let t,
    o,
    n,
    r,
    i = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: Yi,
      then: Zi,
      catch: Gi,
      value: 36,
      blocks: [, , ,],
    };
  return (
    Ae(
      Ys(
        () => import("./b38e25e8.js"),
        ["b38e25e8.js", "a1151122.js", "6ff0a086.css", "981398f2.css"]
      ),
      i
    ),
    {
      c() {
        (t = P("div")), i.block.c(), B(t, "class", "wrap-real svelte-jdc7pc");
      },
      m(e, o) {
        A(e, t, o),
          i.block.m(t, (i.anchor = null)),
          (i.mount = () => t),
          (i.anchor = null),
          (r = !0);
      },
      p(t, o) {
        Te(i, (e = t), o);
      },
      i(s) {
        r ||
          ($e(i.block),
          s &&
            pe(() => {
              r &&
                (n && n.end(1),
                (o = xe(t, cs, { duration: e[8], main: !0 })),
                o.start());
            }),
          (r = !0));
      },
      o(s) {
        for (let e = 0; e < 3; e += 1) Ce(i.blocks[e]);
        o && o.invalidate(), s && (n = Se(t, cs, { duration: e[8] })), (r = !1);
      },
      d(e) {
        e && T(t), i.block.d(), (i.token = null), (i = null), e && n && n.end();
      },
    }
  );
}
function Wi(e) {
  let t,
    o,
    n,
    r,
    i = {
      ctx: e,
      current: null,
      token: null,
      hasCatch: !1,
      pending: Xi,
      then: Qi,
      catch: Ji,
      value: 36,
      blocks: [, , ,],
    };
  return (
    Ae(
      Ys(
        () => import("./d35b1395.js"),
        ["d35b1395.js", "a1151122.js", "6ff0a086.css", "3d7bfa54.css"]
      ),
      i
    ),
    {
      c() {
        (t = P("div")), i.block.c(), B(t, "class", "wrap-demo svelte-jdc7pc");
      },
      m(e, o) {
        A(e, t, o),
          i.block.m(t, (i.anchor = null)),
          (i.mount = () => t),
          (i.anchor = null),
          (r = !0);
      },
      p(t, o) {
        Te(i, (e = t), o);
      },
      i(s) {
        r ||
          ($e(i.block),
          s &&
            pe(() => {
              r &&
                (n && n.end(1),
                (o = xe(t, cs, { duration: e[8], main: !0 })),
                o.start());
            }),
          (r = !0));
      },
      o(s) {
        for (let e = 0; e < 3; e += 1) Ce(i.blocks[e]);
        o && o.invalidate(), s && (n = Se(t, cs, { duration: e[8] })), (r = !1);
      },
      d(e) {
        e && T(t), i.block.d(), (i.token = null), (i = null), e && n && n.end();
      },
    }
  );
}
function Ki(e) {
  function t(t) {
    e[29](t);
  }
  var o;
  let n,
    r,
    i,
    s,
    a,
    l,
    c = {
      user: e[5],
      mobile: e[6].isMobile,
      current:
        (null == (o = e[7].modules) ? void 0 : o.account.accountStore.login) ===
        e[5].login,
    };
  return (
    void 0 !== e[1] && (c.autoConnect = e[1]),
    (r = new gu({ props: c })),
    ca.push(() => _e(r, "autoConnect", t)),
    r.$on("connect", e[17]),
    r.$on("logout", e[21]),
    r.$on("remove", e[22]),
    {
      c() {
        (n = P("div")),
          Ue(r.$$.fragment),
          B(n, "class", "wrap-existing svelte-jdc7pc");
      },
      m(e, t) {
        A(e, n, t), Be(r, n, null), (l = !0);
      },
      p(t, o) {
        var n;
        e = t;
        const s = {};
        32 & o[0] && (s.user = e[5]),
          64 & o[0] && (s.mobile = e[6].isMobile),
          160 & o[0] &&
            (s.current =
              (null == (n = e[7].modules)
                ? void 0
                : n.account.accountStore.login) === e[5].login),
          !i &&
            2 & o[0] &&
            ((i = !0), (s.autoConnect = e[1]), ge(() => (i = !1))),
          r.$set(s);
      },
      i(t) {
        l ||
          ($e(r.$$.fragment, t),
          t &&
            pe(() => {
              l &&
                (a && a.end(1),
                (s = xe(n, cs, { duration: e[8], main: !0 })),
                s.start());
            }),
          (l = !0));
      },
      o(t) {
        Ce(r.$$.fragment, t),
          s && s.invalidate(),
          t && (a = Se(n, cs, { duration: e[8] })),
          (l = !1);
      },
      d(e) {
        e && T(n), Ve(r), e && a && a.end();
      },
    }
  );
}
function Gi(t) {
  return { c: e, m: e, p: e, i: e, o: e, d: e };
}
function Zi(e) {
  let t, o;
  return (
    _i(e),
    (t = new e[37]({ props: { mobile: e[6].isMobile } })),
    t.$on("success", e[19]),
    t.$on("error", e[20]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        _i(e);
        const n = {};
        64 & o[0] && (n.mobile = e[6].isMobile), t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Yi(t) {
  let o, n, r;
  return (
    (n = new Ca({})),
    {
      c() {
        (o = P("div")),
          Ue(n.$$.fragment),
          B(o, "class", "wrap-real loading svelte-jdc7pc");
      },
      m(e, t) {
        A(e, o, t), Be(n, o, null), (r = !0);
      },
      p: e,
      i(e) {
        r || ($e(n.$$.fragment, e), (r = !0));
      },
      o(e) {
        Ce(n.$$.fragment, e), (r = !1);
      },
      d(e) {
        e && T(o), Ve(n);
      },
    }
  );
}
function Ji(t) {
  return { c: e, m: e, p: e, i: e, o: e, d: e };
}
function Qi(e) {
  let t, o;
  return (
    Ui(e),
    (t = new e[35]({ props: { mobile: e[6].isMobile } })),
    t.$on("success", e[14]),
    t.$on("error", e[15]),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        Ui(e);
        const n = {};
        64 & o[0] && (n.mobile = e[6].isMobile), t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function Xi(t) {
  let o, n, r;
  return (
    (n = new Ca({})),
    {
      c() {
        (o = P("div")),
          Ue(n.$$.fragment),
          B(o, "class", "wrap-demo loading svelte-jdc7pc");
      },
      m(e, t) {
        A(e, o, t), Be(n, o, null), (r = !0);
      },
      p: e,
      i(e) {
        r || ($e(n.$$.fragment, e), (r = !0));
      },
      o(e) {
        Ce(n.$$.fragment, e), (r = !1);
      },
      d(e) {
        e && T(o), Ve(n);
      },
    }
  );
}
function es(e) {
  let t, o;
  return (
    (t = new Ca({ props: { overlay: !0 } })),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function ts(e) {
  function t(e, t) {
    var o, n, r;
    return e[6].auth === Vl.Connect && e[7].connect.error
      ? 0
      : e[6].auth === Vl.OpenDemo && e[3]
      ? 1
      : e[6].auth === Vl.OpenReal && e[4]
      ? 2
      : e[5] && (null == (o = e[7].existing[e[5].login]) ? void 0 : o.error)
      ? 3
      : (null == (n = e[7].createdUser) ? void 0 : n.investor) &&
        e[7].createdUser.id === (null == (r = e[5]) ? void 0 : r.id)
      ? 4
      : -1;
  }
  let o, n, r, i;
  const s = [ss, is, rs, ns, os],
    a = [];
  return (
    ~(n = t(e)) && (r = a[n] = s[n](e)),
    {
      c() {
        (o = P("div")), r && r.c(), B(o, "class", "info svelte-jdc7pc");
      },
      m(e, t) {
        A(e, o, t), ~n && a[n].m(o, null), (i = !0);
      },
      p(e, i) {
        let l = n;
        (n = t(e)),
          n === l
            ? ~n && a[n].p(e, i)
            : (r &&
                (ve(),
                Ce(a[l], 1, 1, () => {
                  a[l] = null;
                }),
                ye()),
              ~n
                ? ((r = a[n]),
                  r ? r.p(e, i) : ((r = a[n] = s[n](e)), r.c()),
                  $e(r, 1),
                  r.m(o, null))
                : (r = null));
      },
      i(e) {
        i || ($e(r), (i = !0));
      },
      o(e) {
        Ce(r), (i = !1);
      },
      d(e) {
        e && T(o), ~n && a[n].d();
      },
    }
  );
}
function os(e) {
  let t, o;
  return (
    (t = new yu({
      props: { user: e[5], investor: e[7].createdUser.investor },
    })),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        32 & o[0] && (n.user = e[5]),
          128 & o[0] && (n.investor = e[7].createdUser.investor),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function ns(e) {
  var t, o;
  let n, r;
  return (
    (n = new dc({
      props: {
        message:
          null == (t = e[7].existing[e[5].login].error) ? void 0 : t.message,
        warning:
          "warning" ===
          (null == (o = e[7].existing[e[5].login].error) ? void 0 : o.type),
      },
    })),
    {
      c() {
        Ue(n.$$.fragment);
      },
      m(e, t) {
        Be(n, e, t), (r = !0);
      },
      p(e, t) {
        var o, r;
        const i = {};
        160 & t[0] &&
          (i.message =
            null == (o = e[7].existing[e[5].login].error) ? void 0 : o.message),
          160 & t[0] &&
            (i.warning =
              "warning" ===
              (null == (r = e[7].existing[e[5].login].error)
                ? void 0
                : r.type)),
          n.$set(i);
      },
      i(e) {
        r || ($e(n.$$.fragment, e), (r = !0));
      },
      o(e) {
        Ce(n.$$.fragment, e), (r = !1);
      },
      d(e) {
        Ve(n, e);
      },
    }
  );
}
function rs(e) {
  var t;
  let o, n;
  return (
    (o = new dc({
      props: {
        message: e[4].message,
        warning: "warning" === (null == (t = e[4]) ? void 0 : t.type),
      },
    })),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p(e, t) {
        var n;
        const r = {};
        16 & t[0] && (r.message = e[4].message),
          16 & t[0] &&
            (r.warning = "warning" === (null == (n = e[4]) ? void 0 : n.type)),
          o.$set(r);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function is(e) {
  var t;
  let o, n;
  return (
    (o = new dc({
      props: {
        message: e[3].message,
        warning: "warning" === (null == (t = e[3]) ? void 0 : t.type),
      },
    })),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p(e, t) {
        var n;
        const r = {};
        8 & t[0] && (r.message = e[3].message),
          8 & t[0] &&
            (r.warning = "warning" === (null == (n = e[3]) ? void 0 : n.type)),
          o.$set(r);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function ss(e) {
  let t, o;
  return (
    (t = new dc({
      props: {
        message: e[7].connect.error.message,
        warning: "warning" === e[7].connect.error.type,
      },
    })),
    {
      c() {
        Ue(t.$$.fragment);
      },
      m(e, n) {
        Be(t, e, n), (o = !0);
      },
      p(e, o) {
        const n = {};
        128 & o[0] && (n.message = e[7].connect.error.message),
          128 & o[0] && (n.warning = "warning" === e[7].connect.error.type),
          t.$set(n);
      },
      i(e) {
        o || ($e(t.$$.fragment, e), (o = !0));
      },
      o(e) {
        Ce(t.$$.fragment, e), (o = !1);
      },
      d(e) {
        Ve(t, e);
      },
    }
  );
}
function as(e) {
  function t(t) {
    e[25](t);
  }
  function o(e, t) {
    return e[6].auth === Vl.OpenDemo
      ? 0
      : e[6].auth === Vl.OpenReal
      ? 1
      : e[5]
      ? 2
      : 3;
  }
  let n,
    r,
    i,
    s,
    a,
    l,
    c,
    u,
    d,
    h,
    p,
    g,
    m,
    f,
    w,
    b,
    v,
    y,
    $ = {
      checked: e[6].isMobile && "string" == typeof e[6].auth,
      value: Vl.Connect,
      icon: Rc,
      disabled: e[6].otpForm,
      $$slots: { default: [Vi] },
      $$scope: { ctx: e },
    };
  void 0 !== e[6].auth && ($.group = e[6].auth),
    (s = new $u({ props: $ })),
    ca.push(() => _e(s, "group", t)),
    s.$on("change", e[18]);
  let C =
      _l.demoGroups.length &&
      (function (e) {
        function t(t) {
          e[26](t);
        }
        let o,
          n,
          r,
          i = {
            value: Vl.OpenDemo,
            icon: Nc,
            disabled: !_l.demoGroups.length || e[6].otpForm,
            $$slots: { default: [ji] },
            $$scope: { ctx: e },
          };
        return (
          void 0 !== e[6].auth && (i.group = e[6].auth),
          (o = new $u({ props: i })),
          ca.push(() => _e(o, "group", t)),
          o.$on("change", e[18]),
          {
            c() {
              Ue(o.$$.fragment);
            },
            m(e, t) {
              Be(o, e, t), (r = !0);
            },
            p(e, t) {
              const r = {};
              64 & t[0] && (r.disabled = !_l.demoGroups.length || e[6].otpForm),
                1024 & t[1] && (r.$$scope = { dirty: t, ctx: e }),
                !n &&
                  64 & t[0] &&
                  ((n = !0), (r.group = e[6].auth), ge(() => (n = !1))),
                o.$set(r);
            },
            i(e) {
              r || ($e(o.$$.fragment, e), (r = !0));
            },
            o(e) {
              Ce(o.$$.fragment, e), (r = !1);
            },
            d(e) {
              Ve(o, e);
            },
          }
        );
      })(e),
    S =
      _l.realGroups.length &&
      (function (e) {
        function t(t) {
          e[27](t);
        }
        let o,
          n,
          r,
          i = {
            value: Vl.OpenReal,
            icon: Hc,
            disabled: !_l.realGroups.length || e[6].otpForm,
            $$slots: { default: [zi] },
            $$scope: { ctx: e },
          };
        return (
          void 0 !== e[6].auth && (i.group = e[6].auth),
          (o = new $u({ props: i })),
          ca.push(() => _e(o, "group", t)),
          o.$on("change", e[18]),
          {
            c() {
              Ue(o.$$.fragment);
            },
            m(e, t) {
              Be(o, e, t), (r = !0);
            },
            p(e, t) {
              const r = {};
              64 & t[0] && (r.disabled = !_l.realGroups.length || e[6].otpForm),
                1024 & t[1] && (r.$$scope = { dirty: t, ctx: e }),
                !n &&
                  64 & t[0] &&
                  ((n = !0), (r.group = e[6].auth), ge(() => (n = !1))),
                o.$set(r);
            },
            i(e) {
              r || ($e(o.$$.fragment, e), (r = !0));
            },
            o(e) {
              Ce(o.$$.fragment, e), (r = !1);
            },
            d(e) {
              Ve(o, e);
            },
          }
        );
      })(e),
    k =
      (!e[6].isMobile ||
        (e[6].isMobile &&
          e[6].auth !== Vl.OpenDemo &&
          e[6].auth !== Vl.OpenReal &&
          e[6].auth !== Vl.CreatedAccount)) &&
      Ii(e);
  const O = [Wi, Fi, qi, Ri],
    M = [];
  (g = o(e)), (m = M[g] = O[g](e));
  let L = e[0] && es(),
    _ = !e[0] && ts(e);
  return {
    c() {
      (n = P("div")),
        (r = P("div")),
        (i = P("div")),
        Ue(s.$$.fragment),
        (l = E()),
        C && C.c(),
        (c = E()),
        S && S.c(),
        (u = E()),
        k && k.c(),
        (d = E()),
        (h = P("div")),
        (p = P("div")),
        m.c(),
        (w = E()),
        L && L.c(),
        (b = E()),
        _ && _.c(),
        (v = D()),
        B(i, "class", "menu svelte-jdc7pc"),
        B(r, "class", "login-nav svelte-jdc7pc"),
        B(p, "class", "content-inner svelte-jdc7pc"),
        B(h, "class", "content svelte-jdc7pc"),
        pe(() => e[30].call(h)),
        W(h, "min-height", (e[10].length, "auto")),
        B(n, "class", "login-content svelte-jdc7pc");
    },
    m(t, o) {
      A(t, n, o),
        x(n, r),
        x(r, i),
        Be(s, i, null),
        x(i, l),
        C && C.m(i, null),
        x(i, c),
        S && S.m(i, null),
        x(r, u),
        k && k.m(r, null),
        x(n, d),
        x(n, h),
        x(h, p),
        M[g].m(p, null),
        (f = G(h, e[30].bind(h))),
        e[31](h),
        x(n, w),
        L && L.m(n, null),
        A(t, b, o),
        _ && _.m(t, o),
        A(t, v, o),
        (y = !0);
    },
    p(e, t) {
      const i = {};
      64 & t[0] && (i.checked = e[6].isMobile && "string" == typeof e[6].auth),
        64 & t[0] && (i.disabled = e[6].otpForm),
        1024 & t[1] && (i.$$scope = { dirty: t, ctx: e }),
        !a &&
          64 & t[0] &&
          ((a = !0), (i.group = e[6].auth), ge(() => (a = !1))),
        s.$set(i),
        _l.demoGroups.length && C.p(e, t),
        _l.realGroups.length && S.p(e, t),
        !e[6].isMobile ||
        (e[6].isMobile &&
          e[6].auth !== Vl.OpenDemo &&
          e[6].auth !== Vl.OpenReal &&
          e[6].auth !== Vl.CreatedAccount)
          ? k
            ? (k.p(e, t), 64 & t[0] && $e(k, 1))
            : ((k = Ii(e)), k.c(), $e(k, 1), k.m(r, null))
          : k &&
            (ve(),
            Ce(k, 1, 1, () => {
              k = null;
            }),
            ye());
      let l = g;
      (g = o(e)),
        g === l
          ? M[g].p(e, t)
          : (ve(),
            Ce(M[l], 1, 1, () => {
              M[l] = null;
            }),
            ye(),
            (m = M[g]),
            m ? m.p(e, t) : ((m = M[g] = O[g](e)), m.c()),
            $e(m, 1),
            m.m(p, null)),
        1024 & t[0] && W(h, "min-height", (e[10].length, "auto")),
        e[0]
          ? L
            ? 1 & t[0] && $e(L, 1)
            : ((L = es()), L.c(), $e(L, 1), L.m(n, null))
          : L &&
            (ve(),
            Ce(L, 1, 1, () => {
              L = null;
            }),
            ye()),
        e[0]
          ? _ &&
            (ve(),
            Ce(_, 1, 1, () => {
              _ = null;
            }),
            ye())
          : _
          ? (_.p(e, t), 1 & t[0] && $e(_, 1))
          : ((_ = ts(e)), _.c(), $e(_, 1), _.m(v.parentNode, v));
    },
    i(e) {
      y ||
        ($e(s.$$.fragment, e),
        $e(C),
        $e(S),
        $e(k),
        $e(m),
        $e(L),
        $e(_),
        (y = !0));
    },
    o(e) {
      Ce(s.$$.fragment, e), Ce(C), Ce(S), Ce(k), Ce(m), Ce(L), Ce(_), (y = !1);
    },
    d(t) {
      t && (T(n), T(b), T(v)),
        Ve(s),
        C && C.d(),
        S && S.d(),
        k && k.d(),
        M[g].d(),
        f(),
        e[31](null),
        L && L.d(),
        _ && _.d(t);
    },
  };
}
function ls(e) {
  return 0 === e ? Hc : 3 === e ? fu : Nc;
}
function cs(
  e,
  { delay: t = 0, duration: o = 400, easing: n = ko, main: r = !1 } = {}
) {
  const i = +getComputedStyle(e).opacity;
  return {
    delay: t,
    duration: o,
    easing: n,
    css: (e) =>
      `opacity: ${e * i}; position: ${r ? "static" : "absolute"}; width: 100%;`,
  };
}
function us(e, t, o) {
  function n() {
    b(c, (i.auth = Vl.None), i);
  }
  let r, i, s, a;
  const c = tc.layout.layoutStore;
  l(e, c, (e) => o(6, (i = e)));
  const u = tc.users.usersStore;
  l(e, u, (e) => o(24, (s = e)));
  const d = Ac.authStore;
  l(e, d, (e) => o(7, (a = e)));
  const h = Ac.authController;
  let p,
    { autoConnect: g } = t,
    { loading: m = !1 } = t,
    { clientHeight: f = 0 } = t,
    { showMessage: w = !1 } = t,
    v = 0,
    y = null,
    $ = null,
    C = null;
  return (
    (e.$$set = (e) => {
      "autoConnect" in e && o(1, (g = e.autoConnect)),
        "loading" in e && o(0, (m = e.loading)),
        "clientHeight" in e && o(2, (f = e.clientHeight)),
        "showMessage" in e && o(23, (w = e.showMessage));
    }),
    (e.$$.update = () => {
      var t, n;
      64 & e.$$.dirty[0] && o(8, (v = i.isMobile ? 0 : 120)),
        16777216 & e.$$.dirty[0] && o(10, (r = s.getAllUsers())),
        16777280 & e.$$.dirty[0] &&
          o(5, (C = "string" == typeof i.auth ? s.getUserById(i.auth) : null)),
        224 & e.$$.dirty[0] &&
          o(
            0,
            (m = Boolean(
              (i.auth === Vl.Connect &&
                a.connect.status !== Rs.NONE &&
                a.connect.status !== Rs.DONE) ||
                (C &&
                  a.existing[C.login] &&
                  a.existing[C.login].status !== Rs.NONE &&
                  a.existing[C.login].status !== Rs.DONE)
            ))
          ),
        249 & e.$$.dirty[0] &&
          o(
            23,
            (w = Boolean(
              !m &&
                ((i.auth === Vl.Connect && a.connect.error) ||
                  (i.auth === Vl.OpenDemo && y) ||
                  (i.auth === Vl.OpenReal && $) ||
                  (C &&
                    (null == (t = a.existing[C.login]) ? void 0 : t.error)) ||
                  ((null == (n = a.createdUser) ? void 0 : n.investor) &&
                    a.createdUser.id === (null == C ? void 0 : C.id)))
            ))
          ),
        64 & e.$$.dirty[0] &&
          (async function (e) {
            await he(), p && f !== p.clientHeight && o(2, (f = p.clientHeight));
          })();
    }),
    [
      m,
      g,
      f,
      y,
      $,
      C,
      i,
      a,
      v,
      p,
      r,
      c,
      u,
      d,
      function (e) {
        b(d, (a.createdUser = e.detail.response), a),
          c.setLayout({ auth: a.createdUser.id });
        const t = s.getUserById(a.createdUser.id);
        t &&
          s.updateCurrentUser(t.login, {
            isHedgedMargin: e.detail.isHedgedMargin,
          });
      },
      function (e) {
        o(3, (y = e.detail));
      },
      function () {
        var e;
        if (!a.connect.error) {
          if (
            (b(d, (a.createdUser = null), a),
            null == (e = a.modules)
              ? void 0
              : e.account.accountStore.isResetPass)
          ) {
            const e = u.getUserByLogin(a.modules.account.accountStore.login);
            e && i.setLayout({ auth: e.id });
          } else n();
          b(d, (a.connect.error = null), a);
        }
      },
      function () {
        var e;
        if (
          (b(d, (a.createdUser = null), a),
          null == (e = a.modules) ? void 0 : e.account.accountStore.isResetPass)
        ) {
          const e = u.getUserByLogin(a.modules.account.accountStore.login);
          e && i.setLayout({ auth: e.id });
        }
        n();
      },
      function () {
        b(d, (a.connect.error = null), a);
      },
      function (e) {
        b(d, (a.createdUser = e.detail.response), a),
          c.setLayout({ auth: a.createdUser.id });
        const t = s.getUserById(a.createdUser.id);
        t &&
          s.updateCurrentUser(t.login, {
            isHedgedMargin: e.detail.isHedgedMargin,
          });
      },
      function (e) {
        o(4, ($ = e.detail));
      },
      function () {
        h.logout();
      },
      async function () {
        if (!(null == C ? void 0 : C.login)) return;
        const e = r.findIndex((e) => e.id === (null == C ? void 0 : C.id));
        var t;
        s.removeUser(C.id),
          (t = C.id),
          Ol.objects.removeByUserId(t),
          Ol.indicators.removeByUserId(t),
          Ol.indicatorsByOrder.removeByUserId(t),
          Ol.configs.removeByUserId(t),
          Ol.trade_bars.removeByUserId(t),
          Ol.marks.removeByUserId(t),
          Ol.watchlist.removeByUserId(t),
          Ol.user_settings.removeByUserId(t),
          await he(),
          -1 !== e && r.length
            ? r.length > e
              ? i.setLayout({ auth: r[e].id })
              : i.setLayout({ auth: r[r.length - 1].id })
            : i.setLayout({ auth: Vl.Connect });
      },
      w,
      s,
      function (t) {
        e.$$.not_equal(i.auth, t) && ((i.auth = t), c.set(i));
      },
      function (t) {
        e.$$.not_equal(i.auth, t) && ((i.auth = t), c.set(i));
      },
      function (t) {
        e.$$.not_equal(i.auth, t) && ((i.auth = t), c.set(i));
      },
      function (t) {
        e.$$.not_equal(i.auth, t) && ((i.auth = t), c.set(i));
      },
      function (e) {
        (g = e), o(1, g);
      },
      function () {
        (f = this.clientHeight), o(2, f);
      },
      function (e) {
        ca[e ? "unshift" : "push"](() => {
          (p = e), o(9, p);
        });
      },
    ]
  );
}
function ds(e) {
  function t(t) {
    e[11](t);
  }
  function o(t) {
    e[12](t);
  }
  function n(t) {
    e[13](t);
  }
  function r(t) {
    e[14](t);
  }
  let i,
    s,
    a,
    l,
    c,
    u,
    d,
    h = {};
  return (
    void 0 !== e[3] && (h.loading = e[3]),
    void 0 !== e[1] && (h.clientHeight = e[1]),
    void 0 !== e[0] && (h.autoConnect = e[0]),
    void 0 !== e[2] && (h.showMessage = e[2]),
    (s = new Su({ props: h })),
    ca.push(() => _e(s, "loading", t)),
    ca.push(() => _e(s, "clientHeight", o)),
    ca.push(() => _e(s, "autoConnect", n)),
    ca.push(() => _e(s, "showMessage", r)),
    {
      c() {
        (i = P("div")),
          Ue(s.$$.fragment),
          B(i, "class", "login svelte-s7093c"),
          W(i, "height", e[4]);
      },
      m(e, t) {
        A(e, i, t), Be(s, i, null), (d = !0);
      },
      p(e, t) {
        const o = {};
        !a && 8 & t && ((a = !0), (o.loading = e[3]), ge(() => (a = !1))),
          !l &&
            2 & t &&
            ((l = !0), (o.clientHeight = e[1]), ge(() => (l = !1))),
          !c && 1 & t && ((c = !0), (o.autoConnect = e[0]), ge(() => (c = !1))),
          !u && 4 & t && ((u = !0), (o.showMessage = e[2]), ge(() => (u = !1))),
          s.$set(o),
          16 & t && W(i, "height", e[4]);
      },
      i(e) {
        d || ($e(s.$$.fragment, e), (d = !0));
      },
      o(e) {
        Ce(s.$$.fragment, e), (d = !1);
      },
      d(e) {
        e && T(i), Ve(s);
      },
    }
  );
}
function hs(t) {
  let o, n;
  return (
    (o = new ic({ props: { slot: "close", name: rc } })),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p: e,
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function ps(e) {
  var t;
  let o, n;
  return (
    (o = new xc({
      props: {
        mobile: e[5].isMobile,
        draggable: !0,
        hideCloseButton:
          !e[6].modules ||
          e[3] ||
          (null == (t = e[6].modules)
            ? void 0
            : t.account.accountStore.isResetPass),
        title:
          e[9] && !e[5].isMobile
            ? window.tr(window.lang.login.mainForm.titleWithName, {
                brokerName: e[9],
              })
            : window.tr(window.lang.login.mainForm.title),
        $$slots: { close: [hs], default: [ds] },
        $$scope: { ctx: e },
      },
    })),
    o.$on("close", e[10]),
    {
      c() {
        Ue(o.$$.fragment);
      },
      m(e, t) {
        Be(o, e, t), (n = !0);
      },
      p(e, [t]) {
        var n;
        const r = {};
        32 & t && (r.mobile = e[5].isMobile),
          72 & t &&
            (r.hideCloseButton =
              !e[6].modules ||
              e[3] ||
              (null == (n = e[6].modules)
                ? void 0
                : n.account.accountStore.isResetPass)),
          32 & t &&
            (r.title =
              e[9] && !e[5].isMobile
                ? window.tr(window.lang.login.mainForm.titleWithName, {
                    brokerName: e[9],
                  })
                : window.tr(window.lang.login.mainForm.title)),
          32799 & t && (r.$$scope = { dirty: t, ctx: e }),
          o.$set(r);
      },
      i(e) {
        n || ($e(o.$$.fragment, e), (n = !0));
      },
      o(e) {
        Ce(o.$$.fragment, e), (n = !1);
      },
      d(e) {
        Ve(o, e);
      },
    }
  );
}
function gs(e, t, o) {
  let n, r;
  const i = tc.layout.layoutStore;
  l(e, i, (e) => o(5, (n = e)));
  const s = Ac.authStore;
  l(e, s, (e) => o(6, (r = e)));
  const a = _l.broker.name;
  let c,
    u,
    { autoConnect: d } = t,
    h = !1,
    p = "auto";
  return (
    (e.$$set = (e) => {
      "autoConnect" in e && o(0, (d = e.autoConnect));
    }),
    (e.$$.update = () => {
      6 & e.$$.dirty && o(4, (p = c ? `${c + 40 * Number(u)}px` : "auto"));
    }),
    [
      d,
      c,
      u,
      h,
      p,
      n,
      r,
      i,
      s,
      a,
      function () {
        b(i, (n.auth = Vl.None), n);
      },
      function (e) {
        (h = e), o(3, h);
      },
      function (e) {
        (c = e), o(1, c);
      },
      function (e) {
        (d = e), o(0, d);
      },
      function (e) {
        (u = e), o(2, u);
      },
    ]
  );
}
function ms(e) {
  let t = "";
  for (let o = 0, n = 16; o < e; o++)
    t += "abcdef0123456789".charAt(Math.floor(Math.random() * n));
  return t;
}
function fs(e) {
  let t, o, n, r;
  const i = e[7].label,
    s = c(i, e, e[6], Tu),
    a =
      s ||
      (function (e) {
        let t;
        return {
          c() {
            t = L(e[0]);
          },
          m(e, o) {
            A(e, t, o);
          },
          p(e, o) {
            1 & o && R(t, e[0]);
          },
          d(e) {
            e && T(t);
          },
        };
      })(e),
    l = e[7].default,
    u = c(l, e, e[6], null);
  return {
    c() {
      (t = P(e[5] ? "div" : "label")),
        (o = P("div")),
        a && a.c(),
        (n = E()),
        u && u.c(),
        B(o, "class", "label svelte-lnfury"),
        W(o, "width", "calc(var(--indent-half) * " + e[4] + ")"),
        Z(o, "compact", e[1]),
        Z(o, "compact-height", e[2]),
        Z(o, "hide", e[3]),
        z(e[5] ? "div" : "label")(t, { class: "field svelte-lnfury" });
    },
    m(e, i) {
      A(e, t, i),
        x(t, o),
        a && a.m(o, null),
        x(t, n),
        u && u.m(t, null),
        (r = !0);
    },
    p(e, t) {
      s
        ? s.p &&
          (!r || 65 & t) &&
          h(s, i, e, e[6], r ? d(i, e[6], t, Au) : p(e[6]), Tu)
        : a && a.p && (!r || 1 & t) && a.p(e, r ? t : -1),
        (!r || 16 & t) &&
          W(o, "width", "calc(var(--indent-half) * " + e[4] + ")"),
        (!r || 2 & t) && Z(o, "compact", e[1]),
        (!r || 4 & t) && Z(o, "compact-height", e[2]),
        (!r || 8 & t) && Z(o, "hide", e[3]),
        u &&
          u.p &&
          (!r || 64 & t) &&
          h(u, l, e, e[6], r ? d(l, e[6], t, null) : p(e[6]), null);
    },
    i(e) {
      r || ($e(a, e), $e(u, e), (r = !0));
    },
    o(e) {
      Ce(a, e), Ce(u, e), (r = !1);
    },
    d(e) {
      e && T(t), a && a.d(e), u && u.d(e);
    },
  };
}
function ws(e) {
  let t,
    o,
    n = e[5] ? "div" : "label",
    r = (e[5] ? "div" : "label") && fs(e);
  return {
    c() {
      r && r.c(), (t = D());
    },
    m(e, n) {
      r && r.m(e, n), A(e, t, n), (o = !0);
    },
    p(e, [o]) {
      e[5],
        n
          ? s(n, e[5] ? "div" : "label")
            ? (r.d(1),
              (r = fs(e)),
              (n = e[5] ? "div" : "label"),
              r.c(),
              r.m(t.parentNode, t))
            : r.p(e, o)
          : ((r = fs(e)),
            (n = e[5] ? "div" : "label"),
            r.c(),
            r.m(t.parentNode, t));
    },
    i(e) {
      o || ($e(r, e), (o = !0));
    },
    o(e) {
      Ce(r, e), (o = !1);
    },
    d(e) {
      e && T(t), r && r.d(e);
    },
  };
}
function bs(e, t, o) {
  let { $$slots: n = {}, $$scope: r } = t,
    { label: i = "" } = t,
    { compact: s = !1 } = t,
    { compactHeight: a = !1 } = t,
    { hideLabel: l = !1 } = t,
    { labelWidth: c = 30 } = t,
    { div: u = !1 } = t;
  return (
    (e.$$set = (e) => {
      "label" in e && o(0, (i = e.label)),
        "compact" in e && o(1, (s = e.compact)),
        "compactHeight" in e && o(2, (a = e.compactHeight)),
        "hideLabel" in e && o(3, (l = e.hideLabel)),
        "labelWidth" in e && o(4, (c = e.labelWidth)),
        "div" in e && o(5, (u = e.div)),
        "$$scope" in e && o(6, (r = e.$$scope));
    }),
    [i, s, a, l, c, u, r, n]
  );
}
var vs,
  ys,
  $s,
  Cs,
  xs,
  Ss,
  ks,
  As,
  Ts,
  Os,
  Ps,
  Ms,
  Ls,
  Es,
  Ds,
  _s,
  Us,
  Bs,
  Vs,
  js,
  zs,
  Is,
  Hs,
  Ns,
  Rs,
  qs,
  Fs,
  Ws,
  Ks = Object.defineProperty,
  Gs = (e, t, o) => (
    ((e, t, o) => {
      t in e
        ? Ks(e, t, { enumerable: !0, configurable: !0, writable: !0, value: o })
        : (e[t] = o);
    })(e, "symbol" != typeof t ? t + "" : t, o),
    o
  );
const Zs = {},
  Ys = function (e, t, o) {
    if (!t || 0 === t.length) return e();
    const n = document.getElementsByTagName("link");
    return Promise.all(
      t.map((e) => {
        if (
          (e = (function (e) {
            return "/terminal/" + e;
          })(e)) in Zs
        )
          return;
        Zs[e] = !0;
        const t = e.endsWith(".css"),
          r = t ? '[rel="stylesheet"]' : "";
        if (o)
          for (let o = n.length - 1; o >= 0; o--) {
            const r = n[o];
            if (r.href === e && (!t || "stylesheet" === r.rel)) return;
          }
        else if (document.querySelector(`link[href="${e}"]${r}`)) return;
        const i = document.createElement("link");
        return (
          (i.rel = t ? "stylesheet" : "modulepreload"),
          t || ((i.as = "script"), (i.crossOrigin = "")),
          (i.href = e),
          document.head.appendChild(i),
          t
            ? new Promise((t, o) => {
                i.addEventListener("load", t),
                  i.addEventListener("error", () =>
                    o(new Error(`Unable to preload CSS for ${e}`))
                  );
              })
            : void 0
        );
      })
    )
      .then(() => e())
      .catch((e) => {
        const t = new Event("vite:preloadError", { cancelable: !0 });
        if (((t.payload = e), window.dispatchEvent(t), !t.defaultPrevented))
          throw e;
      });
  },
  Js = (e) => e,
  Qs = "undefined" != typeof window;
let Xs = Qs ? () => window.performance.now() : () => Date.now(),
  ea = Qs ? (e) => requestAnimationFrame(e) : e;
const ta = new Set(),
  oa =
    "undefined" != typeof window
      ? window
      : "undefined" != typeof globalThis
      ? globalThis
      : global,
  na = ["width", "height"];
let ra;
const ia = new Map();
let sa,
  aa = 0;
const la = [],
  ca = [];
let ua = [];
const da = [],
  ha = Promise.resolve();
let pa = !1;
const ga = new Set();
let ma,
  fa = 0;
const wa = new Set();
let ba;
const va = { duration: 0 };
class ya {
  constructor() {
    Gs(this, "$$"), Gs(this, "$$set");
  }
  $destroy() {
    Ve(this, 1), (this.$destroy = e);
  }
  $on(t, o) {
    if (!i(o)) return e;
    const n = this.$$.callbacks[t] || (this.$$.callbacks[t] = []);
    return (
      n.push(o),
      () => {
        const e = n.indexOf(o);
        -1 !== e && n.splice(e, 1);
      }
    );
  }
  $set(e) {
    var t;
    this.$$set &&
      ((t = e), 0 !== Object.keys(t).length) &&
      ((this.$$.skip_bound = !0), this.$$set(e), (this.$$.skip_bound = !1));
  }
}
"undefined" != typeof window &&
  (window.__svelte || (window.__svelte = { v: new Set() })).v.add("4");
class $a extends ya {
  constructor(e) {
    super(), je(this, e, Ie, ze, s, { duration: 0, delay: 1, size: 3 });
  }
}
class Ca extends ya {
  constructor(e) {
    super(), je(this, e, Fe, qe, s, { overlay: 0, delay: 1, label: 2 });
  }
}
let xa, Sa;
const ka =
  (null == localStorage ? void 0 : localStorage.getItem("journal")) ?? "10";
let Aa = "1" === ka[0],
  Ta = "1" === ka[1],
  Oa = "1" === ka[2],
  Pa = "1" === ka[3],
  Ma = (null == localStorage ? void 0 : localStorage.getItem("f")) || "";
const La = {},
  Ea = JSON.parse(
    (null == localStorage ? void 0 : localStorage.getItem("tags")) || "[]"
  ),
  Da = [];
class _a {
  constructor(e = nt) {
    (this.subscribers = []),
      (this._systemName = ""),
      (this.stop = null),
      (this.value = this),
      (this.start = e);
  }
  set(e) {
    if (
      ((t = this.value),
      (o = e),
      Boolean(
        t != t
          ? o == o
          : t !== o || (t && "object" == typeof t) || "function" == typeof t
      ) && ((this.value = e), this.stop))
    ) {
      const e = !Da.length;
      for (let t = 0; t < this.subscribers.length; t += 1) {
        const e = this.subscribers[t];
        e[1](), Da.push(e, this.value);
      }
      if (e) {
        for (let e = 0; e < Da.length; e += 2) Da[e][0](Da[e + 1]);
        Da.length = 0;
      }
    }
    var t, o;
  }
  update(e) {
    this.set(e(this.value));
  }
  subscribe(e, t = nt) {
    const o = [e, t];
    return (
      this.subscribers.push(o),
      this._systemName,
      1 === this.subscribers.length && (this.stop = this.start(this.set) || nt),
      e(this.value),
      () => {
        const e = this.subscribers.indexOf(o);
        -1 !== e && (this.subscribers.splice(e, 1), this._systemName),
          0 === this.subscribers.length &&
            this.stop &&
            (this.stop(), (this.stop = null));
      }
    );
  }
  refresh() {
    this.update((e) => e);
  }
}
const Ua = {
    background: 16777215,
    border: 15263976,
    bottomPanel: 16250871,
    card: 16777215,
    icon: { default: 5590089, disabled: 13750737 },
    fill: {
      blue: 3245055,
      blueHover: 4953087,
      blueActive: 3045867,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 15354956,
      redHover: 16013657,
      redActive: 16075595,
      lightBlue: 15858175,
      lightBlueHover: 15070463,
      lightBlueActive: 14281204,
      lightRed: 16642545,
      lightRedHover: 16443624,
      lightRedActive: 16376803,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 16644849,
      total: 15791609,
    },
    text: {
      default: 0,
      secondary: 8421504,
      inverted: 16777215,
      red: 14155776,
      blue: 750067,
      green: 2200372,
      orange: 12408606,
      disabled: 10989752,
    },
    input: {
      fill: { disabled: 16053750 },
      border: { default: 14540253, hover: 8899326, invalid: 12067876 },
    },
    button: { disabled: 13750737 },
    scroll: 10461087,
    chart: {
      backgroundColor: 16777215,
      gridColor: 15263976,
      titleColor: 0,
      descriptionColor: 8421504,
      graph: {
        upColor: 2533018,
        downColor: 15684432,
        lineColor: 45039,
        areaColor: 45039,
      },
      axis: { borderColor: 10461087, textColor: 0 },
      crossHair: {
        lineColor: 10461087,
        textColor: 16777215,
        textBackgroundColor: 10461087,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 8421504 },
      object: {
        point: {
          hover: { backgroundColor: 16777215, borderColor: 3245055 },
          focus: { backgroundColor: 16777215, borderColor: 4953087 },
          active: { backgroundColor: 16777215, borderColor: 3045867 },
        },
      },
      volume: { upColor: 110447, downColor: 16723968, lineColor: 45039 },
    },
    calendar: {
      button: { backgroundColor: 16777215, textColor: 0 },
      group: {
        borderColor: 15263976,
        backgroundColor: 16777215,
        title: {
          textColor: 8421504,
          backgroundColor: 16777215,
          linkColor: 750067,
        },
        event: { titleColor: 0, timeColor: 8421504, descriptionColor: 8421504 },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 8421504,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  Ba = {
    background: 988960,
    border: 2831683,
    bottomPanel: 1381653,
    card: 2502463,
    icon: { default: 13750738, disabled: 6582657 },
    fill: {
      blue: 3245055,
      blueHover: 4953087,
      blueActive: 3045867,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 15354956,
      redHover: 16013657,
      redActive: 16075595,
      lightBlue: 2107699,
      lightBlueHover: 2437180,
      lightBlueActive: 3356216,
      lightRed: 3943470,
      lightRedHover: 4402480,
      lightRedActive: 4929081,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 3943470,
      total: 2831683,
    },
    text: {
      default: 16777215,
      secondary: 9413304,
      inverted: 16777215,
      red: 16734296,
      blue: 4560895,
      green: 4900447,
      orange: 16746051,
      disabled: 10989752,
    },
    input: {
      fill: { disabled: 3026994 },
      border: { default: 14540253, hover: 8899326, invalid: 12067876 },
    },
    button: { disabled: 3026994 },
    scroll: 6580601,
    chart: {
      backgroundColor: 988960,
      gridColor: 2831683,
      titleColor: 988960,
      descriptionColor: 9413304,
      graph: {
        upColor: 2533018,
        downColor: 15684432,
        lineColor: 45039,
        areaColor: 45039,
      },
      axis: { borderColor: 6580601, textColor: 10461087 },
      crossHair: {
        lineColor: 6580601,
        textColor: 16777215,
        textBackgroundColor: 6580601,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 9413304 },
      object: {
        point: {
          hover: { backgroundColor: 988960, borderColor: 3245055 },
          focus: { backgroundColor: 988960, borderColor: 4953087 },
          active: { backgroundColor: 988960, borderColor: 3045867 },
        },
      },
      volume: { upColor: 110447, downColor: 16723968, lineColor: 45039 },
    },
    calendar: {
      button: { backgroundColor: 988960, textColor: 16777215 },
      group: {
        borderColor: 2833488,
        backgroundColor: 988960,
        title: {
          textColor: 9413304,
          backgroundColor: 988960,
          linkColor: 4560895,
        },
        event: {
          titleColor: 16777215,
          timeColor: 9413304,
          descriptionColor: 9413304,
        },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 9413304,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  Va = {
    background: 16777215,
    border: 15263976,
    bottomPanel: 16250871,
    card: 16777215,
    icon: { default: 5590089, disabled: 13750737 },
    fill: {
      blue: 4676090,
      blueHover: 7372543,
      blueActive: 2439664,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 15219761,
      redHover: 16013657,
      redActive: 16075595,
      lightBlue: 15858175,
      lightBlueHover: 15070463,
      lightBlueActive: 14281204,
      lightRed: 16642545,
      lightRedHover: 16443624,
      lightRedActive: 16376803,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 16644849,
      total: 15791609,
    },
    text: {
      default: 0,
      secondary: 8224125,
      inverted: 16777215,
      red: 12850967,
      blue: 4676090,
      green: 2200372,
      orange: 12408606,
      disabled: 10989752,
    },
    input: {
      fill: { disabled: 16053750 },
      border: { default: 14540253, hover: 5737714, invalid: 12067876 },
    },
    button: { disabled: 13750737 },
    scroll: 10461087,
    chart: {
      backgroundColor: 16777215,
      gridColor: 15263976,
      titleColor: 0,
      descriptionColor: 8421504,
      graph: {
        upColor: 5737714,
        downColor: 15219761,
        lineColor: 4676090,
        areaColor: 4676090,
      },
      axis: { borderColor: 10461087, textColor: 0 },
      crossHair: {
        lineColor: 10461087,
        textColor: 16777215,
        textBackgroundColor: 10461087,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 8421504 },
      object: {
        point: {
          hover: { backgroundColor: 16777215, borderColor: 3045867 },
          focus: { backgroundColor: 16777215, borderColor: 4953087 },
          active: { backgroundColor: 16777215, borderColor: 3045867 },
        },
      },
      volume: { upColor: 4676090, downColor: 16723968, lineColor: 4676090 },
    },
    calendar: {
      button: { backgroundColor: 16777215, textColor: 0 },
      group: {
        borderColor: 15263976,
        backgroundColor: 16777215,
        title: {
          textColor: 8421504,
          backgroundColor: 16777215,
          linkColor: 750067,
        },
        event: { titleColor: 0, timeColor: 8421504, descriptionColor: 8421504 },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 8421504,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  ja = {
    background: 988960,
    border: 2831683,
    bottomPanel: 1381653,
    card: 2502463,
    icon: { default: 13750738, disabled: 6582657 },
    fill: {
      blue: 5737714,
      blueHover: 7381759,
      blueActive: 3107802,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 16734029,
      redHover: 16739942,
      redActive: 15353662,
      lightBlue: 2107699,
      lightBlueHover: 2437180,
      lightBlueActive: 3356216,
      lightRed: 3943470,
      lightRedHover: 4402480,
      lightRedActive: 4929081,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 3943470,
      total: 2831683,
    },
    text: {
      default: 16777215,
      secondary: 9413304,
      inverted: 16777215,
      red: 16734296,
      blue: 9349119,
      green: 4900447,
      orange: 16746051,
      disabled: 16777215,
    },
    input: {
      fill: { disabled: 3026994 },
      border: { default: 14540253, hover: 8899326, invalid: 12067876 },
    },
    button: { disabled: 3026994 },
    scroll: 6580601,
    chart: {
      backgroundColor: 988960,
      gridColor: 2831683,
      titleColor: 988960,
      descriptionColor: 9413304,
      graph: {
        upColor: 5737714,
        downColor: 16734029,
        lineColor: 5737714,
        areaColor: 5737714,
      },
      axis: { borderColor: 6580601, textColor: 10461087 },
      crossHair: {
        lineColor: 6580601,
        textColor: 16777215,
        textBackgroundColor: 6580601,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 9413304 },
      object: {
        point: {
          hover: { backgroundColor: 988960, borderColor: 3245055 },
          focus: { backgroundColor: 988960, borderColor: 4953087 },
          active: { backgroundColor: 988960, borderColor: 3045867 },
        },
      },
      volume: { upColor: 5737714, downColor: 16734029, lineColor: 45039 },
    },
    calendar: {
      button: { backgroundColor: 988960, textColor: 988960 },
      group: {
        borderColor: 2833488,
        backgroundColor: 988960,
        title: {
          textColor: 9413304,
          backgroundColor: 988960,
          linkColor: 4560895,
        },
        event: {
          titleColor: 16777215,
          timeColor: 9413304,
          descriptionColor: 9413304,
        },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 9413304,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  za = {
    background: 16777215,
    border: 15263976,
    bottomPanel: 16250871,
    card: 16777215,
    icon: { default: 5590089, disabled: 13750737 },
    fill: {
      blue: 3245055,
      blueHover: 4953087,
      blueActive: 3045867,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 15354956,
      redHover: 16013657,
      redActive: 16075595,
      lightBlue: 15858175,
      lightBlueHover: 15070463,
      lightBlueActive: 14281204,
      lightRed: 16642545,
      lightRedHover: 16443624,
      lightRedActive: 16376803,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 16644849,
      total: 15791609,
    },
    text: {
      default: 0,
      secondary: 8421504,
      inverted: 16777215,
      red: 14155776,
      blue: 750067,
      green: 2200372,
      orange: 12408606,
      disabled: 10989752,
    },
    input: {
      fill: { disabled: 16053750 },
      border: { default: 14540253, hover: 8899326, invalid: 12067876 },
    },
    button: { disabled: 13750737 },
    scroll: 10461087,
    chart: {
      backgroundColor: 16777215,
      gridColor: 15263976,
      titleColor: 0,
      descriptionColor: 8421504,
      graph: { upColor: 0, downColor: 11908533, lineColor: 0, areaColor: 0 },
      axis: { borderColor: 10461087, textColor: 0 },
      crossHair: {
        lineColor: 10461087,
        textColor: 16777215,
        textBackgroundColor: 10461087,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 8421504 },
      object: {
        point: {
          hover: { backgroundColor: 16777215, borderColor: 3245055 },
          focus: { backgroundColor: 16777215, borderColor: 4953087 },
          active: { backgroundColor: 16777215, borderColor: 3045867 },
        },
      },
      volume: { upColor: 13750737, downColor: 6184542, lineColor: 0 },
    },
    calendar: {
      button: { backgroundColor: 16777215, textColor: 0 },
      group: {
        borderColor: 15263976,
        backgroundColor: 16777215,
        title: {
          textColor: 8421504,
          backgroundColor: 16777215,
          linkColor: 750067,
        },
        event: { titleColor: 0, timeColor: 8421504, descriptionColor: 8421504 },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 8421504,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  Ia = {
    background: 0,
    border: 2831683,
    bottomPanel: 1381653,
    card: 2502463,
    icon: { default: 13750738, disabled: 6582657 },
    fill: {
      blue: 3245055,
      blueHover: 4953087,
      blueActive: 3045867,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 15354956,
      redHover: 16013657,
      redActive: 16075595,
      lightBlue: 2107699,
      lightBlueHover: 2437180,
      lightBlueActive: 3356216,
      lightRed: 3943470,
      lightRedHover: 4402480,
      lightRedActive: 4929081,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 3943470,
      total: 2831683,
    },
    text: {
      default: 16777215,
      secondary: 9413304,
      inverted: 16777215,
      red: 16734296,
      blue: 4560895,
      green: 4900447,
      orange: 16746051,
      disabled: 10989752,
    },
    input: {
      fill: { disabled: 3026994 },
      border: { default: 14540253, hover: 8899326, invalid: 12067876 },
    },
    button: { disabled: 3026994 },
    scroll: 6580601,
    chart: {
      backgroundColor: 0,
      gridColor: 2831683,
      titleColor: 988960,
      descriptionColor: 9413304,
      graph: {
        upColor: 16777215,
        downColor: 8026746,
        lineColor: 16777215,
        areaColor: 16777215,
      },
      axis: { borderColor: 6580601, textColor: 10461087 },
      crossHair: {
        lineColor: 6580601,
        textColor: 16777215,
        textBackgroundColor: 6580601,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 9413304 },
      object: {
        point: {
          hover: { backgroundColor: 988960, borderColor: 3245055 },
          focus: { backgroundColor: 988960, borderColor: 4953087 },
          active: { backgroundColor: 988960, borderColor: 3045867 },
        },
      },
      volume: { upColor: 16777215, downColor: 8026746, lineColor: 16777215 },
    },
    calendar: {
      button: { backgroundColor: 988960, textColor: 988960 },
      group: {
        borderColor: 2833488,
        backgroundColor: 988960,
        title: {
          textColor: 9413304,
          backgroundColor: 988960,
          linkColor: 4560895,
        },
        event: {
          titleColor: 16777215,
          timeColor: 9413304,
          descriptionColor: 9413304,
        },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 9413304,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  Ha = {
    background: 16777215,
    border: 15263976,
    bottomPanel: 16250871,
    card: 16777215,
    icon: { default: 5590089, disabled: 13750737 },
    fill: {
      blue: 7777413,
      blueHover: 6857080,
      blueActive: 5474402,
      green: 3584843,
      greenHover: 4308566,
      greenActive: 3054913,
      red: 13665669,
      redHover: 11430763,
      redActive: 12284530,
      lightBlue: 15857142,
      lightBlueHover: 15528691,
      lightBlueActive: 14937069,
      lightRed: 16642545,
      lightRedHover: 16443624,
      lightRedActive: 16376803,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 16644849,
      total: 15857142,
    },
    text: {
      default: 0,
      secondary: 8421504,
      inverted: 16777215,
      red: 12667209,
      blue: 4416588,
      green: 2200372,
      orange: 12408606,
      disabled: 10989752,
    },
    input: {
      fill: { disabled: 16053750 },
      border: { default: 14540253, hover: 11390647, invalid: 12067876 },
    },
    button: { disabled: 13750737 },
    scroll: 10461087,
    chart: {
      backgroundColor: 16777215,
      gridColor: 15263976,
      titleColor: 0,
      descriptionColor: 8421504,
      graph: {
        upColor: 7777413,
        downColor: 13665669,
        lineColor: 7183527,
        areaColor: 7183527,
      },
      axis: { borderColor: 10461087, textColor: 0 },
      crossHair: {
        lineColor: 10461087,
        textColor: 16777215,
        textBackgroundColor: 10461087,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 8421504 },
      object: {
        point: {
          hover: { backgroundColor: 16777215, borderColor: 3245055 },
          focus: { backgroundColor: 16777215, borderColor: 4953087 },
          active: { backgroundColor: 16777215, borderColor: 3045867 },
        },
      },
      volume: { upColor: 7777413, downColor: 13665669, lineColor: 45039 },
    },
    calendar: {
      button: { backgroundColor: 16777215, textColor: 0 },
      group: {
        borderColor: 15263976,
        backgroundColor: 16777215,
        title: {
          textColor: 8421504,
          backgroundColor: 16777215,
          linkColor: 750067,
        },
        event: { titleColor: 0, timeColor: 8421504, descriptionColor: 8421504 },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 8421504,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  },
  Na = {
    background: 988960,
    border: 2831683,
    bottomPanel: 1381653,
    card: 2502463,
    icon: { default: 13750738, disabled: 6582657 },
    fill: {
      blue: 7777413,
      blueHover: 7645827,
      blueActive: 5867622,
      green: 7777413,
      greenHover: 7645827,
      greenActive: 5867622,
      red: 13134442,
      redHover: 11753046,
      redActive: 11358802,
      lightBlue: 2107699,
      lightBlueHover: 2437180,
      lightBlueActive: 3356216,
      lightRed: 3943470,
      lightRedHover: 4402480,
      lightRedActive: 4929081,
      orange: 15495191,
      orangeHover: 16746803,
      orangeActive: 14707994,
      lightYellow: 3943470,
      total: 2831683,
    },
    text: {
      default: 16777215,
      secondary: 9413304,
      inverted: 16777215,
      red: 16748431,
      blue: 10800816,
      green: 4900447,
      orange: 16746051,
      disabled: 16777215,
    },
    input: {
      fill: { disabled: 3026994 },
      border: { default: 14540253, hover: 8899326, invalid: 12067876 },
    },
    button: { disabled: 3026994 },
    scroll: 6580601,
    chart: {
      backgroundColor: 988960,
      gridColor: 2831683,
      titleColor: 988960,
      descriptionColor: 9413304,
      graph: {
        upColor: 7777413,
        downColor: 13134442,
        lineColor: 7183527,
        areaColor: 7183527,
      },
      axis: { borderColor: 6580601, textColor: 10461087 },
      crossHair: {
        lineColor: 6580601,
        textColor: 16777215,
        textBackgroundColor: 6580601,
      },
      selected: {
        marker: { textColor: 0, backgroundColor: 13097950 },
        diff: { color: 13097950, alpha: 0.3 },
      },
      indicator: { titleColor: 9413304 },
      object: {
        point: {
          hover: { backgroundColor: 988960, borderColor: 3245055 },
          focus: { backgroundColor: 988960, borderColor: 4953087 },
          active: { backgroundColor: 988960, borderColor: 3045867 },
        },
      },
      volume: { upColor: 7777413, downColor: 13134442, lineColor: 7183527 },
    },
    calendar: {
      button: { backgroundColor: 988960, textColor: 988960 },
      group: {
        borderColor: 2833488,
        backgroundColor: 988960,
        title: {
          textColor: 9413304,
          backgroundColor: 988960,
          linkColor: 4560895,
        },
        event: {
          titleColor: 16777215,
          timeColor: 9413304,
          descriptionColor: 9413304,
        },
      },
    },
    tradeMark: {
      buyLine: 3245055,
      buyText: 4560895,
      buyArrow: 3245055,
      buyArrowBorder: 16777215,
      sellLine: 15354956,
      sellText: 16734296,
      sellArrow: 15354956,
      sellArrowBorder: 16777215,
      blurLine: 11908533,
      blurText: 9413304,
      blurArrow: 11908533,
      blurArrowBorder: 16777215,
      slLine: 15495191,
      slText: 16746051,
      slArrow: 15495191,
      slArrowBorder: 16777215,
      tpLine: 3584843,
      tpText: 4900447,
      tpArrow: 3584843,
      tpArrowBorder: 16777215,
    },
    dark: 0,
  };
(vs = Object.defineProperty),
  (ys = Object.getOwnPropertyDescriptor),
  ($s = (e, t, o, n) => {
    var r,
      i,
      s = n > 1 ? void 0 : n ? ys(t, o) : t;
    for (r = e.length - 1; r >= 0; r--)
      (i = e[r]) && (s = (n ? i(t, o, s) : i(s)) || s);
    return n && s && vs(t, o, s), s;
  });
const Ra = { LIGHT: 0, DARK: 1 },
  qa = {
    greenRed: "greenRed",
    blueRed: "blueRed",
    blackWhite: "blackWhite",
    neutral: "neutral",
  },
  Fa = {
    zIndex: {
      base: 1,
      mainScreen: 10,
      screenHeader: 30,
      bottomMenu: 40,
      popupScreen: 100,
      contextMenu: 150,
    },
    indent: 8,
    font: {
      family: "Trebuchet MS,Roboto,Ubuntu,sans-serif",
      big: 16,
      size: 14,
      small: 13,
      tiny: 12,
    },
    button: { radius: 3, font: { size: 15 } },
    menu: { shadow: "0px 3px 8px 2px rgba(0, 0, 0, 0.1)" },
    popup: { shadow: "0px 16px 46px 8px rgba(0, 0, 0, 0.12)" },
  },
  Wa = class e extends _a {
    constructor(t, o, n) {
      super(),
        (this._systemName = "ThemeStore"),
        (this.THEMES = e.THEMES),
        (this.sizes = Fa),
        (this.theme = t),
        (this.mode = o),
        (this.colors = n);
    }
    setMode(e) {
      this.mode = e;
    }
    setTheme(e) {
      this.theme = e;
    }
    updateColors(e) {
      this.colors = Object.assign(this.colors, e);
    }
    updateSizes(e) {
      this.sizes = Object.assign(this.sizes, e);
    }
  };
(Wa.THEMES = {
  [qa.greenRed]: { id: qa.greenRed, light: () => Ua, dark: () => Ba },
  [qa.blueRed]: { id: qa.blueRed, light: () => Va, dark: () => ja },
  [qa.blackWhite]: { id: qa.blackWhite, light: () => za, dark: () => Ia },
  [qa.neutral]: { id: qa.neutral, light: () => Ha, dark: () => Na },
}),
  $s([rt], Wa.prototype, "setMode", 1),
  $s([rt], Wa.prototype, "setTheme", 1);
let Ka = Wa;
const Ga = {
    get: function (e) {
      return new URLSearchParams(window.self.location.search).get(e);
    },
    remove: function (e) {
      const t = new URLSearchParams(window.self.location.search);
      t.delete(e),
        window.self.history.replaceState(
          null,
          "",
          t.size ? `/terminal?${t.toString()}` : "/terminal"
        );
    },
    stringify: function (e, t = "?") {
      const o = [];
      return (
        Object.keys(e).forEach((t) => {
          const n = e[t];
          "boolean" == typeof n
            ? o.push(`${t}=${Number(n)}`)
            : (("number" == typeof n && !isNaN(n)) || n) && o.push(`${t}=${n}`);
        }),
        o.length ? `${t}${o.join("&")}` : ""
      );
    },
    parse: function (e = window.self.location.search) {
      const t = new URLSearchParams(e),
        o = {};
      return (
        t.forEach((e, t) => {
          o[t] = e;
        }),
        o
      );
    },
  },
  Za = new (class {
    constructor() {
      (this.allowed = !1),
        (this.storage = {}),
        it() && ((this.storage = window.localStorage), (this.allowed = !0));
    }
    getItem(e) {
      return this.allowed
        ? window.localStorage.getItem(e)
        : this.storage[e] ?? null;
    }
    setItem(e, t) {
      this.allowed && window.localStorage.setItem(e, t);
    }
    removeItem(e) {
      this.allowed && window.localStorage.removeItem(e), delete this.storage[e];
    }
  })();
class Ya {
  constructor(e) {
    (this.themeStore = e), (this.onChange = this.onChange.bind(this));
  }
  onChange() {
    const e = window.getComputedStyle(document.documentElement);
    this.setVariables(e), this.setColors(e);
  }
  static init() {
    let e = Ra.LIGHT,
      t = qa.greenRed;
    const o = Za.getItem("theme-mode");
    if (Number(o) === Ra.DARK) e = Ra.DARK;
    else {
      const t = Ga.get("theme-mode");
      Number(t) === Ra.DARK && (e = Ra.DARK);
    }
    const n = Za.getItem("theme");
    if (
      n === qa.greenRed ||
      n === qa.blueRed ||
      n === qa.blackWhite ||
      n === qa.neutral
    )
      t = n;
    else {
      const e = (function (e) {
        switch ((Ga.get("theme") ?? "").toLowerCase()) {
          case qa.greenRed.toLowerCase():
            return qa.greenRed;
          case qa.blueRed.toLowerCase():
            return qa.blueRed;
          case qa.blackWhite.toLowerCase():
            return qa.blackWhite;
          case qa.neutral.toLowerCase():
            return qa.neutral;
          default:
            return "";
        }
      })();
      (e !== qa.greenRed &&
        e !== qa.blueRed &&
        e !== qa.blackWhite &&
        e !== qa.neutral) ||
        (t = e);
    }
    return { theme: t, mode: e };
  }
  static load(e, t) {
    return e === Ra.DARK
      ? { ...Ka.THEMES[t].dark() }
      : { ...Ka.THEMES[t].light() };
  }
  init() {
    const { theme: e, mode: t } = Ya.init();
    this.themeStore.subscribe(this.onChange), this.setThemeOptions(t, e);
  }
  setMode(e) {
    Za.setItem("theme-mode", e.toString()),
      this.setThemeOptions(e, this.themeStore.theme);
  }
  setTheme(e) {
    Za.setItem("theme", e), this.setThemeOptions(this.themeStore.mode, e);
  }
  setThemeOptions(e, t) {
    const o = Ya.load(e, t);
    this.themeStore.updateColors(o);
    const n = window.getComputedStyle(document.documentElement);
    this.setColors(n),
      this.setVariables(n),
      this.themeStore.setMode(e),
      this.themeStore.setTheme(t);
  }
  setColors(e) {
    const t = this.themeStore.colors;
    [
      ["--color-background", `${Je(t.background)}`],
      ["--color-bottomPanel", `${Je(t.bottomPanel)}`],
      ["--color-border", `${Je(t.border)}`],
      ["--color-card", `${Je(t.card)}`],
      ["--color-icon-default", `${Je(t.icon.default)}`],
      ["--color-icon-disabled", `${Je(t.icon.disabled)}`],
      ["--color-fill-blue", `${Je(t.fill.blue)}`],
      ["--color-fill-blueHover", `${Je(t.fill.blueHover)}`],
      ["--color-fill-blueActive", `${Je(t.fill.blueActive)}`],
      ["--color-fill-red", `${Je(t.fill.red)}`],
      ["--color-fill-red-rgb", `${Qe(t.fill.red)}`],
      ["--color-fill-green", `${Je(t.fill.green)}`],
      ["--color-fill-green-rgb", `${Qe(t.fill.green)}`],
      ["--color-fill-greenHover", `${Je(t.fill.greenHover)}`],
      ["--color-fill-greenActive", `${Je(t.fill.greenActive)}`],
      ["--color-fill-red", `${Je(t.fill.red)}`],
      ["--color-fill-redHover", `${Je(t.fill.redHover)}`],
      ["--color-fill-redActive", `${Je(t.fill.redActive)}`],
      ["--color-fill-lightBlue", `${Je(t.fill.lightBlue)}`],
      ["--color-fill-lightBlueHover", `${Je(t.fill.lightBlueHover)}`],
      ["--color-fill-lightBlueActive", `${Je(t.fill.lightBlueActive)}`],
      ["--color-fill-lightRed", `${Je(t.fill.lightRed)}`],
      ["--color-fill-lightRedHover", `${Je(t.fill.lightRedHover)}`],
      ["--color-fill-lightRedActive", `${Je(t.fill.lightRedActive)}`],
      ["--color-fill-orange", `${Je(t.fill.orange)}`],
      ["--color-fill-orangeHover", `${Je(t.fill.orangeHover)}`],
      ["--color-fill-orangeActive", `${Je(t.fill.orangeActive)}`],
      ["--color-fill-lightYellow", `${Je(t.fill.lightYellow)}`],
      ["--color-fill-total", `${Je(t.fill.total)}`],
      ["--color-text-default", `${Je(t.text.default)}`],
      ["--color-text-secondary", `${Je(t.text.secondary)}`],
      ["--color-text-inverted", `${Je(t.text.inverted)}`],
      ["--color-text-red", `${Je(t.text.red)}`],
      ["--color-text-blue", `${Je(t.text.blue)}`],
      ["--color-text-green", `${Je(t.text.green)}`],
      ["--color-text-orange", `${Je(t.text.orange)}`],
      ["--color-text-disabled", `${Je(t.text.disabled)}`],
      ["--color-input-fill-disabled", `${Je(t.input.fill.disabled)}`],
      ["--color-input-border-default", `${Je(t.input.border.default)}`],
      ["--color-input-border-hover", `${Je(t.input.border.hover)}`],
      ["--color-input-border-invalid", `${Je(t.input.border.invalid)}`],
      ["--color-button-disabled", `${Je(t.button.disabled)}`],
      ["--color-scroll", `${Je(t.scroll)}`],
      ["--color-dark", t.dark.toString()],
    ].forEach(([t, o]) => {
      e.getPropertyValue(t) !== o &&
        document.documentElement.style.setProperty(t, o);
    });
  }
  setVariables(e) {
    const t = this.themeStore.sizes;
    [
      ["--indent", `${t.indent.toString(10)}px`],
      ["--indent2", "calc(var(--indent) * 2)"],
      ["--indent3", "calc(var(--indent) * 3)"],
      ["--indent-one-half", "calc(var(--indent) * 1.5)"],
      ["--indent-half", "calc(var(--indent) * 0.5)"],
      ["--font-family", t.font.family],
      ["--font-size", `${t.font.size}px`],
      ["--font-big", `${t.font.big}px`],
      ["--font-small", `${t.font.small}px`],
      ["--font-tiny", `${t.font.tiny}px`],
      ["--button-radius", `${t.button.radius.toString(10)}px`],
      ["--button-font-size", `${t.button.font.size}px`],
      ["--menu-shadow", t.menu.shadow],
      ["--popup-shadow", t.popup.shadow],
      [
        "--bot-bar-height",
        "calc(var(--indent) * 7 + 1px + env(safe-area-inset-bottom) / 2)",
      ],
      ["--m-screen-header-height", "calc(var(--indent) * 6 + 1px)"],
      ["--history-custom-period-height-mobile", "calc(var(--indent) * 6.5)"],
      ["--history-custom-period-height-desktop", "calc(var(--indent) * 4)"],
      ["--save-left", "env(safe-area-inset-left)"],
      ["--save-right", "env(safe-area-inset-right)"],
      ["--screen-width", "calc(100% - var(--save-left) - var(--save-right))"],
      ["--zIndex-base", `${t.zIndex.base}`],
      ["--zIndex-mainScreen", `${t.zIndex.base}`],
      ["--zIndex-screenHeader", `${t.zIndex.screenHeader}`],
      ["--zIndex-popupScreen", `${t.zIndex.popupScreen}`],
      ["--zIndex-contextMenu", `${t.zIndex.contextMenu}`],
    ].forEach(([t, o]) => {
      e.getPropertyValue(t) !== o &&
        document.documentElement.style.setProperty(t, o);
    });
  }
}
class Ja {
  constructor(e, t, o) {
    (this.themeStore = new Ka(e, t, o)),
      (this.themeController = new Ya(this.themeStore));
  }
}
(Ja.ThemeStore = Ka),
  (Ja.ThemeController = Ya),
  (Cs = ((e) => (
    (e[(e.DESC = -1)] = "DESC"),
    (e[(e.None = 0)] = "None"),
    (e[(e.ASC = 1)] = "ASC"),
    e
  ))(Cs || {})),
  (xs = ((e) => (
    (e[(e.Symbol = 0)] = "Symbol"),
    (e[(e.Bid = 1)] = "Bid"),
    (e[(e.Ask = 2)] = "Ask"),
    (e[(e.DailyChange = 3)] = "DailyChange"),
    (e[(e.High = 4)] = "High"),
    (e[(e.Low = 5)] = "Low"),
    (e[(e.Spread = 6)] = "Spread"),
    (e[(e.Time = 7)] = "Time"),
    (e[(e.BidHigh = 8)] = "BidHigh"),
    (e[(e.BidLow = 9)] = "BidLow"),
    (e[(e.AskHigh = 10)] = "AskHigh"),
    (e[(e.AskLow = 11)] = "AskLow"),
    (e[(e.PriceOpen = 12)] = "PriceOpen"),
    (e[(e.PriceClose = 13)] = "PriceClose"),
    (e[(e.Last = 14)] = "Last"),
    (e[(e.LastHigh = 15)] = "LastHigh"),
    (e[(e.LastLow = 16)] = "LastLow"),
    e
  ))(xs || {}));
const Qa = {},
  Xa = document.createElement("div"),
  el = 2147483647,
  tl = 4294967295,
  ol = 17976931348623157e292,
  nl = BigInt("9223372036854775807"),
  rl = BigInt("18446744073709551615"),
  il = BigInt("-9223372036854775808"),
  sl = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8],
  al = {
    abs: (e) => (e < 0n ? -e : e),
    max: (...e) => e.reduce((e, t) => (t > e ? t : e)),
    min: (...e) => e.reduce((e, t) => (t < e ? t : e)),
  };
Ss = ((e) => (
  (e[(e.Symbol = 0)] = "Symbol"),
  (e[(e.Ticket = 1)] = "Ticket"),
  (e[(e.Time = 2)] = "Time"),
  (e[(e.Type = 3)] = "Type"),
  (e[(e.Volume = 4)] = "Volume"),
  (e[(e.Price = 5)] = "Price"),
  (e[(e.Sl = 6)] = "Sl"),
  (e[(e.Tp = 7)] = "Tp"),
  (e[(e.MarketPrice = 8)] = "MarketPrice"),
  (e[(e.Swap = 9)] = "Swap"),
  (e[(e.Profit = 10)] = "Profit"),
  (e[(e.Comment = 11)] = "Comment"),
  (e[(e.Controls = 12)] = "Controls"),
  e
))(Ss || {});
const ll = [
    { key: 0, name: ["symbol", "symbol"] },
    { visible: 1, key: 1, name: ["id", "order"], level: 3 },
    { visible: 2, key: 2, name: ["timeCreate", "timeSetup"] },
    { visible: 3, key: 3, name: ["typeName", "typeName"] },
    { visible: 4, key: 4, name: ["volumeValue", "volumeValue"], right: !0 },
    { key: 5, name: ["priceOpen", "price"], right: !0 },
    { visible: 6, key: 6, name: ["sl", "sl"], right: !0 },
    { visible: 7, key: 7, name: ["tp", "tp"], right: !0 },
    { visible: 8, key: 8, name: ["priceClose", "priceCurrent"], right: !0 },
    { visible: 9, key: 9, name: ["storage", ""], right: !0, level: 1 },
    { key: 10, name: ["profit", ""], right: !0 },
    { visible: 11, key: 11, name: ["comment", ""], level: 2 },
  ],
  cl = {};
ll.forEach((e) => {
  cl[e.key] = e;
});
const ul = 16,
  dl = Object.freeze(
    "January February March April May June July August September October November December".split(
      " "
    )
  ),
  hl = Object.freeze(
    "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" ")
  ),
  pl = Object.freeze(
    "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" ")
  ),
  gl = Object.freeze("Sun Mon Tue Wed Thu Fri Sat".split(" "));
ks = ((e) => (
  (e.TimeOpen = "timeOpen"),
  (e.Id = "id"),
  (e.Type = "type"),
  (e.VolumeValue = "volumeValue"),
  (e.Symbol = "symbol"),
  (e.PriceOpen = "priceOpen"),
  (e.Sl = "sl"),
  (e.Tp = "tp"),
  (e.TimeClose = "timeClose"),
  (e.PriceClose = "priceClose"),
  (e.Commission = "commission"),
  (e.CommissionFee = "commissionFee"),
  (e.Storage = "storage"),
  (e.Profit = "profit"),
  (e.Comment = "comment"),
  e
))(ks || {});
const ml = [
  { key: "timeOpen", left: !0, mobileSorting: !0 },
  { key: "id", level: 3, mobileSorting: !0 },
  { key: "type", mobileSorting: !0 },
  { key: "volumeValue", mobileSorting: !0 },
  { key: "symbol", left: !0, showAlways: !0, mobileSorting: !0 },
  { key: "priceOpen" },
  { key: "sl" },
  { key: "tp" },
  { key: "timeClose", mobileSorting: !0 },
  { key: "priceClose" },
  { key: "commission", level: 2 },
  { key: "commissionFee", level: 2 },
  { key: "storage", level: 1 },
  { key: "profit", showAlways: !0, mobileSorting: !0 },
  { key: "comment", level: 1 },
];
As = ((e) => (
  (e.TimeSetup = "timeSetup"),
  (e.Order = "order"),
  (e.Symbol = "symbol"),
  (e.Type = "type"),
  (e.VolumeValue = "volumeValue"),
  (e.Price = "price"),
  (e.Sl = "sl"),
  (e.Tp = "tp"),
  (e.TimeDone = "timeDone"),
  (e.State = "state"),
  (e.Comment = "comment"),
  e
))(As || {});
const fl = [
  { key: "timeSetup", left: !0, mobileSorting: !0 },
  { key: "order", level: 2, mobileSorting: !0 },
  { key: "symbol", left: !0, showAlways: !0, mobileSorting: !0 },
  { key: "type", showAlways: !0, mobileSorting: !0 },
  { key: "volumeValue", mobileSorting: !0 },
  { key: "price", showAlways: !0 },
  { key: "sl" },
  { key: "tp" },
  { key: "timeDone", mobileSorting: !0 },
  { key: "state", mobileSorting: !0 },
  { key: "comment", level: 1 },
];
Ts = ((e) => (
  (e.TimeCreate = "timeCreate"),
  (e.Deal = "deal"),
  (e.Order = "order"),
  (e.Symbol = "symbol"),
  (e.Action = "action"),
  (e.Entry = "entry"),
  (e.Volume = "volume"),
  (e.PriceClose = "priceClose"),
  (e.Commission = "commission"),
  (e.CommissionFee = "commissionFee"),
  (e.Storage = "storage"),
  (e.Profit = "profit"),
  (e.Comment = "comment"),
  e
))(Ts || {});
const wl = [
    { key: "timeCreate", left: !0, mobileSorting: !0 },
    { key: "deal", level: 3, mobileSorting: !0 },
    { key: "order" },
    { key: "symbol", left: !0, showAlways: !0, mobileSorting: !0 },
    { key: "action", mobileSorting: !0 },
    { key: "entry" },
    { key: "volume", mobileSorting: !0 },
    { key: "priceClose" },
    { key: "commission", level: 2 },
    { key: "commissionFee", level: 2 },
    { key: "storage" },
    { key: "profit", showAlways: !0, mobileSorting: !0 },
    { key: "comment", level: 1 },
  ],
  bl = "_name",
  vl = {
    layout: "layout",
    uiSettings: "ui_settings",
    users: "users",
    objects: "objects",
    indicators: "indicators",
    indicatorsByOrder: "indicatorsByOrder",
    configs: "configs",
    tradeBars: "trade_bars",
    marks: "marks",
    watchlist: "watchlist",
    userSettings: "user_settings",
  };
(Os = Object.defineProperty),
  (Ps = Object.getOwnPropertyDescriptor),
  (Ms = (e, t, o, n) => {
    var r,
      i,
      s = n > 1 ? void 0 : n ? Ps(t, o) : t;
    for (r = e.length - 1; r >= 0; r--)
      (i = e[r]) && (s = (n ? i(t, o, s) : i(s)) || s);
    return n && s && Os(t, o, s), s;
  });
class yl extends _a {
  constructor() {
    super(),
      (this._systemName = vl.uiSettings),
      (this.selectedSymbol = ""),
      (this.firstChartDate = 0),
      (this.controlsOnChart = !0),
      (this.notifications = !0),
      (this.ohlc = !1),
      (this.grid = !0),
      (this.watchlistColumnsWidth = {}),
      (this.watchlistColumnsVisible = {
        [xs.Symbol]: !0,
        [xs.Bid]: !0,
        [xs.Ask]: !0,
        [xs.DailyChange]: !0,
        [xs.High]: !1,
        [xs.Low]: !1,
        [xs.Spread]: !1,
        [xs.Time]: !1,
        [xs.BidHigh]: !1,
        [xs.BidLow]: !1,
        [xs.AskHigh]: !1,
        [xs.AskLow]: !1,
        [xs.PriceOpen]: !1,
        [xs.PriceClose]: !1,
        [xs.Last]: !1,
        [xs.LastHigh]: !1,
        [xs.LastLow]: !1,
      }),
      (this.quotesColumnsVisible = Wt()),
      (this.watchlistSortDirection = Cs.None),
      (this.historyPositionsColumnsVisible = zt()),
      (this.historyPositionsSortDirection = Cs.None),
      (this.historyPositionsHorizontalScroll = !1),
      (this.historyOrdersColumnsVisible = Nt()),
      (this.historyOrdersSortDirection = Cs.None),
      (this.historyOrdersHorizontalScroll = !1),
      (this.historyDealsColumnsVisible = Ft()),
      (this.historyDealsSortDirection = Cs.None),
      (this.historyDealsHorizontalScroll = !1),
      (this.debugMode = !1),
      (this.quickTrade = !1),
      (this.quickTradePosition = !0),
      (this.crosshair = !1),
      (this.popupSizes = {}),
      (this.askPrice = !1);
  }
  resetQuotesColumsVisible() {
    this.quotesColumnsVisible = Wt();
  }
  setSettings(e) {
    "string" == typeof e.selectedSymbol &&
      (this.selectedSymbol = e.selectedSymbol),
      "number" == typeof e.firstChartDate &&
        (this.firstChartDate = e.firstChartDate),
      "boolean" == typeof e.controlsOnChart &&
        (this.controlsOnChart = e.controlsOnChart),
      "boolean" == typeof e.notifications &&
        (this.notifications = e.notifications),
      "boolean" == typeof e.ohlc && (this.ohlc = e.ohlc),
      "boolean" == typeof e.grid && (this.grid = e.grid),
      "boolean" == typeof e.debugMode && (this.debugMode = e.debugMode),
      "boolean" == typeof e.quickTrade && (this.quickTrade = e.quickTrade),
      "boolean" == typeof e.quickTradePosition &&
        (this.quickTradePosition = e.quickTradePosition),
      "boolean" == typeof e.askPrice && (this.askPrice = e.askPrice),
      this.timezone !== e.timezone &&
        "string" == typeof e.timezone &&
        (this.timezone = e.timezone),
      "boolean" == typeof e.crosshair && (this.crosshair = e.crosshair),
      "object" == typeof e.watchlistColumnsWidth &&
        (this.watchlistColumnsWidth = {
          ...this.watchlistColumnsWidth,
          ...e.watchlistColumnsWidth,
        }),
      e.watchlistColumnsVisible &&
        (this.watchlistColumnsVisible = {
          ...this.watchlistColumnsVisible,
          ...e.watchlistColumnsVisible,
        }),
      e.quotesColumnsVisible &&
        (this.quotesColumnsVisible = {
          ...this.quotesColumnsVisible,
          ...e.quotesColumnsVisible,
        }),
      (this.watchlistSortBy = e.watchlistSortBy ?? this.watchlistSortBy),
      (this.watchlistSortDirection =
        e.watchlistSortDirection ?? this.watchlistSortDirection),
      e.historyPositionsColumnsVisible &&
        (this.historyPositionsColumnsVisible = {
          ...this.historyPositionsColumnsVisible,
          ...e.historyPositionsColumnsVisible,
        }),
      (this.historyPositionsSortBy =
        e.historyPositionsSortBy ?? this.historyPositionsSortBy),
      (this.historyPositionsSortDirection =
        e.historyPositionsSortDirection ?? this.historyPositionsSortDirection),
      "boolean" == typeof e.historyPositionsHorizontalScroll &&
        (this.historyPositionsHorizontalScroll =
          e.historyPositionsHorizontalScroll),
      e.historyOrdersColumnsVisible &&
        (this.historyOrdersColumnsVisible = {
          ...this.historyOrdersColumnsVisible,
          ...e.historyOrdersColumnsVisible,
        }),
      (this.historyOrdersSortBy =
        e.historyOrdersSortBy ?? this.historyOrdersSortBy),
      (this.historyOrdersSortDirection =
        e.historyOrdersSortDirection ?? this.historyOrdersSortDirection),
      "boolean" == typeof e.historyOrdersHorizontalScroll &&
        (this.historyOrdersHorizontalScroll = e.historyOrdersHorizontalScroll),
      e.historyDealsColumnsVisible &&
        (this.historyDealsColumnsVisible = {
          ...this.historyDealsColumnsVisible,
          ...e.historyDealsColumnsVisible,
        }),
      (this.historyDealsSortBy =
        e.historyDealsSortBy ?? this.historyDealsSortBy),
      (this.historyDealsSortDirection =
        e.historyDealsSortDirection ?? this.historyDealsSortDirection),
      "boolean" == typeof e.historyDealsHorizontalScroll &&
        (this.historyDealsHorizontalScroll = e.historyDealsHorizontalScroll),
      "object" == typeof e.popupSizes && (this.popupSizes = e.popupSizes);
  }
  resetHistoryPositionsColumnsVisible() {
    this.setSettings({ historyPositionsColumnsVisible: zt() });
  }
  resetHistoryOrdersColumnsVisible() {
    this.setSettings({ historyOrdersColumnsVisible: Nt() });
  }
  resetHistoryDealsColumnsVisible() {
    this.setSettings({ historyDealsColumnsVisible: Ft() });
  }
  reset(e) {
    this.setSettings(e);
  }
}
Ms([rt], yl.prototype, "resetQuotesColumsVisible", 1),
  Ms([rt], yl.prototype, "setSettings", 1);
let $l = null,
  Cl = !1,
  xl = () => {};
const Sl = new Promise((e) => {
  xl = e;
});
let kl = "";
class Al {
  constructor(e, t = []) {
    (this.name = e), (this.keys = [...t]), (this.single = 0 === t.length);
  }
  getAll(e, t) {
    return Cl
      ? new Promise((o) => {
          Sl.then(() => {
            if (!$l) throw new Error("Database not ready");
            const n = $l
              .transaction(this.name, "readwrite")
              .objectStore(this.name);
            let r, i;
            e && t && n.indexNames.contains(e)
              ? ((r = n.index(e)), (i = r.getAll([kl, t])))
              : n.indexNames.contains("userId")
              ? ((r = n.index("userId")), (i = r.getAll(kl)))
              : (i = n.getAll()),
              (i.onsuccess = () => {
                const e = i.result;
                o(e);
              });
          });
        })
      : Promise.resolve([]);
  }
  get(e) {
    return Cl
      ? new Promise((t) => {
          Sl.then(() => {
            if (!$l) throw new Error("Database not ready");
            const o = $l
              .transaction(this.name, "readwrite")
              .objectStore(this.name)
              .get(e);
            o.onsuccess = () => {
              const e = o.result;
              t(e);
            };
          });
        })
      : Promise.resolve(void 0);
  }
  async add(e) {
    if (!Cl) return;
    if ((await Sl, !$l)) throw new Error("Database not ready");
    const t = $l.transaction(this.name, "readwrite").objectStore(this.name);
    t.indexNames.contains("userId")
      ? t.put({ userId: kl, ...e })
      : this.single
      ? t.put({ [bl]: this.name, ...e })
      : t.put(e);
  }
  async remove(e) {
    if (!Cl) return;
    if ((await Sl, !$l)) throw new Error("Database not ready");
    const t = $l.transaction(this.name, "readwrite").objectStore(this.name);
    t.indexNames.contains("userId") ? t.delete([kl, e]) : t.delete(e);
  }
  async removeByUserId(e) {
    if (!Cl) return;
    if ((await Sl, !$l)) throw new Error("Database not ready");
    const t = $l.transaction(this.name, "readwrite").objectStore(this.name),
      o = t.index("userId").getAllKeys(e);
    o.onsuccess = () => {
      o.result.forEach((e) => {
        t.delete(e);
      });
    };
  }
  async clear() {
    return (
      await Sl,
      new Promise((e, t) => {
        if ((Cl || e(), !$l)) throw new Error("Database not ready");
        const o = $l
          .transaction(this.name, "readwrite")
          .objectStore(this.name)
          .clear();
        (o.onsuccess = () => e()), (o.onerror = () => t());
      })
    );
  }
  async addAll(e) {
    if (!Cl) return;
    if ((await Sl, !$l)) throw new Error("Database not ready");
    const t = $l.transaction(this.name, "readwrite").objectStore(this.name);
    t.indexNames.contains("userId")
      ? e.forEach((e) => {
          const o = { userId: kl, ...e };
          t.put(o);
        })
      : e.forEach((e) => t.put(e));
  }
}
const Tl = [
    new Al(vl.layout, []),
    new Al(vl.uiSettings, []),
    new Al(vl.users, ["id"]),
    new Al(vl.objects, ["userId", "uid", "symbol"]),
    new Al(vl.indicators, ["userId", "uid", "symbol"]),
    new Al(vl.indicatorsByOrder, ["userId", "symbol"]),
    new Al(vl.configs, ["userId", "symbol"]),
    new Al(vl.tradeBars, ["userId", "id"]),
    new Al(vl.marks, ["userId"]),
    new Al(vl.watchlist, ["userId"]),
    new Al(vl.userSettings, ["userId"]),
  ],
  Ol = {
    layout: Tl[0],
    ui_settings: Tl[1],
    users: Tl[2],
    objects: Tl[3],
    indicators: Tl[4],
    indicatorsByOrder: Tl[5],
    configs: Tl[6],
    trade_bars: Tl[7],
    marks: Tl[8],
    watchlist: Tl[9],
    user_settings: Tl[10],
  },
  Pl = {
    africa: {
      cairo: "Africa/Cairo",
      casablanca: "Africa/Casablanca",
      johannesburg: "Africa/Johannesburg",
      lagos: "Africa/Lagos",
      nairobi: "Africa/Nairobi",
      tunis: "Africa/Tunis",
    },
    america: {
      anchorage: "America/Anchorage",
      bogota: "America/Bogota",
      buenosAires: "America/Buenos_Aires",
      caracas: "America/Caracas",
      chicago: "America/Chicago",
      denver: "America/Denver",
      elSalvador: "America/El_Salvador",
      juneau: "America/Juneau",
      lima: "America/Lima",
      losAngeles: "America/Los_Angeles",
      mexicoCity: "America/Mexico_City",
      newYork: "America/New_York",
      phoenix: "America/Phoenix",
      santiago: "America/Santiago",
      saoPaulo: "America/Sao_Paulo",
      toronto: "America/Toronto",
      vancouver: "America/Vancouver",
    },
    asia: {
      almaty: "Asia/Almaty",
      ashgabat: "Asia/Ashgabat",
      bahrain: "Asia/Bahrain",
      bangkok: "Asia/Bangkok",
      calcutta: "Asia/Calcutta",
      colombo: "Asia/Colombo",
      dhaka: "Asia/Dhaka",
      dubai: "Asia/Dubai",
      hongKong: "Asia/Hong_Kong",
      jakarta: "Asia/Jakarta",
      jerusalem: "Asia/Jerusalem",
      karachi: "Asia/Karachi",
      katmandu: "Asia/Katmandu",
      kuwait: "Asia/Kuwait",
      manila: "Asia/Manila",
      muscat: "Asia/Muscat",
      nicosia: "Asia/Nicosia",
      qatar: "Asia/Qatar",
      rangoon: "Asia/Rangoon",
      riyadh: "Asia/Riyadh",
      saigon: "Asia/Saigon",
      seoul: "Asia/Seoul",
      shanghai: "Asia/Shanghai",
      singapore: "Asia/Singapore",
      taipei: "Asia/Taipei",
      tehran: "Asia/Tehran",
      tokyo: "Asia/Tokyo",
    },
    atlantic: { reykjavik: "Atlantic/Reykjavik" },
    australia: {
      adelaide: "Australia/Adelaide",
      brisbane: "Australia/Brisbane",
      perth: "Australia/Perth",
      sydney: "Australia/Sydney",
    },
    europe: {
      amsterdam: "Europe/Amsterdam",
      athens: "Europe/Athens",
      belgrade: "Europe/Belgrade",
      berlin: "Europe/Berlin",
      bratislava: "Europe/Bratislava",
      brussels: "Europe/Brussels",
      bucharest: "Europe/Bucharest",
      budapest: "Europe/Budapest",
      copenhagen: "Europe/Copenhagen",
      dublin: "Europe/Dublin",
      helsinki: "Europe/Helsinki",
      istanbul: "Europe/Istanbul",
      lisbon: "Europe/Lisbon",
      london: "Europe/London",
      luxembourg: "Europe/Luxembourg",
      madrid: "Europe/Madrid",
      malta: "Europe/Malta",
      moscow: "Europe/Moscow",
      oslo: "Europe/Oslo",
      paris: "Europe/Paris",
      prague: "Europe/Prague",
      riga: "Europe/Riga",
      rome: "Europe/Rome",
      stockholm: "Europe/Stockholm",
      tallinn: "Europe/Tallinn",
      vienna: "Europe/Vienna",
      vilnius: "Europe/Vilnius",
      warsaw: "Europe/Warsaw",
      zurich: "Europe/Zurich",
    },
    pacific: {
      auckland: "Pacific/Auckland",
      chatham: "Pacific/Chatham",
      fakaofo: "Pacific/Fakaofo",
      honolulu: "Pacific/Honolulu",
      norfolk: "Pacific/Norfolk",
    },
  },
  Ml = [
    { tz: "UTC", offset: 0 },
    ...(function e(t) {
      const o = [];
      return (
        Object.values(t).forEach((t) => {
          if ("object" == typeof t) {
            const n = e(t);
            o.push(...n);
          } else o.push(t);
        }),
        o
      );
    })(Pl)
      .map((e) => ({ tz: e, offset: Yt(e) }))
      .sort((e, t) => e.offset - t.offset),
  ],
  Ll = {};
Ml.forEach((e) => {
  Ll[e.tz] = e;
});
class El {
  constructor(e) {
    (this.uiSettingsStore = e),
      (this.storage = Ol.ui_settings),
      (this.onChangeUiSettings = this.onChangeUiSettings.bind(this));
  }
  async init() {
    const e = await this.storage.get(vl.uiSettings);
    this.uiSettingsStore.reset(e || {}),
      this.setDefaultTimezone(),
      this.uiSettingsUnsubscribe &&
        (this.uiSettingsUnsubscribe(), delete this.uiSettingsUnsubscribe),
      (this.uiSettingsUnsubscribe = this.uiSettingsStore.subscribe(
        this.onChangeUiSettings
      ));
  }
  setDefaultTimezone() {
    if (this.uiSettingsStore.timezone) return;
    let e;
    try {
      const t = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (((e = Ml.find((e) => e.tz === t)), !e))
        throw new Error("Nothing is found");
    } catch (t) {
      const o = new Date().getTimezoneOffset() / 60;
      e = Ml.find((e) => e.offset === -o);
    }
    e
      ? this.uiSettingsStore.setSettings({ timezone: e.tz })
      : this.uiSettingsStore.setSettings({ timezone: Ll.UTC.tz });
  }
  onChangeUiSettings(e) {
    this.storage.add({
      selectedSymbol: e.selectedSymbol,
      controlsOnChart: e.controlsOnChart,
      notifications: e.notifications,
      ohlc: e.ohlc,
      grid: e.grid,
      debugMode: e.debugMode,
      quickTrade: e.quickTrade,
      quickTradePosition: e.quickTradePosition,
      askPrice: e.askPrice,
      timezone: e.timezone,
      watchlistColumnsWidth: e.watchlistColumnsWidth,
      watchlistColumnsVisible: e.watchlistColumnsVisible,
      watchlistSortBy: e.watchlistSortBy,
      watchlistSortDirection: e.watchlistSortDirection,
      quotesColumnsVisible: e.quotesColumnsVisible,
      historyPositionsColumnsVisible: e.historyPositionsColumnsVisible,
      historyPositionsSortBy: e.historyPositionsSortBy,
      historyPositionsSortDirection: e.historyPositionsSortDirection,
      historyPositionsHorizontalScroll: e.historyPositionsHorizontalScroll,
      historyOrdersColumnsVisible: e.historyOrdersColumnsVisible,
      historyOrdersSortBy: e.historyOrdersSortBy,
      historyOrdersSortDirection: e.historyOrdersSortDirection,
      historyOrdersHorizontalScroll: e.historyOrdersHorizontalScroll,
      historyDealsColumnsVisible: e.historyDealsColumnsVisible,
      historyDealsSortBy: e.historyDealsSortBy,
      historyDealsSortDirection: e.historyDealsSortDirection,
      historyDealsHorizontalScroll: e.historyDealsHorizontalScroll,
      crosshair: e.crosshair,
      popupSizes: e.popupSizes,
    });
  }
  async toggleQuickTrade() {
    this.uiSettingsStore.setSettings({
      quickTrade: !this.uiSettingsStore.quickTrade,
    });
  }
}
class Dl {
  constructor() {
    (this.uiSettingsStore = new yl()),
      (this.uiSettingsController = new El(this.uiSettingsStore));
  }
}
(Ls = ((e) => (
  (e[(e.CUSTOM = 0)] = "CUSTOM"),
  (e[(e.CLIENT_AGREEMENT = 1)] = "CLIENT_AGREEMENT"),
  (e[(e.RISK_DISCLOSURE = 2)] = "RISK_DISCLOSURE"),
  (e[(e.CLIENT_AGREEMENT_AND_RISK_DISCLOSURE = 3)] =
    "CLIENT_AGREEMENT_AND_RISK_DISCLOSURE"),
  (e[(e.COMPLAINTS_HANDLING_PROCEDURE = 4)] = "COMPLAINTS_HANDLING_PROCEDURE"),
  (e[(e.ORDER_EXECUTION_POLICY = 5)] = "ORDER_EXECUTION_POLICY"),
  (e[(e.CLIENT_CATEGORISATION_NOTICE = 6)] = "CLIENT_CATEGORISATION_NOTICE"),
  (e[(e.CONFLICTS_OF_INTEREST_POLICY = 7)] = "CONFLICTS_OF_INTEREST_POLICY"),
  (e[(e.DATA_PROTECTION_POLICY = 8)] = "DATA_PROTECTION_POLICY"),
  e
))(Ls || {})),
  (Es = ((e) => (
    (e[(e.OnlyHedge = 1)] = "OnlyHedge"),
    (e[(e.OnlyOther = 0)] = "OnlyOther"),
    (e[(e.All = -1)] = "All"),
    e
  ))(Es || {}));
const _l = new (class {
    constructor() {
      (this.accountUrl = ""),
        (this.traderCountry = ""),
        (this.traderCurrency = ""),
        (this.demoGroups = []),
        (this.realGroups = []);
      const e = window.__terminal_params;
      (this.tradeServerDemo = e.trade_server_demo),
        (this.tradeServerReal = e.trade_server_real),
        (this.broker = {
          name: e.broker.name,
          url: e.broker.url,
          address: e.broker.address,
          email: e.broker.email,
          phone: e.broker.phone,
          desktop_setup_url: e.broker.desktop_setup_url,
        }),
        (this.servers = e.servers.map((e) => ({
          server: e.server,
          type: e.type,
          groups: e.groups.map((e) => ({
            name: e.name,
            group: e.group,
            account_type: e.account_type,
            leverages: e.leverages,
            default_deposit: e.default_deposit,
            currency: e.currency,
            flags: e.flags,
            agreements: e.agreements,
            real: e.real,
            countries: e.countries,
          })),
        }))),
        (this.startupMode = e.startup_mode),
        (this.login = e.login || ""),
        (this.accountAuto = Boolean(e.account_auto)),
        (this.accountUrl = e.account_url || ""),
        (this.demoGroups = this.getDemoGroups()),
        (this.realGroups = this.getRealGroups()),
        (this.build = e.build);
    }
    setTraderParams(e) {
      (this.traderCountry = e[0]),
        (this.traderCurrency = e[1]),
        (this.demoGroups = this.getDemoGroups()),
        (this.realGroups = this.getRealGroups());
    }
    getDemoGroups() {
      const e = this.servers.find(
        ({ server: e }) => e === this.tradeServerDemo
      );
      return e ? no(e.groups, this.traderCountry) : [];
    }
    getRealGroups() {
      const e = this.servers.find(
        ({ server: e }) => e === this.tradeServerReal
      );
      return e ? no(e.groups, this.traderCountry, !0) : [];
    }
  })(),
  Ul = { BOT: 224, RIGHT: 340, LEFT: 320 },
  Bl = {
    None: 0,
    Quotes: 1,
    Journal: 2,
    HistoryPositions: 3,
    HistoryOrders: 4,
    HistoryDeals: 5,
  },
  Vl = { None: 0, Connect: 1, OpenDemo: 2, OpenReal: 3, CreatedAccount: 4 };
Ds = ((e) => (
  (e[(e.Main = 0)] = "Main"),
  (e[(e.Account = 1)] = "Account"),
  (e[(e.Chart = 2)] = "Chart"),
  e
))(Ds || {});
class jl {
  constructor(e) {
    (this.layoutStore = e),
      (this.storage = Ol.layout),
      (this.onChangeLayout = this.onChangeLayout.bind(this)),
      (this.isSubscribed = !1);
  }
  async init() {
    const e = await this.storage.get(vl.layout);
    this.layoutStore.reset(e || {}),
      "open_demo" === _l.startupMode &&
        this.layoutStore.setLayout({ auth: Vl.OpenDemo }),
      this.isSubscribed ||
        (this.layoutStore.subscribe(this.onChangeLayout),
        (this.isSubscribed = !0));
  }
  onChangeLayout(e) {
    this.storage.add({
      symbols: e.symbols,
      botPanel: e.botPanel,
      depthOfMarket: e.depthOfMarket,
      botPanelSize: e.botPanelSize,
      rightPanelSize: e.rightPanelSize,
      leftPanelSize: e.leftPanelSize,
      showLeftBar: e.showLeftBar,
      settingsPanel: e.settingsPanel,
    });
  }
}
(_s = Object.defineProperty),
  (Us = Object.getOwnPropertyDescriptor),
  (Bs = (e, t, o, n) => {
    var r,
      i,
      s = n > 1 ? void 0 : n ? Us(t, o) : t;
    for (r = e.length - 1; r >= 0; r--)
      (i = e[r]) && (s = (n ? i(t, o, s) : i(s)) || s);
    return n && s && _s(t, o, s), s;
  });
class zl extends _a {
  constructor() {
    super(),
      (this._systemName = vl.layout),
      (this.symbols = !0),
      (this.tradeCreate = null),
      (this.tradeEdit = !1),
      (this.botPanel = Bl.None),
      (this.isMobile = !1),
      (this.isSafari = !1),
      (this.tree = !1),
      (this.colors = !1),
      (this.indicators = !1),
      (this.auth = Vl.None),
      (this.depthOfMarket = !1),
      (this.botPanelSize = Ul.BOT),
      (this.rightPanelSize = Ul.RIGHT),
      (this.leftPanelSize = Ul.LEFT),
      (this.hotkeys = !1),
      (this.showLeftBar = !1),
      (this.settingsPanel = !1),
      (this.settingsScreen = Ds.Main),
      (this.otpForm = !1),
      (this.contacts = !1);
  }
  setLayout(e) {
    void 0 !== e.symbols && (this.symbols = e.symbols),
      void 0 !== e.tradeCreate &&
        ((this.tradeCreate = e.tradeCreate),
        "number" == typeof this.tradeCreate && (this.tradeEdit = !1)),
      void 0 !== e.tradeEdit &&
        ((this.tradeEdit = e.tradeEdit ?? this.tradeEdit),
        this.tradeEdit && (this.tradeCreate = null)),
      void 0 !== e.botPanel && (this.botPanel = e.botPanel),
      void 0 !== e.tree && (this.tree = e.tree),
      void 0 !== e.colors && (this.colors = e.colors),
      void 0 !== e.indicators && (this.indicators = e.indicators),
      void 0 !== e.auth && (this.auth = e.auth),
      void 0 !== e.depthOfMarket && (this.depthOfMarket = e.depthOfMarket),
      e.botPanelSize && (this.botPanelSize = e.botPanelSize),
      e.rightPanelSize && (this.rightPanelSize = e.rightPanelSize),
      e.leftPanelSize && (this.leftPanelSize = e.leftPanelSize),
      void 0 !== e.hotkeys && (this.hotkeys = e.hotkeys),
      void 0 !== e.showLeftBar && (this.showLeftBar = e.showLeftBar),
      void 0 !== e.settingsPanel && (this.settingsPanel = e.settingsPanel),
      void 0 !== e.settingsScreen && (this.settingsScreen = e.settingsScreen),
      void 0 !== e.otpForm && (this.otpForm = e.otpForm),
      void 0 !== e.contacts && (this.contacts = e.contacts);
  }
  reset(e) {
    (this.symbols = !0),
      (this.tradeCreate = null),
      (this.tradeEdit = !1),
      (this.botPanel = Bl.Quotes),
      (this.tree = !1),
      (this.indicators = !1),
      (this.depthOfMarket = !1),
      (this.botPanelSize = Ul.BOT),
      (this.rightPanelSize = Ul.RIGHT),
      (this.leftPanelSize = Ul.LEFT),
      (this.showLeftBar = !1),
      (this.settingsPanel = !1),
      (this.settingsScreen = Ds.Main),
      (this.otpForm = !1),
      this.setLayout(e);
  }
}
Bs([rt], zl.prototype, "setLayout", 1);
class Il {
  constructor() {
    (this.layoutStore = new zl()),
      (this.layoutController = new jl(this.layoutStore));
  }
}
const Hl = window.crypto || window.msCrypto,
  Nl = (Hl && (Hl.subtle || Hl.webkitSubtle)) || null,
  Rl = 16,
  ql = "AES-CBC",
  Fl = po() || "111";
class Wl {
  constructor(e, t) {
    (this.usersStore = e),
      (this.layoutController = t),
      (this.onUpdateUsers = this.onUpdateUsers.bind(this)),
      (this.decryptUser = this.decryptUser.bind(this)),
      (this.storage = Ol.users);
  }
  async init() {
    if (
      (this.usersUnsubscribe &&
        (this.usersUnsubscribe(), (this.usersUnsubscribe = void 0)),
      !this.passwordKey)
    ) {
      const e = ro(
          so(":e4dd535gf:ddg7361613d6885fc6841ffd:4g:g498g8266dg:eff33886f738c")
        ),
        t = await this.getPrivateKey(await co(e));
      (this.loginKey = await this.getLoginKey(t)),
        (this.passwordKey = await this.getPasswordKey());
    }
    const e = await this.storage.getAll(),
      t = [];
    e.forEach((e) => t.push(this.decryptUser(e)));
    const o = await Promise.all(t),
      n = [];
    o.forEach((e) => {
      e && n.push(e);
    }),
      this.usersStore.reset(n),
      (this.usersUnsubscribe = this.usersStore.subscribe(this.onUpdateUsers));
    const r = Za.getItem("ll");
    r && this.usersStore.setCurrentUser(r);
  }
  setCurrentUser(e) {
    this.usersStore.setCurrentUser(e),
      e ? Za.setItem("ll", e) : Za.removeItem("ll");
  }
  onUpdateUsers() {
    this.storage.getAll().then(async (e) => {
      const t = this.usersStore.getAllUsers(),
        o = [];
      t.forEach((t) => {
        if (t.line) {
          const n = e.findIndex(({ id: e }) => e === t.id);
          (-1 !== n &&
            e[n].line === t.line &&
            e[n].name === t.name &&
            e[n].currency === t.currency &&
            e[n].profit === t.profit &&
            e[n].balance === t.balance &&
            e[n].leverage === t.leverage &&
            e[n].type === t.type &&
            e[n].isHedgedMargin === t.isHedgedMargin) ||
            o.push(t);
        } else o.push(t);
      });
      const n = await this.encryptUsers(o);
      (await this.storage.getAll()).forEach((e) => {
        -1 === n.findIndex((t) => e.id === t.id) && this.storage.remove(e.id);
      }),
        this.storage.addAll(n);
    });
  }
  updateCurrentUser(e) {
    const t = this.usersStore.getUserByLogin(e.login),
      o = {};
    let n = !1;
    t &&
      (t.name !== e.name && ((o.name = e.name), (n = !0)),
      t.currency !== e.currency && ((o.currency = e.currency), (n = !0)),
      t.balance !== e.balance && ((o.balance = e.balance), (n = !0)),
      t.profit !== e.profit && ((o.profit = e.profit), (n = !0)),
      t.leverage !== e.marginLeverage &&
        ((o.leverage = e.marginLeverage), (n = !0)),
      t.type !== e.type && ((o.type = e.type), (n = !0)),
      t.group !== e.group && ((o.group = e.group), (n = !0)),
      t.isHedgedMargin !== e.isHedgedMargin &&
        ((o.isHedgedMargin = e.isHedgedMargin), (n = !0))),
      n && this.usersStore.updateCurrentUser(e.login, o);
  }
  async addUser(e) {
    const t = await this.generateUserId(e.login, e.server);
    return this.usersStore.addUser({ id: t, ...e }), t;
  }
  async encryptUsers(e) {
    const t = [];
    e.forEach((e) => {
      t.push(this.encryptUser(e));
    });
    const o = await Promise.all(t),
      n = [];
    return (
      o.forEach((e) => {
        e && n.push(e);
      }),
      n
    );
  }
  generateUserId(e, t) {
    return this.encryptLine(
      e,
      t,
      "8:8465cd9d9:138:49gb9gd:9b9:ed9:1c98178f5211e897b234818:df3:ebf2"
    );
  }
  async encryptUser(e) {
    const {
        login: t,
        server: o,
        password: n,
        name: r,
        currency: i,
        profit: s,
        balance: a,
        leverage: l,
        type: c,
        isHedgedMargin: u,
        savePassword: d = !0,
      } = e,
      [h, p] = await Promise.all([
        this.generateUserId(t, o),
        this.encryptLine(t, o, d ? n : ""),
      ]);
    if (h !== e.id) return null;
    const g = { id: h, line: p, updatedAt: Date.now() };
    return (
      r && (g.name = r),
      i && (g.currency = i),
      s && (g.profit = s),
      a && (g.balance = a),
      l && (g.leverage = l),
      void 0 !== c && (g.type = c),
      void 0 !== u && (g.isHedgedMargin = u),
      g
    );
  }
  async decryptUser(e) {
    let t = null;
    try {
      t = await this.decryptLine(e.line);
    } catch (s) {
      (t = null), Error;
    }
    if (!t) return null;
    const { login: o, server: n, password: r } = t;
    let i;
    try {
      i = await this.generateUserId(o, n);
    } catch (s) {
      return Error, null;
    }
    return {
      id: i,
      line: e.id,
      login: o,
      server: n,
      password: r,
      name: e.name,
      currency: e.currency,
      profit: e.profit,
      balance: e.balance,
      leverage: e.leverage,
      type: e.type,
      isHedgedMargin: e.isHedgedMargin,
      savePassword: Boolean(r),
    };
  }
  async encryptPassword(e) {
    if (this.passwordKey) {
      const t = ro(io(e)),
        o = await uo(t, this.passwordKey);
      if (o) return lo(o);
    }
    return "";
  }
  async decryptPassword(e) {
    if (this.passwordKey) {
      const t = ro(e),
        o = await ho(t, this.passwordKey);
      if (o) return new TextDecoder().decode(new Uint8Array(o));
    }
    return "";
  }
  async encryptLine(e, t, o = "") {
    if (this.loginKey) {
      const n = ro(
          io([o ? await this.encryptPassword(o) : "", e, t].join("\t"))
        ),
        r = await uo(n, this.loginKey);
      if (r) return lo(r);
    }
    return "";
  }
  async decryptLine(e) {
    if (
      this.loginKey &&
      e.length &&
      e.length / 16 === Math.floor(e.length / 16)
    ) {
      const t = ro(e),
        o = await ho(t, this.loginKey);
      if (o) {
        const e = new TextDecoder().decode(new Uint8Array(o)).split("\t"),
          t = e[0] ? await this.decryptPassword(e[0]) : "",
          n = Number(e[1]),
          r = e[2];
        return n < 0 ? null : { login: n, password: t, server: r };
      }
    }
    return null;
  }
  async getPrivateKey(e) {
    return uo(
      ro(
        [Fl, so("bfddfd:b:c5b5bdd976fbc::86dec9b:bfbc:685cgc7115389")].join("")
      ),
      e
    );
  }
  async getLoginKey(e) {
    return co(e);
  }
  async getPasswordKey() {
    return co(
      ro(so("987264ef98b:159fe89dd9bf986fc97ggcd7:27dg95dd28173b45f48b:d8e397"))
    );
  }
}
(Vs = Object.defineProperty),
  (js = Object.getOwnPropertyDescriptor),
  (zs = (e, t, o, n) => {
    var r,
      i,
      s = n > 1 ? void 0 : n ? js(t, o) : t;
    for (r = e.length - 1; r >= 0; r--)
      (i = e[r]) && (s = (n ? i(t, o, s) : i(s)) || s);
    return n && s && Vs(t, o, s), s;
  });
class Kl extends _a {
  constructor() {
    super(), (this._systemName = vl.users), (this.items = new Map());
  }
  setCurrentUser(e) {
    e
      ? this.items.has(e) && (this.currentUserId = e)
      : delete this.currentUserId;
  }
  updateCurrentUser(e, t) {
    const o = this.getUserByLogin(e);
    o &&
      (t.name && (o.name = t.name),
      t.currency && (o.currency = t.currency),
      t.balance && (o.balance = t.balance),
      t.profit && (o.profit = t.profit),
      t.leverage && (o.leverage = t.leverage),
      void 0 !== t.type && (o.type = t.type),
      void 0 !== t.isHedgedMargin && (o.isHedgedMargin = t.isHedgedMargin));
  }
  getAllUsers() {
    return Array.from(this.items.values());
  }
  reset(e) {
    return (
      e &&
        ((this.items = new Map()),
        e.forEach((e) => {
          this.items.set(e.id, e);
        })),
      this
    );
  }
  addUser(e) {
    const t = this.items.get(e.id);
    return this.items.set(e.id, { ...(t ?? {}), ...e }), this;
  }
  removeUser(e) {
    this.items.delete(e);
  }
  getUserById(e) {
    return this.items.get(e) || null;
  }
  getUserByLogin(e) {
    return [...this.items.values()].find((t) => Number(t.login) === Number(e));
  }
  getCurrentUser() {
    return this.currentUserId ? this.getUserById(this.currentUserId) : null;
  }
}
zs([rt], Kl.prototype, "setCurrentUser", 1),
  zs([rt], Kl.prototype, "updateCurrentUser", 1),
  zs([rt], Kl.prototype, "reset", 1),
  zs([rt], Kl.prototype, "addUser", 1),
  zs([rt], Kl.prototype, "removeUser", 1);
class Gl {
  constructor(e) {
    (this.usersStore = new Kl()),
      (this.usersController = new Wl(this.usersStore, e));
  }
}
class Zl {
  constructor(e, t) {
    (this.journalStore = e),
      (this.usersController = t),
      (this.onDisconnect = this.onDisconnect.bind(this)),
      (this.onTradeLog = this.onTradeLog.bind(this)),
      (this.onConnect = this.onConnect.bind(this)),
      (this.onGetToken = this.onGetToken.bind(this)),
      (this.onLogin = this.onLogin.bind(this)),
      (this.onLoadAccount = this.onLoadAccount.bind(this)),
      (this.onError = this.onError.bind(this));
  }
  async connectApi(e) {
    this.disconnectApi(),
      (this.api = e),
      this.api.view.on(11, this.onDisconnect),
      this.api.view.on(6, this.onTradeLog),
      this.api.view.on(10, this.onConnect),
      this.api.view.on(9, this.onGetToken),
      this.api.view.on(12, this.onLogin),
      this.api.view.on(13, this.onLoadAccount),
      this.api.view.on(15, this.onError);
    const t = _l.servers && _l.servers.map((e) => e.server).filter(Boolean);
    this.journalStore.log(
      2,
      [
        "Initializing start (",
        `login: ${_l.login || "not specified"}`,
        `, trade_server: ${_l.tradeServerDemo || "not specified"}`,
        `, servers: ${t ? t.join(", ") : "not specified"})`,
      ].join(""),
      !0
    ),
      this.journalStore.log(
        2,
        (() => {
          let e = "Initializing environment was successful (";
          const t = new Date().toString();
          e += `Timezone: ${t.substring(t.indexOf("GMT"))}`;
          const o = it();
          return (
            (e += `, localStorage: ${String(o)}`),
            o &&
              (e += ` (remaining space: ${(function (e) {
                let t;
                const o = Math.floor(Number(e));
                return (
                  (t =
                    o > 1048576
                      ? `${Number(o / 1048576).toFixed(1)} Mb`
                      : o > 1024
                      ? `${Number(o / 1024).toFixed(1)} Kb`
                      : `${o.toFixed(1)} byte`),
                  t
                );
              })(
                (function () {
                  try {
                    return window.localStorage
                      ? 5242880 -
                          window.decodeURI(JSON.stringify(window.localStorage))
                            .length
                      : 0;
                  } catch (e) {
                    return 0;
                  }
                })()
              )})`),
            (e += `, cookie: ${String(Boolean(document.cookie))}`),
            (e += `, webGL: ${String(
              (function () {
                const e = document.createElement("canvas");
                if (e) {
                  const t = e.getContext("webgl");
                  if (null == t ? void 0 : t.createProgram) return !0;
                }
                return !1;
              })()
            )}`),
            (e += `, user-Agent: ${navigator.userAgent}`),
            (e += ")"),
            e
          );
        })(),
        !0
      );
    const o = co(
      ro(so("13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75"))
    );
    o.then(() =>
      this.journalStore.log(2, "Initializing crypto api was successful", !0)
    ).catch(() =>
      this.journalStore.err(2, "Initializing crypto api failed", !0)
    );
    const n = Sl;
    n
      .then(() =>
        this.journalStore.log(2, "Initializing indexedDB was successful", !0)
      )
      .catch(() =>
        this.journalStore.err(2, "Initializing indexedDB was successful", !0)
      ),
      await Promise.all([o, n]),
      this.journalStore.log(2, "MetaTrader Web Trader started");
  }
  err(e, t, o = !1) {
    this.journalStore.err(e, t, o);
  }
  warn(e, t, o = !1) {
    this.journalStore.warn(e, t, o);
  }
  log(e, t, o = !1) {
    this.journalStore.log(e, t, o);
  }
  attn(e, t, o = !1) {
    this.journalStore.attn(e, t, o);
  }
  onError(e) {
    if (e) {
      const { code: t, command: o } = e;
      1 === t
        ? this.journalStore.err(3, "websocket returned internal error.", !0)
        : 2 === t
        ? this.journalStore.err(
            3,
            "websocket returned error: trade server is not available.",
            !0
          )
        : (3 !== t && 28 !== o) ||
          this.journalStore.err(
            3,
            "websocket returned error: authorization error on the trading server.",
            !0
          );
    }
  }
  getLogin() {
    const e = this.usersController.usersStore.getCurrentUser();
    return (null == e ? void 0 : e.login)
      ? `${null == e ? void 0 : e.login}: `
      : "";
  }
  onLoadAccount(e) {
    const t = this.getLogin();
    e.isInvestor
      ? this.journalStore.log(
          6,
          `${t}trading has been disabled - investor mode`
        )
      : e.isTradeDisabled ||
        e.isReadOnly ||
        (e.isHedgedMargin
          ? this.journalStore.log(
              6,
              `${t}trading has been enabled - hedging mode`
            )
          : this.journalStore.log(
              6,
              `${t}trading has been enabled - netting mode`
            ));
  }
  onTradeLog(e) {
    e && this.journalStore.log(6, e);
  }
  onDisconnect(e) {
    var t;
    this.journalStore.log(
      3,
      (null == (t = e.event.event) ? void 0 : t.wasClean)
        ? "websocket connection was closed by the server-side (to create demo account)"
        : "websocket connection was suddenly closed (to create demo account)",
      !0
    );
  }
  onConnect() {
    this.journalStore.log(
      3,
      `${this.getLogin()}websocket connection is successfully established`,
      !0
    );
  }
  onGetToken(e) {
    this.journalStore.log(
      3,
      `${this.getLogin()}token for authorization received (server: ${e})`,
      !0
    );
  }
  onLogin(e) {
    this.journalStore.log(3, `${this.getLogin()}authorized on ${e}`);
  }
  disconnectApi() {
    this.api &&
      (this.api.view.off(11, this.onDisconnect),
      this.api.view.off(6, this.onTradeLog),
      this.api.view.off(10, this.onConnect),
      this.api.view.off(9, this.onGetToken),
      this.api.view.off(12, this.onLogin),
      this.api.view.off(13, this.onLoadAccount),
      this.api.view.off(15, this.onError));
  }
}
(Is = Object.defineProperty),
  (Hs = Object.getOwnPropertyDescriptor),
  (Ns = (e, t, o, n) => {
    var r,
      i,
      s = n > 1 ? void 0 : n ? Hs(t, o) : t;
    for (r = e.length - 1; r >= 0; r--)
      (i = e[r]) && (s = (n ? i(t, o, s) : i(s)) || s);
    return n && s && Is(t, o, s), s;
  });
class Yl extends _a {
  constructor() {
    super(),
      (this._systemName = "journal"),
      (this.list = []),
      (this.index = { code: {}, type: {} }),
      (this.add = this.add.bind(this));
  }
  getList(e = !1) {
    return e
      ? [...this.list]
      : this.list.filter((e) => !e.debug || 2 === e.code);
  }
  add(e) {
    var t, o;
    this.list.push(e),
      (this.index.code[e.code] = this.index.code[e.code] || []),
      null == (t = this.index.code[e.code]) || t.push(e),
      (this.index.type[e.type] = this.index.type[e.type] || []),
      null == (o = this.index.type[e.type]) || o.push(e);
  }
  log(e, t, o = !1) {
    this.add({ time: Date.now(), code: 0, message: t, type: e, debug: o });
  }
  warn(e, t, o = !1) {
    this.add({ time: Date.now(), code: 1, message: t, type: e, debug: o });
  }
  err(e, t, o = !1) {
    this.add({ time: Date.now(), code: 2, message: t, type: e, debug: o });
  }
  attn(e, t, o = !1) {
    this.add({ time: Date.now(), code: 3, message: t, type: e, debug: o });
  }
  clear() {
    (this.list = []), (this.index = { code: {}, type: {} });
  }
}
Ns([rt], Yl.prototype, "add", 1), Ns([rt], Yl.prototype, "clear", 1);
class Jl {
  constructor(e) {
    (this.journalStore = new Yl()),
      (this.journalController = new Zl(this.journalStore, e));
  }
}
const { theme: Ql, mode: Xl } = Ja.ThemeController.init(),
  ec = Ja.ThemeController.load(Xl, Ql),
  tc = new (class {
    constructor(e, t, o) {
      (this.theme = new Ja(e, t, o)),
        (this.layout = new Il()),
        (this.uiSettings = new Dl()),
        (this.users = new Gl(this.layout.layoutController)),
        (this.journal = new Jl(this.users.usersController));
    }
    async init() {
      await (async function () {
        const e = window.self.indexedDB.open("database", 13);
        return (
          (e.onerror = (e) => {
            (Cl = !1), xl();
          }),
          (e.onsuccess = () => {
            (Cl = !0), ($l = e.result), xl();
          }),
          (e.onupgradeneeded = (t) => {
            (Cl = !0),
              (function (e, t, o) {
                const n = e.result,
                  r = e.transaction;
                t.oldVersion < 10
                  ? (function (e, t) {
                      t.forEach((t) => {
                        if (
                          (e.objectStoreNames.contains(t.name) &&
                            e.deleteObjectStore(t.name),
                          t.keys.includes("userId"))
                        ) {
                          const o = t.keys.indexOf("userId"),
                            n = t.keys;
                          -1 !== o && n.splice(o, 1);
                          const r = e.createObjectStore(t.name, {
                            keyPath: ["userId", n[0]].filter(Boolean),
                          });
                          r.createIndex("userId", "userId", { unique: !1 }),
                            n.forEach((e) => {
                              r.createIndex(e, ["userId", e], { unique: !1 });
                            });
                        } else if (t.single)
                          e.createObjectStore(t.name, { keyPath: bl });
                        else {
                          const o = e.createObjectStore(t.name, {
                            keyPath: t.keys[0],
                          });
                          t.keys.length > 1 &&
                            t.keys.forEach((e) => {
                              o.createIndex(e, e, { unique: !1 });
                            });
                        }
                      });
                    })(n, o)
                  : (t.oldVersion < 11 &&
                      (function (e) {
                        const t = e.createObjectStore(vl.indicatorsByOrder, {
                          keyPath: ["userId", "symbol"],
                        });
                        t.createIndex("userId", "userId", { unique: !1 }),
                          t.createIndex("symbol", ["userId", "symbol"], {
                            unique: !1,
                          });
                      })(n),
                    t.oldVersion < 12 &&
                      (function (e) {
                        e.createObjectStore(vl.marks, {
                          keyPath: ["userId"],
                        }).createIndex("userId", "userId", { unique: !1 });
                      })(n),
                    t.oldVersion < 13 &&
                      (function (e, t) {
                        if (
                          ((function (e) {
                            e.createObjectStore(vl.userSettings, {
                              keyPath: ["userId"],
                            }).createIndex("userId", "userId", { unique: !1 });
                          })(e),
                          !t)
                        )
                          return Kt(e), Gt(e), void Zt(e);
                        !(function (e, t) {
                          const o = t.objectStore(vl.layout).getAll();
                          (o.onsuccess = () => {
                            const t = o.result[0],
                              n = Kt(e);
                            delete t.userId, n.add({ [bl]: vl.layout, ...t });
                          }),
                            (o.onerror = () => Kt(e));
                        })(e, t),
                          (function (e, t) {
                            const o = t.objectStore(vl.uiSettings).getAll();
                            (o.onsuccess = () => {
                              const t = o.result[0],
                                n = Gt(e);
                              delete t.userId,
                                n.add({ [bl]: vl.uiSettings, ...t });
                            }),
                              (o.onerror = () => Gt(e));
                          })(e, t),
                          (function (e, t) {
                            const o = t.objectStore(vl.users).getAll();
                            (o.onsuccess = () => {
                              const t = o.result,
                                n = Zt(e);
                              t.forEach((e) => {
                                const t = e.userId;
                                delete e.userId, n.add({ ...e, id: t });
                              });
                            }),
                              (o.onerror = () => Zt(e));
                          })(e, t);
                      })(n, r));
              })(e, t, Tl);
          }),
          Sl
        );
      })(),
        this.theme.themeController.init(),
        await this.layout.layoutController.init(),
        await this.uiSettings.uiSettingsController.init(),
        await this.users.usersController.init();
    }
  })(Ql, Xl, ec);
let oc = null;
class nc extends ya {
  constructor(e) {
    super(), je(this, e, fo, go, s, { parent: 2, style: 0 });
  }
}
class rc extends ya {
  constructor(e) {
    super(), je(this, e, null, wo, s, {});
  }
}
class ic extends ya {
  constructor(e) {
    super(), je(this, e, vo, bo, s, { name: 0, width: 1, height: 2 });
  }
}
class sc extends Error {
  constructor(e) {
    super(e.message ?? ""),
      (this.command = e.command),
      (this.code = e.code),
      (this.count = e.count);
  }
}
let ac = null,
  lc = !1;
const cc = (function () {
  if (
    (lc ||
      ((lc = !0),
      ac ||
        ((ac = document.createElement("div")),
        (ac.className = "GoogleAd Advertisment BannerAd"),
        (ac.id = "yandex_ad"),
        (ac.style.width = "1px"),
        (ac.style.height = "1px"),
        (ac.style.visibility = "hidden"),
        (ac.style.position = "absolute"),
        document.body.appendChild(ac))),
    !ac)
  )
    return !1;
  const e = 0 === ac.offsetHeight;
  try {
    document.body.removeChild(ac);
  } catch (t) {}
  return (ac = null), e;
})();
let uc = class extends ya {
  constructor(e) {
    super(), je(this, e, xo, Co, s, { warning: 0 });
  }
};
class dc extends ya {
  constructor(e) {
    super(), je(this, e, _o, Do, s, { message: 0, warning: 1 });
  }
}
class hc extends ya {
  constructor(e) {
    super(),
      je(this, e, Bo, Uo, s, {
        mobile: 0,
        cols: 1,
        gap: 2,
        marginBottom: 3,
        style: 4,
      });
  }
}
const pc = (e) => ({}),
  gc = (e) => ({});
class mc extends ya {
  constructor(e) {
    super(),
      je(this, e, zo, jo, s, {
        disabled: 0,
        active: 1,
        title: 2,
        icon: 3,
        type: 4,
        red: 5,
        style: 6,
      });
  }
}
const { window: fc } = oa,
  wc = (e) => ({ maxContentHeight: 147456 & e[0] }),
  bc = (e) => ({ maxContentHeight: e[14] - e[17] }),
  vc = (e) => ({}),
  yc = (e) => ({}),
  $c = (e) => ({}),
  Cc = (e) => ({});
class xc extends ya {
  constructor(e) {
    super(),
      je(
        this,
        e,
        Fo,
        Ro,
        s,
        {
          mobile: 0,
          title: 1,
          draggable: 2,
          resizable: 3,
          closeOnOverlayClick: 4,
          closeOnEsc: 5,
          hideCloseButton: 6,
          width: 33,
          height: 34,
          calcPosition: 35,
        },
        null,
        [-1, -1]
      );
  }
  get calcPosition() {
    return this.$$.ctx[35];
  }
}
Rs = ((e) => (
  (e[(e.NONE = 0)] = "NONE"),
  (e[(e.API_AJAX = 1)] = "API_AJAX"),
  (e[(e.API_SOCKET = 2)] = "API_SOCKET"),
  (e[(e.API_LOGIN = 3)] = "API_LOGIN"),
  (e[(e.USER = 4)] = "USER"),
  (e[(e.MODULES = 5)] = "MODULES"),
  (e[(e.DONE = 6)] = "DONE"),
  (e[(e.ERROR = 7)] = "ERROR"),
  e
))(Rs || {});
class Sc {
  constructor(e, t, o, n) {
    (this.authStore = e),
      (this.usersController = t),
      (this.layoutController = o),
      (this.journalController = n);
  }
  async login(e) {
    const { authApi: t } = await Ys(
        () => import("./42f624f0.js"),
        ["42f624f0.js", "04a8e93f.js"]
      ),
      o = Ys(
        () => import("./25029c36.js").then((e) => e.m),
        [
          "25029c36.js",
          "d09b99f6.js",
          "917f94f7.js",
          "f54151ac.js",
          "02c71ccc.css",
          "7313b880.css",
          "f60bb92f.js",
          "a4b22e5d.js",
          "a3b77070.css",
          "883cebe6.css",
          "3049ce3f.js",
        ]
      ),
      n = (function (e) {
        const t = document.createElement("a");
        return (t.href = e), t;
      })(document.referrer).hostname;
    let r;
    try {
      r = await t.login({ ...e, url: n });
    } catch (i) {
      throw i;
    }
    return async () => {
      let t;
      try {
        t = await r();
      } catch (i) {
        throw i;
      }
      return async () => {
        let n;
        try {
          (n = await t()), n.view.on(11, this.onDisconnect.bind(this, n));
        } catch (i) {
          throw i;
        }
        return async () => {
          let t;
          try {
            this.authStore.clearUnsavedPasswords(),
              (t = await this.usersController.addUser({
                login: e.login,
                password: e.password,
                server: e.server,
                savePassword: e.savePassword,
              })),
              this.usersController.setCurrentUser(t),
              (kl = t);
          } catch (i) {
            throw (i instanceof sc || Error, i);
          }
          return async () => {
            try {
              const { Modules: e } = await o,
                t = new e(n);
              return await t.init(), t;
            } catch (i) {
              throw (Error, i);
            }
          };
        };
      };
    };
  }
  onDisconnect(e, t) {
    var o, n;
    null == (o = null == e ? void 0 : e.view) || o.destroy();
    const r = this.usersController.usersStore.getCurrentUser();
    r &&
      r.login === t.login &&
      (null == (n = this.authStore.modules) ? void 0 : n.api) === e &&
      this.existing(r, 5).then((e) => {
        e || this.layoutController.layoutStore.setLayout({ auth: r.id });
      });
  }
  async setModules(e) {
    this.authStore.setModules(e);
  }
  async connectOtp(e, t, o, n, r) {
    const { authApi: i } = await Ys(
      () => import("./42f624f0.js"),
      ["42f624f0.js", "04a8e93f.js"]
    );
    await i.connectOtp({
      login: t,
      server: e,
      password: o,
      otp_secret: n,
      otp_secret_check: r,
    });
  }
  async connect() {
    var e, t, o;
    this.authStore.setConnect({ status: 1 });
    try {
      const t = await this.login({
        login: this.authStore.connect.values.login,
        password: this.authStore.connect.values.password,
        server: this.authStore.connect.values.server,
        savePassword: this.authStore.connect.values.savePassword,
        otp: this.authStore.connect.values.otp,
      });
      this.authStore.setConnect({ status: 2 });
      const o = await t();
      this.authStore.setConnect({ status: 3 });
      const n = await o();
      this.authStore.setConnect({ status: 4 });
      const r = await n();
      this.authStore.setConnect({ status: 5 }),
        await (null == (e = this.authStore.modules) ? void 0 : e.destroy());
      const i = await r();
      return (
        this.logout(!0),
        await this.setModules(i),
        this.authStore.setConnect({ status: 6 }),
        this.authStore.createdUser && this.authStore.setCreatedUser(),
        this.journalController.log(
          3,
          `${this.authStore.connect.values.login} authorized on ${this.authStore.connect.values.server}`
        ),
        !0
      );
    } catch (n) {
      this.authStore.setConnect({ status: 0 });
      let e = "Unknown error";
      if (n instanceof sc) {
        201 === n.code
          ? this.authStore.setConnect({
              errors: { otp: "Invalid account OTP" },
              focus: "otp",
            })
          : 5 === n.code
          ? (this.authStore.setConnect({ focus: "otp" }),
            (null == (t = this.authStore.connect.error) ? void 0 : t.code) ===
              n.code &&
              this.authStore.setConnect({
                errors: { otp: "Invalid account OTP" },
              }),
            this.authStore.setConnect({ showOtp: !0 }))
          : 6 === n.code
          ? this.authStore.setConnect({ showOtpConnect: !0 })
          : this.authStore.setConnect({ showOtp: !1 }),
          this.authStore.setConnect({ values: { otp: "" } });
        const e = yo(
          n.code,
          null == (o = this.authStore.connect.error) ? void 0 : o.code
        );
        this.authStore.setConnect({ error: e }),
          "error" === e.type && this.journalController.err(3, e.message);
      } else
        n instanceof Error &&
          ((e = n.message),
          this.authStore.setConnect({
            error: { message: n.message, type: "error" },
          }));
      return (
        this.authStore.connect.error ||
          (this.authStore.connect.error = { message: e, type: "error" }),
        !1
      );
    }
  }
  async existing(e, t = 0) {
    var o, n, r;
    this.authStore.setExisting(e.login, { status: 1 });
    try {
      const t = await this.login({
        login: e.login,
        password:
          this.authStore.existing[e.login].values.password || e.password,
        server: e.server,
        savePassword: this.authStore.existing[e.login].values.savePassword,
        otp: this.authStore.existing[e.login].values.otp,
      });
      this.authStore.setExisting(e.login, { status: 2 });
      const n = await t();
      this.authStore.setExisting(e.login, { status: 3 });
      const r = await n();
      this.authStore.setExisting(e.login, { status: 4 });
      const i = await r();
      this.authStore.setExisting(e.login, { status: 5 }),
        await (null == (o = this.authStore.modules) ? void 0 : o.destroy());
      const s = await i();
      return (
        this.logout(!0),
        await this.setModules(s),
        this.authStore.setExisting(e.login, {
          showOtp: !1,
          showOtpConnect: !1,
          values: { otp: "" },
        }),
        this.authStore.setExisting(e.login, { status: 6 }),
        this.authStore.createdUser && this.authStore.setCreatedUser(),
        this.authStore.setExisting(e.login, { error: null }),
        this.journalController.log(3, `${e.login} authorized on ${e.server}`),
        !0
      );
    } catch (i) {
      this.authStore.setExisting(e.login, { status: 0 });
      let o = "Unknown error";
      if (i instanceof sc) {
        201 === i.code
          ? this.authStore.setExisting(e.login, {
              errors: { otp: "Invalid account OTP" },
              focus: "otp",
            })
          : 5 === i.code
          ? (this.authStore.setExisting(e.login, { focus: "otp" }),
            (null == (n = this.authStore.existing[e.login].error)
              ? void 0
              : n.code) === i.code &&
              this.authStore.setExisting(e.login, {
                errors: { otp: "Invalid account OTP" },
              }),
            this.authStore.setExisting(e.login, { showOtp: !0 }))
          : 6 === i.code
          ? this.authStore.setExisting(e.login, { showOtpConnect: !0 })
          : this.authStore.setExisting(e.login, { showOtp: !1 }),
          this.authStore.setExisting(e.login, { values: { otp: "" } });
        const o = yo(
          i.code,
          null == (r = this.authStore.existing[e.login].error) ? void 0 : r.code
        );
        if (
          (this.authStore.setExisting(e.login, { error: o }),
          "error" === o.type && this.journalController.err(3, o.message),
          (100 === i.code || 2 === i.code) && t > 0)
        )
          return this.existing(e, t - 1);
        this.setModules(null);
      } else
        i instanceof Error &&
          ((o = i.message),
          this.authStore.setExisting(e.login, {
            error: { message: i.message, type: "error" },
          }));
      return (
        this.authStore.existing[e.login].error ||
          (this.authStore.existing[e.login].error = {
            message: o,
            type: "error",
          }),
        !1
      );
    }
  }
  async logout(e = !1) {
    var t;
    const o = this.usersController.usersStore.getCurrentUser();
    o &&
      this.authStore.setExisting(null == o ? void 0 : o.login, {
        values: { otp: "", password: "" },
      }),
      e || this.usersController.setCurrentUser();
    const n = this.authStore.modules;
    n &&
      (this.authStore.setModules(null),
      await (null == (t = null == n ? void 0 : n.account)
        ? void 0
        : t.accountController.logout()));
  }
}
(qs = Object.defineProperty),
  (Fs = Object.getOwnPropertyDescriptor),
  (Ws = (e, t, o, n) => {
    var r,
      i,
      s = n > 1 ? void 0 : n ? Fs(t, o) : t;
    for (r = e.length - 1; r >= 0; r--)
      (i = e[r]) && (s = (n ? i(t, o, s) : i(s)) || s);
    return n && s && qs(t, o, s), s;
  });
class kc extends _a {
  constructor() {
    super(...arguments),
      (this.createdUser = null),
      (this.connect = {
        values: {
          login: "",
          password: "",
          server: "",
          savePassword: !1,
          otp: "",
        },
        status: Rs.NONE,
        error: null,
        errors: {},
        showOtp: !1,
        showOtpConnect: !1,
        focus: "",
      }),
      (this.existing = {}),
      (this.modules = null);
  }
  getExisting(e) {
    return (
      this.existing[String(e)] || (this.createExisting(e), this.refresh()),
      this.existing[String(e)] || {
        values: { otp: "" },
        status: Rs.NONE,
        error: null,
        errors: {},
        showOtp: !1,
        showOtpConnect: !1,
        showChangePassword: !1,
        focus: "",
      }
    );
  }
  createExisting(e) {
    const t = String(e);
    this.existing[t] = this.existing[t] || {
      values: { otp: "", password: "", savePassword: !0 },
      status: Rs.NONE,
      error: null,
      errors: {},
      showOtp: !1,
      showOtpConnect: !1,
      showChangePassword: !1,
      focus: "",
    };
  }
  setExisting(e, t) {
    const o = String(e);
    this.createExisting(e),
      "number" == typeof t.status && (this.existing[o].status = t.status),
      void 0 !== t.error && (this.existing[o].error = t.error),
      void 0 !== t.errors && (this.existing[o].errors = t.errors),
      "boolean" == typeof t.showOtp &&
        (Object.values(this.existing).forEach((e) => {
          e.showOtp = !1;
        }),
        (this.existing[o].showOtp = t.showOtp)),
      "boolean" == typeof t.showOtpConnect &&
        (Object.values(this.existing).forEach((e) => {
          e.showOtpConnect = !1;
        }),
        (this.existing[o].showOtpConnect = t.showOtpConnect)),
      "boolean" == typeof t.showChangePassword &&
        (this.existing[o].showChangePassword = t.showChangePassword),
      "string" == typeof t.focus && (this.existing[o].focus = t.focus),
      "boolean" == typeof t.showOtpDisconnect &&
        (this.existing[o].showOtpDisconnect = t.showOtpDisconnect),
      t.values &&
        (t.values.otp &&
          Object.values(this.existing).forEach((e) => {
            e.values.otp = "";
          }),
        (this.existing[o].values = {
          ...this.existing[o].values,
          ...t.values,
        }));
  }
  clearUnsavedPasswords() {
    Object.values(this.existing).forEach((e) => {
      e.values.savePassword || (e.values.password = "");
    });
  }
  setConnect(e) {
    "number" == typeof e.status && (this.connect.status = e.status),
      void 0 !== e.error && (this.connect.error = e.error),
      void 0 !== e.errors && (this.connect.errors = e.errors),
      "boolean" == typeof e.showOtp && (this.connect.showOtp = e.showOtp),
      "boolean" == typeof e.showOtpConnect &&
        (this.connect.showOtpConnect = e.showOtpConnect),
      "string" == typeof e.focus && (this.connect.focus = e.focus),
      e.values &&
        (this.connect.values = { ...this.connect.values, ...e.values });
  }
  setModules(e) {
    this.modules = e;
  }
  setCreatedUser(e = null) {
    this.createdUser = e;
  }
}
Ws([rt], kc.prototype, "createExisting", 1),
  Ws([rt], kc.prototype, "setExisting", 1),
  Ws([rt], kc.prototype, "setConnect", 1),
  Ws([rt], kc.prototype, "setModules", 1),
  Ws([rt], kc.prototype, "setCreatedUser", 1);
const Ac = new (class {
  constructor(e, t, o) {
    (this.authStore = new kc()),
      (this.authController = new Sc(this.authStore, e, t, o));
  }
})(
  tc.users.usersController,
  tc.layout.layoutController,
  tc.journal.journalController
);
let Tc = new ArrayBuffer(0);
const Oc = {
  parse: function (e, t, o = 0) {
    const n = [],
      r = new DataView(e);
    return (
      t.forEach((t, i) => {
        if (o >= e.byteLength) return;
        let s = 0;
        switch (t.propType) {
          case 1:
            (s = r.getInt8(o)), (o += 1);
            break;
          case 2:
            (s = r.getInt16(o, !0)), (o += 2);
            break;
          case 3:
            (s = r.getInt32(o, !0)), (o += 4);
            break;
          case 4:
            (s = r.getUint8(o)), (o += 1);
            break;
          case 5:
            (s = r.getUint16(o, !0)), (o += 2);
            break;
          case 6:
            (s = r.getUint32(o, !0)), (o += 4);
            break;
          case 7:
            (s = r.getFloat32(o, !0)), (o += 4);
            break;
          case 8:
            (s = r.getFloat64(o, !0)), (o += 8);
            break;
          case 9:
            (s = (function (e, t = 0) {
              const o = new Uint8Array(e);
              let n = 0;
              for (let r = 7; r >= 0; r--) n = 256 * n + o[t + r];
              return (n = Math.floor(n / 1e4) - 116444736e5), n;
            })(e, o)),
              (o += 8);
            break;
          case 10:
            (s = Jo(e, o, t.propLength)), t.propLength && (o += t.propLength);
            break;
          case 11:
            (s = (function (e, t = 0, o = 0) {
              if (!e) return "";
              const n = new DataView(e);
              let r = "";
              for (let i = t, s = t + o; i < s; i += 2) {
                const e = n.getUint16(i, !0);
                if (0 === e) break;
                r += String.fromCharCode(e);
              }
              return r;
            })(e, o, t.propLength)),
              (null == t ? void 0 : t.propLength) && (o += t.propLength);
            break;
          case 12:
            if (t.propLength || t.propLengthType) {
              if (t.propLengthType)
                switch (t.propLengthType) {
                  case 4:
                    (t.propLength = r.getUint8(o)), (o += 1);
                    break;
                  case 5:
                    (t.propLength = r.getUint16(o, !0)), (o += 2);
                    break;
                  case 6:
                    (t.propLength = r.getUint32(o, !0)), (o += 4);
                }
              if (!t.propLength) return;
              (s = e.slice(o, o + t.propLength)),
                t.parser && s instanceof ArrayBuffer && (s = t.parser(s)),
                (o += t.propLength);
            }
            break;
          case 17:
            (s = r.getBigInt64(o, !0)), (o += 8);
            break;
          case 18:
            (s = r.getBigUint64(o, !0)), (o += 8);
        }
        n[i] = s;
      }),
      n
    );
  },
  toHex: function (e) {
    return Array.from(new Uint8Array(e))
      .map((e) => e.toString(16).padStart(2, "0"))
      .join("");
  },
  serialize: function (e) {
    if (!e.length) return null;
    const t = new ArrayBuffer(Qo(e)),
      o = new Uint8Array(t),
      n = new DataView(t);
    let r = 0;
    return (
      e.forEach((e) => {
        var i;
        switch (e.propType) {
          case 1:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setInt8(r, e.propValue), (r += 1);
            break;
          case 2:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setInt16(r, e.propValue, !0), (r += 2);
            break;
          case 3:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setInt32(r, e.propValue, !0), (r += 4);
            break;
          case 17:
            if ("bigint" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "bigint");
              throw new Error(t);
            }
            n.setBigInt64(r, e.propValue, !0), (r += 8);
            break;
          case 4:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setUint8(r, e.propValue), (r += 1);
            break;
          case 5:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setUint16(r, e.propValue, !0), (r += 2);
            break;
          case 6:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setUint32(r, e.propValue, !0), (r += 4);
            break;
          case 18:
            if ("bigint" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "bigint");
              throw new Error(t);
            }
            n.setBigUint64(r, e.propValue, !0), (r += 8);
            break;
          case 7:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setFloat32(r, e.propValue, !0), (r += 4);
            break;
          case 8:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            n.setFloat64(r, e.propValue, !0), (r += 8);
            break;
          case 9:
            if ("number" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "number");
              throw new Error(t);
            }
            !(function (e, t, o) {
              if (!e) return;
              const n = new DataView(e);
              let r = 1e4 * (o + 116444736e5);
              for (let i = 0; i < 8; i++) n.setInt8(t + i, r % 256), (r /= 256);
            })(t, r, e.propValue),
              (r += 8);
            break;
          case 10:
            if ("string" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "string");
              throw new Error(t);
            }
            Yo(t, e.propValue, r), (r += e.propLength || e.propValue.length);
            break;
          case 11:
            if ("string" != typeof e.propValue) {
              const t = Zo(typeof e.propValue, "string");
              throw new Error(t);
            }
            !(function (e, t = "", o = 0) {
              if (!e) return;
              const n = new DataView(e);
              for (let r = 0, i = t.length; r < i; r++)
                n.setInt16(o, t.charCodeAt(r), !0), (o += 2);
            })(t, e.propValue, r),
              (r += e.propLength || 2 * e.propValue.length);
            break;
          case 12:
            if (
              (null == (i = e.propValue) ? void 0 : i.constructor) !==
              ArrayBuffer
            ) {
              const t = Zo(typeof e.propValue, "ArrayBuffer");
              throw new Error(t);
            }
            o.set(new Uint8Array(e.propValue), r),
              (r += e.propValue.byteLength);
        }
      }),
      t
    );
  },
  getSeriesSize: Qo,
  setCharString: Yo,
  getCharString: Jo,
  getString16: function (e, t, o) {
    const n = new Uint8Array(e.slice(t, t + o));
    return (function (e) {
      let t = "";
      const o = e.length;
      let n = 0;
      for (; n < o; ) {
        const o = e.charCodeAt(n);
        switch (((n += 1), o >> 4)) {
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
            t += e.charAt(n - 1);
            break;
          case 12:
          case 13: {
            const r = e.charCodeAt(n);
            (n += 1), (t += String.fromCharCode(((31 & o) << 6) | (63 & r)));
            break;
          }
          case 14: {
            const r = e.charCodeAt(n);
            n += 1;
            const i = e.charCodeAt(n);
            (n += 1),
              (t += String.fromCharCode(
                ((15 & o) << 12) | ((63 & r) << 6) | ((63 & i) << 0)
              ));
            break;
          }
        }
      }
      return t;
    })(String.fromCharCode(...n));
  },
  concat: function (e, t) {
    const o = new Uint8Array(e.byteLength + t.byteLength);
    return (
      o.set(new Uint8Array(e), 0),
      o.set(new Uint8Array(t), e.byteLength),
      o.buffer
    );
  },
};
class Pc {
  constructor(e, t) {
    (this.canceled = !1),
      (this.timeout = void 0),
      (this.start = 0),
      (this.command = e),
      (this.buffer = t),
      (this.promise = new Promise((e, t) => {
        (this.resolve = e), (this.reject = t);
      })),
      (this.promise.request = this);
  }
  resolvePromise(e) {
    !this.canceled &&
      this.resolve &&
      ((this.canceled = !0), this.resolve(e), this.stopTimeout());
  }
  rejectPromise(e) {
    !this.canceled &&
      this.reject &&
      ((this.canceled = !0), this.reject(e), this.stopTimeout());
  }
  onTimeout(e) {
    return (
      (this.timeout = window.setTimeout(() => {
        e(this);
      }, 3e4)),
      this
    );
  }
  stopTimeout() {
    return (
      window.clearTimeout(this.timeout),
      (this.canceled = !0),
      delete this.timeout,
      delete this.resolve,
      delete this.reject,
      this
    );
  }
}
const Mc = {
    Close: "close",
    Error: "error",
    Open: "open",
    Reconnect: "reconnect",
  },
  Lc = [
    0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22,
    23, 24, 25, 27, 28, 29, 30, 33, 34, 37, 38, 39, 40, 41, 42, 43, 44, 50, 51,
  ],
  Ec = new Set(Lc);
class Dc {
  constructor(e, t) {
    (this.isReady = !1),
      (this.requests = new Map()),
      (this.listeners = new Map()),
      (this.queues = new Map()),
      (this.systemListeners = new Map()),
      (this.count = 0),
      (this.count = t),
      (this.server = e.signal_server),
      "string" == typeof e.token
        ? (this.token = (function (e = "") {
            const t = new ArrayBuffer(64);
            return Oc.setCharString(t, e, 0), t;
          })(e.token))
        : (this.token = e.token),
      (this.apiKey = e.apiKey),
      this.reset(),
      (this.onMessage = this.onMessage.bind(this)),
      (this.onParse = this.onParse.bind(this)),
      (this.onClose = this.onClose.bind(this)),
      (this.onTimeout = this.onTimeout.bind(this)),
      (this.onError = this.onError.bind(this)),
      (this.onOpen = this.onOpen.bind(this));
  }
  get readyState() {
    var e;
    return null == (e = this.webSocket) ? void 0 : e.readyState;
  }
  getServer() {
    return this.server;
  }
  recreateSocket(e) {
    return new Dc(
      { signal_server: this.server, token: this.token, apiKey: this.apiKey },
      e
    );
  }
  onError(e) {
    this.reject &&
      this.reject(new sc({ code: 104, command: -1, count: this.count }));
  }
  onOpen() {
    this.systemTrigger(Mc.Open), this.resolve && this.resolve(this);
  }
  async connectToServer() {
    (this.isReady = !1),
      await Promise.all([
        co(ro(this.apiKey)).then((e) => {
          this.keyPublic = e;
        }),
        co(
          ro(
            so(
              "13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75"
            )
          )
        ).then((e) => {
          this.keyPrivate = e;
        }),
      ]);
    const e = new Promise((e, t) => {
      (this.reject = t),
        (this.resolve = e),
        (this.webSocket = new WebSocket(`wss://${this.server}`)),
        (this.webSocket.binaryType = "arraybuffer"),
        this.webSocket.removeEventListener("message", this.onMessage),
        this.webSocket.addEventListener("message", this.onMessage),
        this.webSocket.addEventListener("close", this.onClose, { once: !0 }),
        this.webSocket.addEventListener("error", this.onError, { once: !0 }),
        this.webSocket.addEventListener("open", this.onOpen, { once: !0 });
    });
    await e;
    const t = await this.sendCommand(0, this.token);
    return (
      (this.signalServerVersion = new Uint16Array(t.resBody)[0]),
      (this.isReady = !0),
      this
    );
  }
  close(e = !1) {
    return new Promise((t) => {
      this.queues.forEach((e) => {
        e.forEach((e) => e.stopTimeout());
      }),
        (this.queues = new Map()),
        this.requests.forEach((e) => {
          e.stopTimeout();
        }),
        (this.requests = new Map()),
        this.webSocket.removeEventListener("message", this.onMessage),
        this.webSocket.removeEventListener("error", this.onError),
        this.webSocket.removeEventListener("open", this.onOpen),
        e
          ? (this.webSocket.removeEventListener("close", this.onClose),
            this.onClose(),
            t())
          : this.webSocket.addEventListener("close", () => t()),
        this.webSocket.close();
    });
  }
  onMessage(e) {
    const t = e.data.slice(8);
    t.byteLength && ho(t, this.keyPublic).then(en).then(this.onParse);
  }
  onClose(e) {
    (this.isReady = !1),
      this.systemTrigger(Mc.Close, { count: this.count, event: e }),
      this.reset();
  }
  async sendCommand(e, t, o = !0, n = !1) {
    if (!Xo(e)) throw new sc({ command: e, code: 102, count: this.count });
    const r = 0 === e ? this.keyPrivate : this.keyPublic,
      i = (function (e, t) {
        const o = new Uint8Array(4 + ((t && t.byteLength) || 0));
        t && o.set(new Uint8Array(t), 4);
        const n = new DataView(o.buffer);
        return (
          n.setUint8(0, Math.floor(255 * Math.random())),
          n.setUint8(1, Math.floor(255 * Math.random())),
          n.setUint16(2, e, !0),
          o.buffer
        );
      })(e, t),
      s = await uo(i, r);
    try {
      const t = await this.send(e, s, o, n);
      if (0 !== t.resCode)
        throw new sc({ command: e, code: t.resCode, count: this.count });
      return t;
    } catch (a) {
      const { command: e, code: t } = a;
      throw new sc({ command: e, code: t, count: this.count });
    }
  }
  on(e, t) {
    var o;
    return null == (o = this.listeners.get(e)) || o.add(t), this;
  }
  off(e, t) {
    const o = this.listeners.get(e);
    return (
      o && t && o.has(t) && o.delete(t),
      t || this.listeners.set(e, new Set()),
      this
    );
  }
  subscribe(e, t) {
    let o = this.systemListeners.get(e);
    return (
      o || ((o = new Set()), this.systemListeners.set(e, o)), o.add(t), this
    );
  }
  unsubscribe(e, t) {
    if (t) {
      const o = this.systemListeners.get(e);
      o && o.delete(t);
    } else this.systemListeners.set(e, new Set());
    return this;
  }
  systemTrigger(e, t) {
    const o = this.systemListeners.get(e);
    o &&
      o.forEach((e) => {
        e(t);
      });
  }
  reset() {
    return (
      (this.requests = new Map()),
      (this.listeners = new Map()),
      (this.queues = new Map()),
      Lc.forEach((e) => {
        const t = Number(e);
        isNaN(t) || (this.listeners.set(t, new Set()), this.queues.set(t, []));
      }),
      this
    );
  }
  send(e, t, o, n) {
    var r;
    if (!this.isReady && 0 !== e) {
      const t = new sc({ command: e, code: 103, count: this.count });
      return this.systemTrigger(Mc.Error, t), Promise.reject(new sc(t));
    }
    const i = new Pc(
      e,
      (function (e) {
        const t = (e && e.byteLength) || 0,
          o = new Uint8Array(8 + t);
        e && o.set(new Uint8Array(e), 8);
        const n = new DataView(o.buffer);
        return n.setUint32(0, t, !0), n.setUint32(4, 1, !0), o.buffer;
      })(t)
    );
    if ((o && i.onTimeout(this.onTimeout), n)) {
      const t = this.queues.get(e);
      null == t ||
        t.forEach((t) => {
          t.rejectPromise(new sc({ command: e, code: 1e4, count: this.count }));
        }),
        this.queues.set(e, [i]);
    } else null == (r = this.queues.get(e)) || r.push(i);
    return this.checkQueue(e), i.promise;
  }
  sendRequest(e) {
    this.requests.set(e.command, e), this.webSocket.send(e.buffer);
  }
  checkQueue(e) {
    const t = this.queues.get(e);
    if (t && t.length && !this.requests.get(e)) {
      const e = t.shift();
      e && this.sendRequest(e);
    }
  }
  trigger(e, t) {
    const o = this.listeners.get(e);
    return (
      o &&
        o.forEach((e) => {
          e.call(this, t);
        }),
      this
    );
  }
  onParse(e) {
    const { resCommand: t, resCode: o, resBody: n } = e;
    o > 0 &&
      this.systemTrigger(
        Mc.Error,
        new sc({ code: o, command: t, count: this.count })
      );
    const r = this.requests.get(t);
    r &&
      (r.resolvePromise({ resCode: o, resBody: n }),
      r && 8 !== r.command && Xo(r.command),
      this.requests.delete(t)),
      this.checkQueue(t),
      this.trigger(t, { resCode: o, resBody: n });
  }
  onTimeout(e) {
    e.rejectPromise(
      new sc({ command: e.command, code: 408, count: this.count })
    ),
      this.requests.delete(e.command),
      this.checkQueue(e.command);
  }
}
const _c = "/terminal/json",
  Uc = [
    { propType: 6 },
    { propType: 17 },
    { propType: 11, propLength: 32 },
    { propType: 11, propLength: 32 },
  ],
  Bc = [{ propType: 4 }, { propType: 4 }];
class Vc extends ya {
  constructor(e) {
    super(), je(this, e, mn, gn, s, {});
  }
}
const jc = [];
class zc extends ya {
  constructor(e) {
    super(), je(this, e, null, bn, s, {});
  }
}
class Ic extends ya {
  constructor(e) {
    super(),
      je(this, e, Cn, $n, s, {
        name: 3,
        checked: 0,
        value: 4,
        group: 1,
        disabled: 5,
        id: 6,
        checkboxPosition: 7,
        errors: 2,
      });
  }
}
class Hc extends ya {
  constructor(e) {
    super(), je(this, e, null, xn, s, {});
  }
}
class Nc extends ya {
  constructor(e) {
    super(), je(this, e, null, Sn, s, {});
  }
}
let Rc = class extends ya {
  constructor(e) {
    super(), je(this, e, null, kn, s, {});
  }
};
class qc extends ya {
  constructor(e) {
    super(), je(this, e, null, An, s, {});
  }
}
class Fc extends ya {
  constructor(e) {
    super(), je(this, e, null, Tn, s, {});
  }
}
class Wc extends ya {
  constructor(e) {
    super(), je(this, e, null, On, s, {});
  }
}
const Kc = (e) => ({}),
  Gc = (e) => ({}),
  Zc = (e) => ({}),
  Yc = (e) => ({});
class Jc extends ya {
  constructor(e) {
    super(),
      je(
        this,
        e,
        Bn,
        Un,
        s,
        {
          value: 0,
          type: 3,
          min: 4,
          maxlength: 5,
          max: 6,
          step: 7,
          digits: 26,
          invalid: 8,
          placeholder: 9,
          name: 10,
          autocomplete: 11,
          disabled: 12,
          readonly: 13,
          element: 1,
          large: 14,
          style: 15,
          width: 16,
          maxWidth: 17,
          title: 18,
          focus: 25,
          errors: 2,
          onChange: 19,
          stepUp: 27,
          stepDown: 28,
        },
        null,
        [-1, -1, -1]
      );
  }
  get onChange() {
    return this.$$.ctx[19];
  }
  get stepUp() {
    return this.$$.ctx[27];
  }
  get stepDown() {
    return this.$$.ctx[28];
  }
}
class Qc extends ya {
  constructor(e) {
    super(),
      je(this, e, Rn, Nn, s, {
        name: 3,
        value: 0,
        disabled: 4,
        invalid: 5,
        options: 6,
        focus: 15,
        errors: 1,
        element: 2,
        type: 7,
        placeholder: 8,
        style: 9,
        width: 10,
        maxWidth: 11,
        selectFirst: 16,
      });
  }
}
class Xc extends ya {
  constructor(e) {
    super(), je(this, e, null, qn, s, {});
  }
}
class eu {
  constructor(e) {
    (this.fields = e), (this.errors = {});
  }
  getValues(e) {
    return Object.entries(e).reduce(
      (e, [t, o]) => ((e[t] = o.value ?? ""), e),
      {}
    );
  }
  getElements(e) {
    const t = {};
    return (
      Object.entries(e).forEach(([e, o]) => {
        o.element && (t[e] = o.element);
      }),
      t
    );
  }
  validate(e) {
    return (
      (this.errors = Object.entries(this.fields)
        .filter(([, { validators: e }]) => e)
        .reduce((t, [o, n]) => {
          const { validators: r, disabled: i, minChars: s } = n;
          if (i || !r) return t;
          const a = String(e[o] ?? "").trim();
          let l = {};
          return (
            r.some((t) => {
              const n = "string" == typeof t ? { type: t } : t,
                { type: r } = n;
              switch (n.type) {
                case "required": {
                  const t = "boolean" == typeof e[o] ? e[o] : a;
                  l = this.requiredValidator(t);
                  break;
                }
                case "email":
                  l = this.emailValidator(a);
                  break;
                case "phone":
                  l = this.phoneValidator(a);
                  break;
                case "number":
                  l = this.numberValidator(a);
                  break;
                case "regExp":
                  l = this.regExpValidator(n.value, a);
                  break;
                default:
                  throw (
                    ((l = { valid: !0 }), new Error(`Unexpected type: ${r}`))
                  );
              }
              return !l.valid;
            }),
            l.valid
              ? s && s > a.length && (t[o] = `Min ${s} chars`)
              : (t[o] = l.error),
            t
          );
        }, {})),
      this.errors
    );
  }
  removeFieldError(e) {
    return delete this.errors[e], this.errors;
  }
  regExpValidator(e, t, o) {
    if (!(e instanceof RegExp))
      return { valid: !1, error: o || "Incorrect value" };
    const n = e.test(t);
    return n ? { valid: n } : { valid: !1, error: o || "Incorrect value" };
  }
  phoneValidator(e) {
    return this.regExpValidator(/^\s*\+?[\s\d]+$/, e, "Incorrect phone");
  }
  numberValidator(e) {
    return this.regExpValidator(/^\d+$/, e, "Expected only numbers");
  }
  emailValidator(e) {
    return this.regExpValidator(/\S+@\S+\.\S+/, e, "Incorrect email");
  }
  requiredValidator(e) {
    const t = Boolean(e);
    return t ? { valid: t } : { valid: !1, error: "Required" };
  }
}
class tu extends ya {
  constructor(e) {
    super(), je(this, e, Zn, Gn, s, {});
  }
}
const ou = (e) => ({}),
  nu = (e) => ({}),
  ru = (e) => ({}),
  iu = (e) => ({});
class su extends ya {
  constructor(e) {
    super(), je(this, e, Jn, Yn, s, { labelWidth: 0, autocomplete: 1 });
  }
}
const au = (e) => ({}),
  lu = (e) => ({});
class cu extends ya {
  constructor(e) {
    super(),
      je(this, e, ur, cr, s, {
        user: 5,
        otp: 0,
        showOtp: 6,
        focus: 1,
        errors: 2,
        current: 7,
        password: 3,
        savePassword: 4,
        mobile: 8,
      });
  }
}
class uu extends ya {
  constructor(e) {
    super(),
      je(this, e, $r, yr, s, {
        accountStore: 4,
        user: 5,
        otp: 0,
        showOtp: 6,
        focus: 1,
        errors: 2,
        current: 7,
        password: 3,
      });
  }
}
class du extends ya {
  constructor(e) {
    super(), je(this, e, Pr, Or, s, { mobile: 0, user: 1, investor: 2 });
  }
}
const hu = [2001, 2007, 2005];
class pu extends ya {
  constructor(e) {
    super(),
      je(this, e, Vr, Br, s, {
        mobile: 0,
        accountController: 9,
        accountStore: 1,
        user: 2,
      });
  }
}
class gu extends ya {
  constructor(e) {
    super(),
      je(
        this,
        e,
        ti,
        Xr,
        s,
        { autoConnect: 21, mobile: 1, user: 0, current: 2 },
        null,
        [-1, -1]
      );
  }
}
const mu = Object.freeze(
  Object.defineProperty({ __proto__: null, default: gu }, Symbol.toStringTag, {
    value: "Module",
  })
);
class fu extends ya {
  constructor(e) {
    super(), je(this, e, null, oi, s, {});
  }
}
class wu extends ya {
  constructor(e) {
    super(),
      je(this, e, ri, ni, s, {
        value: 1,
        disabled: 2,
        group: 0,
        selected: 3,
        icon: 4,
      });
  }
}
class bu extends ya {
  constructor(e) {
    super(), je(this, e, null, ii, s, {});
  }
}
class vu extends ya {
  constructor(e) {
    super(), je(this, e, ci, li, s, { copyText: 0, errorText: 1, copy: 4 });
  }
  get copy() {
    return this.$$.ctx[4];
  }
}
class yu extends ya {
  constructor(e) {
    super(), je(this, e, hi, di, s, { user: 2, investor: 3 });
  }
}
class $u extends ya {
  constructor(e) {
    super(),
      je(this, e, gi, pi, s, {
        value: 1,
        checked: 2,
        disabled: 3,
        group: 0,
        selected: 4,
        icon: 5,
      });
  }
}
class Cu extends ya {
  constructor(e) {
    super(), je(this, e, Di, Li, s, { mobile: 0 }, null, [-1, -1]);
  }
}
const { Boolean: xu } = oa;
class Su extends ya {
  constructor(e) {
    super(),
      je(
        this,
        e,
        us,
        as,
        s,
        { autoConnect: 1, loading: 0, clientHeight: 2, showMessage: 23 },
        null,
        [-1, -1]
      );
  }
}
const ku = Object.freeze(
    Object.defineProperty(
      {
        __proto__: null,
        default: class extends ya {
          constructor(e) {
            super(), je(this, e, gs, ps, s, { autoConnect: 0 });
          }
        },
      },
      Symbol.toStringTag,
      { value: "Module" }
    )
  ),
  Au = (e) => ({ label: 1 & e }),
  Tu = (e) => ({ label: e[0] });
class Ou extends ya {
  constructor(e) {
    super(),
      je(this, e, bs, ws, s, {
        label: 0,
        compact: 1,
        compactHeight: 2,
        hideLabel: 3,
        labelWidth: 4,
        div: 5,
      });
  }
}
export {
  at as $,
  d as A,
  D as B,
  Ic as C,
  wt as D,
  ce as E,
  Ou as F,
  pe as G,
  xe as H,
  Jc as I,
  Se as J,
  F as K,
  W as L,
  Z as M,
  q as N,
  _ as O,
  r as P,
  ue as Q,
  R,
  ya as S,
  ca as T,
  _e as U,
  Qc as V,
  ge as W,
  f as X,
  N as Y,
  Ge as Z,
  cn as _,
  E as a,
  nn as a$,
  Ao as a0,
  ae as a1,
  i as a2,
  ic as a3,
  $a as a4,
  ie as a5,
  se as a6,
  he as a7,
  z as a8,
  v as a9,
  et as aA,
  ot as aB,
  Ea as aC,
  tt as aD,
  Ys as aE,
  xc as aF,
  hc as aG,
  rc as aH,
  _l as aI,
  Ga as aJ,
  oo as aK,
  sc as aL,
  yo as aM,
  $o as aN,
  mc as aO,
  Ca as aP,
  dc as aQ,
  tc as aR,
  Ac as aS,
  Vl as aT,
  to as aU,
  b as aV,
  Ae as aW,
  Te as aX,
  Ke as aY,
  Oc as aZ,
  Go as a_,
  le as aa,
  Mo as ab,
  Po as ac,
  ko as ad,
  H as ae,
  Le as af,
  Pe as ag,
  rt as ah,
  l as ai,
  fn as aj,
  wn as ak,
  t as al,
  g as am,
  J as an,
  Ee as ao,
  De as ap,
  V as aq,
  m as ar,
  We as as,
  xt as at,
  Mt as au,
  St as av,
  nc as aw,
  Za as ax,
  Xe as ay,
  La as az,
  B as b,
  Cs as b$,
  rn as b0,
  tn as b1,
  on as b2,
  sn as b3,
  an as b4,
  _c as b5,
  Ze as b6,
  Ko as b7,
  Vc as b8,
  Bl as b9,
  el as bA,
  tl as bB,
  rl as bC,
  ol as bD,
  ao as bE,
  gt as bF,
  dt as bG,
  kt as bH,
  At as bI,
  Tt as bJ,
  Ot as bK,
  Pt as bL,
  al as bM,
  ut as bN,
  vt as bO,
  yt as bP,
  $t as bQ,
  Ct as bR,
  lt as bS,
  bt as bT,
  ht as bU,
  ct as bV,
  Ts as bW,
  As as bX,
  ks as bY,
  Ol as bZ,
  vl as b_,
  Ye as ba,
  Ll as bb,
  Ul as bc,
  Su as bd,
  Kn as be,
  Mc as bf,
  Ls as bg,
  Xt as bh,
  eu as bi,
  eo as bj,
  Es as bk,
  su as bl,
  tu as bm,
  M as bn,
  I as bo,
  Wc as bp,
  Xc as bq,
  vu as br,
  bu as bs,
  po as bt,
  uo as bu,
  ro as bv,
  io as bw,
  ho as bx,
  co as by,
  so as bz,
  Ue as c,
  xs as c0,
  ln as c1,
  w as c2,
  Lt as c3,
  G as c4,
  pt as c5,
  zc as c6,
  ml as c7,
  fl as c8,
  wl as c9,
  un as cA,
  pn as cB,
  ke as cC,
  Oo as cD,
  Bt as cE,
  qt as cF,
  jt as cG,
  Ht as cH,
  Js as cI,
  dn as cJ,
  il as cK,
  nl as cL,
  mu as cM,
  ku as cN,
  Dt as ca,
  _t as cb,
  Ut as cc,
  Ml as cd,
  Qt as ce,
  Jt as cf,
  Ra as cg,
  Et as ch,
  U as ci,
  ft as cj,
  cl as ck,
  ll as cl,
  Ss as cm,
  mt as cn,
  Je as co,
  Rc as cp,
  Nc as cq,
  Hc as cr,
  qc as cs,
  Fc as ct,
  te as cu,
  oe as cv,
  ee as cw,
  Me as cx,
  Pn as cy,
  hn as cz,
  A as d,
  P as e,
  x as f,
  ve as g,
  Ce as h,
  je as i,
  ye as j,
  T as k,
  Ve as l,
  Be as m,
  L as n,
  e as o,
  Oe as p,
  O as q,
  a as r,
  s,
  $e as t,
  oa as u,
  ms as v,
  _a as w,
  c as x,
  h as y,
  p as z,
};
