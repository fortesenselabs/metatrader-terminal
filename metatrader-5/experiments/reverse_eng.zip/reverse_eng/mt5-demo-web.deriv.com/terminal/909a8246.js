async function t() {
  const t = await re(Zt(se(Je))),
    e = await Jt(Zt(ei + se(Ze)), t);
  return (ii = await re(e)), (ri = await re(Zt(se(ti)))), (si = !0), !0;
}
function e(t, e = 0) {
  return (function (t, e = 0) {
    const i = ee.parse(t, ai, e);
    return {
      symbol_path: i[0],
      spread_diff: i[1],
      spread_diff_balance: i[2],
      trade_mode: i[3],
      trade_stops_level: i[4],
      trade_freeze_level: i[5],
      trade_exemode: i[6],
      trade_fill_flags: i[7],
      trade_time_flags: i[8],
      trade_order_flags: i[9],
      trade_request_flags: i[10],
      trade_request_timeout: i[11],
      trade_instant_flags: i[12],
      trade_instant_timeout: i[13],
      trade_instant_slip_profit: i[14],
      trade_instant_slip_losing: i[15],
      trade_instant_volume: i[16],
      trade_instant_checkmode: i[17],
      trade_market_flags: i[18],
      trade_exchange_flags: i[19],
      volume_min: i[20],
      volume_max: i[21],
      volume_step: i[22],
      volume_limit: i[23],
      margin_flags: i[24],
      margin_initial: i[25],
      margin_maintenance: i[26],
      margin_rates_initial: i[27],
      margin_rates_maintenance: i[28],
      margin_rate_liquidity: i[29],
      margin_hedged: i[30],
      margin_rate_currency: i[31],
      swap_mode: i[32],
      swap_long: i[33],
      swap_short: i[34],
      swap_rollover3days: i[35],
      permissions_flags: i[36],
      permissions_bookdepth: i[37],
    };
  })(t, e);
}
function i(t) {
  return new Float64Array(t);
}
function r(t, e, i) {
  const r = [];
  if (t.byteLength > e.value)
    for (let s = 0; s < i; s++) {
      const i = ee.parse(t, _i, e.value);
      (e.value += di), r.push(i);
    }
  return r;
}
function s(t, e = 0) {
  const i = ee.parse(t, hi, e);
  return (i[24] = i[24] || 8), Object.values(i);
}
function o(t, i = 0) {
  const o = new DataView(t);
  let a = i;
  const n = [...s(t, a)];
  a = pi;
  const l = [];
  if (t.byteLength > a) {
    const i = o.getUint32(a, !0);
    if (i) {
      a += 4;
      for (let r = 0; r < i; r++) l.push(e(t, a)), (a += ni);
    }
  }
  let c = Ae.NONE;
  t.byteLength > a && ((c = o.getInt32(a, !0)), (a += 4));
  let _ = 0;
  t.byteLength > a && ((_ = o.getInt32(a, !0)), (a += 4));
  let d = 0n;
  t.byteLength > a && ((d = o.getBigUint64(a, !0)), (a += 8));
  const h = (function (t, e) {
    const i = new DataView(t);
    let s = 0;
    const o = [];
    if (t.byteLength > e.value) {
      (s = i.getInt32(e.value, !0)), (e.value += 4);
      for (let i = 0; i < s; i++) {
        const i = ee.parse(t, li, e.value);
        e.value += ci;
        const s = r(t, e, i[4]);
        o.push([...i, s]);
      }
    }
    return o;
  })(t, { value: a });
  return [...n, l, c, _, d, h];
}
function a(t, e = 0) {
  return { group_name: ee.parse(t, Si, e)[0] };
}
function n(t, e) {
  return 4 + new DataView(t).getUint32(e, !0) * Mi;
}
function l(t, e, i = 0) {
  const r = ee.parse(e, Ai, i);
  return new Ri(t, r);
}
function c(t, e, i = 0) {
  const r = [];
  let s = i;
  const o = new DataView(e).getUint32(s, !0);
  s += 4;
  for (let a = 0; a < o; a++) r.push(l(t, e, s)), (s += Mi);
  return r;
}
function _(t, e = 0) {
  const i = ee.parse(t, $i, e);
  return new Ii(i);
}
function d(t) {
  const e = [],
    i = new DataView(t),
    r = t.byteLength;
  let s = 0;
  for (; s < r; ) {
    s += 4;
    const r = i.getUint32(s, !0);
    s += 4;
    for (let i = 0; i < r; i++) {
      const i = _(t, s);
      (s += xi),
        0 !== i.spread_id &&
          ((i.legs_a = c(i, t, s)),
          (s += n(t, s)),
          (i.legs_b = c(i, t, s)),
          (s += n(t, s)),
          e.push(i));
    }
  }
  return e;
}
function h(t) {
  return Uint32Array.from([t.length].concat(t)).buffer;
}
function p(t, e) {
  return t.trade_symbol > e.trade_symbol
    ? 1
    : t.trade_symbol < e.trade_symbol
    ? -1
    : t.spread_id > e.spread_id
    ? 1
    : t.spread_id < e.spread_id
    ? -1
    : 0;
}
function u(t, e, i) {
  const r = t.filter(({ trade_symbol: t }) => i === t),
    s = [];
  return (
    r.forEach((t) => {
      t.checkSymbol(e.trade_symbol, e.basis, e.time_expiration) &&
        s.push(t.spread);
    }),
    s
  );
}
function m(t, e) {
  return t.symbol_id > e.symbol_id ? 1 : t.symbol_id < e.symbol_id ? -1 : 0;
}
function g(t, e) {
  return t.trade_symbol > e.trade_symbol
    ? 1
    : t.trade_symbol < e.trade_symbol
    ? -1
    : 0;
}
function y(t, e = !0) {
  if (e && t >= 1e6) {
    let e = oe(Number(t / 1e6), 14).toFixed(14);
    return (e = _e(e, 12)), (e += "M"), e;
  }
  if (e && t >= 1e3) {
    let e = oe(Number(t / 1e3), 11).toFixed(11);
    return (e = _e(e, 9)), (e += "K"), e;
  }
  let i = oe(t, 8).toFixed(8);
  return (i = _e(i, 6)), i;
}
function f(t, e = !0) {
  return y(Yi.toDouble(t), e);
}
function b(t = 0, e = 0, i = 0) {
  let r = oe(t, e + i).toFixed(e + i);
  return (r = _e(r, i)), r;
}
function v(t, e) {
  let i = oe(t, e).toFixed(e);
  return e > 0 && (i = _e(i, e)), i;
}
function T(t, e) {
  return de(t, e);
}
function S(t, e = !1, i = !1) {
  if (!t) return "";
  const r = new Date(t);
  let s = "";
  return (
    (s += r.getUTCFullYear()),
    (s += "."),
    (s += (r.getUTCMonth() + 1).toString().padStart(2, "0")),
    (s += "."),
    (s += r.getUTCDate().toString().padStart(2, "0")),
    e &&
      ((s += " "),
      (s += r.getUTCHours().toString().padStart(2, "0")),
      (s += ":"),
      (s += r.getUTCMinutes().toString().padStart(2, "0")),
      (s += ":"),
      (s += r.getUTCSeconds().toString().padStart(2, "0")),
      i && (s += r.getUTCMilliseconds().toString().padStart(3, "0"))),
    s
  );
}
function k(t, e = 0) {
  return ee.parse(t, Wi, e);
}
function C(t, e = 0) {
  return (function (t, e = 0) {
    return ee.parse(t, Xi, e);
  })(t, e);
}
function E(t, e = 0) {
  return ee.parse(t, ir, e);
}
function B(t) {
  const e = [],
    i = new DataView(t).getUint32(0, !0);
  let r = 4;
  for (let s = 0; s < i; s++) e.push(E(t, r)), (r += rr);
  return e;
}
function w(t, e = 0) {
  const i = ee.parse(t, ar, e);
  return {
    symbol_id: i[0],
    fields: i[1],
    lasttime: 1e3 * i[2],
    digits: i[3],
    bid_last: i[4],
    bid_high: i[5],
    bid_low: i[6],
    ask_last: i[7],
    ask_high: i[8],
    ask_low: i[9],
    last_last: i[10],
    last_high: i[11],
    last_low: i[12],
    vol_last: i[13],
    vol_high: i[14],
    vol_low: i[15],
    trade_deals: i[16],
    trade_volume: i[17],
    trade_turnover: i[18],
    trade_interest: i[19],
    trade_buy_orders: i[20],
    trade_buy_volume: i[21],
    trade_sell_orders: i[22],
    trade_sell_volume: i[23],
    price_open: i[24],
    price_close: i[25],
    price_aw: i[26],
    price_change: i[27],
    price_volatility: i[28],
    price_theoretical: i[29],
    lasttime_msc: i[30],
    price_greeks_delta: i[31],
    price_greeks_theta: i[32],
    price_greeks_gamma: i[33],
    price_greeks_vega: i[34],
    price_greeks_rho: i[35],
    price_greeks_omega: i[36],
    price_sensitivity: i[37],
    flags: i[38],
  };
}
function L(t, e = 0) {
  const i = ee.parse(t, cr, e);
  return {
    symbol_id: i[0],
    tick_time: 1e3 * i[1],
    fields: i[2],
    bid: i[3],
    ask: i[4],
    last: i[5],
    tick_volume: i[6],
    time_ms_delta: i[7],
    flags: i[8],
    tick_time_ms: 1e3 * i[1] + i[7],
  };
}
function O(t, e, i) {
  let r = t;
  return e && (r = oe(t / e, 0) * e), oe(r, i);
}
function I(t, e, i, r, s, o) {
  if (!t) return { result: !0, bid: s, ask: o };
  if (!s || !o) return { result: !0, bid: s, ask: o };
  const a = oe((o - s) / i + t, 0);
  return {
    bid: (s = oe(
      t > 0
        ? s - i * (t - Math.trunc(t / 2) - e)
        : s - i * (t - Math.trunc(t / 2) + e),
      r
    )),
    ask: (o = oe(s + i * a, r)),
    result: s <= o,
  };
}
function R(t, e, i, r, s) {
  return oe(
    t > 0
      ? s - i * (t - Math.trunc(t / 2) - e)
      : s - i * (t - Math.trunc(t / 2) + e),
    r
  );
}
function A(t, e, i, r, s) {
  return oe(
    t > 0 ? s + i * (Math.trunc(t / 2) + e) : s + i * (Math.trunc(t / 2) - e),
    r
  );
}
function M(t, e, i) {
  let r = t;
  return i ? (r |= e) : (r &= ~e), r;
}
function $(t = 0, e = 0) {
  return 0 === e || t === e ? mr : t >= e ? pr : ur;
}
function x(t = BigInt(0), e = BigInt(0)) {
  return e && e !== t ? (t >= e ? pr : ur) : mr;
}
function P(t, e) {
  switch (t.getTrend(e)) {
    case ur:
      return -1;
    case pr:
      return 1;
  }
  return 0;
}
function z(t) {
  const e = t.digits,
    i = t.ask_last,
    r = t.bid_last;
  return i && r ? Math.round((i - r) * 10 ** e) : null;
}
function D(t, e, i, r, s, o, a) {
  let n = r,
    l = 0;
  for (let c = 0; c < t.tiers.length; c++) {
    const e = t.tiers[c];
    if (e.range_to === ce || e.range_from === ce) break;
    let _ = e.range_to - e.range_from;
    if (_ > 0) {
      i && (_ = Math.min(i, _)), n < _ ? ((i = _ - n), (_ = n)) : (i = 0);
      const t = s * (_ / r),
        c = o ? t * e.margin_rate_initial : t * e.margin_rate_maintenance;
      if (((l = oe(l + c, a)), _ >= n)) {
        n = 0;
        break;
      }
      n -= _;
    }
  }
  if (n) {
    const e = o
      ? t.tiers[t.tiers.length - 1].margin_rate_initial
      : t.tiers[t.tiers.length - 1].margin_rate_maintenance;
    l = oe(l + s * (n / r) * e, a);
  }
  return l;
}
function N(t, e, i) {
  let r = 0,
    s = 0;
  const o = e.findPrices(t, !1);
  if (
    (o && ((r = o.last), (s = o.ask)),
    r || (r = i),
    !r && "_TOD" === t.substring(t.length - 4))
  ) {
    const i = `${t.substring(0, t.length - 4)}_TOM`,
      o = e.findPrices(i, !1);
    o && ((r = o.last), (s = o.ask));
  }
  return s || (s = r), [r, s];
}
function U(t, e, i, r, s, o, a) {
  let n = 0,
    l = 0;
  switch (
    (o
      ? (l = t.trade.margin_initial)
      : ((l = t.trade.margin_initial),
        t.trade.margin_maintenance && (l = t.trade.margin_maintenance)),
    t.trade_calc_mode)
  ) {
    case 0:
      n = l > 0 ? (l * r) / t.trade_contract_size / e : r / e;
      break;
    case 5:
      n = l > 0 ? (l * r) / t.trade_contract_size : r;
      break;
    case 2:
    case 32:
    case 38:
    case 35:
    case 36:
      n = l > 0 ? (l * r) / t.trade_contract_size : r * s;
      break;
    case 1:
    case 33:
      n = (l * r) / t.trade_contract_size;
      break;
    case 3:
      l > 0
        ? (n = (l * r) / t.trade_contract_size)
        : t.trade_tick_size &&
          (n = ((r * s) / t.trade_tick_size) * t.trade_tick_value);
      break;
    case 64:
      n = 0;
      break;
    case 4:
      n = l > 0 ? (l * r) / t.trade_contract_size / e : (r * s) / e;
      break;
    case 34:
      if (t.trade_tick_size)
        switch (i) {
          case 0: {
            const {
                trade_contract_size: e,
                trade_price_settle: i,
                trade_tick_value: o,
                trade_tick_size: l,
                trade_price_limit_max: c,
                trade: _,
              } = t,
              { margin_initial: d, margin_rate_currency: h } = _;
            n = a
              ? (r / e) * (d + (o / l) * (s - i) * (1 + 0.01 * h))
              : (r / e) * (d + (o / l) * (c - i) * (1 + 0.01 * h));
            break;
          }
          case 1: {
            const {
                trade_contract_size: e,
                trade_price_settle: i,
                trade_tick_value: o,
                trade_tick_size: l,
                trade_price_limit_min: c,
                trade: _,
              } = t,
              { margin_rate_currency: d, margin_maintenance: h } = _;
            n = a
              ? (r / e) * (h + (o / l) * (i - s) * (1 + 0.01 * d))
              : (r / e) * (h + (o / l) * (i - c) * (1 + 0.01 * d));
            break;
          }
          case 2:
          case 6: {
            const {
                trade_contract_size: e,
                trade_price_settle: i,
                trade_tick_value: o,
                trade_tick_size: a,
                trade: l,
              } = t,
              { margin_rate_currency: c, margin_initial: _ } = l;
            n = (r / e) * (_ + (o / a) * (s - i) * (1 + 0.01 * c));
            break;
          }
          case 3:
          case 7: {
            const {
                trade_contract_size: e,
                trade_price_settle: i,
                trade_tick_value: o,
                trade_tick_size: a,
                trade: l,
              } = t,
              { margin_rate_currency: c, margin_maintenance: _ } = l;
            n = (r / e) * (_ + (o / a) * (i - s) * (1 + 0.01 * c));
            break;
          }
          case 4:
            {
              const {
                  trade_contract_size: e,
                  trade_price_settle: i,
                  trade_tick_value: s,
                  trade_tick_size: o,
                  trade_price_limit_max: a,
                  trade: l,
                } = t,
                { margin_rate_currency: c, margin_initial: _ } = l;
              n = (r / e) * (_ + (s / o) * (a - i) * (1 + 0.01 * c));
            }
            break;
          case 5: {
            const {
                trade_contract_size: e,
                trade_price_settle: i,
                trade_tick_value: s,
                trade_tick_size: o,
                trade_price_limit_min: a,
                trade: l,
              } = t,
              { margin_rate_currency: c, margin_maintenance: _ } = l;
            n = (r / e) * (_ + (s / o) * (i - a) * (1 + 0.01 * c));
            break;
          }
          default:
            n = (l * r) / t.trade_contract_size;
        }
      break;
    case 37:
    case 39:
      n =
        l > 0
          ? (l * r) / t.trade_contract_size
          : oe((r * t.trade_face_value * s) / 100, t.currency_base_digits);
  }
  return n;
}
function q(t, e) {
  const i = Number(t.volume + e.volume);
  return [
    Number(t.price * Number(t.volume) + e.price * Number(e.volume)) / i,
    (t.margin_rate * Number(t.volume) + e.margin_rate * Number(e.volume)) / i,
  ];
}
function V(t) {
  t.volume &&
    ((t.price /= Number(t.volume)), (t.margin_rate /= Number(t.volume)));
}
function F(t, e, i, r, s, o, a) {
  let n = 0,
    l = 0;
  switch (
    (o
      ? (l = t.trade.margin_initial)
      : ((l = t.trade.margin_initial),
        t.trade.margin_maintenance && (l = t.trade.margin_maintenance)),
    t.trade_calc_mode)
  ) {
    case 0:
      n =
        l > 0
          ? (l * r) / t.trade_contract_size / e.margin_leverage
          : r / e.margin_leverage;
      break;
    case 5:
      n = l > 0 ? (l * r) / t.trade_contract_size : r;
      break;
    case 2:
    case 32:
    case 38:
    case 35:
    case 36:
      n = l > 0 ? (l * r) / t.trade_contract_size : r * s;
      break;
    case 1:
    case 33:
      n = (l * r) / t.trade_contract_size;
      break;
    case 3:
      l > 0
        ? (n = (l * r) / t.trade_contract_size)
        : t.trade_tick_size &&
          (n = ((r * s) / t.trade_tick_size) * t.trade_tick_value);
      break;
    case 64:
      n = 0;
      break;
    case 4:
      n =
        l > 0
          ? (l * r) / t.trade_contract_size / e.margin_leverage
          : (r * s) / e.margin_leverage;
      break;
    case 34:
      if (t.trade_tick_size)
        switch (i) {
          case 0:
            n = a
              ? (r / t.trade_contract_size) *
                (t.trade.margin_initial +
                  (s - t.trade_price_settle) *
                    (t.trade_tick_value / t.trade_tick_size) *
                    (1 + 0.01 * t.trade.margin_rate_currency))
              : (r / t.trade_contract_size) *
                (t.trade.margin_initial +
                  (t.trade_price_limit_max - t.trade_price_settle) *
                    (t.trade_tick_value / t.trade_tick_size) *
                    (1 + 0.01 * t.trade.margin_rate_currency));
            break;
          case 1:
            n = a
              ? (r / t.trade_contract_size) *
                (t.trade.margin_maintenance +
                  (t.trade_price_settle - s) *
                    (t.trade_tick_value / t.trade_tick_size) *
                    (1 + 0.01 * t.trade.margin_rate_currency))
              : (r / t.trade_contract_size) *
                (t.trade.margin_maintenance +
                  (t.trade_price_settle - t.trade_price_limit_min) *
                    (t.trade_tick_value / t.trade_tick_size) *
                    (1 + 0.01 * t.trade.margin_rate_currency));
            break;
          case 2:
          case 6:
            n =
              (r / t.trade_contract_size) *
              (t.trade.margin_initial +
                (s - t.trade_price_settle) *
                  (t.trade_tick_value / t.trade_tick_size) *
                  (1 + 0.01 * t.trade.margin_rate_currency));
            break;
          case 3:
          case 7:
            n =
              (r / t.trade_contract_size) *
              (t.trade.margin_maintenance +
                (t.trade_price_settle - s) *
                  (t.trade_tick_value / t.trade_tick_size) *
                  (1 + 0.01 * t.trade.margin_rate_currency));
            break;
          case 4:
            n =
              (r / t.trade_contract_size) *
              (t.trade.margin_initial +
                (t.trade_price_limit_max - t.trade_price_settle) *
                  (t.trade_tick_value / t.trade_tick_size) *
                  (1 + 0.01 * t.trade.margin_rate_currency));
            break;
          case 5:
            n =
              (r / t.trade_contract_size) *
              (t.trade.margin_maintenance +
                (t.trade_price_settle - t.trade_price_limit_min) *
                  (t.trade_tick_value / t.trade_tick_size) *
                  (1 + 0.01 * t.trade.margin_rate_currency));
            break;
          default:
            n = (l * r) / t.trade_contract_size;
        }
      break;
    case 37:
    case 39:
      n =
        l > 0
          ? (l * r) / t.trade_contract_size
          : oe((r * t.trade_face_value * s) / 100, t.currency_base_digits);
  }
  return n;
}
function H(t, e) {
  (e.length = 0),
    t.forEach((t, i) => {
      e[i] = t.getSpreadVolume();
    });
}
function G(t, e, i, r) {
  if (((r.volume_ratio = Number.MAX_VALUE), !e.total() && !i.length)) return !0;
  let s;
  for (s = 0; s < i.length; s++) {
    const o = i[s];
    let a = !1;
    const n = e.getAll();
    for (let e = 0; e < n.length; e++) {
      const i = n[e];
      if (o.checkSymbol(i.name(), i.basis(), i.expiration())) {
        if ((i.setSpreadLeg(o), o.spread_ratio)) {
          const t = i.getVolume() / BigInt(o.spread_ratio);
          r.volume_ratio = Number(Te.min(BigInt(r.volume_ratio), t));
        }
        if (((a = !0), t.margin_type === Li && o.spread_mode === Oi)) continue;
        break;
      }
    }
    if (!a) break;
  }
  return !(s < i.length && (e.forEach((t) => t.setSpreadLeg()), 1));
}
function Y(t = Lr) {
  switch (t) {
    case Br:
      return window.tr(window.lang.trade.margin.rangeMode.volume);
    case wr:
      return window.tr(window.lang.trade.margin.rangeMode.volumePerSymbol);
    case Or:
      return window.tr(window.lang.trade.margin.rangeMode.valuePerSymbol);
    default:
      return window.tr(window.lang.trade.margin.rangeMode.value);
  }
}
function Q(t) {
  switch (t) {
    case cs.M1:
      return _s.M1;
    case cs.M5:
      return _s.M5;
    case cs.M15:
      return _s.M15;
    case cs.M30:
      return _s.M30;
    case cs.H1:
      return _s.H1;
    case cs.H4:
      return _s.H4;
    case cs.D1:
      return _s.D1;
    case cs.W1:
      return _s.W1;
    case cs.MN:
      return _s.MON1;
    default:
      return 0;
  }
}
function K(t, e) {
  const i = t.trade_order.toString(),
    r = e.trade_order.toString();
  return i > r ? 1 : i < r ? -1 : 0;
}
function W(t, e) {
  const i = t.position_id.toString(),
    r = e.position_id.toString();
  return i > r ? 1 : i < r ? -1 : 0;
}
function j(t, e) {
  if (t.position_id.toString() > e.position_id.toString()) return 1;
  if (t.position_id.toString() < e.position_id.toString()) return -1;
  if (Ee(t.trade_type) !== Ee(e.trade_type)) {
    if (t.trade_type > e.trade_type) return 1;
    if (t.trade_type < e.trade_type) return -1;
  }
  return 0;
}
function X(t, e) {
  return t.time_create > e.time_create
    ? 1
    : t.time_create < e.time_create
    ? -1
    : 0;
}
function J(t, e) {
  return t.deal > e.deal ? 1 : t.deal < e.deal ? -1 : 0;
}
function Z(t, e = 0) {
  const i = ee.parse(t, Ss, e);
  (i[3] = 1e3 * i[3] + i[28]), (i[4] *= 1e3), (i[5] = 1e3 * i[5] + i[29]);
  const r = new kr();
  return (
    (r.trade_order = i[0]),
    (r.order_id = i[1]),
    (r.trade_symbol = i[2]),
    (r.time_setup = i[3]),
    (r.time_expiration = i[4]),
    (r.time_done = i[5]),
    (r.order_type = i[6]),
    (r.type_filling = i[7]),
    (r.type_time = i[8]),
    (r.type_reason = i[9]),
    (r.price_order = i[10]),
    (r.price_trigger = i[11]),
    (r.price_current = i[12]),
    (r.price_sl = i[13]),
    (r.price_tp = i[14]),
    (r.volume_initial = i[15]),
    (r.volume_current = i[16]),
    (r.order_state = i[17]),
    (r.expert = i[18]),
    (r.position_id = i[19]),
    (r.comment = i[20]),
    (r.contract_size = i[21]),
    (r.digits = i[22]),
    (r.digits_currency = i[23]),
    (r.commission_daily = i[24]),
    (r.commission_monthly = i[25]),
    (r.margin_rate = i[26]),
    (r.activation_mode = i[27]),
    r
  );
}
function tt(t, e = 0) {
  let i = e;
  const r = [],
    s = new DataView(t).getUint32(i, !0);
  i += 4;
  for (let o = 0; o < s; o++) r.push(Z(t, i)), (i += ks);
  return r;
}
function et(t, e = 0) {
  const i = ee.parse(t, Cs, e);
  return new Kr({
    deal: i[0],
    deal_id: i[1],
    trade_order: i[2],
    time_create: 1e3 * i[3] + i[25],
    time_update: 1e3 * i[4] + i[26],
    trade_symbol: i[5],
    trade_action: i[6],
    entry: i[7],
    price_open: i[8],
    price_close: i[9],
    sl: i[10],
    tp: i[11],
    trade_volume: i[12],
    profit: i[13],
    rate_profit: i[14],
    rate_margin: i[15],
    commission: i[16],
    storage: i[17],
    expert: i[18],
    position_id: i[19],
    comment: i[20],
    contract_size: i[21],
    digits: i[22],
    digits_currency: i[23],
    trade_reason: i[24],
    commission_fee: i[27],
  });
}
function it(t, e = 0) {
  return new DataView(t).getUint32(e, !0) * Es + 4;
}
function rt(t, e = 0) {
  let i = e;
  const r = [],
    s = new DataView(t).getUint32(i, !0);
  i += 4;
  for (let o = 0; o < s; o++) r.push(et(t, i)), (i += Es);
  return r;
}
function st(t) {
  return t.deal_id.toString();
}
function ot(t) {
  return t.trade_symbol;
}
function at(t) {
  return t.position_id ? t.position_id.toString() : "";
}
function nt(t) {
  return t.deal.toString();
}
function lt(t) {
  return t.trade_order ? t.trade_order.toString() : "";
}
function ct(t, e) {
  const i = f(t.trade_volume);
  return _t(t, e)(i);
}
function _t(t, e) {
  let i = "",
    r = "";
  return (
    e && (i += `#${e} `),
    (i += Le(t.trade_action)),
    (r += `${ot(t)} ${b(t.price_open, t.digits, 3)}`),
    (t) => `${i} ${t} ${r}`
  );
}
function dt(t) {
  return ct(t, at(t) || st(t));
}
function ht(t) {
  switch (t) {
    case 0:
    case 0:
      return "buy";
    case 1:
    case 1:
      return "sell";
    default:
      return "unknown";
  }
}
function pt(t) {
  return t.trade_symbol;
}
function ut(t) {
  return t.trade_order.toString();
}
function mt(t) {
  return t.order_id;
}
function gt(t, e = !0) {
  let i = "",
    r = t.volume_initial,
    s = t.volume_current;
  if (e)
    r >= s
      ? ((i += f(r)), (i += " / "), (i += f(r - s)))
      : ((i += f(r)), (i += " / "), (i += f(s)));
  else {
    const e = t.contract_size;
    (r = T(r, e)), (s = T(s, e)), (i += f(r)), (i += " / "), (i += f(r - s));
  }
  return i;
}
function yt(t, e = !0) {
  let i = "";
  const r = ut(t);
  return (
    r && (i += `#${r} `),
    (i += Oe(t.order_type)),
    t.volume_initial === t.volume_current
      ? (i += ` ${f(t.volume_initial)}`)
      : (i += ` ${gt(t)}`),
    e && (i += ` ${pt(t)}`),
    i
  );
}
function ft(t, e) {
  let i = 0,
    r = 0;
  return (
    (function (t) {
      switch (t.trade_calc_mode) {
        case 32:
        case 33:
        case 34:
        case 35:
        case 36:
        case 37:
        case 38:
        case 39:
          return !0;
        default:
          return !1;
      }
    })(t)
      ? ((i = e.last_last), (r = e.last_last))
      : ((i = e.bid), (r = e.ask)),
    { bid: i, ask: r }
  );
}
function bt(t, e, i, r, s, o = !1) {
  (e.profit = (function (t, e, i, r, s, o, a = !1) {
    let n = 0;
    const l = t.currency_profit_digits,
      c = t.trade_tick_value,
      _ = t.trade_tick_size,
      d = t.trade_face_value;
    switch (t.trade_calc_mode) {
      case 0:
      case 5: {
        const t = Yi.toSize(i, r);
        n = e ? oe(o * t, l) - oe(s * t, l) : oe(s * t, l) - oe(o * t, l);
        break;
      }
      case 1:
      case 33:
      case 35:
      case 36: {
        const t = Yi.toDouble(i);
        (n = e ? (o - s) * t * c : (s - o) * t * c), _ && (n /= _);
        break;
      }
      case 34: {
        const t = Yi.toDouble(i);
        let r, a;
        _
          ? ((r = oe((s * c) / _, l)), (a = oe((o * c) / _, l)))
          : ((r = oe(s * c, l)), (a = oe(o * c, l))),
          (n = e ? (a - r) * t : (r - a) * t);
        break;
      }
      case 37:
      case 39: {
        const t = Yi.toSize(i, r);
        n = e
          ? oe((t * o * d) / 100, l) - oe((t * s * d) / 100, l)
          : oe((t * s * d) / 100, l) - oe((t * o * d) / 100, l);
        break;
      }
      case 64:
        if (a) {
          const t = Yi.toSize(i, r);
          n = e ? o * t - s * t : s * t - o * t;
        } else n = 0;
        break;
      default: {
        const t = Yi.toSize(i, r);
        n = e ? o * t - s * t : s * t - o * t;
      }
    }
    return (
      (n > Ms || n < -Ms) && (n = 0),
      (o < 0 || (!t.isCollateral() && !o)) && (n = 0),
      oe(n, l)
    );
  })(
    t,
    e.isBuy(),
    e.trade_volume,
    e.contract_size,
    e.price_open,
    e.price_close,
    o
  )),
    t.isForex() && 0 == (t.trade_flags & Ae.PROFIT_BY_MARKET)
      ? e.isBuy()
        ? ((e.profit *= r), (e.rate_profit = r))
        : ((e.profit *= s), (e.rate_profit = s))
      : e.profit > 0
      ? ((e.profit *= s), (e.rate_profit = s))
      : ((e.profit *= r), (e.rate_profit = r)),
    (e.profit = oe(e.profit, i.currency_digits));
}
function vt(t, e = 0) {
  const i = ee.parse(t, zs, e);
  return new Kr({
    position_id: i[0],
    trade_order: i[1],
    time_create: 1e3 * i[2] + i[24],
    time_update: 1e3 * i[3] + i[25],
    trade_symbol: i[4],
    trade_action: i[5],
    price_open: i[6],
    price_close: i[7],
    sl: i[8],
    tp: i[9],
    trade_volume: i[10],
    profit: i[11],
    rate_profit: i[12],
    rate_margin: i[13],
    commission: i[14],
    storage: i[15],
    expert: i[16],
    expert_position_id: i[17],
    comment: i[18],
    contract_size: i[19],
    digits: i[20],
    digits_currency: i[21],
    trade_reason: i[22],
    external_id: i[23],
  });
}
function Tt(t, e = 0) {
  return new DataView(t).getUint32(e, !0) * Ds + 4;
}
function St(t, e = 0) {
  let i = e;
  const r = [],
    s = new DataView(t).getUint32(i, !0);
  i += 4;
  for (let o = 0; o < s; o++) r.push(vt(t, i)), (i += Ds);
  return r;
}
function kt(t) {
  switch (t) {
    case 2:
      return 1;
    case 4:
      return 2;
    case 3:
      return 3;
    case 5:
      return 4;
    default:
      return 0;
  }
}
function Ct(t, e = 0) {
  return ee.parse(t, Xs, e);
}
function Et(t = 0) {
  return t * Js;
}
function Bt(t, e = 0, i = 0) {
  const r = [];
  for (let s = 0; s < i; s++) r.push(Ct(t, e)), (e += Js);
  return r;
}
function wt(t, e = 0) {
  return Object.values(ee.parse(t, Zs, e));
}
function Lt(t, e = 0) {
  let i,
    r = e,
    s = 0;
  return (
    (s += no),
    (r += no),
    (i = it(t, r)),
    (s += i),
    (r += i),
    (i = Tt(t, r)),
    (s += i),
    (r += i),
    s
  );
}
function Ot(t, e = 0) {
  let i = e;
  const r = (function (t, e = 0) {
    const i = ee.parse(t, ao, e);
    return new oo(i);
  })(t, i);
  return (
    (i += no),
    (r.deals = rt(t, i)),
    (i += it(t, i)),
    (r.positions = St(t, i)),
    (i += Tt(t, i)),
    r
  );
}
function It(t, e = 0) {
  const i = ee.parse(t, co, e);
  return new lo(i);
}
function Rt(t, e) {
  return (
    !(t < 0 || t > 1e9) &&
    (function (t, e) {
      if (!e.trade_tick_size || !t) return !0;
      const i = 10 ** -(e.digits + 1),
        r = oe(Ie(t, e.trade_tick_size), e.digits);
      return r <= i || r >= e.trade_tick_size;
    })((t = oe(t, e.digits)), e)
  );
}
function At(t, e, i = !1) {
  if (
    t.trade.trade_exemode === Fe.REQUEST ||
    t.trade.trade_exemode === Fe.INSTANT
  )
    return 5 === e.trade_action || 201 === e.trade_action
      ? (i && (e.type_filling = 2), 2 === e.type_filling)
      : (i && (e.type_filling = 0), 0 === e.type_filling);
  if (t.trade.trade_exemode === Fe.MARKET)
    return 5 === e.trade_action || 201 === e.trade_action
      ? (i && (e.type_filling = 2), 2 === e.type_filling)
      : 0 === e.type_filling
      ? !!(t.trade.trade_fill_flags & Ue.FOK)
      : 1 === e.type_filling && !!(t.trade.trade_fill_flags & Ue.IOC);
  switch (e.type_filling) {
    case 0:
      return (5 !== e.trade_action && 201 !== e.trade_action) ||
        2 === e.trade_type ||
        3 === e.trade_type ||
        6 === e.trade_type ||
        7 === e.trade_type
        ? !!(t.trade.trade_fill_flags & Ue.FOK)
        : !!i && ((e.type_time = 0), (e.type_filling = 2), !0);
    case 1:
      return (5 !== e.trade_action && 201 !== e.trade_action) ||
        2 === e.trade_type ||
        3 === e.trade_type ||
        6 === e.trade_type ||
        7 === e.trade_type
        ? !!(t.trade.trade_fill_flags & Ue.IOC)
        : !!i && ((e.type_time = 0), (e.type_filling = 2), !0);
    case 2:
      return !0;
    case 3:
      return (5 !== e.trade_action && 201 !== e.trade_action) ||
        2 === e.trade_type ||
        3 === e.trade_type ||
        6 === e.trade_type ||
        7 === e.trade_type
        ? !!(t.trade.trade_fill_flags & Ue.BOC)
        : !!i && ((e.type_time = 0), (e.type_filling = 2), !0);
  }
  return !1;
}
function Mt(t, e) {
  return !!(
    (t.trade.trade_order_flags & Ve.MARKET || (0 !== e && 1 !== e)) &&
    (t.trade.trade_order_flags & Ve.LIMIT ||
      (2 !== e && 3 !== e && 6 !== e && 7 !== e)) &&
    (t.trade.trade_order_flags & Ve.STOP || (4 !== e && 5 !== e)) &&
    (t.trade.trade_order_flags & Ve.STOP_LIMIT || (6 !== e && 7 !== e))
  );
}
function $t(t, e, i, r, s, o) {
  if (!e) return 10011;
  const a = oe(e.point * e.trade.trade_stops_level, e.digits);
  switch (i.trade_type) {
    case 0: {
      if (i.price_order < 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      if (!i.price_order)
        return e.trade.trade_exemode === Fe.MARKET ||
          e.trade.trade_exemode === Fe.EXCHANGE
          ? 0
          : 10015;
      const r = t.bid;
      if (0 === r) return 0;
      let n = oe(r - a, e.digits);
      if (i.price_sl > 0) {
        if (e.isCollateral()) return 10017;
        if (i.price_sl !== s && i.price_sl > n) return 10016;
      }
      if (((n = oe(r + a, e.digits)), i.price_tp > 0)) {
        if (e.isCollateral()) return 10017;
        if (i.price_tp !== o && i.price_tp < n) return 10016;
      }
      return 0;
    }
    case 1: {
      if (i.price_order < 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      if (!i.price_order)
        return e.trade.trade_exemode === Fe.MARKET ||
          e.trade.trade_exemode === Fe.EXCHANGE
          ? 0
          : 10015;
      const r = t.ask;
      if (0 === r) return 0;
      let n = oe(r + a, e.digits);
      if (i.price_sl > 0) {
        if (e.isCollateral()) return 10017;
        if (i.price_sl !== s && i.price_sl < n) return 10016;
      }
      if (((n = oe(r - a, e.digits)), i.price_tp > 0)) {
        if (e.isCollateral()) return 10017;
        if (i.price_tp !== o && i.price_tp > n) return 10016;
      }
      return 0;
    }
    case 2: {
      const n = t.ask;
      if (i.price_order <= 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      if (e.trade.trade_exemode !== Fe.EXCHANGE) {
        const t = oe(n - a, e.digits);
        if (0 !== n && i.price_order !== r && i.price_order > t) return 10015;
      }
      let l = oe(i.price_order - a, e.digits);
      return i.price_sl > 0 &&
        (i.price_sl !== s || r !== i.price_order) &&
        i.price_sl > l
        ? 10016
        : ((l = oe(i.price_order + a, e.digits)),
          i.price_tp > 0 &&
          (i.price_tp !== o || r !== i.price_order) &&
          i.price_tp < l
            ? 10016
            : 0);
    }
    case 3: {
      const n = t.bid;
      if (i.price_order <= 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      if (e.trade.trade_exemode !== Fe.EXCHANGE) {
        const t = oe(n + a, e.digits);
        if (0 !== n && i.price_order !== r && i.price_order < t) return 10015;
      }
      let l = oe(i.price_order + a, e.digits);
      return i.price_sl > 0 &&
        (i.price_sl !== s || r !== i.price_order) &&
        i.price_sl < l
        ? 10016
        : ((l = oe(i.price_order - a, e.digits)),
          i.price_tp > 0 &&
          (i.price_tp !== o || r !== i.price_order) &&
          i.price_tp > l
            ? 10016
            : 0);
    }
    case 4: {
      const n = t.ask;
      if (i.price_order <= 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      let l = oe(n + a, e.digits);
      return 0 !== n && i.price_order !== r && i.price_order < l
        ? 10015
        : ((l = oe(i.price_order - a, e.digits)),
          i.price_sl > 0 &&
          (i.price_sl !== s || r !== i.price_order) &&
          i.price_sl > l
            ? 10016
            : ((l = oe(i.price_order + a, e.digits)),
              i.price_tp > 0 &&
              (i.price_tp !== o || r !== i.price_order) &&
              i.price_tp < l
                ? 10016
                : 0));
    }
    case 5: {
      const n = t.bid;
      if (i.price_order <= 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      let l = oe(n - a, e.digits);
      return 0 !== n && i.price_order !== r && i.price_order > l
        ? 10015
        : ((l = oe(i.price_order + a, e.digits)),
          i.price_sl > 0 &&
          (i.price_sl !== s || r !== i.price_order) &&
          i.price_sl < l
            ? 10016
            : ((l = oe(i.price_order - a, e.digits)),
              i.price_tp > 0 &&
              (i.price_tp !== o || r !== i.price_order) &&
              i.price_tp > l
                ? 10016
                : 0));
    }
    case 6: {
      const s = t.ask;
      if (i.price_order <= 0 || i.price_trigger <= 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      let o = oe(s + a, e.digits);
      return (0 !== s && i.price_order !== r && i.price_order < o) ||
        (e.trade.trade_exemode !== Fe.EXCHANGE &&
          ((o = oe(i.price_order - a, e.digits)), i.price_trigger > o))
        ? 10015
        : ((o = oe(i.price_trigger - a, e.digits)),
          i.price_sl > 0 && i.price_sl > o
            ? 10016
            : ((o = oe(i.price_trigger + a, e.digits)),
              i.price_tp > 0 && i.price_tp < o ? 10016 : 0));
    }
    case 7: {
      const s = t.bid;
      if (i.price_order <= 0 || i.price_trigger <= 0) return 10015;
      if (i.price_sl < 0 || i.price_tp < 0) return 10016;
      let o = oe(s - a, e.digits);
      return (0 !== s && i.price_order !== r && i.price_order > o) ||
        (e.trade.trade_exemode !== Fe.EXCHANGE &&
          ((o = oe(i.price_order + a, e.digits)), i.price_trigger < o))
        ? 10015
        : ((o = oe(i.price_trigger + a, e.digits)),
          i.price_sl > 0 && i.price_sl < o
            ? 10016
            : ((o = oe(i.price_trigger - a, e.digits)),
              i.price_tp > 0 && i.price_tp > o ? 10016 : 0));
    }
  }
  return 0;
}
function xt(t, e) {
  return (e.isBuy() && t.isBuy()) || (e.isSell() && t.isSell())
    ? Qr.IN
    : e.trade_volume >= t.volume_current
    ? Qr.OUT
    : Qr.INOUT;
}
function Pt(t) {
  return t && 0 !== t.trade.trade_mode ? 0 : 10017;
}
function zt(t, e, i) {
  const r = new kr();
  return (
    (r.order_type = t.trade_type),
    (r.volume_initial = t.trade_volume),
    (r.volume_current = t.trade_volume),
    (function (t, e, i, r) {
      return !(
        e <= 0 ||
        (xt(i, r) !== Qr.OUT && e < t.trade.volume_min) ||
        e > t.trade.volume_max ||
        e % t.trade.volume_step
      );
    })(e, t.trade_volume, r, i)
  );
}
function Dt(t, e, i) {
  const r = new kr();
  return (
    (r.order_type = t.trade_type),
    (r.volume_initial = t.trade_volume),
    (r.volume_current = t.trade_volume),
    (function (t, e, i) {
      switch (t.trade.trade_mode) {
        case 0:
        default:
          return 10017;
        case 1:
          return t.isCollateral()
            ? 10017
            : e.isBuy() || (e.isSell() && xt(e, i) === Qr.OUT)
            ? 0
            : 10042;
        case 2:
          return t.isCollateral()
            ? 10017
            : e.isSell() || (e.isBuy() && xt(e, i) === Qr.OUT)
            ? 0
            : 10043;
        case 3:
          return xt(e, i) === Qr.OUT ? 0 : 10044;
        case 4:
          return t.isCollateral() ? 10017 : 0;
      }
    })(e, r, i)
  );
}
function Nt(t) {
  return 0 === t
    ? "buy"
    : 1 === t
    ? "sell"
    : 2 === t
    ? "buy limit"
    : 3 === t
    ? "sell limit"
    : 4 === t
    ? "buy stop"
    : 5 === t
    ? "sell stop"
    : 6 === t
    ? "buy stop limit"
    : 7 === t
    ? "sell stop limit"
    : "unknown";
}
function Ut(t, e, i, r = 0) {
  if ((void 0 === r && (r = 0), e)) {
    let s = "";
    return (s += b(t, i, r)), (s += ` (${b(e, i)})`), s;
  }
  return t ? b(t, i) : "market";
}
function qt(t) {
  return t.volume_current && t.volume_initial === t.volume_current
    ? f(t.volume_initial)
    : (function (t = BigInt(0), e = BigInt(0)) {
        let i = "";
        return (
          t >= e
            ? ((i += f(t)), (i += " / "), (i += f(t - e)))
            : ((i += f(t)), (i += " / "), (i += f(e))),
          i
        );
      })(t.volume_initial, t.volume_current);
}
function Vt(t, e, i, r, s, o, a) {
  let n = "",
    l = "";
  if (!r) return "";
  if (o.isDone() && (s.isMarket() || s.isPending())) {
    const t = new kr();
    (t.trade_order = o.trade_order),
      (t.order_type = s.trade_type),
      (t.digits = s.digits),
      (t.price_order = o.price),
      (t.price_sl = s.price_sl),
      (t.price_tp = s.price_tp),
      (t.trade_symbol = s.trade_symbol),
      (t.volume_initial = o.volume);
    const e = (function (t) {
      let e = "";
      (e += `#${ut(t)}`),
        (e += ` ${Nt(t.order_type)}`),
        (e += ` ${qt(t)}`),
        (e += ` ${t.trade_symbol}`);
      const i = Ut(t.price_order, t.price_trigger, t.digits);
      return i && (e += ` at ${i}`), e;
    })(t);
    s.trade_volume === o.volume
      ? (n += `${s.login}: order ${e} done`)
      : (n += `${s.login}: order ${e} done partially`);
  } else {
    let r, o;
    if (
      ((s.isPending() || s.isModify() || s.isRemove()) &&
        ((r = t.getOrderById(s.trade_order)),
        r || (r = e.getOrderById(s.trade_order))),
      s.isMarket() || 6 === s.trade_action || 10 === s.trade_action)
    ) {
      const r = i.getAccount().isHedgedMargin();
      r && s.trade_position
        ? (o = t.getPositionById(s.trade_position))
        : r ||
          ((o = t.getPositionBySymbol(s.trade_symbol)),
          !o &&
            s.trade_position &&
            (o = e.getDealBySymbolId(s.trade_position)));
    }
    l = (function (t, e, i, r) {
      let s = "";
      switch (t.trade_action) {
        case 0:
          (s += "prices for"),
            (s += ` ${t.trade_symbol}`),
            (s += ` ${f(t.trade_volume)}`);
          break;
        case 1:
          (s += "request"),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${f(t.trade_volume)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${b(t.price_order, t.digits)}`),
            t.price_sl && (s += ` sl: ${b(t.price_sl, t.digits)}`),
            t.price_tp && (s += ` tp: ${b(t.price_tp, t.digits)}`),
            t.trade_position &&
              e &&
              ((s += ", close"),
              (s += ` #${at(e)}`),
              (s += ` ${ht(e.trade_action)}`),
              (s += ` ${f(e.trade_volume)}`),
              (s += ` ${e.trade_symbol}`),
              (s += ` ${b(e.price_open, e.digits)}`));
          break;
        case 2:
          (s += "instant"),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${f(t.trade_volume)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${b(t.price_order, t.digits)}`),
            t.price_sl && (s += ` sl: ${b(t.price_sl, t.digits)}`),
            t.price_tp && (s += ` tp: ${b(t.price_tp, t.digits)}`),
            t.trade_position &&
              e &&
              ((s += ", close"),
              (s += ` #${at(e)}`),
              (s += ` ${ht(e.trade_action)}`),
              (s += ` ${f(e.trade_volume)}`),
              (s += ` ${e.trade_symbol}`),
              (s += ` ${b(e.price_open, e.digits)}`));
          break;
        case 3:
          (s += "market"),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${f(t.trade_volume)}`),
            (s += ` ${t.trade_symbol}`),
            t.price_sl && (s += ` sl: ${b(t.price_sl, t.digits)}`),
            t.price_tp && (s += ` tp: ${b(t.price_tp, t.digits)}`),
            t.trade_position &&
              e &&
              ((s += ", close"),
              (s += ` #${at(e)}`),
              (s += ` ${ht(e.trade_action)}`),
              (s += ` ${f(e.trade_volume)}`),
              (s += ` ${e.trade_symbol}`),
              (s += ` ${b(e.price_open, e.digits)}`));
          break;
        case 4:
          (s += "exchange"),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${f(t.trade_volume)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${
              t.price_order ? b(t.price_order, t.digits) : "market"
            }`),
            t.price_sl && (s += ` sl: ${b(t.price_sl, t.digits)}`),
            t.price_tp && (s += ` tp: ${b(t.price_tp, t.digits)}`),
            t.trade_position &&
              e &&
              ((s += ", close"),
              (s += ` #${at(e)}`),
              (s += ` ${ht(e.trade_action)}`),
              (s += ` ${f(e.trade_volume)}`),
              (s += ` ${e.trade_symbol}`),
              (s += ` ${b(e.price_open, e.digits)}`));
          break;
        case 5:
          (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${f(t.trade_volume)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${Ut(t.price_order, t.price_trigger, t.digits)}`),
            t.price_sl && (s += ` sl: ${b(t.price_sl, t.digits)}`),
            t.price_tp && (s += ` tp: ${b(t.price_tp, t.digits)}`);
          break;
        case 6:
          if (!e) break;
          (s += `modify #${st(e) || at(e)}`),
            (s += ` ${ht(e.trade_action)}`),
            (s += ` ${f(e.trade_volume)}`),
            (s += ` ${e.trade_symbol}`),
            (s += ` sl: ${b(e.sl, t.digits)}`),
            (s += `, tp: ${b(e.tp, t.digits)}`),
            (s += ` -> sl: ${b(t.price_sl, t.digits)}`),
            (s += `, tp: ${b(t.price_tp, t.digits)}`);
          break;
        case 7:
          if (!i) break;
          (s += `modify order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${i.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            (s += ` sl: ${b(i.price_sl, t.digits)}`),
            (s += `, tp: ${b(i.price_tp, t.digits)}`),
            (s += ` -> ${Ut(t.price_order, t.price_trigger, t.digits)}`),
            (s += `, sl: ${b(t.price_sl, t.digits)}`),
            (s += `, tp: ${b(t.price_tp, t.digits)}`);
          break;
        case 8:
          if (!i) break;
          (s += `cancel order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${i.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            i.price_sl && (s += ` sl: ${b(i.price_sl, t.digits)}`),
            i.price_tp && (s += ` tp: ${b(i.price_tp, t.digits)}`);
          break;
        case 10:
          if (!e) break;
          (s += `close position #${st(e)}`),
            (s += ` ${ht(e.trade_action)}`),
            (s += ` ${f(e.trade_volume)}`),
            (s += ` ${e.trade_symbol}`),
            (s += ` by position #${t.position_by.toString()}`);
          break;
        case 9:
          (s += "transfer"),
            (s += Re(t.price_order, 2)),
            (s += " to "),
            (s += ` ${t.comment}`);
          break;
        case 100:
          if (!i) break;
          (s += `activate order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${i.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            i.price_sl && (s += ` sl: ${b(i.price_sl, t.digits)}`),
            i.price_tp && (s += ` tp: ${b(i.price_tp, t.digits)}`);
          break;
        case 101:
          if (!i || !e) break;
          (s += `activate #${st(e)}`),
            (s += " stop loss,"),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${Ut(t.price_order, 0, t.digits)}`);
          break;
        case 102:
          if (!i || !e) break;
          (s += `activate #${st(e)}`),
            (s += " take profit,"),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${Ut(t.price_order, 0, t.digits)}`);
          break;
        case 103:
          if (!i) break;
          (s += `activate stop-limit order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            i.price_sl && (s += ` sl: ${b(i.price_sl, t.digits)}`),
            i.price_tp && (s += ` tp: ${b(i.price_tp, t.digits)}`);
          break;
        case 104:
          if (!i) break;
          (s += `activate stop-out order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            i.price_sl && (s += ` sl: ${b(i.price_sl, t.digits)}`),
            i.price_tp && (s += ` tp: ${b(i.price_tp, t.digits)}`);
          break;
        case 105:
          if (!e) break;
          (s += `activate stop-out position #${st(e)}`),
            (s += ` ${ht(e.trade_action)}`),
            (s += ` ${f(e.trade_volume)}`),
            (s += ` ${e.trade_symbol}`),
            e.sl && (s += ` sl: ${b(e.sl, t.digits)}`),
            e.tp && (s += ` tp: ${b(e.tp, t.digits)}`);
          break;
        case 106:
          if (!i) break;
          (s += `expire order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${i.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            i.price_sl && (s += ` sl: ${b(i.price_sl, t.digits)}`),
            i.price_tp && (s += ` tp: ${b(i.price_tp, t.digits)}`);
          break;
        case 200:
        case 201:
          (s += `for ${t.login}`),
            (s += ` ${Nt(t.trade_type)}`),
            (s += ` ${f(t.trade_volume)}`),
            (s += ` ${t.trade_symbol}`),
            t.price_sl && (s += ` sl: ${b(t.price_sl, t.digits)}`),
            t.price_tp && (s += ` tp: ${b(t.price_tp, t.digits)}`);
          break;
        case 202:
          if (!e) break;
          (s += `for ${t.login}`),
            (s += ` modify #${st(e) || at(e)}`),
            (s += ` ${ht(e.trade_action)}`),
            (s += ` ${f(e.trade_volume)}`),
            (s += ` ${e.trade_symbol}`),
            (s += ` ${Ut(e.price_open, t.digits, 3)}`),
            (s += ` sl: ${b(e.sl, t.digits)}`),
            (s += ` tp: ${b(e.tp, t.digits)}`),
            (s += ` -> ${Ut(t.price_order, t.digits, 3)}`),
            (s += ` sl: ${b(t.price_sl, t.digits)}`),
            (s += ` tp: ${b(t.price_tp, t.digits)}`);
          break;
        case 203:
          if (!i) break;
          (s += `for ${t.login}`),
            (s += ` modify order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            (s += ` sl: ${b(i.price_sl, t.digits)}`),
            (s += ` tp: ${b(i.price_tp, t.digits)}`),
            (s += ` -> ${Ut(t.price_order, t.price_trigger, t.digits)}`),
            (s += ` sl: ${b(t.price_sl, t.digits)}`),
            (s += ` tp: ${b(t.price_tp, t.digits)}`);
          break;
        case 204:
          if (!i) break;
          (s += `for ${t.login}`),
            (s += ` cancel order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${i.trade_symbol}`),
            (s += ` at ${Ut(i.price_order, i.price_trigger, t.digits)}`),
            i.price_sl && (s += ` sl: ${b(i.price_sl, t.digits)}`),
            i.price_tp && (s += ` tp: ${b(i.price_tp, t.digits)}`);
          break;
        case 205:
          if (!i) break;
          (s += `for ${t.login}`),
            (s += ` activate order #${i.trade_order.toString()}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` as ${f(t.trade_volume)}`),
            (s += ` at ${b(i.price_order, t.digits)}`);
          break;
        case 207:
          if (!i) break;
          (s += `for ${t.login}`),
            (s += ` activate stop-limit order #${ut(i)}`),
            (s += ` ${Nt(i.order_type)}`),
            (s += ` ${qt(i)}`),
            (s += ` ${t.trade_symbol}`),
            (s += ` at ${b(i.price_order, t.digits)}`);
          break;
        case 208:
          if (!e) break;
          (s += ` for ${t.login}`),
            (s += ` close position #${st(e)}`),
            (s += ` ${ht(e.trade_action)}`),
            (s += ` ${f(e.trade_volume)}`),
            (s += ` ${e.trade_symbol}`),
            (s += ` by position #${t.position_by.toString()}`);
          break;
        case 206:
          (s += "balance"),
            (s += ` ${Re(t.price_order, 2)}`),
            (s += ` ${t.comment}`),
            (s += ` for ${t.login}`);
      }
      return s;
    })(s, o, r);
  }
  switch (o.retcode) {
    case 10001:
      if (((n += `${s.login}: ${l}`), 10 === s.trade_action)) {
        let i = t.getPositionById(s.position_by);
        i || (i = e.getDealById(s.position_by)),
          i &&
            ((n += ` ${ht(i.trade_action)}`),
            (n += ` ${f(i.trade_volume)}`),
            (n += ` ${i.trade_symbol}`));
      }
      break;
    case 10002:
      n += `${s.login}: accepted ${l}`;
      break;
    case 10003:
      n += `${s.login}: processed ${l}`;
      break;
    case 10004:
      (n += `${s.login}: requote`),
        (n += ` ${b(o.bid, r.digits)}`),
        (n += ` / ${b(o.ask, r.digits)}`),
        (n += ` (${l})`);
      break;
    case 10005:
      (n += `${s.login}: answer ${l}`),
        (n += ` ${b(o.bid, r.digits)}`),
        (n += ` / ${b(o.ask, r.digits)}`),
        a && (n += ` in ${a} ms`);
      break;
    case 10006:
      n += `${s.login}: rejected ${l}`;
      break;
    case 10008:
      (n += `${s.login}: ${l} placed for execution`), a && (n += ` in ${a} ms`);
      break;
    case 10009:
    case 10010:
    case 11001:
      switch (s.trade_action) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        case 6:
        case 7:
        case 8:
        case 10:
          n += `${s.login}: ${(function (t) {
            let e = "";
            switch (t.trade_action) {
              case 0:
                e += `prices for ${t.trade_symbol} ${f(t.trade_volume)}`;
                break;
              case 1:
                (e += "request"),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " at"),
                  (e += b(t.price_order, t.digits)),
                  t.trade_position
                    ? (e += `, close #${t.trade_position.toString()}`)
                    : (t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                      t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`));
                break;
              case 2:
                (e += "instant"),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " at"),
                  (e += ` ${b(t.price_order, t.digits)}`),
                  t.trade_position
                    ? (e += `, close #${t.trade_position.toString()}`)
                    : (t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                      t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`));
                break;
              case 3:
                (e += "market"),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  t.trade_position
                    ? (e += `, close #${t.trade_position.toString()}`)
                    : (t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                      t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`));
                break;
              case 4:
                (e += "exchange"),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " at"),
                  (e += ` ${
                    t.price_order ? b(t.price_order, t.digits) : "market"
                  }`),
                  t.trade_position
                    ? (e += `, close #${t.trade_position.toString()}`)
                    : (t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                      t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`));
                break;
              case 5:
                (e += Nt(t.trade_type)),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " at"),
                  (e += ` ${Ut(t.price_order, t.price_trigger, t.digits)}`),
                  t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                  t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`);
                break;
              case 6:
                (e += "modify"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += ` ${ht(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " ->"),
                  (e += ` sl: ${b(t.price_sl, t.digits)}`),
                  (e += `, tp: ${b(t.price_tp, t.digits)}`);
                break;
              case 7:
                (e += "modify"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " ->"),
                  (e += ` price: ${Ut(
                    t.price_order,
                    t.price_trigger,
                    t.digits
                  )}`),
                  (e += `, sl: ${b(t.price_sl, t.digits)}`),
                  (e += `, tp: ${b(t.price_tp, t.digits)}`);
                break;
              case 8:
                (e += "cancel"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, t.price_trigger, t.digits)}`);
                break;
              case 9:
                (e += "transfer"),
                  (e += ` ${Re(t.price_order, 2)}`),
                  (e += " to ''"),
                  (e += `${t.comment}`);
                break;
              case 10:
                (e += "close position"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += " by position"),
                  (e += ` #${t.position_by.toString()}`);
                break;
              case 100:
                (e += "activate "),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, t.price_trigger, t.digits)}`);
                break;
              case 101:
                (e += "activate"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += " stop loss,"),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, 0, t.digits)}`);
                break;
              case 102:
                (e += "activate"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += " take profit,"),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, 0, t.digits)}`);
                break;
              case 103:
                (e += "activate stop-limit order"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, t.price_trigger, t.digits)}`);
                break;
              case 104:
                (e += "delete stop-out order"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, t.price_trigger, t.digits)}`);
                break;
              case 105:
                (e += "close stop-out position"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, 0, t.digits)}`);
                break;
              case 106:
                (e += "expire"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, 0, t.digits)}`);
                break;
              case 200:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, 0, t.digits)}`),
                  t.trade_position
                    ? (e += `, close #${t.trade_position.toString()}`)
                    : (t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                      t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`));
                break;
              case 201:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` at ${Ut(t.price_order, t.price_trigger, t.digits)}`),
                  t.price_sl && (e += ` sl: ${b(t.price_sl, t.digits)}`),
                  t.price_tp && (e += ` tp: ${b(t.price_tp, t.digits)}`);
                break;
              case 202:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " modify position"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` -> price: ${Ut(t.price_order, t.digits, 3)}`),
                  (e += ` sl: ${b(t.price_sl, t.digits)}`),
                  (e += ` tp: ${b(t.price_tp, t.digits)}`);
                break;
              case 203:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " modify order"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` -> price: ${Ut(
                    t.price_order,
                    t.price_trigger,
                    t.digits
                  )}`),
                  (e += ` sl: ${b(t.price_sl, t.digits)}`),
                  (e += ` tp: ${b(t.price_tp, t.digits)}`);
                break;
              case 204:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " cancel order"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`);
                break;
              case 205:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " activate order"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`);
                break;
              case 207:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " activate stop-limit order"),
                  (e += ` #${t.trade_order.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`);
                break;
              case 208:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " close position"),
                  t.trade_position && (e += ` #${t.trade_position.toString()}`),
                  (e += ` ${Nt(t.trade_type)}`),
                  (e += ` ${f(t.trade_volume)}`),
                  (e += ` ${t.trade_symbol}`),
                  (e += ` by position #${t.position_by.toString()}`);
                break;
              case 206:
                (e += "for"),
                  (e += ` ${t.login}`),
                  (e += " balance"),
                  (e += ` ${Re(t.price_order, 2)}`),
                  (e += ` ${t.comment}`);
            }
            return e;
          })(s)} done`;
          break;
        default:
          n += `${s.login}: ${l} done`;
      }
      a && (n += ` in ${a} ms`);
      break;
    case 10025:
      n += `${s.login}: ${l} skipped as it changes nothing`;
      break;
    default:
      n += `${s.login}: failed ${l} [${He(o.retcode)}]`;
  }
  return n;
}
function Ft(t) {
  var e;
  return {
    priceOrder: t.price_order,
    priceTrigger: t.price_trigger,
    priceSL: t.price_sl,
    priceTP: t.price_tp,
    priceDeviation: t.price_deviation,
    symbol: t.trade_symbol,
    volume: Yi.toDouble(t.trade_volume),
    position: null == (e = t.trade_position) ? void 0 : e.toString(),
    order: t.trade_order ? t.trade_order.toString() : void 0,
    expiration: t.time_expiration,
    id: t.action_id,
    typeName: Oe(t.trade_type),
    complete: t.complete,
    isBuy: t.isBuy(),
    isSell: t.isSell(),
    isMarket: t.isMarket(),
    isPending: t.isPending(),
    isClose: t.isClose(),
    isCloseBy: t.isCloseBy(),
    digits: t.digits,
    tradeAction: t.trade_action,
    comment: t.comment,
  };
}
function Ht(t) {
  return 1 * t;
}
function Gt(t) {
  return {
    code: t.retcode,
    order: t.trade_order ? t.trade_order.toString() : "",
    volume: Yi.toDouble(t.volume),
    price: t.price,
    time: t.res_time,
    bid: t.bid,
    ask: t.ask,
  };
}
function Yt() {
  return { request: new bo(), result: new vo() };
}
function Qt(t, e) {
  return e || ((t.result.retcode = 3), null);
}
function Kt(t, e) {
  return e || ((t.result.retcode = 3), null);
}
function Wt(t) {
  return { action: Ft(t.request), result: Gt(t.result) };
}
function jt(t, e) {
  const i = ee.parse(t, Ao, e);
  return [i[0], i[1], i[2]];
}
import {
  bt as Xt,
  bu as Jt,
  bv as Zt,
  bw as te,
  aZ as ee,
  bx as ie,
  by as re,
  bz as se,
  $ as oe,
  bA as ae,
  bB as ne,
  bC as le,
  bD as ce,
  bE as _e,
  bF as de,
  aE as he,
  bG as pe,
  at as ue,
  av as me,
  bH as ge,
  bI as ye,
  bJ as fe,
  bK as be,
  bL as ve,
  bM as Te,
  bN as Se,
  bO as ke,
  bP as Ce,
  bQ as Ee,
  bR as Be,
  bS as we,
  bT as Le,
  au as Oe,
  bU as Ie,
  bV as Re,
} from "./00a24b22.js";
import {
  S as Ae,
  h as Me,
  j as $e,
  k as xe,
  M as Pe,
  l as ze,
  t as De,
  m as Ne,
  n as Ue,
  o as qe,
  q as Ve,
  r as Fe,
  s as He,
} from "./917f94f7.js";
import { A as Ge, O as Ye, a as Qe } from "./04a8e93f.js";
import "./f54151ac.js";
class Ke {
  constructor(t) {
    (this.path = t[0]),
      (this.range_mode = t[1]),
      (this.range_currency = t[2]),
      (this.range_currency_digits = t[3]),
      (this.tiers = t[5].map((t) => ({
        range_from: t[0],
        range_to: t[1],
        margin_rate_initial: t[2],
        margin_rate_maintenance: t[3],
      })));
  }
  static createFromResponse(t) {
    return t.map((t) => new Ke(t));
  }
}
class We {
  constructor(t, e) {
    (this.account_type = 0),
      (this.balance = 0),
      (this.credit = 0),
      (this.account_currency = ""),
      (this.currency_digits = 0),
      (this.margin_leverage = 0),
      (this.account_name = ""),
      (this.server_build = 0),
      (this.server_name = ""),
      (this.company = ""),
      (this.timezone_shift = 0),
      (this.daylightmode = 0),
      (this.margin_mode = 0),
      (this.margin_free_mode = 0),
      (this.margin_so_call = 0),
      (this.margin_so_so = 0),
      (this.margin_so_mode = 0),
      (this.margin_virtual = 0),
      (this.margin_free_profit_mode = 0),
      (this.commission_daily = 0),
      (this.commission_monthly = 0),
      (this.acc_profit = 0),
      (this.trade_flags = Ae.NONE),
      (this.rights = 0),
      (this.permissions_flags = 0),
      (this.trade_settings = []),
      (this.margin_free = 0),
      (this.margin_level = 0),
      (this.profit = 0),
      (this.commission = 0),
      (this.storage = 0),
      (this.margin = 0),
      (this.margin_initial = 0),
      (this.margin_maintenance = 0),
      (this.floating = 0),
      (this.equity = 0),
      (this.assets = 0),
      (this.liabilities = 0),
      (this.collateral = 0),
      (this.bad_request = 0),
      (this.auth_password_min = 8),
      (this.symbols_count = 0),
      (this.profit_excluded = 0),
      (this.acc_commission = 0),
      (this.leverage_flags = 0n),
      (this.rules = []),
      (this.so_activation = 0),
      (this.otp_status = 0),
      (this.login = e),
      (this.options = t),
      this.update(t);
  }
  update(t) {
    (this.options = t),
      (this.account_type = t[0]),
      (this.rights = t[1]),
      (this.permissions_flags = t[2]),
      (this.balance = t[3]),
      (this.credit = t[4]),
      (this.account_currency = t[5]),
      (this.currency_digits = t[6]),
      (this.margin_leverage = t[7]),
      (this.account_name = t[8]),
      (this.server_build = t[9]),
      (this.server_name = t[10]),
      (this.company = t[11]),
      (this.timezone_shift = t[12]),
      (this.daylightmode = t[13]),
      (this.margin_mode = t[14]),
      (this.margin_free_mode = t[15]),
      (this.margin_so_call = t[16]),
      (this.margin_so_so = t[17]),
      (this.margin_so_mode = t[18]),
      (this.margin_virtual = t[19]),
      (this.margin_free_profit_mode = t[20]),
      (this.acc_profit = t[21]),
      (this.commission_daily = t[22]),
      (this.commission_monthly = t[23]),
      (this.auth_password_min = t[24]),
      (this.otp_status = t[25]),
      (this.trade_settings = t[26].map((t) => ({ ...t }))),
      (this.trade_flags = t[27]),
      (this.symbols_count = t[28]),
      (this.leverage_flags = t[29]),
      (this.rules = Ke.createFromResponse(t[30]));
  }
  copy() {
    return new We(this.options, this.login);
  }
  isInvestor() {
    return Boolean(8 & this.rights);
  }
  isTradeDisabled() {
    return Boolean(4 & this.rights);
  }
  isReadOnly() {
    return Boolean(512 & this.rights);
  }
  isResetPass() {
    return !!(1024 & this.rights);
  }
  isHedgedMargin() {
    return 2 === this.margin_mode;
  }
  isExchangeMargin() {
    return 1 === this.margin_mode;
  }
  getServerOffsetTime() {
    return 3600 * this.daylightmode + this.timezone_shift;
  }
  riskWarning() {
    return Boolean(16 & this.permissions_flags);
  }
}
class je {
  constructor(t) {
    this.account = t;
  }
  getAccount() {
    return this.account;
  }
  setAccount(t) {
    return (this.account = t), this.account;
  }
}
class Xe {
  constructor(t, e, i, r) {
    (this.emitter = t),
      (this.accountApi = e),
      (this.accountStorage = new je(new We([...i], r)));
    const s = this.accountStorage.getAccount();
    this.emitter.trigger(13, {
      isInvestor: s.isInvestor(),
      isResetPass: s.isResetPass(),
      isTradeDisabled: s.isTradeDisabled(),
      isReadOnly: s.isReadOnly(),
      isHedgedMargin: s.isHedgedMargin(),
    }),
      this.accountApi.on(this.onUpdate);
  }
  destroy() {
    this.accountApi.off(this.onUpdate);
  }
  onUpdate(t) {
    var e;
    null == (e = this.emitter) || e.trigger(14), this.updateAccount(t);
  }
  updateAccount(t) {
    this.getAccount().update(t);
  }
  getAccount() {
    return this.accountStorage.getAccount();
  }
  setAccount(t) {
    return this.accountStorage.setAccount(t);
  }
}
const Je = ":e4dd535gf:ddg7361613d6885fc6841ffd:4g:g498g8266dg:eff33886f738c",
  Ze = "bfddfd:b:c5b5bdd976fbc::86dec9b:bfbc:685cgc7115389",
  ti = "987264ef98b:159fe89dd9bf986fc97ggcd7:27dg95dd28173b45f48b:d8e397",
  ei = Xt();
let ii,
  ri,
  si = !1;
class oi {
  constructor(t) {
    this.accountController = t;
  }
  getAccount() {
    const t = this.accountController.getAccount();
    return {
      type: t.account_type,
      isReal: 0 === t.account_type,
      isDemo: 1 === t.account_type,
      isContest: 2 === t.account_type,
      isPreliminary: 3 === t.account_type,
      name: t.account_name,
      login: t.login,
      company: t.company,
      timezoneShift: t.timezone_shift,
      dayLightMode: t.daylightmode,
      currency: t.account_currency,
      digits: t.currency_digits,
      serverBuild: t.server_build,
      serverName: t.server_name,
      balance: t.balance,
      credit: t.credit,
      profit: t.profit,
      commission: t.acc_commission,
      storage: t.storage,
      margin: t.margin,
      marginFree: t.margin_free,
      marginInitial: t.margin_initial,
      marginMaintenance: t.margin_maintenance,
      marginLeverage: t.margin_leverage,
      marginLevel: oe(t.margin_level, t.currency_digits),
      floating: t.floating,
      equity: t.equity,
      assets: t.assets,
      liabilities: t.liabilities,
      collateral: t.collateral,
      isInvestor: t.isInvestor(),
      isTradeDisabled: t.isTradeDisabled(),
      isReadOnly: t.isReadOnly(),
      isHedgedMargin: t.isHedgedMargin(),
      isResetPass: t.isResetPass(),
      passwordMin: t.auth_password_min,
      serverOffsetTime: t.getServerOffsetTime(),
      riskWarning: t.riskWarning(),
      otpStatus: t.otp_status,
    };
  }
  static enc(e, i, r) {
    return (async function (e, i, r) {
      si || (await t());
      let s = await Jt(Zt(te(r)), ri);
      return (
        (r = ee.toHex(s)),
        (s = await Jt(Zt(te(`${r}\t${e}\t${i}`)), ii)),
        ee.toHex(s)
      );
    })(e, i, r);
  }
  static async dec(e, i = !1) {
    const r = await (async function (e, i = !1) {
        si || (await t());
        let r = await ie(Zt(e), ii);
        const s = String.fromCharCode
            .apply(null, Array.from(new Uint8Array(r)))
            .split("\t"),
          o = { login: s[1], trade_server: s[2] };
        return (
          i &&
            ((r = await ie(Zt(s[0]), ri)),
            (o.password = String.fromCharCode.apply(
              null,
              Array.from(new Uint8Array(r))
            ))),
          o
        );
      })(e, i),
      s = { login: r.login, server: r.trade_server };
    return i && (s.password = r.password), s;
  }
}
const ai = [
    { propType: 11, propLength: 256 },
    { propType: 3 },
    { propType: 3 },
    { propType: 6 },
    { propType: 3 },
    { propType: 3 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 18 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 18 },
    { propType: 18 },
    { propType: 18 },
    { propType: 18 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 12, propLength: 64, parser: i },
    { propType: 12, propLength: 64, parser: i },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 3 },
    { propType: 6 },
    { propType: 6 },
  ],
  ni = ee.getSeriesSize(ai),
  li = [
    { propType: 11, propLength: 256 },
    { propType: 6 },
    { propType: 11, propLength: 32 },
    { propType: 6 },
    { propType: 3 },
  ],
  ci = ee.getSeriesSize(li),
  _i = [{ propType: 8 }, { propType: 8 }, { propType: 8 }, { propType: 8 }],
  di = ee.getSeriesSize(_i),
  hi = [
    { propType: 4 },
    { propType: 3 },
    { propType: 3 },
    { propType: 8 },
    { propType: 8 },
    { propType: 11, propLength: 64 },
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 256 },
    { propType: 5 },
    { propType: 11, propLength: 128 },
    { propType: 11, propLength: 256 },
    { propType: 3 },
    { propType: 1 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 8 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 6 },
  ],
  pi = ee.getSeriesSize(hi);
class ui extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  async get() {
    return o((await this.socket.sendCommand(3)).resBody);
  }
  on(t) {
    let e = this.map.get(t);
    return (
      e || ((e = this.onAccount.bind(this, t)), this.map.set(t, e)),
      this.socket.on(14, e),
      this
    );
  }
  off(t) {
    const e = this.map.get(t);
    return e && this.socket.off(14, e), this;
  }
  onAccount(t, e) {
    t(o(e.resBody));
  }
}
class mi {
  constructor(t, e, i, r) {
    (this.controller = new Xe(t, e, i, r)),
      (this.view = new oi(this.controller));
  }
  static async create(t, e, i) {
    const r = new ui(e),
      s = await r.get();
    return new mi(t, r, s, i);
  }
}
class gi {
  constructor(t) {
    this.notifyApi = t;
  }
  async send(t) {
    await this.notifyApi.send(t);
  }
}
class yi extends Ge {
  async send(t) {
    await this.socket.sendCommand(
      42,
      (function (t) {
        return ee.serialize([{ propType: 6, propValue: t.risk || 0 }]);
      })(t)
    );
  }
}
class fi {
  constructor(t) {
    this.notifyController = t;
  }
  async send(t) {
    await this.notifyController.send(t);
  }
}
class bi {
  constructor(t) {
    (this.controller = new gi(new yi(t))),
      (this.view = new fi(this.controller));
  }
}
class vi {
  constructor() {
    (this.list = new Map()),
      (this.tree = { count: 0, path: "", label: "", children: new Map() });
  }
  getAll() {
    return new Map(this.list);
  }
  getTree() {
    return { ...this.tree };
  }
  calcCounts(t) {
    t.forEach((t) => {
      let e = this.tree.children;
      for (let i = 0; i < t.path_category_list.length; i++) {
        const r = t.path_category_list[i],
          s = e.get(r);
        if (!s) return;
        (s.count += 1), (e = s.children);
      }
    });
  }
  clear() {
    this.list.clear(), this.tree.children.clear(), (this.tree.count = 0);
  }
  setType(t, e) {
    this.list.set(t, e.group_name), this.setTree(e.group_name);
  }
  setTree(t) {
    const e = t.split("\\");
    let i = this.tree.children;
    e.forEach((t, r) => {
      let s = i.get(t);
      s ||
        ((s = {
          count: 0,
          children: new Map(),
          path: e.slice(0, r + 1).join("\\"),
          label: t,
        }),
        i.set(t, s)),
        (i = s.children);
    });
  }
}
class Ti {
  constructor(t) {
    (this.typesStorage = new vi()),
      (this.symbolTypesApi = t),
      (this.onTypes = this.onTypes.bind(this)),
      this.init();
  }
  async init() {
    this.destroy();
    const t = await this.symbolTypesApi.loadTypes();
    this.onTypes(t);
  }
  destroy() {
    this.typesStorage.clear();
  }
  calcCounts(t) {
    t.forEach((t) => {
      let e = this.typesStorage.getTree().children;
      for (let i = 0; i < t.path_category_list.length; i++) {
        const r = t.path_category_list[i],
          s = e.get(r);
        if (!s) return;
        (s.count += 1), (e = s.children);
      }
    });
  }
  onTypes(t) {
    t.forEach((t, e) => {
      this.typesStorage.setType(e, t);
    });
  }
  getAll() {
    return this.typesStorage.getAll();
  }
  getTree() {
    return this.typesStorage.getTree();
  }
}
const Si = [{ propType: 11, propLength: 256 }],
  ki = ee.getSeriesSize(Si);
class Ci extends Ge {
  async loadTypes() {
    return (function (t) {
      const e = [],
        i = new DataView(t).getUint32(0, !0);
      let r = 4;
      for (let s = 0; s < i; s++) e.push(a(t, r)), (r += ki);
      return e;
    })((await this.socket.sendCommand(9)).resBody);
  }
}
class Ei {
  constructor(t, e, i = !0) {
    this.catagories = [];
    const r = e.split("\\");
    r.forEach((e) => {
      const i = t.children.get(e);
      i && (t = i);
    }),
      (this.parentPath = r.slice(0, r.length - 1).join("\\")),
      i &&
        (this.catagories = Array.from(t.children)
          .filter((t) => t[1].count)
          .map((e) => new Ei(t, e[1].path, !1))),
      (this.label = t.label),
      (this.count = t.count),
      (this.path = t.path);
  }
}
class Bi {
  constructor(t) {
    this.symbolTypesController = t;
  }
  getBranch(t = "") {
    return new Ei(this.symbolTypesController.getTree(), t);
  }
  getTypes() {
    return this.symbolTypesController.getAll();
  }
}
class wi {
  constructor(t) {
    (this.controller = new Ti(new Ci(t))),
      (this.view = new Bi(this.controller));
  }
}
const Li = 1,
  Oi = 1;
class Ii {
  constructor(t) {
    (this.legs_a = []),
      (this.legs_b = []),
      (this.spread_id = t[0]),
      (this.flag_mask = t[1]),
      (this.margin_initial = t[2]),
      (this.margin_maintenance = t[3]),
      (this.margin_type = t[4]);
  }
  preferable(t) {
    return (
      !(
        (2 !== this.margin_type && 3 !== this.margin_type) ||
        (2 !== t && 3 !== t)
      ) && this.margin_type > t
    );
  }
}
class Ri {
  constructor(t, e) {
    (this.spread_id = t.spread_id),
      (this.spread = t),
      (this.spread_mode = e[0]),
      (this.flag_mask = e[1]),
      (this.trade_symbol = e[2]),
      (this.time_from = e[3]),
      (this.time_to = e[4]),
      (this.spread_ratio = e[5]);
  }
  checkSymbol(t, e, i) {
    if (i < 0) return !1;
    switch (this.spread_mode) {
      case 0:
        return this.trade_symbol === t;
      case Oi:
        return (
          (!this.time_from || i >= this.time_from) &&
          (!this.time_to || i <= this.time_to) &&
          this.trade_symbol === e
        );
      default:
        return !1;
    }
  }
  checkSymbolByConfig(t) {
    return this.checkSymbol(t.trade_symbol, t.basis, t.time_expiration);
  }
}
const Ai = [
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 64 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
  ],
  Mi = ee.getSeriesSize(Ai),
  $i = [
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
  ],
  xi = ee.getSeriesSize($i);
class Pi extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  async getSpreads(t) {
    const e = h(t);
    return d((await this.socket.sendCommand(20, e)).resBody);
  }
  on(t) {
    let e = this.map.get(t);
    return (
      e || ((e = this.onSpreads.bind(this, t)), this.map.set(t, e)),
      this.socket.on(20, e),
      this
    );
  }
  off(t) {
    const e = this.map.get(t);
    return e && this.socket.off(20, e), this;
  }
  onSpreads(t, e) {
    t(d(e.resBody));
  }
}
class zi {
  constructor() {
    (this.spreads = []),
      (this.spreadsIndex = {}),
      (this.legs_symbol = []),
      (this.legs_basis = []),
      (this.path = ""),
      (this.trade_spreads_symbols = []);
  }
  legsGetAll() {
    return [...this.trade_spreads_symbols];
  }
  legsClear() {
    this.trade_spreads_symbols = [];
  }
  legsAdd(t) {
    this.trade_spreads_symbols.push(t);
  }
  legsTotal() {
    return this.trade_spreads_symbols.length;
  }
  legsGetBySymbol(t) {
    return this.trade_spreads_symbols.filter((e) => e.trade_symbol === t);
  }
  legsSort(t) {
    this.trade_spreads_symbols.sort(t);
  }
  legsSymbolGetAll() {
    return [...this.legs_symbol];
  }
  legsSymbolClear() {
    this.legs_symbol = [];
  }
  legsSymbolAdd(t) {
    this.legs_symbol.push(t);
  }
  legsBasisGetAll() {
    return [...this.legs_basis];
  }
  legsBasisClear() {
    this.legs_basis = [];
  }
  legsBasisAdd(t) {
    this.legs_basis.push(t);
  }
  spreadsReset(t) {
    this.spreadsClear(),
      t.forEach((t) => {
        this.spreadsAdd(t);
      });
  }
  spreadsAdd(t) {
    this.spreads.push(t), (this.spreadsIndex[t.spread_id] = t);
  }
  spreadsClear() {
    (this.spreads = []), (this.spreadsIndex = {});
  }
  spreadsGetAll() {
    return [...this.spreads];
  }
  spreadsGet(t) {
    return this.spreadsIndex[t] ?? this.spreads.find((e) => e.spread_id === t);
  }
  spreadsTotal() {
    return this.spreads.length;
  }
  spreadsForEach(t) {
    this.spreads.forEach(t);
  }
  legsSymbolSort(t) {
    this.legs_symbol.sort(t);
  }
  legsBasisSort(t) {
    this.legs_basis.sort(t);
  }
  getBySymbolId(t) {
    return [];
  }
}
class Di {
  constructor(t, e) {
    (this.storage = new zi()),
      (this.spreadApi = t),
      (this.symbolsController = e);
  }
  async loadSpreads(t) {
    if (!t.length) return;
    const e = [],
      i = [];
    if (
      (t.forEach((t) => {
        const r = this.symbolsController.getSymbolByName(t);
        r &&
          (i.push(r.symbol_id),
          this.symbolsController.getFullSymbolByName(t) || e.push(r.symbol_id));
      }),
      !i.length)
    )
      return;
    e.length && (await this.symbolsController.loadConfig(i));
    const r = await this.spreadApi.getSpreads(i);
    this.accountUpdate(i),
      this.storage.spreadsReset(r),
      this.buildSpreadsLegs();
  }
  getSpreadBySymbolId(t) {
    return this.storage.getBySymbolId(t);
  }
  legsGetBySymbol(t) {
    return this.storage.legsGetBySymbol(t);
  }
  get(t) {
    return this.storage.spreadsGet(t);
  }
  getLegs() {
    return this.storage.legsGetAll();
  }
  legsTotal() {
    return this.storage.legsTotal();
  }
  accountUpdate(t) {
    const e = [];
    t.forEach((t) => {
      const i = this.symbolsController.getFullSymbolById(t);
      i && e.push(i);
    }),
      this.storage.legsClear(),
      e.forEach((t) => {
        this.buildSpreadsLegsAccount(
          this.storage.legsSymbolGetAll(),
          t,
          t.trade_symbol
        ),
          this.buildSpreadsLegsAccount(
            this.storage.legsBasisGetAll(),
            t,
            t.basis
          );
      });
  }
  total() {
    return this.storage.spreadsTotal();
  }
  find(t) {
    return [
      ...u(this.storage.legsSymbolGetAll(), t, t.trade_symbol),
      ...u(this.storage.legsBasisGetAll(), t, t.basis),
    ];
  }
  baseClear() {
    this.storage.spreadsClear();
  }
  buildSpreadsLegs() {
    this.storage.legsSymbolClear(),
      this.storage.legsBasisClear(),
      this.storage.spreadsForEach((t) => {
        t.legs_a.forEach((t) => {
          0 === t.spread_mode
            ? this.storage.legsSymbolAdd(t)
            : t.spread_mode === Oi && this.storage.legsBasisAdd(t);
        }),
          t.legs_b.forEach((t) => {
            0 === t.spread_mode
              ? this.storage.legsSymbolAdd(t)
              : t.spread_mode === Oi && this.storage.legsBasisAdd(t);
          });
      }),
      this.storage.legsSymbolSort(p),
      this.storage.legsBasisSort(p);
  }
  buildSpreadsLegsAccount(t, e, i) {
    i &&
      (t
        .filter((t) => t.trade_symbol === i)
        .forEach((t) => {
          t.checkSymbol(e.trade_symbol, e.basis, e.time_expiration) &&
            this.storage.legsAdd(t);
        }),
      this.storage.legsSort(p));
  }
}
class Ni {
  constructor(t) {
    this.spreadController = t;
  }
}
class Ui {
  constructor(t, e) {
    (this.controller = new Di(new Pi(t), e)),
      (this.view = new Ni(this.controller));
  }
}
class qi {
  constructor(t) {
    (this.basis = ""),
      (this.digits = 0),
      (this.symbol_description = ""),
      (this.symbol_id = 0),
      (this.symbol_path = ""),
      (this.path_list = []),
      (this.path_category_list = []),
      (this.path_category = ""),
      (this.trade_symbol = ""),
      (this.time_expiration = 0),
      (this.sector = 0),
      (this.trade_symbol = t[0] ?? this.trade_symbol),
      (this.symbol_description = t[1] ?? this.symbol_description),
      (this.digits = t[2] ?? this.digits),
      (this.symbol_id = t[3] ?? this.symbol_id),
      this.setPath(t[4] ?? this.symbol_path),
      (this.time_expiration = t[5] ?? this.time_expiration),
      (this.basis = t[6] ?? this.basis),
      (this.sector = t[7] ?? this.sector);
  }
  setPath(t = "") {
    (this.symbol_path = t),
      (this.path_list = this.symbol_path.split("\\")),
      (this.path_category_list = this.path_list.slice(
        0,
        this.path_list.length - 1
      )),
      (this.path_category = this.path_category_list.join("\\"));
  }
  update(t) {
    (this.basis = t.basis ?? this.basis),
      (this.digits = t.digits ?? this.digits),
      (this.symbol_description =
        t.symbol_description ?? this.symbol_description),
      (this.symbol_id = t.symbol_id ?? this.symbol_id),
      (this.time_expiration = t.time_expiration ?? this.time_expiration),
      (this.trade_symbol = t.trade_symbol ?? this.trade_symbol),
      (this.sector = t.sector ?? this.sector),
      this.setPath((null == t ? void 0 : t.symbol_path) ?? this.symbol_path);
  }
}
class Vi extends qi {
  constructor(t) {
    super([t[0], t[2], t[21], t[24], t[46].symbol_path, t[45], t[4], t[10]]),
      (this.isin = ""),
      (this.international = ""),
      (this.symbol_source = ""),
      (this.symbol_page = ""),
      (this.category = ""),
      (this.trade_exchange = ""),
      (this.cfi = ""),
      (this.industry = 0),
      (this.country = ""),
      (this.currency_base = ""),
      (this.currency_profit = ""),
      (this.currency_margin = ""),
      (this.currency_base_digits = 0),
      (this.currency_profit_digits = 0),
      (this.currency_margin_digits = 0),
      (this.symbol_color = 0),
      (this.color_background = 0),
      (this.point = 0),
      (this.symbol_multiply = 0),
      (this.ticks_flags = 0),
      (this.ticks_bookdepth = 0),
      (this.ticks_chart_mode = 0),
      (this.trade_flags = Ae.NONE),
      (this.trade_spread = 0),
      (this.trade_spread_balance = 0),
      (this.trade_tick_value = 0),
      (this.trade_tick_size = 0),
      (this.trade_contract_size = 0),
      (this.trade_gtc_mode = Me.ORDERS_GTC),
      (this.trade_calc_mode = 0),
      (this.trade_price_settle = 0),
      (this.trade_price_limit_min = 0),
      (this.trade_price_limit_max = 0),
      (this.trade_price_strike = 0),
      (this.trade_option_mode = $e.EUROPEAN_CALL),
      (this.trade_face_value = 0),
      (this.trade_accrued_interest = 0),
      (this.time_flags = 0),
      (this.time_start = 0),
      this.setPath(t[46].symbol_path || this.symbol_path),
      (this.isin = t[1] ?? this.isin),
      (this.international = t[3] ?? this.international),
      (this.symbol_source = t[5] ?? this.symbol_source),
      (this.symbol_page = t[6] ?? this.symbol_page),
      (this.category = t[7] ?? this.category),
      (this.trade_exchange = t[8] ?? this.trade_exchange),
      (this.cfi = t[9] ?? this.cfi),
      (this.industry = t[11] ?? this.industry),
      (this.country = t[12] ?? this.country),
      (this.currency_base = t[13] ?? this.currency_base),
      (this.currency_profit = t[14] ?? this.currency_profit),
      (this.currency_margin = t[15] ?? this.currency_margin),
      (this.currency_base_digits = t[16] ?? this.currency_base_digits),
      (this.currency_profit_digits = t[17] ?? this.currency_profit_digits),
      (this.currency_margin_digits = t[18] ?? this.currency_margin_digits),
      (this.symbol_color = t[19] ?? this.symbol_color),
      (this.color_background = t[20] ?? this.color_background),
      (this.point = t[22] ?? this.point),
      (this.symbol_multiply = t[23] ?? this.symbol_multiply),
      (this.ticks_flags = t[25] ?? this.ticks_flags),
      (this.ticks_bookdepth = t[26] ?? this.ticks_bookdepth),
      (this.ticks_chart_mode = t[27] ?? this.ticks_chart_mode),
      (this.trade_flags = t[28] ?? this.trade_flags),
      (this.trade_spread = t[29] ?? this.trade_spread),
      (this.trade_spread_balance = t[30] ?? this.trade_spread_balance),
      (this.trade_tick_value = t[31] ?? this.trade_tick_value),
      (this.trade_tick_size = t[32] ?? this.trade_tick_size),
      (this.trade_contract_size = t[33] ?? this.trade_contract_size),
      (this.trade_gtc_mode = t[34] ?? this.trade_gtc_mode),
      (this.trade_calc_mode = t[35] ?? this.trade_calc_mode),
      (this.trade_price_settle = t[36] ?? this.trade_price_settle),
      (this.trade_price_limit_min = t[37] ?? this.trade_price_limit_min),
      (this.trade_price_limit_max = t[38] ?? this.trade_price_limit_max),
      (this.trade_price_strike = t[39] ?? this.trade_price_strike),
      (this.trade_option_mode = t[40] ?? this.trade_option_mode),
      (this.trade_face_value = t[41] ?? this.trade_face_value),
      (this.trade_accrued_interest = t[42] ?? this.trade_accrued_interest),
      (this.time_flags = t[43] ?? this.time_flags),
      (this.time_start = t[44] ?? this.time_start),
      (this.trade = { ...t[46] }),
      (this.schedule = {
        quote_sessions: [...t[47].quote_sessions],
        trade_sessions: [...t[47].trade_sessions],
      }),
      (this.prevTrade = { ...t[46] }),
      (this.subscription = t[48]);
  }
  update(t) {
    var e;
    super.update(t),
      this.setPath(
        t.symbol_path ||
          (null == (e = t.trade) ? void 0 : e.symbol_path) ||
          this.symbol_path
      ),
      (this.isin = t.isin ?? this.isin),
      (this.international = t.international ?? this.international),
      (this.symbol_source = t.symbol_source ?? this.symbol_source),
      (this.symbol_page = t.symbol_page ?? this.symbol_page),
      (this.category = t.category ?? this.category),
      (this.trade_exchange = t.trade_exchange ?? this.trade_exchange),
      (this.cfi = t.cfi ?? this.cfi),
      (this.industry = t.industry ?? this.industry),
      (this.country = t.country ?? this.country),
      (this.currency_base = t.currency_base ?? this.currency_base),
      (this.currency_profit = t.currency_profit ?? this.currency_profit),
      (this.currency_margin = t.currency_margin ?? this.currency_margin),
      (this.currency_base_digits =
        t.currency_base_digits ?? this.currency_base_digits),
      (this.currency_profit_digits =
        t.currency_profit_digits ?? this.currency_profit_digits),
      (this.currency_margin_digits =
        t.currency_margin_digits ?? this.currency_margin_digits),
      (this.symbol_color = t.symbol_color ?? this.symbol_color),
      (this.color_background = t.color_background ?? this.color_background),
      (this.point = t.point ?? this.point),
      (this.symbol_multiply = t.symbol_multiply ?? this.symbol_multiply),
      (this.ticks_flags = t.ticks_flags ?? this.ticks_flags),
      (this.ticks_bookdepth = t.ticks_bookdepth ?? this.ticks_bookdepth),
      (this.ticks_chart_mode = t.ticks_chart_mode ?? this.ticks_chart_mode),
      (this.trade_flags = t.trade_flags ?? this.trade_flags),
      (this.trade_spread = t.trade_spread ?? this.trade_spread),
      (this.trade_spread_balance =
        t.trade_spread_balance ?? this.trade_spread_balance),
      (this.trade_tick_value = t.trade_tick_value ?? this.trade_tick_value),
      (this.trade_tick_size = t.trade_tick_size ?? this.trade_tick_size),
      (this.trade_contract_size =
        t.trade_contract_size ?? this.trade_contract_size),
      (this.trade_gtc_mode = t.trade_gtc_mode ?? this.trade_gtc_mode),
      (this.trade_calc_mode = t.trade_calc_mode ?? this.trade_calc_mode),
      (this.trade_price_settle =
        t.trade_price_settle ?? this.trade_price_settle),
      (this.trade_price_limit_min =
        t.trade_price_limit_min ?? this.trade_price_limit_min),
      (this.trade_price_limit_max =
        t.trade_price_limit_max ?? this.trade_price_limit_max),
      (this.trade_price_strike =
        t.trade_price_strike ?? this.trade_price_strike),
      (this.trade_option_mode = t.trade_option_mode ?? this.trade_option_mode),
      (this.trade_face_value = t.trade_face_value ?? this.trade_face_value),
      (this.trade_accrued_interest =
        t.trade_accrued_interest ?? this.trade_accrued_interest),
      (this.time_flags = t.time_flags ?? this.time_flags),
      (this.time_start = t.time_start ?? this.time_start),
      (this.trade = { ...t.trade }),
      (this.prevTrade = { ...t.trade }),
      (this.trade = { ...(t.trade ?? this.trade) }),
      (this.schedule = {
        quote_sessions: [...t.schedule.quote_sessions],
        trade_sessions: [...t.schedule.trade_sessions],
      }),
      (this.subscription = t.subscription ?? this.subscription);
  }
  cacheTradeSettings() {
    const { trade: t } = this;
    return t && (this.prevTrade = { ...t }), this;
  }
  resetTradeSettings() {
    this.trade && this.prevTrade && Object.assign(this.trade, this.prevTrade);
  }
  orderRate(t, e) {
    const i = this.trade;
    let r = 0,
      s = 0,
      o = 0;
    if (i)
      switch (t) {
        case 0:
          (s = i.margin_rates_initial[xe.BUY]),
            (o = i.margin_rates_maintenance[xe.BUY]);
          break;
        case 1:
          (s = i.margin_rates_initial[xe.SELL]),
            (o = i.margin_rates_maintenance[xe.SELL]);
          break;
        case 2:
          (s = i.margin_rates_initial[xe.BUY_LIMIT]),
            (o = i.margin_rates_maintenance[xe.BUY_LIMIT]);
          break;
        case 4:
          (s = i.margin_rates_initial[xe.BUY_STOP]),
            (o = i.margin_rates_maintenance[xe.BUY_STOP]);
          break;
        case 6:
          (s = i.margin_rates_initial[xe.BUY_STOP_LIMIT]),
            (o = i.margin_rates_maintenance[xe.BUY_STOP_LIMIT]);
          break;
        case 3:
          (s = i.margin_rates_initial[xe.SELL_LIMIT]),
            (o = i.margin_rates_maintenance[xe.SELL_LIMIT]);
          break;
        case 5:
          (s = i.margin_rates_initial[xe.SELL_STOP]),
            (o = i.margin_rates_maintenance[xe.SELL_STOP]);
          break;
        case 7:
          (s = i.margin_rates_initial[xe.SELL_STOP_LIMIT]),
            (o = i.margin_rates_maintenance[xe.SELL_STOP_LIMIT]);
          break;
        default:
          (s = 0), (o = 0);
      }
    else (s = 0), (o = 0);
    return (r = e ? s : o || s), r;
  }
  isLargeLeg() {
    return Boolean(this.trade.margin_flags & Pe.HEDGE_LARGE_LEG);
  }
  isMarginExcludePL() {
    return Boolean(this.trade.margin_flags & Pe.EXCLUDE_PL);
  }
  isValueBased() {
    return Boolean(
      32 === this.trade_calc_mode ||
        35 === this.trade_calc_mode ||
        37 === this.trade_calc_mode ||
        38 === this.trade_calc_mode ||
        39 === this.trade_calc_mode
    );
  }
  isForex() {
    return 0 === (t = this.trade_calc_mode) || 5 === t;
    var t;
  }
  isFORTS() {
    return 34 === this.trade_calc_mode;
  }
  isBond() {
    return 37 === this.trade_calc_mode || 39 === this.trade_calc_mode;
  }
  isCollateral() {
    return 64 === this.trade_calc_mode;
  }
  isTradeEnabled() {
    const { trade: t } = this;
    return (
      !!t &&
      0 !== t.trade_mode &&
      (64 !== this.trade_calc_mode || 3 === t.trade_mode)
    );
  }
  isOrderEnabled(t) {
    const { trade: e } = this;
    return !!e && 0 != (e.trade_order_flags & t);
  }
  isSubscription() {
    return 1 === this.subscription.status || 2 === this.subscription.status;
  }
  isSubscribed() {
    return 2 === this.subscription.status;
  }
  isUnsubscribed() {
    return 1 === this.subscription.status;
  }
  isDelayed() {
    return this.isSubscription() && 0 === this.subscription.level;
  }
  isDerivative() {
    return (
      33 === this.trade_calc_mode ||
      34 === this.trade_calc_mode ||
      35 === this.trade_calc_mode ||
      36 === this.trade_calc_mode
    );
  }
  isOption() {
    return 35 === this.trade_calc_mode || 36 === this.trade_calc_mode;
  }
  isFuture() {
    return (
      1 === this.trade_calc_mode ||
      33 === this.trade_calc_mode ||
      34 === this.trade_calc_mode
    );
  }
  isChartByLast() {
    return 1 === this.ticks_chart_mode || 255 === this.ticks_chart_mode;
  }
  hasBook() {
    const { trade: t } = this;
    return (
      !t ||
      void 0 === t.permissions_flags ||
      0 != (t.permissions_flags & ze.BOOK)
    );
  }
  hasInitialMargin() {
    var t;
    return Boolean(
      (null == (t = this.trade) ? void 0 : t.margin_initial) &&
        this.trade.margin_maintenance &&
        this.trade.margin_initial !== this.trade.margin_maintenance
    );
  }
}
class Fi {
  constructor() {
    (this.list = new Map()),
      (this.listById = []),
      (this.listByName = []),
      (this.listByType = new Map());
  }
  clear() {
    (this.list = new Map()),
      (this.listByType = new Map()),
      (this.listById = []),
      (this.listByName = []);
  }
  addShort(t, e = !1) {
    const i = this.list.has(t.trade_symbol);
    this.list.set(t.trade_symbol, t);
    let r = this.listByType.get(t.path_category);
    r || ((r = []), this.listByType.set(t.path_category, r)),
      r.push(t),
      i && e && this.sortRecords();
  }
  addFull(t, e = !1) {
    const i = this.list.has(t.trade_symbol);
    this.list.set(t.trade_symbol, t);
    let r = this.listByType.get(t.path_category);
    r || ((r = []), this.listByType.set(t.path_category, r)),
      r.push(t),
      t.setPath(t.trade.symbol_path),
      i && e && this.sortRecords();
  }
  concat(t) {
    t && t.forEach((t) => this.addShort(t)), this.sortRecords();
  }
  update(t) {
    const e = t.trade_symbol;
    if (e) {
      const i = this.get(e);
      if (!i) return this.addFull(t), !0;
      !(i instanceof Vi) && t instanceof Vi ? this.addFull(t, !0) : i.update(t);
    }
    return !1;
  }
  sortRecords() {
    (this.listById = [...this.list.values()].sort(m)),
      (this.listByName = [...this.list.values()].sort(g));
  }
  get(t) {
    return this.list.get(t);
  }
  getFull(t) {
    const e = this.list.get(t);
    return e instanceof Vi ? e : null;
  }
  getById(t) {
    let e = 0,
      i = this.listById.length;
    for (; e <= i; ) {
      const r = Math.floor(e + (i - e) / 2),
        s = this.listById[r] && this.listById[r].symbol_id;
      if (s === t) return this.listById[r];
      s > t ? (i = r - 1) : (e = r + 1);
    }
    return null;
  }
  getFullById(t) {
    let e = 0,
      i = this.listById.length;
    for (; e <= i; ) {
      const r = Math.floor(e + (i - e) / 2),
        s = this.listById[r],
        o = null == s ? void 0 : s.symbol_id;
      if (o === t && s instanceof Vi) return s;
      o > t ? (i = r - 1) : (e = r + 1);
    }
    return null;
  }
  all() {
    return [...this.list.values()];
  }
  allFull() {
    return [...this.list.values()].filter((t) => t instanceof Vi);
  }
  getAllByType(t) {
    return this.listByType.get(t) || [];
  }
  allByName() {
    return (this.listByName && this.listByName.slice()) || [];
  }
  allById() {
    return (this.listById && this.listById.slice()) || [];
  }
}
const Hi = {
  applyConfig: function (t, e) {
    e.forEach((e) => {
      Hi.check(e.symbol_path, t.trade.symbol_path) && Hi.apply(e, t);
    });
  },
  upgrade: function (t, e) {
    return (
      t.forEach((t) => {
        Hi.applyConfig(t, e);
      }),
      !0
    );
  },
  apply: function (t, e) {
    e.resetTradeSettings();
    const { trade: i } = e;
    i &&
      (t.spread_diff !== ae && (i.spread_diff = t.spread_diff),
      t.spread_diff_balance !== ae &&
        (i.spread_diff_balance = t.spread_diff_balance),
      t.trade_mode < ne && (i.trade_mode = t.trade_mode),
      t.trade_stops_level < ae && (i.trade_stops_level = t.trade_stops_level),
      t.trade_freeze_level < ae &&
        (i.trade_freeze_level = t.trade_freeze_level),
      t.trade_exemode < ne && (i.trade_exemode = t.trade_exemode),
      t.trade_fill_flags !== ne && (i.trade_fill_flags = t.trade_fill_flags),
      t.trade_time_flags !== ne && (i.trade_time_flags = t.trade_time_flags),
      t.trade_order_flags !== ne && (i.trade_order_flags = t.trade_order_flags),
      t.trade_request_flags !== ne &&
        (i.trade_request_flags = t.trade_request_flags),
      t.trade_request_timeout !== ne &&
        (i.trade_request_timeout = t.trade_request_timeout),
      t.trade_instant_flags !== ne &&
        (i.trade_instant_flags = t.trade_instant_flags),
      t.trade_instant_timeout !== ne &&
        (i.trade_instant_timeout = t.trade_instant_timeout),
      t.trade_instant_slip_profit !== ne &&
        (i.trade_instant_slip_profit = t.trade_instant_slip_profit),
      t.trade_instant_slip_losing !== ne &&
        (i.trade_instant_slip_losing = t.trade_instant_slip_losing),
      t.trade_instant_volume &&
        t.trade_instant_volume !== le &&
        (i.trade_instant_volume = t.trade_instant_volume),
      t.trade_instant_checkmode !== ne &&
        (i.trade_instant_checkmode = t.trade_instant_checkmode),
      t.trade_market_flags !== ne &&
        (i.trade_market_flags = t.trade_market_flags),
      t.trade_exchange_flags !== ne &&
        (i.trade_exchange_flags = t.trade_exchange_flags),
      t.volume_min && t.volume_min !== le && (i.volume_min = t.volume_min),
      t.volume_max && t.volume_max !== le && (i.volume_max = t.volume_max),
      t.volume_step && t.volume_step !== le && (i.volume_step = t.volume_step),
      t.volume_limit &&
        t.volume_limit !== le &&
        (i.volume_limit = t.volume_limit),
      t.margin_flags !== ne && (i.margin_flags = t.margin_flags),
      t.margin_initial !== ce && (i.margin_initial = t.margin_initial),
      t.margin_maintenance !== ce &&
        (i.margin_maintenance = t.margin_maintenance),
      t.margin_rates_initial[0] !== ce &&
        (i.margin_rates_initial[0] = t.margin_rates_initial[0]),
      t.margin_rates_initial[1] !== ce &&
        (i.margin_rates_initial[1] = t.margin_rates_initial[1]),
      t.margin_rates_initial[2] !== ce &&
        (i.margin_rates_initial[2] = t.margin_rates_initial[2]),
      t.margin_rates_initial[3] !== ce &&
        (i.margin_rates_initial[3] = t.margin_rates_initial[3]),
      t.margin_rates_initial[4] !== ce &&
        (i.margin_rates_initial[4] = t.margin_rates_initial[4]),
      t.margin_rates_initial[5] !== ce &&
        (i.margin_rates_initial[5] = t.margin_rates_initial[5]),
      t.margin_rates_initial[6] !== ce &&
        (i.margin_rates_initial[6] = t.margin_rates_initial[6]),
      t.margin_rates_initial[7] !== ce &&
        (i.margin_rates_initial[7] = t.margin_rates_initial[7]),
      t.margin_rates_maintenance[0] !== ce &&
        (i.margin_rates_maintenance[0] = t.margin_rates_maintenance[0]),
      t.margin_rates_maintenance[1] !== ce &&
        (i.margin_rates_maintenance[1] = t.margin_rates_maintenance[1]),
      t.margin_rates_maintenance[2] !== ce &&
        (i.margin_rates_maintenance[2] = t.margin_rates_maintenance[2]),
      t.margin_rates_maintenance[3] !== ce &&
        (i.margin_rates_maintenance[3] = t.margin_rates_maintenance[3]),
      t.margin_rates_maintenance[4] !== ce &&
        (i.margin_rates_maintenance[4] = t.margin_rates_maintenance[4]),
      t.margin_rates_maintenance[5] !== ce &&
        (i.margin_rates_maintenance[5] = t.margin_rates_maintenance[5]),
      t.margin_rates_maintenance[6] !== ce &&
        (i.margin_rates_maintenance[6] = t.margin_rates_maintenance[6]),
      t.margin_rates_maintenance[7] !== ce &&
        (i.margin_rates_maintenance[7] = t.margin_rates_maintenance[7]),
      t.margin_rate_liquidity !== ce &&
        (i.margin_rate_liquidity = t.margin_rate_liquidity),
      t.margin_hedged !== ce && (i.margin_hedged = t.margin_hedged),
      t.margin_rate_currency !== ce &&
        (i.margin_rate_currency = t.margin_rate_currency),
      t.swap_mode < ne && (i.swap_mode = t.swap_mode),
      t.swap_long !== ce && (i.swap_long = t.swap_long),
      t.swap_short !== ce && (i.swap_short = t.swap_short),
      t.swap_rollover3days !== ae &&
        (i.swap_rollover3days = t.swap_rollover3days),
      t.permissions_flags < ne && (i.permissions_flags = t.permissions_flags),
      t.permissions_bookdepth !== ne &&
        (i.permissions_bookdepth = t.permissions_bookdepth));
  },
  check: function (t, e) {
    if (!t || !e) return !1;
    const i = t.split(",");
    if (i.length)
      for (let r, s = 0, o = i.length; s < o; s++) {
        if (((r = i[s]), "!" === r.charAt(0) && Hi.checkMask(r, e))) return !1;
        if (Hi.checkMask(r, e)) return !0;
      }
    return !1;
  },
  checkMask: function (t, e) {
    if (!t || !e) return !1;
    let i, r, s;
    for (t = t.trim().replace(/\*+/g, "*"); "!" === t[0]; ) t = t.substring(1);
    if ("*" === t) return !0;
    if (((i = t[0]), "*" === i)) {
      if (!(t.length > 1)) return !0;
      r = t[1];
    }
    for (let o = 0, a = 0, n = e.length; o < n; o++)
      if (((s = e[o]), "*" !== i)) {
        if (s !== i) return !1;
        if (((a += 1), !(t.length >= a))) return !0;
        if (((i = t[a]), "*" === i)) {
          if (!(t.length < a + 1)) return !0;
          r = t[a + 1];
        }
      } else s === r && ((i = r), (r = null), (o -= 1));
    return !0;
  },
};
class Gi {
  constructor(t, e, i, r) {
    (this.symbolsStorage = new Fi()),
      (this.onUpdateAccount = this.onUpdateAccount.bind(this)),
      (this.onUpdateSymbols = this.onUpdateSymbols.bind(this)),
      (this.emitter = t),
      (this.symbolsApi = e),
      (this.accountController = i),
      (this.symbolTypesController = r),
      this.symbolsApi.on(this.onUpdateSymbols),
      this.emitter.on(14, this.onUpdateAccount);
  }
  onUpdateSymbols(t) {
    const e = this.accountController.getAccount(),
      i = [];
    null == t ||
      t.forEach((t) => {
        const r = new Vi(t);
        i.push(r.trade_symbol), this.symbolsStorage.update(r);
        const s = this.symbolsStorage.getFull(r.trade_symbol);
        return s && Hi.applyConfig(s, e.trade_settings), r;
      }),
      this.emitter.trigger(17, i);
  }
  onUpdateAccount() {
    const t = this.accountController.getAccount();
    Hi.upgrade(this.getAllFullSymbols(), t.trade_settings);
  }
  async init() {
    this.destroy();
    const t = await this.symbolsApi.loadSymbols();
    this.onList(t);
  }
  destroy() {
    this.symbolsStorage.clear();
  }
  async loadConfig(t) {
    if (!t.length) return;
    const e = await this.symbolsApi.loadFullSymbols(t),
      i = this.accountController.getAccount();
    e &&
      e.forEach((t) => {
        const e = new Vi(t);
        this.symbolsStorage.update(e);
        const r = this.symbolsStorage.getFull(e.trade_symbol);
        return r && Hi.applyConfig(r, i.trade_settings), e;
      });
  }
  onList(t) {
    const e = t.map((t) => new qi(t));
    this.symbolsStorage.concat(e), this.symbolTypesController.calcCounts(e);
  }
  getSymbolByName(t) {
    return this.symbolsStorage.get(t);
  }
  getFullSymbolByName(t) {
    return this.symbolsStorage.getFull(t);
  }
  getSymbolById(t) {
    return this.symbolsStorage.getById(t);
  }
  getFullSymbolById(t) {
    return this.symbolsStorage.getFullById(t);
  }
  getAllSymbols() {
    return this.symbolsStorage.all();
  }
  getAllFullSymbols() {
    return this.symbolsStorage.allFull();
  }
  getSymbolsByType(t) {
    return this.symbolsStorage.getAllByType(t);
  }
  getAllSymbolsByName() {
    return this.symbolsStorage.allByName();
  }
}
class Yi {
  static toDouble(t) {
    return De(t, 8);
  }
  static toSize(t, e) {
    return oe(Yi.toDouble(t) * e, 8);
  }
  static toInt(t) {
    const e = oe(t, 8).toFixed(8).split(".").join("");
    return BigInt(e);
  }
  static toDigits(t) {
    let e = Yi.toDouble(t);
    e = oe(e, 8);
    let i = e.toFixed(8);
    const r = i.indexOf(".");
    if (-1 !== r) {
      for (
        i = i
          .substring(r + 1)
          .split("")
          .reverse();
        i.length && "0" === i[0];

      )
        i.splice(0, 1);
      return i.length;
    }
    return 0;
  }
  static toNewPrice(t) {
    return BigInt(t) * BigInt(1e8);
  }
}
class Qi {
  constructor(t, e, i) {
    if (
      ((this.stopsLevel = 0),
      (this.lotsMin = 0),
      (this.lotsMax = 0),
      (this.lotsStep = 1),
      (this.id = t.symbol_id),
      (this.symbol = t.trade_symbol),
      (this.description = t.symbol_description),
      (this.digits = t.digits),
      (this.sector = t.sector),
      (this.path = t.symbol_path),
      (this.pathList = t.path_list),
      (this.pathCategory = t.path_category),
      (this.delay = 0),
      (this.isExchangeMargin = i),
      (this.serverOffsetTime = e),
      (this.contractSize = 0),
      (this.currencyBase = ""),
      t instanceof Vi)
    ) {
      (this.requestTimeout = t.trade.trade_request_timeout),
        (this.requoteTimeout = t.trade.trade_instant_timeout),
        (this.ticksBookDepth = t.ticks_bookdepth),
        (this.schedule = t.schedule),
        (this.international = t.international),
        (this.isFull = !0),
        (this.multiply = t.symbol_multiply);
      const { trade: e } = t;
      if (
        ((this.contractSize = t.trade_contract_size),
        (this.page = t.symbol_page),
        (this.isin = t.isin || ""),
        (this.category = t.category || ""),
        (this.exchange = t.trade_exchange || ""),
        t.isCollateral() ||
          (t.trade_spread && t.trade_spread > 0
            ? (this.spread = t.trade_spread)
            : (this.spread = "floating"),
          (this.stopsLevel = e.trade_stops_level),
          (this.currencyMargin = t.currency_margin),
          (this.currencyBase = t.currency_base)),
        (this.currencyProfit = t.currency_profit),
        (this.calcMode = t.trade_calc_mode),
        (this.tradeMode = e.trade_mode),
        t.isCollateral())
      )
        (this.marginRateLiqudity = e.margin_rate_liquidity),
          (this.tickChartMode = t.ticks_chart_mode);
      else {
        if (
          ((t.isFuture() || t.isOption()) && t.basis && (this.basis = t.basis),
          t.isOption() &&
            ((this.optionType = (function (t) {
              switch (t) {
                case 0:
                case 2:
                  return "Call";
                case 1:
                case 3:
                  return "Put";
                default:
                  return "";
              }
            })(t.trade_option_mode)),
            (this.optionMode = (function (t) {
              switch (t.trade_option_mode) {
                case 0:
                case 1:
                  return "European";
                case 2:
                case 3:
                  return "American";
                default:
                  return "";
              }
            })(t)),
            (this.priceStrike = t.trade_price_strike)),
          t.isForex() ||
            ((this.tickSize = t.trade_tick_size),
            "number" == typeof t.trade_tick_value &&
              (this.tickValue = v(t.trade_tick_value, 8))),
          t.isBond() &&
            (t.trade_face_value &&
              t.trade_face_value > 0 &&
              (this.faceValue = Number(
                t.trade_face_value.toFixed(t.currency_base_digits)
              )),
            t.trade_accrued_interest &&
              t.trade_accrued_interest > 0 &&
              (this.accruedInterest = Number(
                t.trade_accrued_interest.toFixed(t.currency_base_digits)
              ))),
          e.margin_initial > 0 && (this.marginInitial = v(e.margin_initial, 8)),
          e.margin_maintenance > 0 &&
            (this.marginMaintenance = v(e.margin_maintenance, 8)),
          this.isExchangeMargin &&
            (4 & e.margin_flags
              ? (this.marginLargeLeg = !0)
              : e.margin_hedged > 0 &&
                (this.marginHedged = v(e.margin_hedged, 8))),
          (this.chartMode = t.ticks_chart_mode),
          (this.marginRate = (function (t) {
            switch (t) {
              case 0:
                return "By bid price";
              case 1:
                return "By last price";
              case 255:
                return "By default";
              default:
                return "";
            }
          })(t.ticks_chart_mode)),
          e.margin_rate_liquidity > 0 && (this.trade = e.trade_mode),
          e.trade_mode > 0)
        ) {
          switch (
            ((this.isRequestExecution = e.trade_exemode === Fe.REQUEST),
            (this.isInstantExecution = e.trade_exemode === Fe.INSTANT),
            (this.isMarketExecution = e.trade_exemode === Fe.MARKET),
            (this.isExchangeExecution = e.trade_exemode === Fe.EXCHANGE),
            (this.gtc = (function (t) {
              switch (t) {
                case Me.ORDERS_GTC:
                  return "Good till cancelled";
                case Me.ORDERS_DAILY:
                  return "Good till today including SL/TP";
                case Me.ORDERS_DAILY_NO_STOPS:
                  return "Good till today excluding SL/TP";
                default:
                  return "";
              }
            })(t.trade_gtc_mode)),
            (this.isFillingFOK = Boolean(e.trade_fill_flags & Ue.FOK)),
            (this.isFillingIOC = Boolean(e.trade_fill_flags & Ue.IOC)),
            (this.isFillingBOC = Boolean(e.trade_fill_flags & Ue.BOC)),
            e.trade_fill_flags & Ue.ALL)
          ) {
            case Ue.NONE:
              this.filling = "None";
              break;
            case Ue.ALL:
              this.filling = "All";
              break;
            default:
              this.filling = [Ue.FOK, Ue.IOC, Ue.BOC]
                .filter((t) => e && e.trade_fill_flags & t)
                .map((t) =>
                  (function (t) {
                    switch (t) {
                      case Ue.NONE:
                        return "None";
                      case Ue.ALL:
                        return "All";
                      case Ue.FOK:
                        return "Fill or Kill";
                      case Ue.IOC:
                        return "Immediate or Cancel";
                      case Ue.BOC:
                        return "Book or Cancel";
                      default:
                        return "";
                    }
                  })(t)
                )
                .join(",");
          }
          switch (
            ((this.isGTCExpiration = Boolean(e.trade_time_flags & qe.GTC)),
            (this.isDayExpiration = Boolean(e.trade_time_flags & qe.DAY)),
            (this.isSpecifiedExpiration = Boolean(
              e.trade_time_flags & qe.SPECIFIED
            )),
            (this.isSpecifiedDayExpiration = Boolean(
              e.trade_time_flags & qe.SPECIFIED_DAY
            )),
            e.trade_time_flags & qe.ALL)
          ) {
            case qe.NONE:
              this.expiration = "None";
              break;
            case qe.ALL:
              this.expiration = "All";
              break;
            default:
              this.expiration = [qe.GTC, qe.DAY, qe.SPECIFIED, qe.SPECIFIED_DAY]
                .filter((t) => e && e.trade_time_flags & t)
                .map((t) =>
                  (function (t) {
                    switch (t) {
                      case qe.GTC:
                        return "GTC";
                      case qe.DAY:
                        return "Today";
                      case qe.SPECIFIED:
                        return "Specified";
                      case qe.SPECIFIED_DAY:
                        return "Specified day";
                      default:
                        return "";
                    }
                  })(t)
                )
                .join(", ");
          }
          switch (e.trade_order_flags & Ve.ALL) {
            case Ve.NONE:
              this.orders = "None";
              break;
            case Ve.ALL:
              this.orders = "All";
              break;
            default:
              this.orders = [
                Ve.MARKET,
                Ve.LIMIT,
                Ve.STOP,
                Ve.STOP_LIMIT,
                Ve.SL,
                Ve.TP,
              ]
                .filter((t) => e && e.trade_order_flags & t)
                .map((t) =>
                  (function (t) {
                    switch (t) {
                      case Ve.MARKET:
                        return "Market";
                      case Ve.LIMIT:
                        return "Limit";
                      case Ve.STOP:
                        return "Stop";
                      case Ve.STOP_LIMIT:
                        return "Stop Limit";
                      case Ve.SL:
                        return "Stop Loss";
                      case Ve.TP:
                        return "Take Profit";
                      default:
                        return "";
                    }
                  })(t)
                )
                .join(",");
          }
          (null == e ? void 0 : e.trade_order_flags) &&
            (e.trade_order_flags & Ve.MARKET &&
              (this.isOrderMarketAllowed = !0),
            e.trade_order_flags & Ve.LIMIT && (this.isOrderLimitAllowed = !0),
            e.trade_order_flags & Ve.STOP && (this.isOrderStopAllowed = !0),
            e.trade_order_flags & Ve.STOP_LIMIT &&
              (this.isOrderStopLimitAllowed = !0),
            e.trade_order_flags & Ve.SL && (this.isOrderSlAllowed = !0),
            e.trade_order_flags & Ve.TP && (this.isOrderTpAllowed = !0)),
            (this.lotsMin = Yi.toDouble(e.volume_min)),
            (this.lotsMax = Yi.toDouble(e.volume_max)),
            (this.lotsStep = Yi.toDouble(e.volume_step)),
            e.volume_limit > 0 && (this.lotsLimit = f(e.volume_limit, !0));
        }
        if (e.swap_mode > Ne.DISABLED) {
          let i = (function (t) {
            switch (t.swap_mode) {
              case Ne.BY_POINTS:
                return "In points";
              case Ne.BY_SYMBOL_CURRENCY:
              case Ne.BY_MARGIN_CURRENCY:
              case Ne.BY_GROUP_CURRENCY:
                return "";
              case Ne.BY_INTEREST_CURRENT:
                return "In percentage terms, using current price";
              case Ne.BY_INTEREST_OPEN:
                return "In percentage terms, using open price";
              case Ne.REOPEN_BY_CLOSE_PRICE:
                return "In points, reopen position by close price";
              case Ne.REOPEN_BY_BID:
                return "In points, reopen position by bid price";
              default:
                return "";
            }
          })(e);
          e.swap_mode === Ne.BY_MARGIN_CURRENCY &&
            t.currency_margin &&
            (i = t.currency_margin),
            e.swap_mode === Ne.BY_SYMBOL_CURRENCY &&
              t.currency_base &&
              (i = t.currency_base),
            (this.swapType = i),
            (this.swapLong = v(e.swap_long, 8)),
            (this.swapShort = v(e.swap_short, 8)),
            e.swap_rollover3days >= 0 &&
              e.swap_rollover3days <= 7 &&
              (this.swap3Day =
                "Sunday Monday Tuesday Wednesday Thursday Friday Saturday Disabled".split(
                  " "
                )[e.swap_rollover3days]);
        }
        t.time_start && (this.timeStart = S(t.time_start)),
          t.time_expiration && (this.timeExpiration = S(t.time_expiration));
      }
      (this.isCollateral = t.isCollateral()),
        (this.isFuture = t.isFuture()),
        (this.isFORTS = t.isFORTS()),
        (this.isOption = t.isOption()),
        (this.isForex = t.isForex()),
        (this.isBond = t.isBond()),
        (this.isTradeEnabled = t.isTradeEnabled()),
        (this.isCloseByOrderEnabled = t.isOrderEnabled(Ve.CLOSEBY)),
        t.isDelayed() && (this.delay = t.subscription.delay);
    }
  }
  static from(t, e, i) {
    return new Qi(t, e, i);
  }
  isMarketClosed(t = new Date()) {
    const { schedule: e } = this;
    if (e) {
      const i = this.serverOffsetTime / 60,
        r = new Date(t.getTime());
      let s = e.trade_sessions[r.getUTCDay()] || [],
        o = r.getUTCMinutes() + 60 * r.getUTCHours(),
        a = s.find((t) => o >= t[0] - i && o < t[1] - i);
      return (
        a ||
          (r.setUTCDate(r.getUTCDate() - 1),
          (s = e.trade_sessions[r.getUTCDay()] || []),
          (o = r.getUTCMinutes() + 60 * r.getUTCHours() + 1440),
          (a = s.find((t) => o >= t[0] - i && o < t[1] - i))),
        !a
      );
    }
    return !1;
  }
  marketOpenTime() {
    const { schedule: t } = this;
    if (t) {
      let e;
      if (!this.isMarketClosed()) return 0;
      const i = this.serverOffsetTime / 60,
        r = new Date();
      r.setUTCMilliseconds(0), r.setUTCSeconds(0);
      const s = r.getUTCMinutes() + 60 * r.getUTCHours(),
        o = t.trade_sessions;
      for (let t = 0; t < 7; t++) {
        const a = o[r.getUTCDay()];
        if (a)
          if (0 === t) {
            if (((e = a.find((t) => t[0] - i > s)), e))
              return (
                r.setUTCHours(Math.floor((e[0] - i) / 60)),
                r.setUTCMinutes(e[0] - i - 60 * r.getUTCHours()),
                r.getTime()
              );
          } else if (((e = a.find((t) => t[0] - i >= 0 && t[1] - i >= 0)), e))
            return (
              r.setUTCHours(Math.floor((e[0] - i) / 60)),
              r.setUTCMinutes(e[0] - i - 60 * r.getUTCHours()),
              r.getTime()
            );
        r.setUTCDate(r.getUTCDate() + 1);
      }
    }
    return 0;
  }
  marketOpenServerTime() {
    const t = this.marketOpenTime();
    if (!t) return 0;
    const e = Math.floor(this.serverOffsetTime / 3600),
      i = this.serverOffsetTime % 3600,
      r = new Date(t);
    return (
      r.setHours(r.getUTCHours() + e),
      r.setMinutes(r.getUTCMinutes() + i),
      r.getTime()
    );
  }
}
class Ki {
  constructor(t, e, i) {
    (this.symbolsController = t),
      (this.symbolTypesController = e),
      (this.account = i);
  }
  async get(t) {
    const e = this.symbolsController.getSymbolByName(t),
      i = this.account;
    if (e) {
      if (e instanceof Vi)
        return new Promise((t) => {
          t(Qi.from(e, i.getServerOffsetTime(), i.isExchangeMargin()));
        });
      await this.symbolsController.loadConfig([e.symbol_id]);
      const r = this.symbolsController.getSymbolByName(t);
      if (r) return new Qi(r, i.getServerOffsetTime(), i.isExchangeMargin());
    }
    return new Promise((t) => {
      t(null);
    });
  }
  all() {
    const { account: t } = this;
    return this.symbolsController
      .getAllSymbols()
      .map((e) => Qi.from(e, t.getServerOffsetTime(), t.isExchangeMargin()));
  }
  async getMany(t) {
    const e = [],
      i = [],
      r = [];
    t.forEach((t, s) => {
      const o = this.symbolsController.getSymbolByName(t);
      o &&
        (o instanceof Vi
          ? i.push(o)
          : (i.push(null), r.push({ idx: s, symbol: t }), e.push(o.symbol_id)));
    }),
      e.length &&
        (await this.symbolsController.loadConfig(e),
        r.forEach(({ idx: t, symbol: e }) => {
          const r = this.symbolsController.getSymbolByName(e);
          r && r instanceof Vi && (i[t] = r);
        }));
    const s = [];
    for (let o = 0; o < i.length; o++) {
      const t = i[o];
      null !== t &&
        s.push(
          new Qi(
            t,
            this.account.getServerOffsetTime(),
            this.account.isExchangeMargin()
          )
        );
    }
    return s;
  }
}
const Wi = [
    { propType: 11, propLength: 64 },
    { propType: 11, propLength: 128 },
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 256 },
    { propType: 6 },
    { propType: 11, propLength: 64 },
    { propType: 5 },
  ],
  ji = ee.getSeriesSize(Wi),
  Xi = [{ propType: 5 }, { propType: 5 }],
  Ji = ee.getSeriesSize(Xi),
  Zi = 16 * Ji * 7 * 2,
  tr = [{ propType: 6 }, { propType: 4 }, { propType: 4 }, { propType: 5 }],
  er = ee.getSeriesSize(tr),
  ir = [
    { propType: 11, propLength: 64 },
    { propType: 11, propLength: 32 },
    { propType: 11, propLength: 128 },
    { propType: 11, propLength: 128 },
    { propType: 11, propLength: 64 },
    { propType: 11, propLength: 64 },
    { propType: 11, propLength: 512 },
    { propType: 11, propLength: 128 },
    { propType: 11, propLength: 128 },
    { propType: 11, propLength: 16 },
    { propType: 5 },
    { propType: 5 },
    { propType: 11, propLength: 8 },
    { propType: 11, propLength: 32 },
    { propType: 11, propLength: 32 },
    { propType: 11, propLength: 32 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 3 },
    { propType: 3 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 3 },
    { propType: 3 },
    { propType: 12, propLength: ni, parser: e },
    {
      propType: 12,
      propLength: Zi,
      parser: function (t, e = 0) {
        let i = e;
        const r = { quote_sessions: [], trade_sessions: [] };
        for (let s = 0; s < 7; s++) {
          r.quote_sessions[s] = [];
          for (let e = 0; e < 16; e++)
            (r.quote_sessions[s][e] = C(t, i)), (i += Ji);
        }
        for (let s = 0; s < 7; s++) {
          r.trade_sessions[s] = [];
          for (let e = 0; e < 16; e++)
            (r.trade_sessions[s][e] = C(t, i)), (i += Ji);
        }
        return r;
      },
    },
    {
      propType: 12,
      propLength: er,
      parser: function (t, e) {
        const i = ee.parse(t, tr, e);
        return { delay: i[0], status: i[1], level: i[2], reserved: i[3] };
      },
    },
  ],
  rr = ee.getSeriesSize(ir);
class sr extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  async loadSymbols() {
    const t = await this.socket.sendCommand(34);
    return (function (t) {
      const e = [],
        i = new DataView(t).getUint32(0, !0);
      let r = 4;
      for (let s = 0; s < i; s++) e.push(k(t, r)), (r += ji);
      return e;
    })(
      await (async function (t) {
        const e = t.slice(4),
          i = new Uint8Array(e);
        return (await he(() => import("./7953a2e8.js"), [])).ungzip(i).buffer;
      })(t.resBody)
    );
  }
  async loadFullSymbols(t) {
    return B((await this.socket.sendCommand(18, h(t))).resBody);
  }
  on(t) {
    let e = this.map.get(t);
    return (
      e || ((e = this.onUpdate.bind(this, t)), this.map.set(t, e)),
      this.socket.on(13, e),
      this
    );
  }
  off(t) {
    const e = this.map.get(t);
    return e && this.socket.off(13, e), this;
  }
  onUpdate(t, e) {
    t(
      (function (t) {
        const e = [],
          i = Math.floor(t.byteLength / rr);
        let r = 0;
        for (let s = 0; s < i; s++) e.push(E(t, r)), (r += rr);
        return e;
      })(e.resBody)
    );
  }
}
class or {
  constructor(t, e, i, r) {
    (this.controller = new Gi(t, new sr(e), r, i)),
      (this.view = new Ki(this.controller, i, r.getAccount()));
  }
}
const ar = [
    { propType: 6 },
    { propType: 17 },
    { propType: 3 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 6 },
    { propType: 18 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 17 },
    { propType: 6 },
    { propType: 17 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 5 },
  ],
  nr = ee.getSeriesSize(ar);
class lr extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  on(t) {
    let e = this.map.get(t);
    e || ((e = this.onStats.bind(this, t)), this.map.set(t, e)),
      this.socket.on(17, e);
  }
  off(t) {
    const e = this.map.get(t);
    e && this.socket.off(17, e);
  }
  onStats(t, e) {
    t(
      (function (t) {
        const e = [],
          i = Math.floor(t.byteLength / nr);
        let r = 0;
        for (let s = 0; s < i; s++) e.push(w(t, r)), (r += nr);
        return e;
      })(e.resBody)
    );
  }
}
const cr = [
    { propType: 6 },
    { propType: 3 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 17 },
    { propType: 6 },
    { propType: 5 },
  ],
  _r = ee.getSeriesSize(cr);
class dr extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  subscribe(t) {
    const e = h(t);
    return this.socket.sendCommand(7, e, !1);
  }
  on(t) {
    let e = this.map.get(t);
    e || ((e = this.onTicks.bind(this, t)), this.map.set(t, e)),
      this.socket.on(8, e);
  }
  off(t) {
    const e = this.map.get(t);
    e && this.socket.off(8, e);
  }
  onTicks(t, e) {
    t(
      (function (t) {
        const e = [],
          i = Math.floor(t.byteLength / _r);
        for (let r = 0; r < i; r++) e.push(L(t, r * _r));
        return e;
      })(e.resBody)
    );
  }
}
const hr = {
    BID_LAST: BigInt("0x0000000000000001"),
    BID_HIGH: BigInt("0x0000000000000002"),
    BID_LOW: BigInt("0x0000000000000004"),
    ASK_LAST: BigInt("0x0000000000000008"),
    ASK_HIGH: BigInt("0x0000000000000010"),
    ASK_LOW: BigInt("0x0000000000000020"),
    LAST_LAST: BigInt("0x0000000000000040"),
    LAST_HIGH: BigInt("0x0000000000000080"),
    LAST_LOW: BigInt("0x0000000000000100"),
    VOL_LAST: BigInt("0x0000000000000200"),
    VOL_HIGH: BigInt("0x0000000000000400"),
    VOL_LOW: BigInt("0x0000000000000800"),
    TRADE_BUY_VOLUME: BigInt("0x0000000000001000"),
    TRADE_SELL_VOLUME: BigInt("0x0000000000002000"),
    TRADE_BUY_ORDERS: BigInt("0x0000000000004000"),
    TRADE_SELL_ORDERS: BigInt("0x0000000000008000"),
    TRADE_DEALS: BigInt("0x0000000000010000"),
    TRADE_VOLUME: BigInt("0x0000000000020000"),
    TRADE_TURNOVER: BigInt("0x0000000000040000"),
    TRADE_INTEREST: BigInt("0x0000000000080000"),
    PRICE_OPEN: BigInt("0x0000000000100000"),
    PRICE_CLOSE: BigInt("0x0000000000200000"),
    PRICE_AW: BigInt("0x0000000000400000"),
    PRICE_CHANGE: BigInt("0x0000000000800000"),
    PRICE_VOLATILITY: BigInt("0x0000000001000000"),
    PRICE_THEORETICAL: BigInt("0x0000000002000000"),
    MSC: BigInt("0x0000000004000000"),
    PRICE_CHANGE_SIGNED: BigInt("0x0000000008000000"),
    VOL_LAST_FRACT: BigInt("0x0000000010000000"),
    VOL_HIGH_FRACT: BigInt("0x0000000020000000"),
    VOL_LOW_FRACT: BigInt("0x0000000040000000"),
    TRADE_BUY_VOLUME_FRACT: BigInt("0x0000000080000000"),
    TRADE_SELL_VOLUME_FRACT: BigInt("0x0000000100000000"),
    TRADE_VOLUME_FRACT: BigInt("0x0000000200000000"),
    PRICE_DELTA: BigInt("0x0000000400000000"),
    PRICE_THETA: BigInt("0x0000000800000000"),
    PRICE_GAMMA: BigInt("0x0000001000000000"),
    PRICE_VEGA: BigInt("0x0000002000000000"),
    PRICE_RHO: BigInt("0x0000004000000000"),
    PRICE_OMEGA: BigInt("0x0000008000000000"),
    PRICE_SENSITIVITY: BigInt("0x0000010000000000"),
  },
  pr = 0,
  ur = 1,
  mr = 2;
class gr {
  constructor(t) {
    (this.tick_time = 0),
      (this.tick_time_ms = 0),
      (this.m_direction_up = BigInt(0)),
      (this.m_direction_down = BigInt(0)),
      (this.id = t.id),
      (this.trade_symbol = t.trade_symbol),
      (this.digits = t.digits),
      (this.high = t.high),
      (this.low = t.low),
      (this.bid = t.bid),
      (this.ask = t.ask),
      (this.last_last = t.last_last),
      (this.vol_last = t.vol_last),
      (this.delayed = t.delayed ?? !1);
  }
  setTrend(t, e) {
    switch (e) {
      case pr:
        (this.m_direction_up |= t), (this.m_direction_down &= ~t);
        break;
      case ur:
        (this.m_direction_down |= t), (this.m_direction_up &= ~t);
        break;
      default:
        (this.m_direction_up &= ~t), (this.m_direction_down &= ~t);
    }
  }
  getTrend(t) {
    return this.m_direction_up & t ? pr : this.m_direction_down & t ? ur : mr;
  }
}
class yr {
  constructor() {
    (this.ticks = new Map()),
      (this.delayedTicks = new Map()),
      (this.selected = new Set()),
      (this.tradeList = new Set()),
      (this.history = new Map()),
      (this.delayedHistory = new Map());
  }
  setTradeList(t) {
    this.tradeList.clear(), t.forEach((t) => this.tradeList.add(t));
  }
  getTradeList() {
    return [...this.tradeList];
  }
  signed(t) {
    return Boolean(this.selected.has(t));
  }
  setSelect(t, e) {
    e ? this.selected.add(t) : this.selected.delete(t);
  }
  getAllSelected() {
    return [...this.selected];
  }
  clear() {
    this.ticks.clear(),
      this.delayedTicks.clear(),
      this.history.clear(),
      this.selected.clear();
  }
  get(t, e) {
    return e ? this.delayedTicks.get(t) : this.ticks.get(t);
  }
  last(t, e = !1) {
    return e ? this.delayedHistory.get(t) : this.history.get(t);
  }
  getTickByConfig(t, e = !1) {
    let i;
    return (
      (i = e
        ? this.delayedTicks.get(t.trade_symbol)
        : this.ticks.get(t.trade_symbol)),
      i ||
        ((i = new gr({
          trade_symbol: t.trade_symbol,
          digits: t.digits,
          id: t.symbol_id,
          high: 0,
          low: 0,
          bid: 0,
          ask: 0,
          last_last: 0,
          vol_last: BigInt(0),
          delayed: e,
        })),
        e
          ? this.delayedTicks.set(t.trade_symbol, i)
          : this.ticks.set(t.trade_symbol, i)),
      i
    );
  }
  setTick(t, e = !1) {
    e
      ? this.delayedTicks.set(t.trade_symbol, t)
      : this.ticks.set(t.trade_symbol, t);
  }
  getHistoryByConfig(t, e = !1) {
    let i;
    return (
      (i = e ? this.delayedHistory.get(t) : this.history.get(t)),
      i ||
        ((i = new Set()),
        e ? this.delayedHistory.set(t, i) : this.history.set(t, i)),
      i
    );
  }
}
class fr {
  constructor(t, e, i, r, s) {
    (this.timeout = 0),
      (this.listeners = new Map()),
      (this.ticksStorage = new yr()),
      (this.emitter = t),
      (this.ticksApi = e),
      (this.statsApi = i),
      (this.symbolsController = r),
      (this.spreadController = s),
      (this.onTicks = this.onTicks.bind(this)),
      (this.onStats = this.onStats.bind(this)),
      (this.sendSelected = this.sendSelected.bind(this)),
      this.ticksApi.on(this.onTicks),
      this.statsApi.on(this.onStats);
  }
  setTradeList(t = []) {
    this.ticksStorage.setTradeList(t), this.spreadController.loadSpreads(t);
  }
  destroy() {
    this.ticksApi.off(this.onTicks),
      this.statsApi.off(this.onStats),
      this.ticksStorage.clear(),
      this.listeners.clear();
  }
  sign(t) {
    t &&
      this.symbolsController.getSymbolByName(t) &&
      (this.ticksStorage.signed(t) ||
        (this.ticksStorage.setSelect(t, !0),
        clearTimeout(this.timeout),
        (this.timeout = window.setTimeout(this.sendSelected, 500))));
  }
  unSign(t) {
    t &&
      this.ticksStorage.signed(t) &&
      (this.ticksStorage.setSelect(t, !1),
      clearTimeout(this.timeout),
      (this.timeout = window.setTimeout(this.sendSelected, 500)));
  }
  sendSelected() {
    const t = new Set(),
      e = new Set();
    [
      ...this.ticksStorage.getAllSelected(),
      ...this.ticksStorage.getTradeList(),
    ].forEach((i) => {
      const r = this.symbolsController.getSymbolByName(i);
      r && (t.add(r.symbol_id), r instanceof Vi || e.add(r.symbol_id));
    });
    const i = [...t],
      r = [...e];
    this.ticksApi.subscribe(i), this.symbolsController.loadConfig(r);
  }
  onTicks(t) {
    this.applyTicks(t);
  }
  onStats(t) {
    this.applyStats(t);
  }
  applyTicks(t) {
    t &&
      t.forEach((t) => {
        const e = Boolean(512 & t.flags),
          i = t.symbol_id,
          r = this.symbolsController.getSymbolById(i);
        if (!r) return;
        const s = this.ticksStorage.getTickByConfig(r, e);
        if (!s) return;
        const o = r.digits,
          a = t.fields;
        if (
          s.lasttime_bidask &&
          t.tick_time_ms < s.lasttime_bidask &&
          (1 & a || 2 & a)
        )
          return;
        if (s.lasttime_last && t.tick_time_ms < s.lasttime_last && 4 & a)
          return;
        if (
          ((s.tick_time = t.tick_time),
          (s.tick_time_ms = t.tick_time_ms),
          (s.is_state = !1),
          null == s.fields && (s.fields = 0),
          (s.fields = M(s.fields, 1, !1)),
          (s.fields = M(s.fields, 2, !1)),
          (s.fields = M(s.fields, 4, !1)),
          (s.fields = M(s.fields, 8, !1)),
          1 & a && 0 !== t.bid)
        ) {
          const e = pe(t.bid, o);
          (r instanceof Vi && r.isChartByLast()) ||
            s.setTrend(hr.LAST_LAST, $(e, s.bid_src)),
            r instanceof Vi &&
              s.price_close &&
              (s.price_change =
                ((n = s.bid), (l = s.price_close), oe(((n - l) / l) * 100, 2))),
            s.setTrend(hr.BID_LAST, $(e, s.bid_src)),
            (s.bid_src = e),
            (s.lasttime_bidask = t.tick_time_ms),
            (s.fields = M(s.fields, 1, !0));
        }
        var n, l;
        if (2 & a && 0 !== t.ask) {
          const e = pe(t.ask, o);
          (r instanceof Vi && r.isChartByLast()) ||
            s.setTrend(hr.LAST_LAST, $(e, s.ask_src)),
            s.setTrend(hr.ASK_LAST, $(e, s.ask_src)),
            (s.ask_src = e),
            (s.lasttime_bidask = t.tick_time_ms),
            (s.fields = M(s.fields, 2, !0));
        }
        if (4 & a && 0 !== t.last) {
          const e = pe(t.last, o);
          s.setTrend(hr.LAST_LAST, $(e, s.last_last)),
            (s.last_last = e),
            (s.lasttime_last = t.tick_time_ms),
            (s.fields = M(s.fields, 4, !0));
        }
        if (8 & a) {
          const e = t.tick_volume;
          s.setTrend(hr.VOL_LAST, x(e, s.vol_last)),
            (s.vol_last = e),
            (s.fields = M(s.fields, 8, !0));
        }
        if (
          ((s.bid = (null == s ? void 0 : s.bid_src) ?? s.bid),
          (s.ask = (null == s ? void 0 : s.ask_src) ?? s.ask),
          (s.last = (null == s ? void 0 : s.last_last) ?? s.last),
          r instanceof Vi && r.trade.spread_diff)
        ) {
          const { trade: t } = r,
            e = I(
              t.spread_diff,
              t.spread_diff_balance,
              r.point || 0,
              r.digits,
              s.bid,
              s.ask
            );
          if (!e.result) return;
          (s.bid = e.bid), (s.ask = e.ask);
        }
        (s.bid_last = s.bid), (s.ask_last = s.ask);
        const c = this.ticksStorage.getHistoryByConfig(r.trade_symbol, e);
        if (
          c &&
          (c.add({ bid: s.bid_last, ask: s.ask_last, last: s.last_last }),
          c.size > 125)
        ) {
          const t = c.values().next();
          t.done || c.delete(t.value);
        }
        this.ticksStorage.setTick(s, e),
          this.trigger(r.trade_symbol, s),
          this.emitter.trigger(0, { symbol: r.trade_symbol, delayed: e });
      });
  }
  applyStats(t) {
    t &&
      t.forEach((t) => {
        const e = t.symbol_id,
          i = Boolean(1 & t.flags),
          r = this.symbolsController.getSymbolById(e);
        if (!(r && r instanceof Vi)) return;
        const s = this.ticksStorage.getTickByConfig(r, i),
          { digits: o } = s,
          { trade: a } = r,
          n = t.fields;
        (s.fields = 0),
          (s.tick_time = s.tick_time
            ? Math.max(t.lasttime, s.tick_time)
            : t.lasttime);
        const l = t.lasttime + Number(t.lasttime_msc);
        if (
          ((s.tick_time_ms = s.tick_time_ms ? Math.max(l, s.tick_time_ms) : l),
          (s.is_state = !0),
          (s.has_stat = !0),
          n & hr.BID_LAST)
        ) {
          const e = pe(t.bid_last, o);
          s.setTrend(hr.BID_LAST, $(e, s.bid_last)),
            (s.bid_last = e),
            (s.bid_src = e),
            (s.bid = e),
            (s.fields |= 1);
        }
        if (n & hr.BID_HIGH) {
          const e = pe(t.bid_high, o);
          s.setTrend(hr.BID_HIGH, $(e, s.bid_high)),
            (s.bid_high = e),
            a &&
              a.spread_diff &&
              ((s.bid_high = R(
                a.spread_diff,
                a.spread_diff_balance,
                r.point || 0,
                r.digits,
                s.bid_high
              )),
              s.bid_high <= 0 && (s.bid_high = e));
        }
        if (n & hr.BID_LOW) {
          const e = pe(t.bid_low, o);
          s.setTrend(hr.BID_LOW, $(e, s.bid_low)),
            (s.bid_low = e),
            a &&
              a.spread_diff &&
              ((s.bid_low = R(
                a.spread_diff,
                a.spread_diff_balance,
                r.point || 0,
                r.digits,
                s.bid_low
              )),
              s.bid_low <= 0 && (s.bid_low = e));
        }
        if (n & hr.ASK_LAST) {
          const e = pe(t.ask_last, o);
          s.setTrend(hr.ASK_LAST, $(e, s.ask_last)),
            (s.ask_last = e),
            (s.ask_src = e),
            (s.ask = e),
            (s.fields |= 2);
        }
        if (n & hr.ASK_HIGH) {
          const e = pe(t.ask_high, o);
          s.setTrend(hr.ASK_HIGH, $(e, s.ask_high)),
            (s.ask_high = e),
            a &&
              a.spread_diff &&
              ((s.ask_high = A(
                a.spread_diff,
                a.spread_diff_balance,
                r.point || 0,
                r.digits,
                s.ask_high
              )),
              s.ask_high <= 0 && (s.ask_high = e));
        }
        if (n & hr.ASK_LOW) {
          const e = pe(t.ask_low, o);
          s.setTrend(hr.ASK_LOW, $(e, s.ask_low)),
            (s.ask_low = e),
            a &&
              a.spread_diff &&
              ((s.ask_low = A(
                a.spread_diff,
                a.spread_diff_balance,
                r.point || 0,
                r.digits,
                s.ask_low
              )),
              s.ask_low <= 0 && (s.ask_low = e));
        }
        if (n & hr.LAST_LAST) {
          const e = pe(t.last_last, o);
          s.setTrend(hr.LAST_LAST, $(e, s.last_last)),
            (s.last_last = e),
            (s.fields |= 4);
        }
        if (n & hr.LAST_HIGH) {
          const e = pe(t.last_high, o);
          s.setTrend(hr.LAST_HIGH, $(e, s.last_high)), (s.last_high = e);
        }
        if (n & hr.LAST_LOW) {
          const e = pe(t.last_low, o);
          s.setTrend(hr.LAST_LOW, $(e, s.last_low)), (s.last_low = e);
        }
        if (
          (n & hr.VOL_LAST &&
            (s.setTrend(hr.VOL_LAST, x(t.vol_last, s.vol_last)),
            (s.vol_last = t.vol_last),
            (s.fields |= 8)),
          n & hr.VOL_HIGH &&
            (s.setTrend(hr.VOL_HIGH, x(t.vol_high, s.vol_high)),
            (s.vol_high = t.vol_high)),
          n & hr.VOL_LOW &&
            (s.setTrend(hr.VOL_LOW, x(t.vol_low, s.vol_low)),
            (s.vol_low = t.vol_low)),
          n & hr.TRADE_DEALS && (s.trade_deals = t.trade_deals),
          n & hr.TRADE_VOLUME && (s.trade_volume = t.trade_volume),
          n & hr.TRADE_TURNOVER && (s.trade_turnover = t.trade_turnover),
          n & hr.TRADE_INTEREST && (s.trade_interest = t.trade_interest),
          n & hr.TRADE_BUY_ORDERS &&
            (s.setTrend(
              hr.TRADE_BUY_ORDERS,
              $(t.trade_buy_orders, s.trade_buy_orders)
            ),
            (s.trade_buy_orders = t.trade_buy_orders)),
          n & hr.TRADE_BUY_VOLUME &&
            (s.setTrend(
              hr.TRADE_BUY_VOLUME,
              x(t.trade_buy_volume, s.trade_buy_volume)
            ),
            (s.trade_buy_volume = t.trade_buy_volume)),
          n & hr.TRADE_SELL_ORDERS &&
            (s.setTrend(
              hr.TRADE_SELL_ORDERS,
              $(t.trade_sell_orders, s.trade_sell_orders)
            ),
            (s.trade_sell_orders = t.trade_sell_orders)),
          n & hr.TRADE_SELL_VOLUME &&
            (s.setTrend(
              hr.TRADE_SELL_VOLUME,
              x(t.trade_sell_volume, s.trade_sell_volume)
            ),
            (s.trade_sell_volume = t.trade_sell_volume)),
          n & hr.PRICE_OPEN &&
            (s.setTrend(hr.PRICE_OPEN, mr),
            (s.price_open = pe(t.price_open, o))),
          n & hr.PRICE_CLOSE &&
            (s.setTrend(hr.PRICE_CLOSE, mr),
            (s.price_close = pe(t.price_close, o))),
          n & hr.PRICE_AW)
        ) {
          const e = pe(t.price_aw, o);
          s.setTrend(hr.PRICE_AW, $(e, s.price_aw)), (s.price_aw = e);
        }
        if (n & hr.PRICE_CHANGE) {
          s.price_change = pe(t.price_change, 2);
          const e = s.price_change < 0 ? ur : mr;
          s.setTrend(hr.PRICE_CHANGE, s.price_change > 0 ? pr : e);
        }
        if (n & hr.PRICE_VOLATILITY) {
          const e = pe(t.price_volatility, 3);
          s.setTrend(hr.PRICE_VOLATILITY, $(e, s.price_volatility)),
            (s.price_volatility = e);
        }
        if (n & hr.PRICE_THEORETICAL) {
          const e = pe(t.price_theoretical, o);
          s.setTrend(hr.PRICE_THEORETICAL, $(e, s.price_theoretical)),
            (s.price_theoretical = e);
        }
        if (n & hr.PRICE_DELTA) {
          const e = pe(Number(t.price_greeks_delta), 5);
          s.setTrend(hr.PRICE_DELTA, $(e, s.price_greeks_delta)),
            (s.price_greeks_delta = e);
        }
        if (n & hr.PRICE_THETA) {
          const e = pe(Number(t.price_greeks_theta), 5);
          s.setTrend(hr.PRICE_THETA, $(e, s.price_greeks_theta)),
            (s.price_greeks_theta = e);
        }
        if (n & hr.PRICE_GAMMA) {
          const e = pe(Number(t.price_greeks_gamma), 5);
          s.setTrend(hr.PRICE_GAMMA, $(e, s.price_greeks_gamma)),
            (s.price_greeks_gamma = e);
        }
        if (n & hr.PRICE_VEGA) {
          const e = pe(Number(t.price_greeks_vega), 5);
          s.setTrend(hr.PRICE_VEGA, $(e, s.price_greeks_vega)),
            (s.price_greeks_vega = e);
        }
        if (n & hr.PRICE_RHO) {
          const e = pe(Number(t.price_greeks_rho), 5);
          s.setTrend(hr.PRICE_RHO, $(e, s.price_greeks_rho)),
            (s.price_greeks_rho = e);
        }
        if (n & hr.PRICE_OMEGA) {
          const e = pe(Number(t.price_greeks_omega), 5);
          s.setTrend(hr.PRICE_OMEGA, $(e, s.price_greeks_omega)),
            (s.price_greeks_omega = e);
        }
        if (n & hr.PRICE_SENSITIVITY) {
          const e = pe(Number(t.price_sensitivity), 5);
          s.setTrend(hr.PRICE_SENSITIVITY, $(e, s.price_sensitivity)),
            (s.price_sensitivity = e);
        }
        if (
          s.bid_last &&
          s.ask_last &&
          (t.bid_last || t.ask_last) &&
          a &&
          a.spread_diff
        ) {
          (s.bid_last = s.bid_src), (s.ask_last = s.ask_src);
          const t = I(
            a.spread_diff,
            a.spread_diff_balance,
            r.point || 0,
            r.digits,
            s.bid_last,
            s.ask_last
          );
          t.result && ((s.bid_last = t.bid), (s.ask_last = t.ask));
        }
        this.ticksStorage.setTick(s, i),
          this.emitter.trigger(0, { symbol: r.trade_symbol, delayed: i });
      });
  }
  clear() {
    this.ticksStorage.clear();
  }
  on(t, e) {
    let i = this.listeners.get(t);
    i || ((i = new Set()), this.listeners.set(t, i)), i.add(e);
  }
  off(t, e) {
    if (this.listeners.has(t))
      if (void 0 === e) this.listeners.delete(t);
      else {
        const i = this.listeners.get(t);
        i ? i.delete(e) : this.listeners.delete(t);
      }
  }
  trigger(t, e) {
    const i = this.listeners.get(t);
    i && i.forEach((t) => t(e));
  }
  getTick(t, e) {
    return this.ticksStorage.get(t, e);
  }
  getLast(t) {
    this.ticksStorage.last(t);
  }
  getTicksHistory(t) {
    return this.ticksStorage.last(t);
  }
  isSigned(t) {
    return this.ticksStorage.signed(t);
  }
}
class br {
  constructor(t) {
    this.ticksController = t;
  }
  getTick(t, e) {
    const i = this.ticksController.getTick(t, e);
    return this.formatTick(i);
  }
  history(t) {
    const e = this.ticksController.getTicksHistory(t);
    if (!e) return null;
    const i = [];
    return (
      e.forEach((t) => {
        const e = this.formatTick(t);
        e && i.push(e);
      }),
      i
    );
  }
  subscribe(t) {
    this.ticksController.sign(t);
  }
  unSubscribe(t) {
    this.ticksController.unSign(t);
  }
  signed(t) {
    return this.ticksController.isSigned(t);
  }
  formatTick(t) {
    if (!t) return null;
    let e;
    if (t.tick_time_ms) e = t.tick_time_ms;
    else {
      const t = new Date();
      t.setUTCHours(0), t.setUTCMinutes(0, 0, 0), (e = t.getTime());
    }
    return {
      symbol: t.trade_symbol,
      time: t.tick_time,
      timeMs: e,
      change: t.price_change ?? 0,
      bid: t.bid ?? 0,
      bidTrend: P(t, hr.BID_LAST),
      bidLast: t.bid_last ?? 0,
      bidHigh: t.bid_high ?? 0,
      bidHighTrend: P(t, hr.BID_HIGH),
      bidLow: t.bid_low ?? 0,
      bidLowTrend: P(t, hr.BID_LOW),
      bidOriginal: t.bid_src ?? 0,
      ask: t.ask ?? 0,
      askTrend: P(t, hr.ASK_LAST),
      askLast: t.ask_last ?? 0,
      askHigh: t.ask_high ?? 0,
      askHighTrend: P(t, hr.ASK_HIGH),
      askLow: t.ask_low ?? 0,
      askLowTrend: P(t, hr.ASK_LOW),
      askOriginal: t.ask_src ?? 0,
      last: t.last ?? 0,
      lastLast: t.last_last || 0,
      lastHigh: t.last_high || 0,
      lastLow: t.last_low || 0,
      lastTrend: P(t, hr.LAST_LAST),
      volume: f(t.vol_last),
      volumeTrend: P(t, hr.VOL_LAST),
      spread: z(t),
      fields: t.fields || 0,
      volLast: f(t.vol_last),
      delayed: t.delayed,
      priceOpen: t.price_open ?? 0,
      priceClose: t.price_close ?? 0,
      low: t.low ?? 0,
      high: t.high ?? 0,
    };
  }
}
class vr {
  constructor(t, e, i, r) {
    (this.controller = new fr(t, new dr(e), new lr(e), i, r)),
      (this.view = new br(this.controller));
  }
}
class Tr {
  constructor(t, e) {
    (this.map = new Map()),
      (this.bad = new Map()),
      (this.ticksController = e),
      (this.symbolsController = t);
  }
  marginSymbol(t) {
    const e = this.symbolsController.getSymbolByName(t);
    if (e) {
      const i = this.symbolsController.getFullSymbolByName(t);
      return i || this.symbolsController.loadConfig([e.symbol_id]), i;
    }
    return null;
  }
  clearAll() {
    this.map.clear(), this.bad.clear();
  }
  rateBuy(t, e, i, r) {
    if (!e || !i) return 0;
    if (this.checkSynonym(e, i)) return 1;
    const s = this.findBuy(e, i, t, r);
    if (s) return s;
    const o = this.findBuy(e, "USD", t, r),
      a = this.findBuy("USD", i, t, r);
    return o && a ? a * o : 0;
  }
  rateSell(t, e, i, r) {
    if (!e || !i) return 0;
    if (this.checkSynonym(e, i)) return 1;
    const s = this.findSell(e, i, t, r);
    if (s) return s;
    const o = this.findSell(e, "USD", t, r),
      a = this.findSell("USD", i, t, r);
    return o && a ? a * o : 0;
  }
  rateBuyMargin(t, e, i) {
    const r = t.currency_margin;
    if (!r || !e) return 0;
    if (this.checkSynonym(r, e)) return 1;
    const s = this.findBuyMargin(r, e, t, i);
    if (s) return s;
    const o = this.findBuyMargin(r, "USD", t, i),
      a = this.findBuyMargin("USD", e, t, i);
    return o && a ? a * o : 0;
  }
  rateSellMargin(t, e, i) {
    const r = t.currency_margin;
    if (!r || !e) return 0;
    if (this.checkSynonym(r, e)) return 1;
    const s = this.findSellMargin(r, e, t, i);
    if (s) return s;
    const o = this.findSellMargin(r, "USD", t, i),
      a = this.findSellMargin("USD", e, t, i);
    return o && a ? a * o : 0;
  }
  checkSynonym(t, e) {
    if (t === e) return !0;
    const i = [["RUB", "RUR"]];
    for (let r = 0, s = i.length; r < s; r++) {
      const s = i[r];
      if (s && -1 !== s.indexOf(t) && -1 !== s.indexOf(e)) return !0;
    }
    return !1;
  }
  findBuy(t, e, i, r) {
    let s = this.formSymbol(t, e, i),
      o = s.symbol_name,
      a = s.full_name;
    if (
      i &&
      r &&
      i.isForex() &&
      !(i.trade_flags & Ae.PROFIT_BY_MARKET) &&
      o === i.trade_symbol
    )
      return r;
    const n = this.findPrice(o, 1, a);
    if (n > 0) return n;
    if (
      ((s = this.formSymbol(e, t, i)),
      (o = s.symbol_name),
      (a = s.full_name),
      i &&
        r &&
        i.isForex() &&
        !(i.trade_flags & Ae.PROFIT_BY_MARKET) &&
        o === i.trade_symbol)
    )
      return 1 / r;
    const l = this.findPrice(o, 0, a);
    return l > 0 ? 1 / l : 0;
  }
  findSell(t, e, i, r) {
    let s = this.formSymbol(t, e, i),
      o = s.symbol_name,
      a = s.full_name;
    if (
      i &&
      r &&
      i.isForex() &&
      !(i.trade_flags & Ae.PROFIT_BY_MARKET) &&
      o === i.trade_symbol
    )
      return r;
    const n = this.findPrice(o, 0, a);
    if (n > 0) return n;
    if (
      ((s = this.formSymbol(e, t, i)),
      (o = s.symbol_name),
      (a = s.full_name),
      i &&
        r &&
        i.isForex() &&
        !(i.trade_flags & Ae.PROFIT_BY_MARKET) &&
        o === i.trade_symbol)
    )
      return 1 / r;
    const l = this.findPrice(o, 1, a);
    return l > 0 ? 1 / l : 0;
  }
  findBuyMargin(t, e, i, r) {
    let s = this.formSymbol(t, e, i),
      o = s.symbol_name,
      a = s.full_name;
    if (r && i.isForex() && o === i.trade_symbol) return r;
    const n = this.findPrice(o, 1, a);
    if (n > 0) return n;
    if (
      ((s = this.formSymbol(e, t, i)),
      (o = s.symbol_name),
      (a = s.full_name),
      r && i.isForex() && o === i.trade_symbol)
    )
      return 1 / r;
    const l = this.findPrice(o, 0, a);
    return l > 0 ? 1 / l : 0;
  }
  findSellMargin(t, e, i, r) {
    let s = this.formSymbol(t, e, i),
      o = s.symbol_name,
      a = s.full_name;
    if (r && i.isForex() && o === i.trade_symbol) return r;
    const n = this.findPrice(o, 0, a);
    if (n > 0) return n;
    if (
      ((s = this.formSymbol(e, t, i)),
      (o = s.symbol_name),
      (a = s.full_name),
      r && i.isForex() && o === i.trade_symbol)
    )
      return 1 / r;
    const l = this.findPrice(o, 1, a);
    return l > 0 ? 1 / l : 0;
  }
  findName(t) {
    const e = this.map.get(t);
    if (e) return e;
    if (this.bad.has(t)) return null;
    const i = this.symbolsController
      .getAllSymbolsByName()
      .filter((e) => this.filterSymbols(t, e));
    if (i && i.length) {
      const e = i[0].trade_symbol;
      return this.map.set(t, e), e;
    }
    return this.bad.set(t, !0), null;
  }
  findPrice(t, e, i = !1) {
    if (i) {
      const i = this.findPriceExact(t, e);
      if (i > 0) return i;
    }
    const r = this.findName(t);
    return r ? this.findPriceExact(r, e) : 0;
  }
  findPrices(t, e = !1) {
    if (e) {
      const e = this.findPricesExact(t);
      if (e.ask > 0 || e.bid > 0 || e.last > 0) return e;
    }
    const i = this.findName(t);
    return i ? this.findPricesExact(i) : { ask: 0, bid: 0, last: 0 };
  }
  findPriceExact(t, e) {
    const i = this.symbolsController.getSymbolByName(t);
    if (!i) return 0;
    const r = this.symbolsController.getFullSymbolByName(t);
    if (!r) return this.symbolsController.loadConfig([i.symbol_id]), 0;
    if (r.isForex()) {
      const i = this.ticksController.getTick(t, !1);
      if (i) {
        if (1 === e) return i.ask;
        if (0 === e) return i.bid;
        if (2 === e) return i.last_last;
      }
    }
    return this.ticksController.sign(t), 0;
  }
  findPricesExact(t) {
    const e = this.symbolsController.getSymbolByName(t);
    if (!e) return { ask: 0, bid: 0, last: 0 };
    const i = this.symbolsController.getFullSymbolByName(t);
    if (!i)
      return (
        this.symbolsController.loadConfig([e.symbol_id]),
        { ask: 0, bid: 0, last: 0 }
      );
    if (i.isForex()) {
      const e = this.ticksController.getTick(t, !1);
      if (e) return { ask: e.ask, bid: e.bid, last: e.last_last };
    }
    return this.ticksController.sign(t), { ask: 0, bid: 0, last: 0 };
  }
  formSymbol(t, e, i) {
    let r = "",
      s = !1;
    return (
      t &&
        e &&
        i &&
        ((r += t.substring(0, 3)),
        (r += e.substring(0, 3)),
        i &&
          i.isForex() &&
          ((s = !0),
          i.trade_symbol.length > 6 && (r += i.trade_symbol.substring(6)))),
      { symbol_name: r, full_name: s }
    );
  }
  filterSymbols(t, e) {
    return 0 === e.trade_symbol.indexOf(t.substring(0, 6));
  }
}
class Sr {
  constructor(t, e) {
    this.controller = new Tr(t, e);
  }
}
class kr {
  constructor() {
    (this.trade_order = BigInt(0)),
      (this.order_id = ""),
      (this.trade_symbol = ""),
      (this.time_setup = 0),
      (this.time_expiration = 0),
      (this.time_done = 0),
      (this.order_type = 0),
      (this.type_filling = 0),
      (this.type_time = 0),
      (this.type_reason = 0),
      (this.price_order = 0),
      (this.price_trigger = 0),
      (this.price_current = 0),
      (this.price_sl = 0),
      (this.price_tp = 0),
      (this.volume_initial = BigInt(0)),
      (this.volume_current = BigInt(0)),
      (this.order_state = 0),
      (this.expert = BigInt(0)),
      (this.position_id = BigInt(0)),
      (this.comment = ""),
      (this.contract_size = 0),
      (this.digits = 0),
      (this.digits_currency = 0),
      (this.commission_daily = 0),
      (this.commission_monthly = 0),
      (this.margin_rate = 0),
      (this.activation_mode = 0);
  }
  copy() {
    const t = new kr();
    return (
      (t.trade_order = this.trade_order),
      (t.order_id = this.order_id),
      (t.trade_symbol = this.trade_symbol),
      (t.time_setup = this.time_setup),
      (t.time_expiration = this.time_expiration),
      (t.time_done = this.time_done),
      (t.order_type = this.order_type),
      (t.type_filling = this.type_filling),
      (t.type_time = this.type_time),
      (t.type_reason = this.type_reason),
      (t.price_order = this.price_order),
      (t.price_trigger = this.price_trigger),
      (t.price_current = this.price_current),
      (t.price_sl = this.price_sl),
      (t.price_tp = this.price_tp),
      (t.volume_initial = this.volume_initial),
      (t.volume_current = this.volume_current),
      (t.order_state = this.order_state),
      (t.expert = this.expert),
      (t.position_id = this.position_id),
      (t.comment = this.comment),
      (t.contract_size = this.contract_size),
      (t.digits = this.digits),
      (t.digits_currency = this.digits_currency),
      (t.commission_daily = this.commission_daily),
      (t.commission_monthly = this.commission_monthly),
      (t.margin_rate = this.margin_rate),
      (t.activation_mode = this.activation_mode),
      t
    );
  }
  isBuy() {
    return ue(this.order_type);
  }
  isSell() {
    return me(this.order_type);
  }
  isMarket() {
    return ge(this.order_type);
  }
  isPending() {
    return ye(this.order_type);
  }
  isLimit() {
    return fe(this.order_type);
  }
  isStop() {
    return be(this.order_type);
  }
  isStopLimit() {
    return ve(this.order_type);
  }
  isMarketPrice() {
    return this.isMarket() && !this.price_order;
  }
  isCloseBy() {
    return 8 === this.order_type;
  }
  isClose() {
    return Boolean(this.isMarket() && this.position_id);
  }
}
class Cr {
  constructor(t, e) {
    (this.account = t), (this.prices = e);
  }
  isFloatingMarginOrder() {
    return !1;
  }
  calcTickManager(t, e) {
    return this.calcTick(t, e);
  }
}
class Er {
  constructor(t, e, i, r) {
    (this.equity_floating = 0),
      (this.margins_exchange = t),
      (this.margins_moex = e),
      (this.margins_option = i),
      (this.margins_retail = r);
  }
  clear() {
    this.margins_exchange.clear(),
      this.margins_moex.clear(),
      this.margins_option.clear(),
      this.margins_retail.clear(),
      delete this.new_order,
      delete this.new_position,
      (this.equity_floating = 0);
  }
}
const Br = 0,
  wr = 1,
  Lr = 2,
  Or = 3;
class Ir {
  constructor(t, e) {
    (this.symbols = []),
      (this.account = t),
      (this.rule = e),
      (this.symbols = []);
  }
  clear() {
    this.symbols = [];
  }
  add(t) {
    return !(
      (this.rule && !Hi.check(this.rule.path, t.path())) ||
      (t.setLeverageRule(this.rule), this.symbols.push(t), 0)
    );
  }
  calc() {
    if (this.rule && this.rule.tiers.length)
      switch (this.rule.range_mode) {
        case Br:
          return this.calcLeverageVolume(this.rule);
        case wr:
          return this.calcLeverageVolumeSymbol(this.rule);
        case Lr:
          return this.calcLeverageValue(this.rule);
        case Or:
          return this.calcLeverageValueSymbol(this.rule);
        default:
          return 0;
      }
    const t = this.account.currency_digits;
    return this.symbols.reduce((e, i) => {
      const r = i.calc();
      return oe(e + r, t);
    }, 0);
  }
  calcLeverageVolume(t) {
    const { account: e } = this;
    let i,
      r,
      s = 0,
      o = 0,
      a = 0;
    this.symbols.forEach((t) => {
      t.calc(),
        (i = Yi.toDouble(t.leveragePositionsVolume())),
        (o += i),
        (a += t.leveragePositionsMargin()),
        t.leverageCalcVolume(i);
    }),
      o &&
        a &&
        ((r = this.calcLeverageSymbols(t, 0, 0, o, a, !1, e.currency_digits)),
        (s += oe(s + r, e.currency_digits)));
    let n = 0,
      l = 0;
    this.symbols.forEach((t) => {
      (i = Yi.toDouble(t.leveragePositionsOrderVolume())),
        (n += i),
        (l += t.leveragePositionsOrderMargin()),
        t.leverageCalcVolume(i);
    }),
      n &&
        l &&
        ((r = this.calcLeverageSymbols(t, 0, 0, n, l, !0, e.currency_digits)),
        (s = oe(s + r, e.currency_digits)));
    let c = 0,
      _ = 0;
    return (
      this.symbols.forEach((t) => {
        (i = Yi.toDouble(t.leverageOrdersVolume())),
          (c += i),
          (_ += t.leverageOrdersMargin()),
          t.leverageCalcVolume(i);
      }),
      c &&
        _ &&
        ((r = this.calcLeverageSymbols(t, 0, 0, c, _, !0, e.currency_digits)),
        (s = oe(s + r, e.currency_digits))),
      s
    );
  }
  calcLeverageVolumeSymbol(t) {
    const { account: e } = this;
    let i,
      r = 0;
    return (
      this.symbols.forEach((s) => {
        s.calc(),
          s.leveragePositionsVolume() &&
            s.leveragePositionsMargin() &&
            ((i = D(
              t,
              0,
              0,
              Yi.toDouble(s.leveragePositionsVolume()),
              s.leveragePositionsMargin(),
              !1,
              e.currency_digits
            )),
            (r = oe(r + i, e.currency_digits))),
          s.leveragePositionsOrderVolume() &&
            s.leveragePositionsOrderMargin() &&
            ((i = D(
              t,
              0,
              0,
              Yi.toDouble(s.leveragePositionsOrderVolume()),
              s.leveragePositionsOrderMargin(),
              !0,
              e.currency_digits
            )),
            (r = oe(r + i, e.currency_digits))),
          s.leverageOrdersVolume() &&
            s.leverageOrdersMargin() &&
            ((i = D(
              t,
              0,
              0,
              Yi.toDouble(s.leverageOrdersVolume()),
              s.leverageOrdersMargin(),
              !0,
              e.currency_digits
            )),
            (r = oe(r + i, e.currency_digits)));
      }),
      r
    );
  }
  calcLeverageValue(t) {
    const { account: e } = this;
    let i,
      r,
      s = 0,
      o = 0,
      a = 0;
    this.symbols.forEach((t) => {
      t.calc(),
        (i = t.leveragePositionsValue()),
        (o += i),
        (a += t.leveragePositionsMargin()),
        t.leverageCalcVolume(i);
    }),
      o &&
        a &&
        ((r = this.calcLeverageSymbols(t, 0, 0, o, a, !1, e.currency_digits)),
        (s = oe(s + r, e.currency_digits)));
    let n = 0,
      l = 0;
    this.symbols.forEach((t) => {
      (i = t.leveragePositionsOrderValue()),
        (n += i),
        (l += t.leveragePositionsOrderMargin()),
        t.leverageCalcVolume(i);
    }),
      n &&
        l &&
        ((r = this.calcLeverageSymbols(t, 0, 0, n, l, !0, e.currency_digits)),
        (s = oe(s + r, e.currency_digits)));
    let c = 0,
      _ = 0;
    return (
      this.symbols.forEach((t) => {
        (i = t.leverageOrdersValue()),
          (c += i),
          (_ += t.leverageOrdersMargin()),
          t.leverageCalcVolume(i);
      }),
      c &&
        _ &&
        ((r = this.calcLeverageSymbols(t, 0, 0, c, _, !0, e.currency_digits)),
        (s = oe(s + r, e.currency_digits))),
      s
    );
  }
  calcLeverageValueSymbol(t) {
    const { account: e } = this;
    let i,
      r = 0;
    return (
      this.symbols.forEach((s) => {
        s.calc(),
          s.leveragePositionsValue() &&
            s.leveragePositionsMargin() &&
            ((i = D(
              t,
              0,
              0,
              s.leveragePositionsValue(),
              s.leveragePositionsMargin(),
              !1,
              e.currency_digits
            )),
            (r = oe(r + i, e.currency_digits))),
          s.leveragePositionsOrderValue() &&
            s.leveragePositionsOrderMargin() &&
            ((i = D(
              t,
              0,
              0,
              s.leveragePositionsOrderValue(),
              s.leveragePositionsOrderMargin(),
              !0,
              e.currency_digits
            )),
            (r = oe(r + i, e.currency_digits))),
          s.leverageOrdersValue() &&
            s.leverageOrdersMargin() &&
            ((i = D(
              t,
              0,
              0,
              s.leverageOrdersValue(),
              s.leverageOrdersMargin(),
              !0,
              e.currency_digits
            )),
            (r = oe(r + i, e.currency_digits)));
      }),
      r
    );
  }
  calcLeverageSymbols(t, e, i, r, s, o, a) {
    this.symbols.forEach((t) => {
      if (t.leverageCalcVolume()) {
        const e = t.leverageCalcVolume() / r;
        t.leverageCalcRateSymbol(e);
      } else t.leverageCalcRateSymbol(0);
    });
    let n = r,
      l = 0;
    for (let c = 0; c < t.tiers.length; c++) {
      const e = t.tiers[c];
      if (e.range_to === ce || e.range_from === ce) break;
      let _ = e.range_to - e.range_from;
      if (_ > 0) {
        i && (_ = Math.min(i, _)), n < _ ? ((i = _ - n), (_ = n)) : (i = 0);
        const t = s * (_ / r);
        if (
          (this.symbols.forEach((i) => {
            if (i.leverageCalcRateSymbol()) {
              const r =
                t *
                i.leverageCalcRateSymbol() *
                (o ? e.margin_rate_initial : e.margin_rate_maintenance);
              l = oe(l + r, a);
            }
          }),
          _ >= n)
        ) {
          n = 0;
          break;
        }
        n -= _;
      }
    }
    if (n) {
      const e = o
        ? t.tiers[t.tiers.length - 1].margin_rate_initial
        : t.tiers[t.tiers.length - 1].margin_rate_maintenance;
      l = oe(l + s * (n / r) * e, a);
    }
    return l;
  }
}
class Rr {
  constructor(t, e) {
    (this.margins = []),
      (this.marginsIndex = {}),
      (this.leverage_rules = []),
      (this.account = t),
      (this.prices = e),
      (this.leverage_default = new Ir(this.account));
  }
  at(t) {
    return this.margins[t];
  }
  forEach(t) {
    this.margins.forEach(t);
  }
  add(t) {
    this.margins.push(t), (this.marginsIndex[t.name()] = t);
  }
  getAll() {
    return [...this.margins];
  }
  getOrCreate(t) {
    if (t) return this.find(t) ?? this.createByName(t);
  }
  create(t) {
    const e = this.createEntity(t);
    return this.add(e), this.leverageRulesSymbol(e), e;
  }
  createByName(t) {
    const e = this.prices.marginSymbol(t);
    if (e) return this.create(e);
  }
  find(t) {
    return this.marginsIndex[t] ?? this.margins.find((e) => e.name() === t);
  }
  reset() {
    (this.margins = []),
      (this.marginsIndex = {}),
      (this.leverage_rules = []),
      this.leverage_default.clear();
  }
  clear() {
    this.reset();
  }
  total() {
    return this.margins.length;
  }
  calc() {
    let t = this.leverage_default.calc();
    for (let e = 0; e < this.leverage_rules.length; e++)
      t = oe(t + this.leverage_rules[e].calc(), this.account.currency_digits);
    return t;
  }
  leverageRulesBuild() {
    (this.leverage_rules = this.account.rules.map(
      (t) => new Ir(this.account, t)
    )),
      (this.leverage_default = new Ir(this.account));
  }
  leverageRulesSymbol(t) {
    !this.leverage_rules.length &&
      this.account.rules.length &&
      this.leverageRulesBuild();
    for (let e = 0; e < this.leverage_rules.length; e++)
      if (this.leverage_rules[e].add(t)) return;
    this.leverage_default.add(t);
  }
}
class Ar {
  constructor(t, e, i) {
    (this.leverage_positions_volume = 0n),
      (this.leverage_positions_order_volume = 0n),
      (this.leverage_positions_price = 0),
      (this.leverage_positions_value = 0),
      (this.leverage_positions_order_value = 0),
      (this.leverage_positions_margin = 0),
      (this.leverage_positions_order_margin = 0),
      (this.leverage_positions_margin_rate = 0),
      (this.leverage_orders_volume = 0n),
      (this.leverage_orders_price = 0),
      (this.leverage_orders_value = 0),
      (this.leverage_orders_margin = 0),
      (this.leverage_orders_margin_rate = 0),
      (this.leverage_calc_rate_symbol = 0),
      (this.leverage_calc_volume = 0),
      (this.account = t),
      (this.symbol = e),
      (this.prices = i);
  }
  name() {
    return this.symbol.trade_symbol;
  }
  path() {
    return this.symbol.symbol_path;
  }
  basis() {
    return this.symbol.basis;
  }
  id() {
    return this.symbol.symbol_id;
  }
  expiration() {
    return this.symbol.time_expiration;
  }
  orderRate(t, e) {
    return this.symbol.orderRate(t, e);
  }
  isCollateral() {
    return this.symbol.isCollateral();
  }
  isLargeLeg() {
    return this.symbol.isLargeLeg();
  }
  isFORTS() {
    return this.symbol.isFORTS();
  }
  isBond() {
    return this.symbol.isBond();
  }
  isMarginExcludePL() {
    return this.symbol.isMarginExcludePL();
  }
  isFloatingLeverage() {
    return Boolean(this.leverage_rule);
  }
  setLeverageRule(t) {
    this.leverage_rule = t;
  }
  leverageTotalVolume() {
    return (
      this.leverage_positions_volume +
      this.leverage_positions_order_volume +
      this.leverage_orders_volume
    );
  }
  leverageTotalMargin() {
    return (
      this.leverage_positions_margin +
      this.leverage_positions_order_margin +
      this.leverage_orders_margin
    );
  }
  everageTotalValue() {
    return (
      this.leveragePositionsValue() +
      this.leveragePositionsOrderValue() +
      this.leverageOrdersValue()
    );
  }
  leveragePositionsVolume() {
    return this.leverage_positions_volume;
  }
  leveragePositionsMargin() {
    return this.leverage_positions_margin;
  }
  leveragePositionsValue() {
    return (
      this.leverage_positions_value ||
        (this.leverage_positions_value = this.leverageCalcValue(
          this.leverage_positions_volume,
          this.leverage_positions_margin,
          this.leverage_positions_price,
          this.leverage_positions_margin_rate
        )),
      this.leverage_positions_value
    );
  }
  leveragePositionsOrderVolume() {
    return this.leverage_positions_order_volume;
  }
  leveragePositionsOrderMargin() {
    return this.leverage_positions_order_margin;
  }
  leveragePositionsOrderValue() {
    return (
      this.leverage_positions_order_value ||
        (this.leverage_positions_order_value = this.leverageCalcValue(
          this.leverage_positions_order_volume,
          this.leverage_positions_order_margin,
          this.leverage_positions_price,
          this.leverage_positions_margin_rate
        )),
      this.leverage_positions_order_value
    );
  }
  leverageOrdersVolume() {
    return this.leverage_orders_volume;
  }
  leverageOrdersMargin() {
    return this.leverage_orders_margin;
  }
  leverageOrdersValue() {
    return (
      this.leverage_orders_value ||
        (this.leverage_orders_value = this.leverageCalcValue(
          this.leverage_orders_volume,
          this.leverage_orders_margin,
          this.leverage_orders_price,
          this.leverage_orders_margin_rate
        )),
      this.leverage_orders_value
    );
  }
  leverageCalcRateSymbol(t) {
    if (!t) return this.leverage_calc_rate_symbol;
    this.leverage_calc_rate_symbol = t;
  }
  leverageCalcVolume(t) {
    if (!t) return this.leverage_calc_volume;
    this.leverage_calc_volume = t;
  }
  leverageCalcValue(t, e, i, r) {
    if (!t || !e) return 0;
    let s = this.calcValue(
        0,
        t,
        Yi.toSize(t, this.symbol.trade_contract_size),
        i
      ),
      o = 1,
      a = this.account.currency_digits;
    return (
      this.leverage_rule &&
        (this.symbol.currency_base !== this.symbol.currency_margin ||
        ("\0" !== this.leverage_rule.range_currency[0] &&
          this.account.account_currency !== this.leverage_rule.range_currency)
          ? ((o = this.leverage_rule.range_currency[0]
              ? this.prices.rateBuy(
                  this.symbol,
                  this.symbol.currency_base,
                  this.leverage_rule.range_currency
                )
              : this.prices.rateBuy(
                  this.symbol,
                  this.symbol.currency_base,
                  this.account.account_currency
                )),
            (a = this.leverage_rule.range_currency_digits))
          : (o = r)),
      (s = oe(s * o, a)),
      s
    );
  }
  calcValue(t, e, i, r) {
    const { symbol: s, prices: o } = this;
    let a = 0,
      n = 0,
      l = 0;
    switch (s.trade_calc_mode) {
      case 0:
      case 5:
        a = i;
        break;
      case 1:
      case 33:
      case 34:
        s.trade_tick_size &&
          s.trade_tick_value &&
          ((a = Yi.toDouble(e)),
          (a = oe(
            (a * r * s.trade_tick_value) / s.trade_tick_size,
            s.currency_base_digits
          )));
        break;
      case 2:
      case 3:
      case 4:
      case 32:
      case 38:
      case 35:
      case 36:
      case 64:
        a = oe(i * r, s.currency_profit_digits);
        break;
      case 37:
      case 39:
        (a = oe((i * s.trade_face_value * r) / 100, s.currency_base_digits)),
          (l =
            0 === t
              ? o.rateBuy(s, s.currency_base, s.currency_profit)
              : o.rateSell(s, s.currency_base, s.currency_profit)),
          (a = oe(a * l, s.currency_profit_digits)),
          (n = oe(i * s.trade_accrued_interest, s.currency_profit_digits)),
          (a = oe(a + n, s.currency_profit_digits));
        break;
      default:
        a = 0;
    }
    return a;
  }
}
class Mr extends Ar {
  isProfitEquity() {
    return (
      32 !== this.symbol.trade_calc_mode &&
      35 !== this.symbol.trade_calc_mode &&
      36 !== this.symbol.trade_calc_mode &&
      37 !== this.symbol.trade_calc_mode &&
      38 !== this.symbol.trade_calc_mode &&
      39 !== this.symbol.trade_calc_mode
    );
  }
}
class $r extends Mr {
  constructor() {
    super(...arguments),
      (this.price_current = 0),
      (this.price_current_ask = 0),
      (this.position_type = 0),
      (this.position_volume = 0n),
      (this.position_size = 0),
      (this.position_value = 0),
      (this.orders_buy_size = 0),
      (this.orders_buy_value = 0),
      (this.orders_buy_value_market = 0),
      (this.orders_buy_price_min = ce),
      (this.orders_sell_size = 0),
      (this.orders_sell_value_market = 0),
      (this.orders_sell_price_max = 0),
      (this.margin = 0),
      (this.m_margin_initial = 0),
      (this.m_margin_maintenance = 0),
      (this.m_assets = 0),
      (this.m_liabilities = 0);
  }
  addOrder(t, e) {
    let i = t.order_type,
      r = t.price_order;
    if (
      (e &&
        (1 === t.activation_mode && t.isStop() && (i = t.isBuy() ? 0 : 1),
        2 === t.activation_mode &&
          t.isStopLimit() &&
          ((i = t.isBuy() ? 2 : 3), (r = t.price_trigger))),
      0 !== i && 1 !== i && 2 !== i && 3 !== i)
    )
      return !0;
    if (
      (this.price_current ||
        ([this.price_current, this.price_current_ask] = N(
          this.symbol.trade_symbol,
          this.prices,
          t.price_current
        )),
      0 === i || 2 === i)
    ) {
      const e = Yi.toSize(t.volume_current, t.contract_size);
      let s = 0,
        o = 0;
      return (
        (this.orders_buy_size = oe(this.orders_buy_size + e, 8)),
        (o = 0 === i ? this.price_current_ask : r),
        (s = this.calcValue(0, t.volume_current, e, o)),
        (this.orders_buy_value = oe(
          this.orders_buy_value + s,
          this.symbol.currency_base_digits
        )),
        (o =
          0 === i
            ? this.price_current
            : r <= this.price_current
            ? r
            : this.price_current),
        (s = this.calcValue(0, t.volume_current, e, o)),
        (this.orders_buy_value_market = oe(
          this.orders_buy_value_market + s,
          this.symbol.currency_base_digits
        )),
        (this.orders_buy_price_min = Math.min(this.orders_buy_price_min, o)),
        !0
      );
    }
    if (1 === i || 3 === i) {
      const e = Yi.toSize(t.volume_current, t.contract_size);
      let s = 0,
        o = 0;
      return (
        (this.orders_sell_size = oe(this.orders_sell_size + e, 8)),
        (o =
          1 === i
            ? this.price_current
            : r >= this.price_current
            ? r
            : this.price_current),
        (s = this.calcValue(1, t.volume_current, e, o)),
        (this.orders_sell_value_market = oe(
          this.orders_sell_value_market + s,
          this.symbol.currency_base_digits
        )),
        (this.orders_sell_price_max = Math.max(this.orders_sell_price_max, o)),
        !0
      );
    }
    return !1;
  }
  addPosition(t) {
    return (
      this.price_current ||
        ([this.price_current, this.price_current_ask] = N(
          this.symbol.trade_symbol,
          this.prices,
          t.price_close
        )),
      (this.position_type = 0 === t.trade_action ? 0 : 1),
      (this.position_volume = t.trade_volume),
      (this.position_size = Yi.toSize(t.trade_volume, t.contract_size)),
      (this.position_value = this.calcValue(
        this.position_type,
        this.position_volume,
        this.position_size,
        this.price_current
      )),
      !0
    );
  }
  calc() {
    const { account: t } = this;
    let e = 0,
      i = 0,
      r = 0;
    if (!this.position_size && !this.orders_buy_size && !this.orders_sell_size)
      return 0;
    const s = this.prices.rateBuy(
        this.symbol,
        this.symbol.currency_profit,
        this.account.account_currency
      ),
      o = this.prices.rateSell(
        this.symbol,
        this.symbol.currency_profit,
        this.account.account_currency
      );
    if (this.symbol.isCollateral()) {
      if (
        ((this.m_margin_maintenance = 0),
        (this.m_margin_initial = 0),
        (this.margin = 0),
        (this.m_assets = 0),
        (this.m_liabilities = 0),
        0n !== this.position_volume)
      ) {
        if (0 === this.position_type) {
          let e = 0;
          (e = oe(
            this.position_size * this.price_current,
            this.account.currency_digits
          )),
            (e *= this.symbol.trade.margin_rate_liquidity),
            (e = oe(e * s, this.account.currency_digits)),
            (this.m_assets = e),
            (t.assets = oe(t.assets + e, this.account.currency_digits)),
            (t.collateral = oe(t.collateral + e, this.account.currency_digits));
        }
        if (1 === this.position_type) {
          let e = 0;
          (e = oe(
            this.position_size * this.price_current,
            this.account.currency_digits
          )),
            (e = oe(e * o, this.account.currency_digits)),
            (this.m_liabilities = -e),
            (t.liabilities = oe(
              t.liabilities - e,
              this.account.currency_digits
            )),
            (t.collateral = oe(t.collateral - e, this.account.currency_digits));
        }
      }
      return this.margin;
    }
    if (
      (this.position_size
        ? ((this.m_margin_maintenance = this.calcMargin(
            this.position_type,
            this.position_size,
            this.position_value,
            !1
          )),
          (this.m_margin_initial = this.calcMargin(
            this.position_type,
            this.position_size,
            this.position_value,
            !0
          )),
          (this.margin = this.m_margin_initial),
          0 === this.position_type &&
            ((this.m_margin_maintenance = oe(
              this.m_margin_maintenance * s,
              this.account.currency_digits
            )),
            (this.m_margin_initial = oe(
              this.m_margin_initial * s,
              this.account.currency_digits
            )),
            (this.margin = this.m_margin_initial),
            this.symbol.trade.margin_rate_liquidity &&
              ((this.m_assets =
                this.position_value * this.symbol.trade.margin_rate_liquidity),
              (this.m_assets = oe(
                this.m_assets * s,
                this.account.currency_digits
              ))),
            (r = this.position_size)),
          1 === this.position_type &&
            ((this.m_margin_maintenance = oe(
              this.m_margin_maintenance * o,
              this.account.currency_digits
            )),
            (this.m_margin_initial = oe(
              this.m_margin_initial * o,
              this.account.currency_digits
            )),
            (this.margin = this.m_margin_initial),
            (this.m_liabilities = oe(
              this.position_value * o,
              this.account.currency_digits
            )),
            (r = -this.position_size)))
        : ((this.m_margin_maintenance = 0),
          (this.m_margin_initial = 0),
          (this.margin = 0),
          (this.m_assets = 0),
          (this.m_liabilities = 0)),
      this.orders_buy_size)
    )
      if (r + this.orders_buy_size <= 0) e = 0;
      else {
        let t = Math.min(this.orders_buy_price_min, this.price_current),
          i = this.price_current;
        const o = this.symbol.orderRate(0, !0);
        if (o) {
          if (this.symbol.isBond()) {
            const { trade_face_value: e, trade_accrued_interest: r } =
              this.symbol;
            (t = (e * t) / 100 + r), (i = (e * i) / 100 + r);
          }
          (e =
            r * (i - t) +
            (r + this.orders_buy_size) * t * o +
            (this.orders_buy_value_market - this.orders_buy_size * t)),
            (e = oe(e * s, this.account.currency_digits));
        } else e = oe(this.orders_buy_value * s, this.account.currency_digits);
      }
    else e = this.m_margin_initial;
    if (this.orders_sell_size)
      if (r - this.orders_sell_size >= 0) i = 0;
      else {
        let t = Math.max(this.orders_sell_price_max, this.price_current),
          e = this.price_current;
        const s = this.symbol.orderRate(1, !0);
        if (s) {
          if (this.symbol.isBond()) {
            const { trade_face_value: i, trade_accrued_interest: r } =
              this.symbol;
            (t = (i * t) / 100 + r), (e = (i * e) / 100 + r);
          }
          const { orders_sell_size: a, orders_sell_value_market: n } = this;
          (i = -r * (t - e) - (r - a) * t * s + (a * t - n)),
            (i = oe(i * o, this.account.currency_digits));
        } else i = oe(this.m_margin_initial * o, this.account.currency_digits);
      }
    else i = this.m_margin_initial;
    (e || i) && (this.margin = Math.max(e, i));
    const a = this.account.currency_digits;
    return (
      (t.margin = oe(t.margin + this.margin, a)),
      (t.margin_initial = oe(t.margin_initial + this.m_margin_initial, a)),
      (t.margin_maintenance = oe(
        t.margin_maintenance + this.m_margin_maintenance,
        a
      )),
      (t.assets = oe(t.assets + this.m_assets, a)),
      (t.liabilities = oe(t.liabilities - this.m_liabilities, a)),
      this.margin
    );
  }
  calcMargin(t, e, i, r) {
    let s = 0,
      o = 0;
    return (
      r
        ? (o = this.symbol.trade.margin_initial)
        : ((o = this.symbol.trade.margin_initial),
          this.symbol.trade.margin_maintenance &&
            (o = this.symbol.trade.margin_maintenance)),
      (s =
        o > 0
          ? ((o * e) / this.symbol.trade_contract_size) *
            this.symbol.orderRate(t, r)
          : i * this.symbol.orderRate(t, r)),
      oe(s, this.symbol.currency_margin_digits)
    );
  }
}
class xr extends Rr {
  createEntity(t) {
    return new $r(this.account, t, this.prices);
  }
}
class Pr extends Mr {
  constructor() {
    super(...arguments),
      (this.price_current = 0),
      (this.price_current_ask = 0),
      (this.position_type = 0),
      (this.position_volume = 0n),
      (this.position_size = 0),
      (this.position_value = 0),
      (this.orders_buy_size = 0),
      (this.orders_buy_value = 0),
      (this.orders_sell_size = 0),
      (this.margin = 0),
      (this.margin_initial = 0),
      (this.margin_maintenance = 0),
      (this.assets = 0),
      (this.liabilities = 0);
  }
  addOrder(t, e) {
    let i = t.order_type,
      r = t.price_order;
    if (
      (e &&
        (1 === t.activation_mode && t.isStop() && (i = t.isBuy() ? 0 : 1),
        2 === t.activation_mode &&
          t.isStopLimit() &&
          ((i = t.isBuy() ? 2 : 3), (r = t.price_trigger))),
      0 !== i && 1 !== i && 2 !== i && 3 !== i)
    )
      return !0;
    if (
      (this.price_current ||
        ([this.price_current, this.price_current_ask] = N(
          this.symbol.trade_symbol,
          this.prices,
          t.price_current
        )),
      0 === i || 2 === i)
    ) {
      const e = Yi.toSize(t.volume_current, t.contract_size);
      this.orders_buy_size = oe(this.orders_buy_size + e, 8);
      let s = 0;
      s = 0 === i ? this.price_current_ask : r;
      const o = this.calcValue(0, t.volume_current, e, s);
      return (
        (this.orders_buy_value = oe(
          this.orders_buy_value + o,
          this.symbol.currency_base_digits
        )),
        !0
      );
    }
    if (1 === i || 3 === i) {
      const e = Yi.toSize(t.volume_current, t.contract_size);
      return (this.orders_sell_size = oe(this.orders_sell_size + e, 8)), !0;
    }
    return !1;
  }
  addPosition(t) {
    return (
      this.price_current ||
        ([this.price_current, this.price_current_ask] = N(
          this.symbol.trade_symbol,
          this.prices,
          t.price_close
        )),
      (this.position_type = 0 === t.trade_action ? 0 : 1),
      (this.position_volume = t.trade_volume),
      (this.position_size = Yi.toSize(t.trade_volume, t.contract_size)),
      (this.position_value = this.calcValue(
        this.position_type,
        this.position_volume,
        this.position_size,
        this.price_current
      )),
      !0
    );
  }
  calc() {
    const t = this.account,
      e = t.currency_digits;
    let i = 0,
      r = 0,
      s = 0;
    if (!this.position_size && !this.orders_buy_size && !this.orders_sell_size)
      return 0;
    const o = this.prices.rateBuy(
        this.symbol,
        this.symbol.currency_profit,
        t.account_currency
      ),
      a = this.prices.rateSell(
        this.symbol,
        this.symbol.currency_profit,
        t.account_currency
      );
    if (this.symbol.isCollateral()) {
      if (
        ((this.margin_maintenance = 0),
        (this.margin_initial = 0),
        (this.margin = 0),
        (this.assets = 0),
        (this.liabilities = 0),
        0n !== this.position_volume)
      ) {
        if (0 === this.position_type) {
          let i = 0;
          (i = oe(this.position_size * this.price_current, e)),
            (i *= this.symbol.trade.margin_rate_liquidity),
            (i = oe(i * o, e)),
            (this.assets = i),
            (t.assets = oe(t.assets + i, e)),
            (t.collateral = oe(t.collateral + i, e));
        }
        if (1 === this.position_type) {
          let i = 0;
          (i = oe(this.position_size * this.price_current, e)),
            (i = oe(i * a, e)),
            (this.liabilities = -i),
            (t.liabilities = oe(t.liabilities - i, e)),
            (t.collateral = oe(t.collateral - i, e));
        }
      }
      return this.margin;
    }
    if (
      (this.position_size
        ? ((this.margin_maintenance = this.calcMarginPosition(
            0 === this.position_type ? 0 : 1,
            this.position_size,
            this.position_value,
            !1
          )),
          (this.margin_initial = this.calcMarginPosition(
            0 === this.position_type ? 0 : 1,
            this.position_size,
            this.position_value,
            !0
          )),
          (this.margin = this.margin_initial),
          0 === this.position_type &&
            ((this.margin_maintenance = oe(this.margin_maintenance * o, e)),
            (this.margin_initial = oe(this.margin_initial * o, e)),
            (this.margin = this.margin_initial),
            this.symbol.trade.margin_rate_liquidity &&
              ((this.assets =
                this.position_value * this.symbol.trade.margin_rate_liquidity),
              (this.assets = oe(this.assets * o, e))),
            (s = this.position_size)),
          1 === this.position_type &&
            ((this.margin_maintenance = oe(this.margin_maintenance * a, e)),
            (this.margin_initial = oe(this.margin_initial * a, e)),
            (this.margin = this.margin_initial),
            (this.liabilities = oe(this.position_value * a, e)),
            (s = -this.position_size)))
        : ((this.margin_maintenance = 0),
          (this.margin_initial = 0),
          (this.margin = 0),
          (this.assets = 0),
          (this.liabilities = 0)),
      this.orders_buy_size)
    )
      if (s + this.orders_buy_size <= 0) i = 0;
      else {
        const t = this.symbol.orderRate(0, !0);
        if (t) {
          let e = this.price_current;
          const { trade_face_value: r, trade_accrued_interest: o } =
            this.symbol;
          this.symbol.isBond() && (e = (r * e) / 100 + o),
            (i = (s + this.orders_buy_size) * t * e);
        } else i = this.orders_buy_value;
        i = oe(i * o, e);
      }
    else i = this.margin_initial;
    if (this.orders_sell_size)
      if (s - this.orders_sell_size >= 0) r = 0;
      else {
        let t = this.price_current;
        const i = this.symbol.orderRate(1, !0);
        if (this.symbol.isBond()) {
          const { trade_face_value: e, trade_accrued_interest: i } =
            this.symbol;
          t = (e * t) / 100 + i;
        }
        (r = i
          ? (-s + this.orders_sell_size) * i * t
          : (-s + this.orders_sell_size) * t),
          (r = oe(r * a, e));
      }
    else r = this.margin_initial;
    return (
      (i || r) && (this.margin = Math.max(i, r)),
      (t.margin = oe(t.margin + this.margin, e)),
      (t.margin_initial = oe(t.margin_initial + this.margin_initial, e)),
      (t.margin_maintenance = oe(
        t.margin_maintenance + this.margin_maintenance,
        e
      )),
      (t.assets = oe(t.assets + this.assets, e)),
      (t.liabilities = oe(
        t.liabilities - this.liabilities,
        this.account.currency_digits
      )),
      this.margin
    );
  }
  calcMarginPosition(t, e, i, r) {
    let s = 0,
      o = 0;
    return (
      r
        ? (o = this.symbol.trade.margin_initial)
        : ((o = this.symbol.trade.margin_initial),
          this.symbol.trade.margin_maintenance &&
            (o = this.symbol.trade.margin_maintenance)),
      (s =
        o > 0
          ? (o * e) / this.symbol.trade_contract_size
          : this.symbol.orderRate(t, r)
          ? i * this.symbol.orderRate(t, r)
          : 1 === t
          ? i
          : 0),
      oe(s, this.account.currency_digits)
    );
  }
  calcMargin(t, e, i, r, s) {
    const { symbol: o } = this;
    let a = 0,
      n = 0;
    switch (
      (s
        ? (n = o.trade.margin_initial)
        : ((n = o.trade.margin_initial),
          o.trade.margin_maintenance && (n = o.trade.margin_maintenance)),
      o.trade_calc_mode)
    ) {
      case 32:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
        a =
          n > 0
            ? (n * i) / o.trade_contract_size
            : this.calcValue(t, e, i, r) * o.orderRate(t, s);
        break;
      default:
        a = 0;
    }
    return oe(a, o.currency_margin_digits);
  }
}
class zr extends Rr {
  createEntity(t) {
    return new Pr(this.account, t, this.prices);
  }
}
class Dr extends Mr {
  constructor() {
    super(...arguments),
      (this.price_current = 0),
      (this.price_current_ask = 0),
      (this.price_current_bid = 0),
      (this.position_type = 0),
      (this.position_volume = 0n),
      (this.position_size = 0),
      (this.position_value = 0),
      (this.orders_buy_size = 0),
      (this.orders_buy_value = 0),
      (this.orders_sell_size = 0),
      (this.orders_sell_value = 0),
      (this.margin = 0),
      (this.margin_initial = 0),
      (this.margin_maintenance = 0),
      (this.assets = 0),
      (this.liabilities = 0);
  }
  addOrder(t, e = !1) {
    let i = t.order_type,
      r = t.price_order;
    if (
      (e &&
        (1 === t.activation_mode && t.isStop() && (i = t.isBuy() ? 0 : 1),
        2 === t.activation_mode &&
          t.isStopLimit() &&
          ((i = t.isBuy() ? 2 : 3), (r = t.price_trigger))),
      0 !== i && 1 !== i && 2 !== i && 3 !== i)
    )
      return !0;
    if (0 === i || 2 === i) {
      const e = Yi.toSize(t.volume_current, t.contract_size);
      let s = 0,
        o = 0;
      if (((this.orders_buy_size = oe(this.orders_buy_size + e, 8)), 0 === i)) {
        if (!this.price_current_ask) {
          const e = N(this.symbol.trade_symbol, this.prices, t.price_current);
          this.price_current_ask = e[1];
        }
        o = this.price_current_ask;
      } else o = r;
      return (
        (s = this.calcValue(0, t.volume_current, e, o)),
        (this.orders_buy_value = oe(
          this.orders_buy_value + s,
          this.symbol.currency_base_digits
        )),
        !0
      );
    }
    if (1 === i || 3 === i) {
      const e = Yi.toSize(t.volume_current, t.contract_size);
      let s = 0,
        o = 0;
      return (
        (this.orders_sell_size = oe(this.orders_sell_size + e, 8)),
        1 === i
          ? (this.price_current_bid ||
              ([this.price_current_bid] = N(
                this.symbol.trade_symbol,
                this.prices,
                t.price_current
              )),
            (o = this.price_current_bid))
          : (o = r),
        (s = this.calcValue(1, t.volume_current, e, o)),
        (this.orders_sell_value = oe(
          this.orders_sell_value + s,
          this.symbol.currency_base_digits
        )),
        !0
      );
    }
    return !1;
  }
  addPosition(t) {
    return (
      this.price_current ||
        ([this.price_current, this.price_current_ask] = N(
          this.symbol.trade_symbol,
          this.prices,
          t.price_close
        )),
      (this.position_type = 0 === t.trade_action ? 0 : 1),
      (this.position_volume = t.trade_volume),
      (this.position_size = Yi.toSize(t.trade_volume, t.contract_size)),
      (this.position_value = this.calcValue(
        this.position_type,
        this.position_volume,
        this.position_size,
        this.price_current
      )),
      !0
    );
  }
  calc() {
    const { account: t } = this;
    let e = 0,
      i = 0,
      r = 0;
    if (!this.position_size && !this.orders_buy_size && !this.orders_sell_size)
      return 0;
    const s = this.prices.rateBuy(
        this.symbol,
        this.symbol.currency_profit,
        this.account.account_currency
      ),
      o = this.prices.rateSell(
        this.symbol,
        this.symbol.currency_profit,
        this.account.account_currency
      );
    if (this.symbol.isCollateral()) {
      if (
        ((this.margin_maintenance = 0),
        (this.margin_initial = 0),
        (this.margin = 0),
        (this.assets = 0),
        (this.liabilities = 0),
        0n !== this.position_volume)
      ) {
        if (0 === this.position_type) {
          let e = 0;
          (e = oe(
            this.position_size * this.price_current,
            this.account.currency_digits
          )),
            (e *= this.symbol.trade.margin_rate_liquidity),
            (e = oe(e * s, this.account.currency_digits)),
            (this.assets = e),
            (t.assets = oe(t.assets + e, this.account.currency_digits)),
            (t.collateral = oe(t.collateral + e, this.account.currency_digits));
        }
        if (1 === this.position_type) {
          let e = 0;
          (e = oe(
            this.position_size * this.price_current,
            this.account.currency_digits
          )),
            (e = oe(e * o, this.account.currency_digits)),
            (this.liabilities = -e),
            (t.liabilities = oe(
              t.liabilities - e,
              this.account.currency_digits
            )),
            (t.collateral = oe(t.collateral - e, this.account.currency_digits));
        }
      }
      return this.margin;
    }
    if (
      (this.position_size
        ? ((this.margin_maintenance = this.calcMargin(
            this.position_type,
            this.position_size,
            this.position_value,
            !1
          )),
          (this.margin_initial = this.calcMargin(
            this.position_type,
            this.position_size,
            this.position_value,
            !0
          )),
          (this.margin = this.margin_initial),
          0 === this.position_type &&
            ((this.margin_maintenance = oe(
              this.margin_maintenance * s,
              this.account.currency_digits
            )),
            (this.margin_initial = oe(
              this.margin_initial * s,
              this.account.currency_digits
            )),
            (this.margin = this.margin_initial),
            this.symbol.trade.margin_rate_liquidity &&
              ((this.assets =
                this.position_value * this.symbol.trade.margin_rate_liquidity),
              (this.assets = oe(
                this.assets * s,
                this.account.currency_digits
              ))),
            (r = this.position_size)),
          1 === this.position_type &&
            ((this.margin_maintenance = oe(
              this.margin_maintenance * o,
              this.account.currency_digits
            )),
            (this.margin_initial = oe(
              this.margin_initial * o,
              this.account.currency_digits
            )),
            (this.margin = this.margin_initial),
            this.symbol.trade.margin_rate_liquidity &&
              ((this.liabilities =
                this.position_value * this.symbol.trade.margin_rate_liquidity),
              (this.liabilities = oe(
                this.liabilities * o,
                this.account.currency_digits
              ))),
            (r = -this.position_size)))
        : ((this.margin_maintenance = 0),
          (this.margin_initial = 0),
          (this.margin = 0),
          (this.assets = 0),
          (this.liabilities = 0)),
      this.orders_buy_size)
    ) {
      const t = r + this.orders_buy_size;
      if (t <= 0) e = 0;
      else {
        let i = 0;
        this.symbol.orderRate(0, !0)
          ? ((i = this.calcMargin(
              0,
              this.orders_buy_size,
              this.orders_buy_value,
              !0
            )),
            (i = oe(i * s, this.account.currency_digits)))
          : (i = oe(this.orders_buy_value * s, this.account.currency_digits)),
          (e = oe(
            r > 0 ? this.margin + i : (t * i) / this.orders_buy_size,
            this.account.currency_digits
          ));
      }
    } else e = this.margin_initial;
    if (this.orders_sell_size) {
      const t = r - this.orders_sell_size;
      if (t >= 0) i = 0;
      else {
        let e = 0;
        this.symbol.orderRate(1, !0)
          ? ((e = this.calcMargin(
              1,
              this.orders_sell_size,
              this.orders_sell_value,
              !0
            )),
            (e = oe(e * o, this.account.currency_digits)))
          : (e = oe(this.margin_initial * o, this.account.currency_digits)),
          (i = oe(this.margin + e, this.account.currency_digits)),
          (i = oe(
            r < 0 ? this.margin + e : (-t * e) / this.orders_sell_size,
            this.account.currency_digits
          ));
      }
    } else i = this.margin_initial;
    return (
      (e || i) && (this.margin = Math.max(e, i)),
      (t.margin = oe(t.margin + this.margin, this.account.currency_digits)),
      (t.margin_initial = oe(
        t.margin_initial + this.margin_initial,
        this.account.currency_digits
      )),
      (t.margin_maintenance = oe(
        t.margin_maintenance + this.margin_maintenance,
        this.account.currency_digits
      )),
      (t.assets = oe(t.assets + this.assets, this.account.currency_digits)),
      (t.liabilities = oe(
        t.liabilities - this.liabilities,
        this.account.currency_digits
      )),
      this.margin
    );
  }
  calcMargin(t, e, i, r) {
    let s = 0,
      o = 0;
    return (
      r
        ? (o = this.symbol.trade.margin_initial)
        : ((o = this.symbol.trade.margin_initial),
          this.symbol.trade.margin_maintenance &&
            (o = this.symbol.trade.margin_maintenance)),
      (s =
        o > 0
          ? ((o * e) / this.symbol.trade_contract_size) *
            this.symbol.orderRate(t, r)
          : i * this.symbol.orderRate(t, r)),
      oe(s, this.account.currency_digits)
    );
  }
}
class Nr extends Rr {
  createEntity(t) {
    return new Dr(this.account, t, this.prices);
  }
}
class Ur extends Mr {
  constructor() {
    super(...arguments),
      (this.margin_leverage = 1),
      (this.position_type = 0),
      (this.position_volume = 0n),
      (this.position_size = 0),
      (this.position_price_open = 0),
      (this.position_price_curr = 0),
      (this.position_margin = 0),
      (this.orders_margin_buy = 0),
      (this.orders_margin_sell = 0),
      (this.orders_volume_buy = 0n),
      (this.orders_volume_sell = 0n),
      (this.orders_new = !1),
      (this.margin = 0),
      (this.volume = 0n),
      (this.volume_type = 0),
      (this.volume_rate = 0);
  }
  addOrder(t, e) {
    let i,
      r = 0,
      s = t.order_type;
    if (this.symbol.isCollateral()) return !1;
    const o = Yi.toSize(t.volume_current, t.contract_size);
    if (o <= 0) return !0;
    e &&
      ((this.orders_new = !0),
      1 === t.activation_mode &&
        (t.isLimit() || t.isStop()) &&
        (s = t.isBuy() ? 0 : 1),
      2 === t.activation_mode && t.isStopLimit() && (s = t.isBuy() ? 2 : 3));
    const a = this.symbol.orderRate(s, !0);
    if (a <= 0) return !0;
    let n = t.price_order;
    return (
      n || (0 !== s && 1 !== s) || (n = t.price_current),
      (6 !== s && 7 !== s) || (n = t.price_trigger),
      0 === s || 2 === s || 4 === s || 6 === s
        ? (t.margin_rate
            ? (r = t.margin_rate)
            : this.prices.marginSymbol(this.symbol.trade_symbol) &&
              (r = this.prices.rateBuyMargin(
                this.symbol,
                this.account.account_currency,
                n
              )),
          r <= 0 ||
            ((i = U(this.symbol, this.margin_leverage, s, o, n, !0, !1)),
            (i = r),
            (i = a),
            (this.orders_margin_buy = oe(
              this.orders_margin_buy + i,
              this.account.currency_digits
            )),
            (this.orders_volume_buy += t.volume_current)),
          !0)
        : (1 === s || 3 === s || 5 === s || 7 === s) &&
          (t.margin_rate
            ? (r = t.margin_rate)
            : this.prices.marginSymbol(this.symbol.trade_symbol) &&
              (r = this.prices.rateSellMargin(
                this.symbol,
                this.account.account_currency,
                n
              )),
          r <= 0 ||
            ((i = U(this.symbol, this.margin_leverage, s, o, n, !0, !1)),
            (i *= r),
            (i *= a),
            (this.orders_margin_sell = oe(
              this.orders_margin_sell + i,
              this.account.currency_digits
            )),
            (this.orders_volume_sell += t.volume_current)),
          !0)
    );
  }
  addPosition(t) {
    let e = 0;
    return (
      t.isBuy() && (this.position_type = 0),
      t.isSell() && (this.position_type = 1),
      (this.position_size = Yi.toSize(t.trade_volume, t.contract_size)),
      (this.position_price_open = t.price_open),
      (this.position_price_curr = t.price_close),
      (e = U(
        this.symbol,
        this.margin_leverage,
        this.position_type,
        this.position_size,
        this.position_price_open,
        !1,
        !0
      )),
      (e *= t.rate_margin),
      (e *= this.symbol.orderRate(this.position_type, !1)),
      (this.position_margin = oe(e, this.account.currency_digits)),
      (this.position_volume = t.trade_volume),
      !0
    );
  }
  calc() {
    const { account: t } = this;
    let e = this.orders_margin_buy,
      i = this.orders_margin_sell;
    if (this.symbol.isCollateral()) {
      let e = 0,
        i = 0;
      if (
        ((this.margin = 0),
        (this.volume = 0n),
        (this.volume_type = 0),
        (this.volume_rate = 0),
        0n !== this.position_volume)
      ) {
        if (0 === this.position_type) {
          const i = this.prices.rateBuy(
              this.symbol,
              this.symbol.currency_profit,
              this.account.account_currency
            ),
            r = this.calcCollateralPrice(
              this.position_price_curr,
              this.position_type
            );
          (e = oe(this.position_size * r, this.account.currency_digits)),
            (e *= this.symbol.trade.margin_rate_liquidity),
            (e = oe(e * i, this.account.currency_digits)),
            (t.assets = oe(t.assets + e, this.account.currency_digits)),
            (t.collateral = oe(t.collateral + e, this.account.currency_digits));
        }
        if (1 === this.position_type) {
          const e = this.prices.rateSell(
              this.symbol,
              this.symbol.currency_profit,
              this.account.account_currency
            ),
            r = this.calcCollateralPrice(
              this.position_price_curr,
              this.position_type
            );
          (i = oe(this.position_size * r, this.account.currency_digits)),
            (i = oe(i * e, this.account.currency_digits)),
            (t.liabilities = oe(
              t.liabilities - i,
              this.account.currency_digits
            )),
            (t.collateral = oe(t.collateral - i, this.account.currency_digits));
        }
      }
      return this.margin;
    }
    if (((this.margin = 0), 0n !== this.position_volume)) {
      if (0 === this.position_type)
        if (((e += this.position_margin), this.symbol.isFORTS())) {
          const t = U(
            this.symbol,
            this.margin_leverage,
            1,
            this.position_size,
            this.position_price_open,
            !1,
            !0
          );
          i = oe(i - t, this.account.currency_digits);
        } else
          this.orders_margin_sell &&
            this.orders_volume_sell &&
            (i -= oe(
              (this.orders_margin_sell / Number(this.orders_volume_sell)) *
                Number(this.position_volume),
              this.account.currency_digits
            ));
      if (1 === this.position_type)
        if (((i += this.position_margin), this.symbol.isFORTS())) {
          const t = U(
            this.symbol,
            this.margin_leverage,
            0,
            this.position_size,
            this.position_price_open,
            !1,
            !0
          );
          e = oe(e - t, this.account.currency_digits);
        } else
          this.orders_margin_buy &&
            this.orders_volume_buy &&
            (e -= oe(
              (this.orders_margin_buy / Number(this.orders_volume_buy)) *
                Number(this.position_volume),
              this.account.currency_digits
            ));
    }
    this.margin = Math.max(e, i);
    let r = this.orders_volume_buy,
      s = this.orders_volume_sell;
    return (
      (this.volume = 0n),
      (this.volume_rate = 0),
      (this.volume_type = 0),
      0n !== this.position_volume &&
        (0 === this.position_type && (r += this.position_volume),
        1 === this.position_type && (s += this.position_volume)),
      r > s
        ? ((this.volume = r), (this.volume_type = 0))
        : r < s
        ? ((this.volume = s), (this.volume_type = 1))
        : ((this.volume = r), (this.volume_type = this.position_type)),
      this.volume
        ? (this.volume_rate = this.margin / Number(this.volume))
        : (this.volume_rate = 0),
      (t.liabilities = oe(
        t.liabilities - this.margin,
        this.account.currency_digits
      )),
      this.margin
    );
  }
  checkNew(t, e, i) {
    const { account: r } = this;
    if (
      ((i.isBuy() && e.isSell()) || (i.isSell() && e.isBuy())) &&
      i.trade_volume &&
      e.volume_current
    ) {
      const s = i.trade_volume - e.volume_current;
      if ((s >= 0 || Te.abs(s) < i.trade_volume) && t.margin <= r.margin)
        return !0;
    }
    return !1;
  }
  spreadLeg(t) {
    return t && (this.leg = t), this.leg;
  }
  getVolume() {
    return this.volume;
  }
  calcCollateralPrice(t, e) {
    return (
      t ||
      (0 === e
        ? this.prices.findPrice(this.symbol.trade_symbol, 0)
        : 1 === e
        ? this.prices.findPrice(this.symbol.trade_symbol, 1)
        : 0)
    );
  }
}
class qr extends Rr {
  createEntity(t) {
    return new Ur(this.account, t, this.prices);
  }
}
class Vr extends Cr {
  constructor(t, e) {
    super(t, e),
      (this.storage = new Er(
        new xr(t, e),
        new zr(t, e),
        new Nr(t, e),
        new qr(t, e)
      ));
  }
  reset() {
    this.storage.clear();
  }
  isFloatingMarginOrder() {
    return !0;
  }
  calcTick(t, e) {
    this.calcAccount(t, e);
  }
  calcAccount(t, e, i, r = !1) {
    const { account: s } = this;
    (s.profit = 0),
      (s.storage = 0),
      (s.margin = 0),
      (s.margin_level = 0),
      (s.margin_initial = 0),
      (s.margin_maintenance = 0),
      (s.floating = 0),
      (s.equity = 0),
      (s.assets = 0),
      (s.liabilities = 0),
      (s.collateral = 0),
      (s.acc_commission = oe(
        s.commission_daily + s.commission_monthly,
        s.currency_digits
      )),
      this.storage.clear(),
      this.collectPositions(t, i),
      this.collectOrders(e, i, r),
      this.calcMargin(),
      this.calcFloating();
  }
  checkStopOut() {
    const { account: t } = this;
    return (
      (t.so_activation = 0),
      !(t.margin_maintenance <= 0 || t.margin <= 0) &&
        t.equity < t.margin_initial &&
        ((t.so_activation = 1), t.equity < t.margin_maintenance) &&
        ((t.so_activation = 2), !0)
    );
  }
  calcFloating() {
    this.calcEquity(), this.calcFree(), this.calcLevel();
  }
  calcMargin() {
    const { account: t } = this;
    (t.margin = 0),
      (t.margin_initial = 0),
      (t.margin_maintenance = 0),
      (t.assets = 0),
      (t.liabilities = 0),
      (t.collateral = 0),
      this.storage.margins_exchange.forEach((t) => t.calc()),
      this.storage.margins_moex.forEach((t) => t.calc()),
      this.storage.margins_option.forEach((t) => t.calc()),
      this.storage.margins_retail.forEach((t) => t.calc());
  }
  calcFree() {
    const { account: t } = this;
    t.margin_free = oe(t.equity - t.margin, t.currency_digits);
  }
  calcEquity() {
    const { account: t } = this;
    (t.equity = t.balance),
      (t.equity = oe(
        t.equity + this.storage.equity_floating,
        t.currency_digits
      )),
      t.credit && (t.equity = oe(t.equity + t.credit, t.currency_digits)),
      t.assets && (t.equity = oe(t.equity + t.assets, t.currency_digits)),
      t.liabilities &&
        (t.equity = oe(t.equity + t.liabilities, t.currency_digits)),
      t.acc_commission &&
        (t.equity = oe(t.equity + t.acc_commission, t.currency_digits));
  }
  calcLevel() {
    const { account: t } = this;
    0 !== t.margin_maintenance
      ? (t.margin_level = (t.equity / t.margin_maintenance) * 100)
      : (t.margin_level = 0);
  }
  marginsGet(t) {
    let e = this.marginsFind(t);
    if (e) return e;
    const i = this.prices.marginSymbol(t);
    if (i) {
      switch (i.trade_calc_mode) {
        case 32:
        case 37:
          e = this.storage.margins_exchange.create(i);
          break;
        case 38:
        case 39:
          e = this.storage.margins_moex.create(i);
          break;
        case 35:
        case 36:
          e = this.storage.margins_option.create(i);
          break;
        default:
          e = this.storage.margins_retail.create(i);
      }
      return e;
    }
  }
  marginsFind(t) {
    return (
      this.storage.margins_exchange.find(t) ??
      this.storage.margins_moex.find(t) ??
      this.storage.margins_option.find(t) ??
      this.storage.margins_retail.find(t)
    );
  }
  collectPositions(t, e) {
    const { account: i } = this;
    t.forEach((t) => {
      if (!t || 0n === t.trade_volume) return;
      const r = this.marginsGet(t.trade_symbol);
      r &&
        r.addPosition(t) &&
        (r.isCollateral() ||
          (e &&
            e.trade_symbol === t.trade_symbol &&
            (this.storage.new_position = t),
          (i.profit = oe(i.profit + t.profit, i.currency_digits)),
          t.storage &&
            (i.storage = oe(i.storage + t.storage, i.currency_digits)),
          r.isProfitEquity() &&
            ((this.storage.equity_floating = oe(
              this.storage.equity_floating + t.profit,
              i.currency_digits
            )),
            t.storage &&
              (this.storage.equity_floating = oe(
                this.storage.equity_floating + t.storage,
                i.currency_digits
              )))));
    }),
      (i.floating = i.profit),
      i.storage && (i.floating = oe(i.floating + i.storage, i.currency_digits));
  }
  collectOrders(t, e, i = !1) {
    const { account: r } = this,
      s = r.currency_digits,
      o = Boolean(e);
    if (
      (t.forEach((t) => {
        const a = this.marginsGet(t.trade_symbol);
        if (a)
          if (e && e.trade_order === t.trade_order) {
            if (i) return void (e = null);
            a.addOrder(e, o),
              0 !== Se(t.commission_daily, e.commission_daily, s) &&
                (r.acc_commission = oe(
                  r.acc_commission + (e.commission_daily - t.commission_daily),
                  s
                )),
              0 !== Se(t.commission_monthly, e.commission_monthly, s) &&
                (r.acc_commission = oe(
                  r.acc_commission +
                    (e.commission_monthly - t.commission_monthly),
                  s
                )),
              (this.storage.new_order = e),
              (e = null);
          } else a.addOrder(t, o);
      }),
      e)
    ) {
      const t = this.marginsGet(e.trade_symbol);
      t &&
        (t.addOrder(e, o),
        e.commission_daily &&
          (r.acc_commission = oe(r.acc_commission + e.commission_daily, s)),
        e.commission_monthly &&
          (r.acc_commission = oe(r.acc_commission + e.commission_monthly, s)),
        (this.storage.new_order = e));
    }
  }
}
class Fr {
  constructor(t) {
    this.margins = t;
  }
  clear() {
    this.margins.clear();
  }
}
class Hr extends Ar {
  constructor() {
    super(...arguments),
      (this.positions_buy = {
        volume: 0n,
        volume_orders: 0n,
        price: 0,
        price_close: 0,
        margin_rate: 0,
        order_rate: 0,
      }),
      (this.positions_sell = {
        volume: 0n,
        volume_orders: 0n,
        price: 0,
        price_close: 0,
        margin_rate: 0,
        order_rate: 0,
      }),
      (this.orders = [
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
        {
          volume: 0n,
          volume_orders: 0n,
          price: 0,
          price_close: 0,
          margin_rate: 0,
          order_rate: 0,
        },
      ]),
      (this.margin = 0),
      (this.volume_uncovered = 0n),
      (this.volume_hedged = 0n),
      (this.volume_order = 0n),
      (this.margin_order = 0);
  }
  addOrder(t, e) {
    let i = 0,
      r = t.order_type;
    if (this.symbol.isCollateral()) return !1;
    if (t.isClose() || t.isCloseBy()) return !0;
    e &&
      (1 === t.activation_mode &&
        (t.isLimit() || t.isStop()) &&
        (r = t.isBuy() ? 0 : 1),
      2 === t.activation_mode && t.isStopLimit() && (r = t.isBuy() ? 2 : 3));
    const s = this.symbol.orderRate(r, !0);
    if (s <= 0) return !0;
    let o = t.price_order;
    return (
      !o && ge(r) && (o = t.price_current),
      ve(r) && (o = t.price_trigger),
      ue(r)
        ? (t.margin_rate
            ? (i = t.margin_rate)
            : this.prices.marginSymbol(this.symbol.trade_symbol) &&
              (i = this.prices.rateBuyMargin(
                this.symbol,
                this.account.account_currency,
                o
              )),
          i <= 0 ||
            (e && 0 === r
              ? ((this.positions_buy.volume += t.volume_current),
                (this.positions_buy.price += o * Number(t.volume_current)),
                (this.positions_buy.margin_rate +=
                  i * Number(t.volume_current)),
                (this.positions_buy.price_close = o),
                (this.positions_buy.volume_orders = t.volume_current),
                (this.positions_buy.order_rate = s))
              : ((this.orders[r].volume += t.volume_current),
                (this.orders[r].price += o * Number(t.volume_current)),
                (this.orders[r].margin_rate += i * Number(t.volume_current)),
                (this.orders[r].order_rate = s))),
          !0)
        : !!me(r) &&
          (t.margin_rate
            ? (i = t.margin_rate)
            : this.prices.marginSymbol(this.symbol.trade_symbol) &&
              (i = this.prices.rateSellMargin(
                this.symbol,
                this.account.account_currency,
                o
              )),
          i <= 0 ||
            (e && 1 === r
              ? ((this.positions_sell.volume += t.volume_current),
                (this.positions_sell.price += o * Number(t.volume_current)),
                (this.positions_sell.margin_rate +=
                  i * Number(t.volume_current)),
                (this.positions_sell.price_close = o),
                (this.positions_sell.volume_orders = t.volume_current),
                (this.positions_sell.order_rate = s))
              : ((this.orders[r].volume += t.volume_current),
                (this.orders[r].price += o * Number(t.volume_current)),
                (this.orders[r].margin_rate += i * Number(t.volume_current)),
                (this.orders[r].order_rate = s))),
          !0)
    );
  }
  addPosition(t) {
    return ke(t.trade_action)
      ? ((this.positions_buy.volume += t.trade_volume),
        (this.positions_buy.price += t.price_open * Number(t.trade_volume)),
        (this.positions_buy.margin_rate +=
          t.rate_margin * Number(t.trade_volume)),
        (this.positions_buy.price_close = t.price_close),
        (this.positions_buy.order_rate = this.symbol.orderRate(0, !1)),
        !0)
      : !!Ce(t.trade_action) &&
          ((this.positions_sell.volume += t.trade_volume),
          (this.positions_sell.price += t.price_open * Number(t.trade_volume)),
          (this.positions_sell.margin_rate +=
            t.rate_margin * Number(t.trade_volume)),
          (this.positions_sell.price_close = t.price_close),
          (this.positions_sell.order_rate = this.symbol.orderRate(1, !1)),
          !0);
  }
  calc() {
    return (
      (this.margin = 0),
      V(this.positions_buy),
      V(this.positions_sell),
      this.symbol.isCollateral()
        ? this.calcCollateral()
        : this.isLargeLeg()
        ? this.calcLargeLeg()
        : this.calcCommon()
    );
  }
  hasCollateral() {
    return Boolean(
      (this.positions_buy.volume || this.positions_sell.volume) &&
        this.symbol.isCollateral()
    );
  }
  hasInitialMargin() {
    return Boolean(
      this.symbol.trade.margin_initial &&
        this.symbol.trade.margin_maintenance &&
        this.symbol.trade.margin_initial !==
          this.symbol.trade.margin_maintenance
    );
  }
  calcCollateral() {
    const { account: t } = this,
      e = t.currency_digits;
    let i = 0,
      r = 0;
    if (this.positions_buy.volume) {
      const r = this.prices.rateBuy(
          this.symbol,
          this.symbol.currency_profit,
          t.account_currency
        ),
        s = this.calcCollateralPrice(this.positions_buy.price_close, 0);
      (i = oe(
        Yi.toSize(this.positions_buy.volume, this.symbol.trade_contract_size) *
          s,
        e
      )),
        (i *= this.symbol.trade.margin_rate_liquidity),
        (i = oe(i * r, e)),
        (t.assets = oe(t.assets + i, e)),
        (t.collateral = oe(t.collateral + i, e));
    }
    if (this.positions_sell.volume) {
      const i = this.prices.rateSell(
          this.symbol,
          this.symbol.currency_profit,
          t.account_currency
        ),
        s = this.calcCollateralPrice(this.positions_sell.price_close, 1);
      (r = oe(
        Yi.toSize(this.positions_sell.volume, this.symbol.trade_contract_size) *
          s,
        e
      )),
        (r = oe(r * i, e)),
        (t.liabilities = oe(t.liabilities - r, e)),
        (t.collateral = oe(t.collateral - r, e));
    }
    return this.margin;
  }
  calcLargeLeg() {
    let t = 0,
      e = 0,
      i = 0,
      r = 0,
      s = 0;
    for (let n = 0; n < this.orders.length; n++) {
      const r = this.orders[n];
      r.volume &&
        (V(r),
        (0 !== n && 2 !== n && 4 !== n && 6 !== n) ||
          ((t = this.calcMargin(n, r.volume, r.price, !0, !1)),
          (t *= r.margin_rate),
          (t *= r.order_rate),
          (e += t)),
        (1 !== n && 3 !== n && 5 !== n && 7 !== n) ||
          ((t = this.calcMargin(n, r.volume, r.price, !0, !1)),
          (t *= r.margin_rate),
          (t *= r.order_rate),
          (i += t)));
    }
    if (this.positions_buy.volume) {
      if (
        ((this.volume_order = this.positions_buy.volume_orders),
        this.volume_order)
      ) {
        const t =
          this.positions_buy.volume > this.volume_order
            ? this.positions_buy.volume - this.volume_order
            : 0;
        (r = this.calcMargin(
          0,
          this.volume_order,
          this.positions_buy.price,
          !0,
          !1
        )),
          (this.margin_order = r),
          t && (r += this.calcMargin(0, t, this.positions_buy.price, !1, !1));
      } else
        r = this.calcMargin(
          0,
          this.positions_buy.volume,
          this.positions_buy.price,
          !1,
          !1
        );
      (r *= this.positions_buy.margin_rate),
        (r *= this.positions_buy.order_rate),
        (this.margin_order *= this.positions_buy.margin_rate),
        (this.margin_order *= this.positions_buy.order_rate);
    }
    if (this.positions_sell.volume) {
      if (
        ((this.volume_order = this.positions_sell.volume_orders),
        this.positions_sell.volume_orders)
      ) {
        const t =
          this.positions_sell.volume > this.volume_order
            ? this.positions_sell.volume - this.volume_order
            : 0n;
        (s = this.calcMargin(
          1,
          this.volume_order,
          this.positions_sell.price,
          !0,
          !1
        )),
          (this.margin_order = s),
          t && (s += this.calcMargin(1, t, this.positions_sell.price, !1, !1));
      } else
        s = this.calcMargin(
          1,
          this.positions_sell.volume,
          this.positions_sell.price,
          !1,
          !1
        );
      (s *= this.positions_sell.margin_rate),
        (s *= this.positions_sell.order_rate),
        (this.margin_order *= this.positions_sell.margin_rate),
        (this.margin_order *= this.positions_sell.order_rate);
    }
    const o = r + e,
      a = s + i;
    return (
      (this.margin = Math.max(o, a)),
      this.calcLargeLegFloatingLeverage(o, a, r, e, s, i),
      this.margin
    );
  }
  calcLargeLegFloatingLeverage(t, e, i, r, s, o) {
    if (this.isFloatingLeverage())
      if (t >= e) {
        if (
          ((this.leverage_positions_volume =
            this.positions_buy.volume - this.volume_order),
          (this.leverage_positions_order_volume = this.volume_order),
          (this.leverage_positions_price = this.positions_buy.price),
          (this.leverage_positions_margin = i - this.margin_order),
          (this.leverage_positions_order_margin = this.margin_order),
          (this.leverage_positions_margin_rate =
            this.positions_buy.margin_rate),
          (this.leverage_orders_margin = r),
          this.leverage_orders_margin)
        ) {
          for (let t = 0; t < this.orders.length; t++) {
            const e = this.orders[t];
            e.volume &&
              ((0 !== t && 2 !== t && 4 !== t && 6 !== t) ||
                ((this.leverage_orders_volume += e.volume),
                (this.leverage_orders_price += e.price * Number(e.volume)),
                (this.leverage_orders_margin_rate +=
                  e.margin_rate * Number(e.volume))));
          }
          (this.leverage_orders_price /= Number(this.leverage_orders_volume)),
            (this.leverage_orders_margin_rate /= Number(
              this.leverage_orders_volume
            ));
        }
      } else if (
        ((this.leverage_positions_volume =
          this.positions_sell.volume - this.volume_order),
        (this.leverage_positions_order_volume = this.volume_order),
        (this.leverage_positions_price = this.positions_sell.price),
        (this.leverage_positions_margin = s - this.margin_order),
        (this.leverage_positions_order_margin = this.margin_order),
        (this.leverage_positions_margin_rate = this.positions_sell.margin_rate),
        (this.leverage_orders_margin = o),
        this.leverage_orders_margin)
      ) {
        for (let t = 0; t < this.orders.length; t++) {
          const e = this.orders[t];
          e.volume &&
            ((1 !== t && 3 !== t && 5 !== t && 7 !== t) ||
              ((this.leverage_orders_volume += e.volume),
              (this.leverage_orders_price += e.price * Number(e.volume)),
              (this.leverage_orders_margin_rate +=
                e.margin_rate * Number(e.volume))));
        }
        (this.leverage_orders_price /= Number(this.leverage_orders_volume)),
          (this.leverage_orders_margin_rate /= Number(
            this.leverage_orders_volume
          ));
      }
  }
  calcCommon() {
    let t = 0,
      e = 0,
      i = 0,
      r = this.calcPositions();
    for (let s = 0; s < this.orders.length; s++) {
      const r = this.orders[s];
      r.volume &&
        (V(r),
        (2 !== s && 4 !== s && 6 !== s) ||
          ((t = this.calcMargin(s, r.volume, r.price, !0, !1)),
          (t *= r.margin_rate),
          (t *= r.order_rate),
          (e += t)),
        (3 !== s && 5 !== s && 7 !== s) ||
          ((t = this.calcMargin(s, r.volume, r.price, !0, !1)),
          (t *= r.margin_rate),
          (t *= r.order_rate),
          (i += t)));
    }
    if (this.orders[0].volume) {
      this.positions_buy.order_rate ||
        (this.positions_buy.order_rate = this.orders[0].order_rate);
      const [t, e] = q(this.positions_buy, this.orders[0]);
      (this.positions_buy.price = t),
        (this.positions_buy.margin_rate = e),
        (this.positions_buy.volume += this.orders[0].volume),
        (this.positions_buy.volume_orders += this.orders[0].volume);
    }
    if (this.orders[1].volume) {
      this.positions_sell.order_rate ||
        (this.positions_sell.order_rate = this.orders[1].order_rate);
      const [t, e] = q(this.positions_sell, this.orders[1]);
      (this.positions_sell.price = t),
        (this.positions_sell.margin_rate = e),
        (this.positions_sell.volume += this.orders[1].volume),
        (this.positions_sell.volume_orders += this.orders[1].volume);
    }
    if (this.orders[0].volume || this.orders[1].volume) {
      const t = this.calcPositions();
      r = Math.max(r, t);
    }
    return (
      (this.margin = r + e + i),
      this.calcCommonFloatingLeverage(r, e, i),
      this.margin
    );
  }
  calcCommonFloatingLeverage(t, e, i) {
    if (!this.isFloatingLeverage()) return;
    const { trade_contract_size: r, trade: s } = this.symbol,
      { margin_hedged: o } = s;
    (this.leverage_positions_volume =
      this.volume_uncovered - this.volume_order),
      this.volume_hedged &&
        o &&
        r &&
        (this.leverage_positions_volume += BigInt(
          (Number(this.volume_hedged) * Number(o)) / Number(r)
        )),
      (this.leverage_positions_order_volume = this.volume_order),
      (this.leverage_positions_margin = t - this.margin_order),
      (this.leverage_positions_order_margin = this.margin_order);
    const [a, n] = q(this.positions_buy, this.positions_sell);
    if (
      ((this.leverage_positions_price = a),
      (this.leverage_positions_margin_rate = n),
      (this.leverage_orders_margin = e + i),
      this.leverage_orders_margin)
    ) {
      for (let t = 0; t < this.orders.length; t++) {
        const e = this.orders[t];
        e.volume &&
          ((this.leverage_orders_volume += e.volume),
          (this.leverage_orders_price += e.price * Number(e.volume)),
          (this.leverage_orders_margin_rate +=
            e.margin_rate * Number(e.volume)));
      }
      (this.leverage_orders_price /= Number(this.leverage_orders_volume)),
        (this.leverage_orders_margin_rate /= Number(
          this.leverage_orders_volume
        ));
    }
  }
  calcPositions() {
    let t = 0,
      e = 0;
    if (
      ((this.volume_uncovered = 0n),
      (this.volume_hedged = 0n),
      (this.volume_order = 0n),
      (this.margin_order = 0),
      this.positions_buy.volume > this.positions_sell.volume)
    ) {
      if (
        ((this.volume_uncovered =
          this.positions_buy.volume - this.positions_sell.volume),
        (this.volume_order = this.positions_buy.volume_orders),
        this.volume_order)
      )
        if (this.volume_uncovered > this.volume_order) {
          const t = this.volume_uncovered - this.volume_order;
          (e = this.calcMargin(
            0,
            this.volume_order,
            this.positions_buy.price,
            !0,
            !1
          )),
            (this.margin_order = e),
            t && (e += this.calcMargin(0, t, this.positions_buy.price, !1, !1));
        } else
          (e = this.calcMargin(
            0,
            this.volume_uncovered,
            this.positions_buy.price,
            !0,
            !1
          )),
            (this.margin_order = e);
      else
        e = this.calcMargin(
          0,
          this.volume_uncovered,
          this.positions_buy.price,
          !1,
          !1
        );
      (e *= this.positions_buy.margin_rate),
        (e *= this.positions_buy.order_rate),
        (this.margin_order *= this.positions_buy.margin_rate),
        (this.margin_order *= this.positions_buy.order_rate);
    }
    if (this.positions_buy.volume < this.positions_sell.volume) {
      if (
        ((this.volume_uncovered =
          this.positions_sell.volume - this.positions_buy.volume),
        (this.volume_order = this.positions_sell.volume_orders),
        this.volume_order)
      )
        if (this.volume_uncovered > this.volume_order) {
          const t = this.volume_uncovered - this.volume_order;
          (e = this.calcMargin(
            1,
            this.volume_order,
            this.positions_sell.price,
            !0,
            !1
          )),
            (this.margin_order = e),
            t &&
              (e += this.calcMargin(1, t, this.positions_sell.price, !1, !1));
        } else
          (e = this.calcMargin(
            1,
            this.volume_uncovered,
            this.positions_sell.price,
            !0,
            !1
          )),
            (this.margin_order = e);
      else
        e = this.calcMargin(
          1,
          this.volume_uncovered,
          this.positions_sell.price,
          !1,
          !1
        );
      (e *= this.positions_sell.margin_rate),
        (e *= this.positions_sell.order_rate),
        (this.margin_order *= this.positions_sell.margin_rate),
        (this.margin_order *= this.positions_sell.order_rate);
    }
    if (
      ((this.volume_hedged = Te.min(
        this.positions_buy.volume,
        this.positions_sell.volume
      )),
      this.volume_hedged > 0)
    ) {
      let e = 0;
      const [i, r] = q(this.positions_buy, this.positions_sell);
      (e =
        (this.positions_buy.order_rate + this.positions_sell.order_rate) / 2),
        (t = this.calcMargin(0, this.volume_hedged, i, !1, !0)),
        (t *= r),
        (t *= e);
    }
    return e + t;
  }
  calcCollateralPrice(t, e) {
    return (
      t ||
      (0 === e
        ? this.prices.findPrice(this.symbol.trade_symbol, 0)
        : 1 === e
        ? this.prices.findPrice(this.symbol.trade_symbol, 1)
        : 0)
    );
  }
  calcMargin(t, e, i, r, s) {
    const { symbol: o, account: a } = this;
    let n = 0,
      l = 0,
      c = Yi.toSize(e, o.trade_contract_size);
    const _ = Number(e);
    switch (
      (r
        ? (l = o.trade.margin_initial)
        : ((l = o.trade.margin_initial),
          o.trade.margin_maintenance && (l = o.trade.margin_maintenance)),
      s &&
        (l && (l = o.trade.margin_hedged),
        (c = Yi.toSize(e, o.trade.margin_hedged))),
      o.trade_calc_mode)
    ) {
      case 0:
        n = l > 0 ? (l * _) / a.margin_leverage : c / a.margin_leverage;
        break;
      case 5:
        n = l > 0 ? l * _ : c;
        break;
      case 2:
      case 32:
      case 38:
      case 35:
      case 36:
        n = l > 0 ? l * _ : c * i;
        break;
      case 1:
      case 33:
      case 34:
        n = l * _;
        break;
      case 3:
        l > 0
          ? (n = l * _)
          : o.trade_tick_size &&
            (n = ((c * i) / o.trade_tick_size) * o.trade_tick_value);
        break;
      case 64:
        n = 0;
        break;
      case 4:
        n = l > 0 ? (l * _) / a.margin_leverage : (c * i) / a.margin_leverage;
        break;
      case 37:
      case 39:
        n =
          l > 0
            ? l * _
            : oe((c * o.trade_face_value * i) / 100, o.currency_base_digits);
    }
    return n;
  }
}
class Gr extends Rr {
  createEntity(t) {
    return new Hr(this.account, t, this.prices);
  }
}
class Yr extends Cr {
  constructor(t, e) {
    super(t, e), (this.storage = new Fr(new Gr(t, e)));
  }
  reset() {
    this.storage.clear();
  }
  calcTick(t, e) {
    const { account: i } = this,
      r = i.currency_digits;
    this.calcAccount(t, e),
      (i.profit = 0),
      (i.storage = 0),
      (i.floating = 0),
      t.forEach((t) => {
        (i.profit = oe(i.profit + t.profit, r)),
          t.storage && (i.storage = oe(i.storage + t.storage, r)),
          (i.floating = i.profit),
          i.storage && (i.floating = oe(i.floating + i.storage, r));
      }),
      this.calcFloating();
  }
  calcTickManager(t, e) {
    const { account: i } = this,
      r = i.currency_digits;
    if (
      (this.calcAccount(t, e),
      (i.profit = 0),
      (i.storage = 0),
      (i.floating = 0),
      t.length)
    ) {
      let e = 0,
        s = 0;
      t.forEach((t) => {
        (e += t.profit), (s += t.storage);
      }),
        (i.profit = oe(e, r)),
        (i.floating = i.profit),
        0 !== s &&
          ((i.storage = oe(s, r)),
          (i.floating = oe(i.floating + i.storage, r)));
    }
    this.calcFloating();
  }
  calcAccount(t, e, i, r = !1) {
    const { account: s } = this;
    (s.profit = 0),
      (s.storage = 0),
      (s.margin = 0),
      (s.margin_initial = 0),
      (s.margin_maintenance = 0),
      (s.floating = 0),
      (s.equity = 0),
      (s.assets = 0),
      (s.liabilities = 0),
      (s.collateral = 0),
      (s.profit_excluded = 0),
      (s.acc_commission = oe(
        s.commission_daily + s.commission_monthly,
        s.currency_digits
      )),
      this.storage.margins.clear(),
      this.collectPositions(t),
      this.collectOrders(e, i, r),
      this.calcMargin(),
      this.calcFloating();
  }
  checkStopOut() {
    const { account: t } = this;
    if (((t.so_activation = 0), 0 === t.margin_so_mode)) {
      if (0 !== t.margin) {
        if (
          t.margin_level < t.margin_so_call &&
          ((t.so_activation = 1), t.margin_level < t.margin_so_so)
        )
          return (t.so_activation = 2), !0;
      } else if (
        0 != (128 & t.trade_flags) &&
        t.equity < 0 &&
        (t.profit || t.storage)
      )
        return !0;
      return !1;
    }
    if (1 === t.margin_so_mode) {
      if (0 !== t.margin) {
        if (
          t.equity < t.margin_so_call &&
          ((t.so_activation = 1), t.equity < t.margin_so_so)
        )
          return (t.so_activation = 2), !0;
      } else if (
        0 != (128 & this.account.trade_flags) &&
        t.equity < 0 &&
        (t.profit || t.storage)
      )
        return (t.so_activation = 2), !0;
      return !1;
    }
    return !1;
  }
  calcFloating() {
    this.calcFree(), this.calcEquity(), this.calcLevel();
  }
  calcMargin() {
    const { account: t } = this;
    (t.assets = 0),
      (t.liabilities = 0),
      (t.collateral = 0),
      (t.margin = this.storage.margins.calc());
  }
  calcFree() {
    const { account: t } = this,
      e = t.currency_digits;
    switch (
      ((t.margin_free = t.balance),
      (t.margin_free = oe(t.margin_free - t.margin, e)),
      t.credit && (t.margin_free = oe(t.margin_free + t.credit, e)),
      t.assets && (t.margin_free = oe(t.margin_free + t.assets, e)),
      t.liabilities && (t.margin_free = oe(t.margin_free + t.liabilities, e)),
      t.acc_commission &&
        (t.margin_free = oe(t.margin_free + t.acc_commission, e)),
      t.margin_free_mode)
    ) {
      case 1:
        t.margin_free = oe(t.margin_free + t.floating, e);
        break;
      case 2:
        t.floating > 0 && (t.margin_free = oe(t.margin_free + t.floating, e));
        break;
      case 3:
        t.floating < 0 && (t.margin_free = oe(t.margin_free + t.floating, e));
    }
    t.profit_excluded &&
      (t.margin_free = oe(t.margin_free - t.profit_excluded, e)),
      3 === t.margin_free_profit_mode &&
        t.acc_profit > 0 &&
        (t.margin_free = oe(t.margin_free - t.acc_profit, e));
  }
  calcEquity() {
    const { account: t } = this,
      e = t.currency_digits;
    (t.equity = t.balance),
      (t.equity = oe(t.equity + t.floating, e)),
      t.credit && (t.equity = oe(t.equity + t.credit, e)),
      t.assets && (t.equity = oe(t.equity + t.assets, e)),
      t.liabilities && (t.equity = oe(t.equity + t.liabilities, e)),
      t.acc_commission && (t.equity = oe(t.equity + t.acc_commission, e)),
      3 === t.margin_free_profit_mode &&
        t.acc_profit > 0 &&
        (t.equity = oe(t.equity - t.acc_profit, e));
  }
  calcLevel() {
    const { account: t } = this;
    t.margin > 0
      ? (t.margin_level = ((t.equity - t.profit_excluded) / t.margin) * 100)
      : (t.margin_level = 0);
  }
  collectPositions(t) {
    const { account: e } = this,
      i = e.currency_digits;
    t.length &&
      (t.forEach((t) => {
        if (!t || !t.trade_volume) return;
        const r = this.storage.margins.getOrCreate(t.trade_symbol);
        r &&
          r.addPosition(t) &&
          (r.isCollateral() ||
            ((e.profit = oe(e.profit + t.profit, i)),
            t.storage && (e.storage = oe(e.storage + t.storage, i)),
            r.isMarginExcludePL() &&
              t.isBuy() &&
              (e.profit_excluded = oe(e.profit_excluded + t.profit, i))));
      }),
      (e.floating = e.profit),
      e.storage && (e.floating = oe(e.floating + e.storage, i)));
  }
  collectOrders(t, e, i = !1) {
    const { account: r } = this,
      s = r.currency_digits,
      o = Boolean(e);
    if (
      (t.forEach((t) => {
        const a = this.storage.margins.getOrCreate(t.trade_symbol);
        if (a)
          if (e && e.trade_order === t.trade_order) {
            if (i) return void (e = void 0);
            a.addOrder(e),
              0 !== Se(t.commission_daily, e.commission_daily, s) &&
                (r.acc_commission = oe(
                  r.acc_commission + e.commission_daily - t.commission_daily,
                  s
                )),
              0 !== Se(t.commission_monthly, e.commission_monthly, s) &&
                (r.acc_commission = oe(
                  r.acc_commission +
                    e.commission_monthly -
                    t.commission_monthly,
                  s
                )),
              (e = void 0);
          } else a.addOrder(t, o);
      }),
      e)
    ) {
      const t = this.storage.margins.getOrCreate(e.trade_symbol);
      t &&
        (t.addOrder(e, o),
        e.commission_daily &&
          (r.acc_commission = oe(r.acc_commission + e.commission_daily, s)),
        e.commission_monthly &&
          (r.acc_commission = oe(r.acc_commission + e.commission_monthly, s)));
    }
  }
}
const Qr = { IN: 0, OUT: 1, INOUT: 2, OUT_BY: 3, STATE: 255 };
class Kr {
  constructor(t = {}) {
    (this.deal = BigInt(0)),
      (this.deal_id = ""),
      (this.trade_order = BigInt(0)),
      (this.time_create = 0),
      (this.time_update = 0),
      (this.trade_action = 0),
      (this.trade_symbol = ""),
      (this.trade_volume = BigInt(0)),
      (this.trade_reason = 0),
      (this.entry = 0),
      (this.price_open = 0),
      (this.price_close = 0),
      (this.digits = 0),
      (this.digits_currency = 0),
      (this.sl = 0),
      (this.tp = 0),
      (this.profit = 0),
      (this.rate_profit = 0),
      (this.rate_margin = 0),
      (this.commission = 0),
      (this.storage = 0),
      (this.expert = BigInt(0)),
      (this.comment = ""),
      (this.contract_size = 0),
      (this.commission_fee = 0),
      (this.external_id = ""),
      (this.position_id = BigInt(0)),
      (this.expert_position_id = BigInt(0)),
      (this.value = 0),
      (this.__isCollateral = !1),
      (this.trade_volume = t.trade_volume ?? BigInt(0)),
      (this.deal = t.deal ?? this.deal),
      (this.deal_id = t.deal_id ?? this.deal_id),
      (this.trade_symbol = t.trade_symbol ?? this.trade_symbol),
      (this.entry = t.entry ?? this.entry),
      (this.price_close = t.price_close ?? this.price_close),
      (this.trade_order = t.trade_order ?? this.trade_order),
      (this.time_update = t.time_update ?? this.time_update),
      (this.time_create = t.time_create ?? this.time_create),
      (this.trade_action = t.trade_action ?? this.trade_action),
      (this.trade_reason = t.trade_reason ?? this.trade_reason),
      (this.digits = t.digits ?? this.digits),
      (this.sl = t.sl ?? this.sl),
      (this.tp = t.tp ?? this.tp),
      (this.profit = t.profit ?? this.profit),
      (this.rate_profit = t.rate_profit ?? this.rate_profit),
      (this.rate_margin = t.rate_margin ?? this.rate_margin),
      (this.commission = t.commission ?? this.commission),
      (this.price_open = t.price_open ?? this.price_open),
      (this.storage = t.storage ?? this.storage),
      (this.expert = t.expert ?? this.expert),
      (this.position_id = t.position_id ?? this.position_id),
      (this.comment = t.comment ?? this.comment),
      (this.contract_size = t.contract_size ?? this.contract_size),
      (this.digits_currency = t.digits_currency ?? this.digits_currency),
      (this.commission_fee = t.commission_fee ?? this.commission_fee),
      (this.external_id = t.external_id ?? this.external_id),
      (this.expert_position_id =
        t.expert_position_id ?? this.expert_position_id);
  }
  copy() {
    return new Kr({
      trade_volume: this.trade_volume,
      deal: this.deal,
      deal_id: this.deal_id,
      trade_symbol: this.trade_symbol,
      entry: this.entry,
      price_close: this.price_close,
      trade_order: this.trade_order,
      time_update: this.time_update,
      time_create: this.time_create,
      trade_action: this.trade_action,
      trade_reason: this.trade_reason,
      digits: this.digits,
      sl: this.sl,
      tp: this.tp,
      profit: this.profit,
      rate_profit: this.rate_profit,
      rate_margin: this.rate_margin,
      commission: this.commission,
      price_open: this.price_open,
      storage: this.storage,
      expert: this.expert,
      position_id: this.position_id,
      comment: this.comment,
      contract_size: this.contract_size,
      digits_currency: this.digits_currency,
      commission_fee: this.commission_fee,
      external_id: this.external_id,
      expert_position_id: this.expert_position_id,
      __isCollateral: this.__isCollateral,
    });
  }
  isIn() {
    return this.entry === Qr.IN;
  }
  isOut() {
    return this.entry === Qr.OUT;
  }
  isInOut() {
    return this.entry === Qr.INOUT;
  }
  isOutBy() {
    return this.entry === Qr.OUT_BY;
  }
  hasProfit() {
    return this.entry === Qr.OUT || this.entry === Qr.INOUT;
  }
  isBuy() {
    return ke(this.trade_action);
  }
  isSell() {
    return Ce(this.trade_action);
  }
  isTrade() {
    return 0 === this.trade_action || 1 === this.trade_action;
  }
  isCredit() {
    return 3 === this.trade_action || 6 === this.trade_action;
  }
  isCanceled() {
    return 13 === this.trade_action || 14 === this.trade_action;
  }
  isService() {
    const t = this.trade_reason;
    return 6 === t || 8 === t || 11 === t || 12 === t || 13 === t || 14 === t;
  }
  isBalance() {
    return Ee(this.trade_action);
  }
  isBalanceAllowed() {
    return Be(this.trade_action);
  }
  isCommission() {
    const t = this.trade_action;
    return 7 === t || 8 === t || 9 === t;
  }
  isCollateral(t) {
    return (
      void 0 !== this.__isCollateral ||
        (t && (this.__isCollateral = t.isCollateral())),
      this.__isCollateral
    );
  }
}
class Wr {
  constructor(t, e, i) {
    (this.spreads = []),
      (this.spreads_volumes_buy = []),
      (this.spreads_volumes_sell = []),
      (this.new_order_type = 0),
      (this.new_order_volume = 0n),
      (this.new_position_type = 0),
      (this.new_position_volume = 0n),
      (this.margins = t),
      (this.margins_buy = e),
      (this.margins_sell = i);
  }
  clear() {
    this.margins.clear(),
      this.margins_buy.clear(),
      this.margins_sell.clear(),
      (this.spreads = []),
      (this.spreads_volumes_buy = []),
      (this.spreads_volumes_sell = []),
      (this.new_order_type = 0),
      (this.new_order_volume = 0n),
      (this.new_position_type = 0),
      (this.new_position_volume = 0n);
  }
}
class jr extends Ar {
  constructor() {
    super(...arguments),
      (this.position_type = 0),
      (this.position_volume = 0n),
      (this.position_size = 0),
      (this.position_price_open = 0),
      (this.position_price_curr = 0),
      (this.osition_margin = 0),
      (this.position_margin_rate = 0),
      (this.orders_buy_volume = 0n),
      (this.orders_sell_volume = 0n),
      (this.orders_buy_price = 0),
      (this.orders_sell_price = 0),
      (this.orders_buy_margin = 0),
      (this.orders_sell_margin = 0),
      (this.orders_buy_margin_rate = 0),
      (this.orders_sell_margin_rate = 0),
      (this.orders_new = !1),
      (this.margin = 0),
      (this.volume = 0n),
      (this.volume_spread = 0n),
      (this.volume_type = 0),
      (this.volume_rate = 0);
  }
  addOrder(t, e) {
    if (this.symbol.isCollateral()) return !1;
    const i = Yi.toSize(t.volume_current, t.contract_size);
    if (i <= 0) return !0;
    let r = 0,
      s = t.order_type;
    e &&
      ((this.orders_new = !0),
      1 === t.activation_mode &&
        (t.isLimit() || t.isStop()) &&
        (s = t.isBuy() ? 0 : 1),
      2 === t.activation_mode && t.isStopLimit() && (s = t.isBuy() ? 2 : 3));
    const o = this.symbol.orderRate(s, !0);
    if (o <= 0) return !0;
    let a = t.price_order;
    if (
      (a || (0 !== s && 1 !== s) || (a = t.price_current),
      (6 !== s && 7 !== s) || (a = t.price_trigger),
      0 === s || 2 === s || 4 === s || 6 === s)
    ) {
      if (
        ((r = t.margin_rate
          ? t.margin_rate
          : this.prices.rateBuyMargin(
              this.symbol,
              this.account.account_currency,
              a
            )),
        r <= 0)
      )
        return !0;
      let e = F(this.symbol, this.account, s, i, a, !0, !1);
      return (
        (e *= r),
        (e *= o),
        (this.orders_buy_margin = oe(
          this.orders_buy_margin + e,
          this.account.currency_digits
        )),
        (this.orders_buy_volume += t.volume_current),
        (this.orders_buy_price += a * Number(t.volume_current)),
        (this.orders_buy_margin_rate += r * Number(t.volume_current)),
        !0
      );
    }
    if (1 === s || 3 === s || 5 === s || 7 === s) {
      if (
        ((r = t.margin_rate
          ? t.margin_rate
          : this.prices.rateSellMargin(
              this.symbol,
              this.account.account_currency,
              a
            )),
        r <= 0)
      )
        return !0;
      let e = F(this.symbol, this.account, s, i, a, !0, !1);
      return (
        (e *= r),
        (e *= o),
        (this.orders_sell_margin = oe(
          this.orders_sell_margin + e,
          this.account.currency_digits
        )),
        (this.orders_sell_volume += t.volume_current),
        (this.orders_sell_price += a * Number(t.volume_current)),
        (this.orders_sell_margin_rate += r * Number(t.volume_current)),
        !0
      );
    }
    return !1;
  }
  addPosition(t) {
    let e = 0;
    return (
      t.isBuy() && (this.position_type = 0),
      t.isSell() && (this.position_type = 1),
      (this.position_size = Yi.toSize(t.trade_volume, t.contract_size)),
      (this.position_price_open = t.price_open),
      (this.position_price_curr = t.price_close),
      (this.position_margin_rate = t.rate_margin),
      (e = F(
        this.symbol,
        this.account,
        this.position_type,
        this.position_size,
        this.position_price_open,
        !1,
        !0
      )),
      (e *= t.rate_margin),
      (e *= this.symbol.orderRate(this.position_type, !1)),
      (this.osition_margin = oe(e, this.account.currency_digits)),
      (this.position_volume = t.trade_volume),
      !0
    );
  }
  calc() {
    let t = this.orders_buy_margin,
      e = this.orders_sell_margin;
    if (this.symbol.isCollateral()) return this.calcCollateral(this.account);
    if (((this.margin = 0), 0n !== this.position_volume)) {
      if (0 === this.position_type)
        if (((t += this.osition_margin), this.symbol.isFORTS())) {
          const t = F(
            this.symbol,
            this.account,
            1,
            this.position_size,
            this.position_price_open,
            !1,
            !0
          );
          e = oe(e - t, this.account.currency_digits);
        } else
          this.orders_sell_margin &&
            this.orders_sell_volume &&
            (e -= oe(
              (this.orders_sell_margin / Number(this.orders_sell_volume)) *
                Number(this.position_volume),
              this.account.currency_digits
            ));
      if (1 === this.position_type)
        if (((e += this.osition_margin), this.symbol.isFORTS())) {
          const e = F(
            this.symbol,
            this.account,
            0,
            this.position_size,
            this.position_price_open,
            !1,
            !0
          );
          t = oe(t - e, this.account.currency_digits);
        } else
          this.orders_buy_margin &&
            this.orders_buy_volume &&
            (t -= oe(
              (this.orders_buy_margin / Number(this.orders_buy_volume)) *
                Number(this.position_volume),
              this.account.currency_digits
            ));
    }
    this.margin = Math.max(t, e);
    let i = this.orders_buy_volume,
      r = this.orders_sell_volume;
    return (
      (this.volume = 0n),
      (this.volume_rate = 0),
      (this.volume_type = 0),
      0n !== this.position_volume &&
        (0 === this.position_type && (i += this.position_volume),
        1 === this.position_type && (r += this.position_volume)),
      i > r
        ? ((this.volume = i), (this.volume_type = 0))
        : i < r
        ? ((this.volume = r), (this.volume_type = 1))
        : ((this.volume = i), (this.volume_type = this.position_type)),
      this.volume
        ? (this.volume_rate = this.margin / Number(this.volume))
        : (this.volume_rate = 0),
      this.calcFloatingLeverage(t, e),
      this.margin
    );
  }
  getSpreadLeg() {
    return this.leg;
  }
  setSpreadLeg(t) {
    this.leg = t;
  }
  setSpreadVolume(t) {
    this.volume_spread = t;
  }
  getSpreadVolume() {
    return this.volume_spread;
  }
  getVolume() {
    return this.volume;
  }
  getVolumeType() {
    return this.volume_type;
  }
  getVolumeRate() {
    return this.volume_rate;
  }
  volumeDecrease(t) {
    this.volume -= Te.min(this.volume, t);
  }
  hasNewOrder() {
    return this.orders_new;
  }
  hasCollateral() {
    return Boolean(this.position_volume && this.symbol.isCollateral());
  }
  calcCollateral(t) {
    let e = 0,
      i = 0;
    if (
      ((this.margin = 0),
      (this.volume = 0n),
      (this.volume_type = 0),
      (this.volume_rate = 0),
      0n !== this.position_volume)
    ) {
      if (0 === this.position_type) {
        const i = this.prices.rateBuy(
            this.symbol,
            this.symbol.currency_profit,
            this.account.account_currency
          ),
          r = this.calcCollateralPrice(
            this.position_price_curr,
            this.position_type
          );
        (e = oe(this.position_size * r, this.account.currency_digits)),
          (e *= this.symbol.trade.margin_rate_liquidity),
          (e = oe(e * i, this.account.currency_digits)),
          (t.assets = oe(t.assets + e, this.account.currency_digits)),
          (t.collateral = oe(t.collateral + e, this.account.currency_digits));
      }
      if (1 === this.position_type) {
        const e = this.prices.rateSell(
            this.symbol,
            this.symbol.currency_profit,
            this.account.account_currency
          ),
          r = this.calcCollateralPrice(
            this.position_price_curr,
            this.position_type
          );
        (i = oe(this.position_size * r, this.account.currency_digits)),
          (i = oe(i * e, this.account.currency_digits)),
          (t.liabilities = oe(t.liabilities - i, this.account.currency_digits)),
          (t.collateral = oe(t.collateral - i, this.account.currency_digits));
      }
    }
    return this.margin;
  }
  calcFloatingLeverage(t, e) {
    this.isFloatingLeverage() &&
      (t >= e
        ? (0 === this.position_type &&
            ((this.leverage_positions_volume = this.position_volume),
            (this.leverage_positions_order_volume = 0n),
            (this.leverage_positions_price = this.position_price_open),
            (this.leverage_positions_margin = this.osition_margin),
            (this.leverage_positions_order_margin = 0),
            (this.leverage_positions_margin_rate = this.position_margin_rate)),
          (this.leverage_orders_volume = this.orders_buy_volume),
          (this.leverage_orders_margin = this.orders_buy_margin),
          this.orders_buy_volume &&
            ((this.leverage_orders_price =
              this.orders_buy_price / Number(this.orders_buy_volume)),
            (this.leverage_orders_margin_rate =
              this.orders_buy_margin_rate / Number(this.orders_buy_volume))))
        : (1 === this.position_type &&
            ((this.leverage_positions_volume = this.position_volume),
            (this.leverage_positions_order_volume = 0n),
            (this.leverage_positions_price = this.position_price_open),
            (this.leverage_positions_margin = this.osition_margin),
            (this.leverage_positions_order_margin = 0),
            (this.leverage_positions_margin_rate = this.position_margin_rate)),
          (this.leverage_orders_volume = this.orders_sell_volume),
          (this.leverage_orders_margin = this.orders_sell_margin),
          this.orders_buy_volume &&
            ((this.leverage_orders_price =
              this.orders_sell_price / Number(this.orders_sell_volume)),
            (this.leverage_orders_margin_rate =
              this.orders_sell_margin_rate /
              Number(this.orders_sell_volume)))));
  }
  calcCollateralPrice(t, e) {
    return (
      t ||
      (0 === e
        ? this.prices.findPrice(this.symbol.trade_symbol, 0)
        : 1 === e
        ? this.prices.findPrice(this.symbol.trade_symbol, 1)
        : 0)
    );
  }
}
class Xr extends Rr {
  createEntity(t) {
    return new jr(this.account, t, this.prices);
  }
}
const Jr = 1e8;
class Zr extends Cr {
  constructor(t, e, i) {
    super(t, e),
      (this.spreadsController = i),
      (this.storage = new Wr(new Xr(t, e), new Xr(t, e), new Xr(t, e)));
  }
  reset() {
    this.storage.clear();
  }
  calcTick(t, e) {
    const { account: i } = this;
    this.calcAccount(t, e),
      (i.profit = 0),
      (i.storage = 0),
      (i.floating = 0),
      t.forEach((t) => {
        (i.profit = oe(i.profit + t.profit, i.currency_digits)),
          t.storage &&
            (i.storage = oe(i.storage + t.storage, i.currency_digits));
      }),
      (i.floating = i.profit),
      i.storage && (i.floating = oe(i.floating + i.storage, i.currency_digits)),
      this.calcFloating();
  }
  clearMargins() {
    this.storage.margins.clear(),
      (this.storage.new_order_type = 0),
      (this.storage.new_order_volume = 0n),
      (this.storage.new_position_type = 0),
      (this.storage.new_position_volume = 0n);
  }
  calcAccount(t, e, i, r = !1) {
    const { account: s } = this;
    (s.profit = 0),
      (s.storage = 0),
      (s.margin = 0),
      (s.margin_initial = 0),
      (s.margin_maintenance = 0),
      (s.floating = 0),
      (s.equity = 0),
      (s.assets = 0),
      (s.liabilities = 0),
      (s.collateral = 0),
      (s.profit_excluded = 0),
      (s.acc_commission = oe(
        s.commission_daily + s.commission_monthly,
        s.currency_digits
      )),
      this.clearMargins(),
      this.collectPositions(t, i),
      this.collectOrders(e, i, r),
      this.calcMargin(),
      this.calcFloating();
  }
  checkStopOut() {
    const { account: t } = this;
    return (
      (this.account.so_activation = 0),
      0 === this.account.margin_so_mode
        ? 0 !== t.margin &&
          t.margin_level < this.account.margin_so_call &&
          ((t.so_activation = 1), t.margin_level < this.account.margin_so_so) &&
          ((t.so_activation = 2), !0)
        : 1 === this.account.margin_so_mode &&
          0 !== t.margin &&
          this.account.equity < this.account.margin_so_call &&
          ((this.account.so_activation = 1),
          t.equity < this.account.margin_so_so) &&
          ((t.so_activation = 2), !0)
    );
  }
  calcFloating() {
    this.calcFree(), this.calcEquity(), this.calcLevel();
  }
  calcMargin() {
    (this.account.assets = 0),
      (this.account.liabilities = 0),
      (this.account.collateral = 0),
      (this.account.margin = this.storage.margins.calc()),
      this.calcMarginSpreads();
  }
  calcFree() {
    const { account: t } = this;
    switch (
      ((t.margin_free = t.balance),
      (t.margin_free = oe(t.margin_free - t.margin, t.currency_digits)),
      t.credit &&
        (t.margin_free = oe(t.margin_free + t.credit, t.currency_digits)),
      t.assets &&
        (t.margin_free = oe(t.margin_free + t.assets, t.currency_digits)),
      t.liabilities &&
        (t.margin_free = oe(t.margin_free + t.liabilities, t.currency_digits)),
      t.acc_commission &&
        (t.margin_free = oe(
          t.margin_free + t.acc_commission,
          t.currency_digits
        )),
      this.account.margin_free_mode)
    ) {
      case 1:
        t.margin_free = oe(t.margin_free + t.floating, t.currency_digits);
        break;
      case 2:
        t.floating > 0 &&
          (t.margin_free = oe(t.margin_free + t.floating, t.currency_digits));
        break;
      case 3:
        t.floating < 0 &&
          (t.margin_free = oe(t.margin_free + t.floating, t.currency_digits));
    }
    t.profit_excluded &&
      (t.margin_free = oe(
        t.margin_free - t.profit_excluded,
        t.currency_digits
      )),
      1 === this.account.margin_free_profit_mode &&
        t.acc_profit > 0 &&
        (t.margin_free = oe(t.margin_free - t.acc_profit, t.currency_digits));
  }
  calcEquity() {
    const { account: t } = this;
    (t.equity = t.balance),
      (t.equity = oe(t.equity + t.floating, t.currency_digits)),
      t.credit && (t.equity = oe(t.equity + t.credit, t.currency_digits)),
      t.assets && (t.equity = oe(t.equity + t.assets, t.currency_digits)),
      t.liabilities &&
        (t.equity = oe(t.equity + t.liabilities, t.currency_digits)),
      t.acc_commission &&
        (t.equity = oe(t.equity + t.acc_commission, t.currency_digits)),
      1 === t.margin_free_profit_mode &&
        t.acc_profit > 0 &&
        (t.equity = oe(t.equity - t.acc_profit, t.currency_digits));
  }
  calcLevel() {
    const { account: t } = this;
    t.margin > 0
      ? (t.margin_level = ((t.equity - t.profit_excluded) / t.margin) * 100)
      : (t.margin_level = 0);
  }
  calcMarginSpreads() {
    const { account: t } = this;
    if (!this.spreadsController.legsTotal()) return;
    (this.storage.spreads = []),
      this.storage.margins.forEach((t) => {
        const e = t.name();
        this.storage.spreads = this.spreadsController.legsGetBySymbol(e);
      });
    let e = 0;
    const i = { value: 0 };
    for (; this.calcMarginSpreadMax(i); )
      Se(i.value, 0, t.currency_digits) > 0 &&
        (e = oe(e + i.value, t.currency_digits));
    (e = Math.min(t.margin, e)),
      (t.margin = oe(t.margin - e, t.currency_digits));
  }
  calcMarginSpreadMax(t) {
    var e, i;
    let r,
      s = 0,
      o = 0,
      a = 0;
    const n = { volume_ratio: 0 };
    let l;
    const c = { volume_ratio: 0 };
    let _;
    t.value = 0;
    for (let d = 0; d < this.storage.spreads.length; d++) {
      const t = this.storage.spreads[d].spread;
      if (!this.marginsLegsBuild()) break;
      (l = G(t, this.storage.margins_buy, t.legs_a, n)),
        (_ = G(t, this.storage.margins_sell, t.legs_b, c)),
        l && _ && ((r = Math.min(n.volume_ratio, c.volume_ratio)), r > 0)
          ? ((s = this.calcMarginSpread(
              t,
              t.legs_a,
              t.legs_b,
              r,
              this.storage.margins_buy,
              this.storage.margins_sell
            )),
            Se(s, 0, this.account.currency_digits) > 0 &&
              (s > o || t.preferable(a)) &&
              ((o = s),
              (a = t.margin_type),
              H(this.storage.margins_buy, this.storage.spreads_volumes_buy),
              H(this.storage.margins_sell, this.storage.spreads_volumes_sell)))
          : ((l = G(t, this.storage.margins_sell, t.legs_a, n)),
            (_ = G(t, this.storage.margins_buy, t.legs_b, c)),
            l &&
              _ &&
              ((r = Math.min(n.volume_ratio, c.volume_ratio)), r > 0) &&
              ((s = this.calcMarginSpread(
                t,
                t.legs_a,
                t.legs_b,
                r,
                this.storage.margins_sell,
                this.storage.margins_buy
              )),
              Se(s, 0, this.account.currency_digits) > 0 &&
                (s > o || t.preferable(a)) &&
                ((o = s),
                (a = t.margin_type),
                H(this.storage.margins_buy, this.storage.spreads_volumes_buy),
                H(
                  this.storage.margins_sell,
                  this.storage.spreads_volumes_sell
                ))));
    }
    if (((t.value = Math.min(this.account.margin, o)), t.value > 0)) {
      if (
        this.storage.spreads_volumes_buy.length ===
        this.storage.margins_buy.total()
      )
        for (let t = 0; t < this.storage.spreads_volumes_buy.length; t++)
          null == (e = this.storage.margins_buy.at(t)) ||
            e.volumeDecrease(this.storage.spreads_volumes_buy[t]);
      if (
        this.storage.spreads_volumes_sell.length ===
        this.storage.margins_sell.total()
      )
        for (let t = 0; t < this.storage.spreads_volumes_sell.length; t++)
          null == (i = this.storage.margins_sell.at(t)) ||
            i.volumeDecrease(this.storage.spreads_volumes_sell[t]);
      return !0;
    }
    return !1;
  }
  calcMarginSpread(t, e, i, r, s, o) {
    switch (t.margin_type) {
      case 0: {
        const a = { new_order: !1 };
        return (
          this.calcMarginSpreadLegRatio(e, s, r, a) +
          this.calcMarginSpreadLegRatio(i, o, r, a) -
          (t.margin_initial * r) / Jr
        );
      }
      case Li: {
        const t = { new_order: !1 },
          e = this.calcMarginSpreadLeg(s, t),
          i = this.calcMarginSpreadLeg(o, t);
        return (
          (e >= i ? o : s).forEach((t) => {
            t.getSpreadLeg() && t.setSpreadVolume(t.getVolume());
          }),
          Math.min(e, i)
        );
      }
      case 2: {
        const a = { new_order: !1 },
          n = this.calcMarginSpreadLegRatio(e, s, r, a),
          l = this.calcMarginSpreadLegRatio(i, o, r, a),
          c =
            !a.new_order && t.margin_maintenance
              ? t.margin_maintenance
              : t.margin_initial;
        return oe((n * c) / 100 + (l * c) / 100, this.account.currency_digits);
      }
      case 3: {
        const a = { new_order: !1 },
          n = this.calcMarginSpreadLegRatio(e, s, r, a),
          l = this.calcMarginSpreadLegRatio(i, o, r, a),
          c =
            !a.new_order && t.margin_maintenance
              ? t.margin_maintenance
              : t.margin_initial,
          _ = Math.abs(n - l) + (c * r) / Jr;
        return oe(n + l - _, this.account.currency_digits);
      }
    }
    return 0;
  }
  calcMarginSpreadLegRatio(t, e, i, r) {
    let s = 0,
      o = 0n;
    const a = e.getAll();
    for (let n = 0; n < a.length; n++) {
      const e = a[n],
        l = e.getSpreadLeg();
      if (!l) continue;
      let c = 0;
      for (c = 0; c < t.length && t[c] !== l; c++) t.length;
      const _ = e.getVolume();
      (o = BigInt(l.spread_ratio * i)),
        (o = Te.min(_, o)),
        (s = oe(
          s + e.getVolumeRate() * Number(o),
          this.account.currency_digits
        )),
        e.setSpreadVolume(o),
        (r.new_order = r.new_order || e.hasNewOrder());
    }
    return s;
  }
  calcMarginSpreadLeg(t, e) {
    let i = 0;
    return (
      t.forEach((t) => {
        const r = t.getSpreadLeg(),
          s = t.getVolume();
        r &&
          ((i = oe(
            i + t.getVolumeRate() * Number(s),
            this.account.currency_digits
          )),
          (e.new_order = e.new_order || t.hasNewOrder()));
      }),
      i
    );
  }
  marginsLegsBuild() {
    return (
      this.storage.margins_buy.clear(),
      this.storage.margins_sell.clear(),
      this.storage.margins.forEach((t) => {
        t.setSpreadLeg(),
          t.setSpreadVolume(0n),
          t.getVolume() &&
            (0 === t.getVolumeType()
              ? this.storage.margins_buy.add(t)
              : this.storage.margins_sell.add(t));
      }),
      Boolean(
        this.storage.margins_buy.total() || this.storage.margins_sell.total()
      )
    );
  }
  collectPositions(t, e) {
    const { account: i } = this,
      r = i.currency_digits;
    t.forEach((t) => {
      if (!t || 0n === t.trade_volume) return;
      const s = this.storage.margins.getOrCreate(t.trade_symbol);
      s &&
        s.addPosition(t) &&
        (s.isCollateral() ||
          (e &&
            e.trade_symbol === t.trade_symbol &&
            ((this.storage.new_position_type = t.trade_action),
            (this.storage.new_position_volume = t.trade_volume)),
          (i.profit = oe(i.profit + t.profit, r)),
          (i.storage = oe(i.storage + t.storage, r)),
          s.isMarginExcludePL() &&
            t.isBuy() &&
            (i.profit_excluded = oe(i.profit_excluded + t.profit, r))));
    }),
      (i.floating = i.profit),
      (i.floating = oe(i.floating + i.storage, r));
  }
  collectOrders(t, e = null, i) {
    const { account: r } = this,
      { currency_digits: s } = this.account;
    let o = e;
    const a = Boolean(o);
    if (
      (t.forEach((t) => {
        if (!t) return;
        const e = this.storage.margins.getOrCreate(t.trade_symbol);
        if (e)
          if (o && o.trade_order === t.trade_order) {
            if (i) return void (o = null);
            e.addOrder(o, a),
              0 !== Se(t.commission_daily, o.commission_daily, s) &&
                (r.acc_commission = oe(
                  r.acc_commission + o.commission_daily - t.commission_daily,
                  s
                )),
              0 !== Se(t.commission_monthly, o.commission_monthly, s) &&
                (r.acc_commission = oe(
                  r.acc_commission +
                    (o.commission_monthly - t.commission_monthly),
                  s
                )),
              (this.storage.new_order_type = o.order_type),
              (this.storage.new_order_volume = o.volume_current),
              (o = null);
          } else e.addOrder(t, a);
      }),
      o)
    ) {
      const t = this.storage.margins.getOrCreate(o.trade_symbol);
      t &&
        (t.addOrder(o, a),
        o.commission_daily &&
          (r.acc_commission = oe(
            r.acc_commission + o.commission_daily,
            r.currency_digits
          )),
        o.commission_monthly &&
          (r.acc_commission = oe(r.acc_commission + o.commission_monthly, s)),
        (this.storage.new_order_type = o.order_type),
        (this.storage.new_order_volume = o.volume_current));
    }
  }
}
class ts {
  constructor(t, e, i) {
    (this.account = i),
      (this.converterController = t),
      (this.spreadsController = e),
      (this.marginExchange = new Vr(this.account, this.converterController)),
      (this.marginHedged = new Yr(this.account, this.converterController)),
      (this.marginRetail = new Zr(
        this.account,
        this.converterController,
        this.spreadsController
      ));
  }
  calcAccount(t, e, i, r) {
    const { account: s } = this,
      o = s.margin_mode;
    1 !== o
      ? 2 !== o
        ? this.marginRetail.calcAccount(e, t, i, r)
        : this.marginHedged.calcAccount(e, t, i, r)
      : this.marginExchange.calcAccount(e, t, i, r);
  }
  checkStopOut(t) {
    const e = t.margin_mode;
    1 !== e
      ? 2 !== e
        ? this.marginRetail.checkStopOut()
        : this.marginHedged.checkStopOut()
      : this.marginExchange.checkStopOut();
  }
  static isHedgedMargin(t) {
    return 2 === t.margin_mode;
  }
}
class es {
  constructor(t, e) {
    (this.value = 0), (this.result = t ?? 1), (this.value = e ?? 0);
  }
  valid() {
    return 0 === this.result;
  }
  empty() {
    return !this.value;
  }
  applyLeverageTier(t, e) {
    this.empty() || (this.value = oe(this.value * t, e));
  }
}
class is {
  constructor(t, e) {
    (this.rate = 0),
      (this.money = new es()),
      (this.rate = t ?? 0),
      (this.money = e ?? new es());
  }
  empty() {
    return (!this.rate || this.money.valid()) && this.money.empty();
  }
  applyLeverageTier(t, e) {
    this.rate &&
      ((this.rate = oe(this.rate * t, 7)), this.money.applyLeverageTier(t, e));
  }
}
class rs {
  constructor(t, e) {
    (this.initial = t ?? new is()), (this.maintenance = e ?? new is());
  }
  empty() {
    return this.initial.empty() && this.maintenance.empty();
  }
  applyLeverageTier(t, e) {
    this.initial.applyLeverageTier(t.margin_rate_initial, e),
      this.maintenance.applyLeverageTier(t.margin_rate_maintenance, e);
  }
}
class ss {
  constructor(t, e, i, r, s) {
    (this.converterController = t),
      (this.spreadsController = e),
      (this.ticksController = i),
      (this.account = r),
      (this.symbol = s);
  }
  getGroupLeverage(t) {
    return t.rules.find((t) => Hi.check(t.path, this.symbol.trade.symbol_path));
  }
  calculateMargins(t) {
    const { margin_rates_initial: e, margin_rates_maintenance: i } =
      this.symbol.trade;
    return t >= e.length || t >= i.length
      ? new rs()
      : new rs(
          new is(e[t], this.calculateMargin(t, !0)),
          new is(i[t], this.calculateMargin(t, !1))
        );
  }
  calculateMargin(t, e = !1) {
    const { symbol: i } = this,
      r = this.account.copy();
    r.rules = [];
    const { currency_digits: s, account_currency: o } = r,
      a = new ts(this.converterController, this.spreadsController, r),
      n = new kr();
    (n.trade_symbol = i.trade_symbol),
      (n.order_type = t),
      (n.volume_initial = 1n * BigInt(10 ** 8)),
      (n.volume_current = n.volume_initial),
      (n.contract_size = i.trade_contract_size),
      (n.order_state = 0),
      (n.digits = i.digits),
      (n.digits_currency = s);
    const l = this.ticksController.getTick(i.trade_symbol, !1);
    return l
      ? ((n.price_order = (function (t, e) {
          return 0 === e ? t.ask : 1 === e ? t.bid : 0;
        })(l, t)),
        n.price_order <= 0
          ? new es(10021)
          : (n.isBuy()
              ? (n.margin_rate = this.converterController.rateBuyMargin(
                  i,
                  o,
                  n.price_order
                ))
              : (n.margin_rate = this.converterController.rateSellMargin(
                  i,
                  o,
                  n.price_order
                )),
            n.margin_rate <= 0
              ? new es(10021)
              : (e ? a.calcAccount([], [], n, !1) : a.calcAccount([n], []),
                new es(0, r.margin))))
      : new es(10021);
  }
  getLeverages() {
    const { rules: t } = this.account;
    if (t.length && t[0].tiers.length)
      for (let i = 0; i < t.length; i++) {
        const e = t[i],
          r = { floating: !0, mode: Y(e.range_mode), list: [] };
        if (
          (Object.values(xe).forEach((t) => {
            const i = [];
            e.tiers.forEach((e) => {
              const r = this.calculateMargins(t);
              var s;
              r.applyLeverageTier(e, this.account.currency_digits),
                i.push({
                  from: e.range_from,
                  to: ((s = e.range_to), s !== ce ? s : 1 / 0),
                  initial: {
                    rate: r.initial.rate,
                    money: r.initial.money.value,
                  },
                  maintenance: {
                    rate: r.maintenance.rate,
                    money: r.maintenance.money.value,
                  },
                });
            }),
              (r.list[t] = i);
          }),
          r.list.length)
        )
          return r;
      }
    const e = { floating: !1, mode: Y(), list: [] };
    return (
      Object.values(xe).forEach((t) => {
        const i = [],
          r = this.calculateMargins(t);
        i.push({
          initial: { rate: r.initial.rate, money: r.initial.money.value },
          maintenance: {
            rate: r.maintenance.rate,
            money: r.maintenance.money.value,
          },
        }),
          (e.list[t] = i);
      }),
      e
    );
  }
}
class os {
  constructor(t, e, i, r, s) {
    (this.symbolsController = t),
      (this.converterController = e),
      (this.spreadsController = i),
      (this.ticksController = r),
      (this.account = s);
  }
  calcLeverageForSymbol(t) {
    const e = this.symbolsController.getFullSymbolByName(t);
    return e
      ? new ss(
          this.converterController,
          this.spreadsController,
          this.ticksController,
          this.account,
          e
        ).getLeverages()
      : null;
  }
}
class as {
  constructor(t) {
    this.leverageController = t;
  }
  getLeveragesBySymbol(t) {
    return this.leverageController.calcLeverageForSymbol(t);
  }
}
class ns {
  constructor(t, e, i, r, s) {
    (this.controller = new ts(i, r, s.getAccount())),
      (this.leverageController = new os(t, i, r, e, s.getAccount())),
      (this.view = new as(this.leverageController));
  }
}
class ls {
  constructor(t) {
    this.ratesApi = t;
  }
  load(t) {
    return this.ratesApi.getRates(t);
  }
  destroy() {
    this.ratesApi.destroy();
  }
}
const cs = {
    M1: 1,
    M5: 5,
    M15: 15,
    M30: 30,
    H1: 60,
    H4: 240,
    D1: 1440,
    W1: 10080,
    MN: 43200,
  },
  _s = {
    M1: 1,
    M2: 2,
    M3: 3,
    M4: 4,
    M5: 5,
    M6: 6,
    M10: 10,
    M12: 12,
    M15: 15,
    M20: 20,
    M30: 30,
    H1: 16385,
    H2: 16386,
    H3: 16387,
    H4: 16388,
    H6: 16390,
    H8: 16392,
    H12: 16396,
    D1: 16408,
    W1: 32769,
    MON1: 49153,
  };
class ds extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  async getRates(t) {
    try {
      const e = await this.socket.sendCommand(
        11,
        (function (t) {
          return ee.serialize([
            {
              propType: 11,
              propValue: (t.symbol || "").substring(0, 32),
              propLength: 64,
            },
            { propType: 5, propValue: Q(t.period) },
            { propType: 3, propValue: t.from || 0 },
            { propType: 3, propValue: t.to || 0 },
          ]);
        })(t)
      );
      return { buffer: e.resBody };
    } catch (e) {
      const { code: t, message: i, command: r } = e;
      throw e;
    }
  }
  on(t) {
    let e = this.map.get(t);
    return (
      e || ((e = this.onUpdate.bind(this, t)), this.map.set(t, e)),
      this.socket.on(25, e),
      this
    );
  }
  off(t) {
    const e = this.map.get(t);
    return e && this.socket.off(25, e), this;
  }
  onUpdate(t, e) {
    t(B(e.resBody).map((t) => t[24]));
  }
  destroy() {
    this.socket.off(25);
  }
}
class hs {
  constructor(t) {
    this.ratesController = t;
  }
  getRates(t) {
    return this.ratesController.load(t);
  }
}
class ps {
  constructor(t) {
    (this.controller = new ls(new ds(t))),
      (this.view = new hs(this.controller));
  }
}
class us {
  constructor(t) {
    this.otpController = t;
  }
  static async connect(t) {
    await Ye.connect(t);
  }
  async disconnect(t) {
    return this.otpController.disconnect(t);
  }
}
class ms {
  constructor(t) {
    (this.controller = new Ye(new Qe(t))),
      (this.view = new us(this.controller));
  }
}
class gs {
  constructor() {
    (this.balance = 0),
      (this.profit = 0),
      (this.swap = 0),
      (this.commission = 0),
      (this.commissionFee = 0),
      (this.buysell = 0),
      (this.credit = 0),
      (this.deposit = 0),
      (this.withdrawal = 0);
  }
  clear() {
    return (
      (this.balance = 0),
      (this.profit = 0),
      (this.swap = 0),
      (this.commission = 0),
      (this.commissionFee = 0),
      (this.buysell = 0),
      (this.credit = 0),
      (this.deposit = 0),
      (this.withdrawal = 0),
      this
    );
  }
  positionAdd(t) {
    const e = t.digits_currency;
    return (
      (this.balance = we(this.balance, t.profit, e)),
      t.isCredit()
        ? ((this.credit = we(this.credit, t.profit, e)), this)
        : 2 === t.trade_action && t.profit > 0
        ? ((this.deposit = we(this.deposit, t.profit, e)), this)
        : 2 === t.trade_action && t.profit < 0
        ? ((this.withdrawal = we(this.withdrawal, t.profit, e)), this)
        : t.isBalance()
        ? ((this.profit = we(this.profit, t.profit, e)),
          (this.buysell = we(this.buysell, t.profit, e)),
          this)
        : ((this.profit = we(this.profit, t.profit, e)),
          (this.buysell = we(this.buysell, t.profit, e)),
          (this.swap = we(this.swap, t.storage, e)),
          (this.balance = we(this.balance, t.storage, e)),
          (this.buysell = we(this.buysell, t.storage, e)),
          (this.commission = we(this.commission, t.commission, e)),
          (this.commissionFee = we(this.commissionFee, t.commission_fee, e)),
          (this.balance = we(this.balance, t.commission, e)),
          (this.buysell = we(this.buysell, t.commission, e)),
          (this.balance = we(this.balance, t.commission_fee, e)),
          (this.buysell = we(this.buysell, t.commission_fee, e)),
          this)
    );
  }
}
class ys extends Kr {
  constructor() {
    super(...arguments),
      (this.position_id = BigInt(0)),
      (this.trade_symbol = ""),
      (this.trade_type = 0),
      (this.trade_reason = 0),
      (this.expert = BigInt(0)),
      (this.open_volume = BigInt(0)),
      (this.open_time = 0),
      (this.open_price = 0),
      (this.close_volume = BigInt(0)),
      (this.close_time = 0),
      (this.close_price = 0),
      (this.commission = 0),
      (this.storage = 0),
      (this.profit = 0),
      (this.digits = 0),
      (this.digits_currency = 0),
      (this.contract_size = 0);
  }
  dealAdd(t) {
    return t.isBalance()
      ? ((this.position_id = t.deal),
        (this.trade_type = t.trade_action),
        (this.expert = t.expert),
        (this.profit = t.profit),
        (this.trade_reason = t.trade_reason),
        (this.open_volume = BigInt(0)),
        (this.open_time = t.time_create),
        (this.open_price = 0),
        (this.sl = 0),
        (this.tp = 0),
        (this.close_volume = BigInt(0)),
        (this.close_time = 0),
        (this.close_price = 0),
        (this.comment = t.comment),
        (this.digits = t.digits),
        (this.digits_currency = t.digits_currency),
        !0)
      : !!t.position_id &&
          (this.open_volume
            ? this.position_id === t.position_id &&
              ((t.isBuy() && 0 === this.trade_type) ||
              (t.isSell() && 1 === this.trade_type)
                ? ((this.profit = we(
                    this.profit,
                    t.profit,
                    this.digits_currency
                  )),
                  (this.storage = we(
                    this.storage,
                    t.storage,
                    this.digits_currency
                  )),
                  (this.commission = we(
                    this.commission,
                    t.commission,
                    this.digits_currency
                  )),
                  (this.commission_fee = we(
                    this.commission_fee,
                    t.commission_fee,
                    this.digits_currency
                  )),
                  t.isService() ||
                    ((this.open_time = Math.min(this.open_time, t.time_create)),
                    (this.open_price =
                      (Number(this.open_volume) * this.open_price +
                        Number(t.trade_volume) * t.price_open) /
                      (Number(this.open_volume) + Number(t.trade_volume))),
                    (this.open_volume += t.trade_volume),
                    (this.sl = t.sl),
                    (this.tp = t.tp)),
                  (t.isOut() || t.isInOut()) &&
                    (this.close_time = Math.max(
                      this.close_time,
                      t.time_create
                    )),
                  !t.isService() && t.comment && (this.comment = t.comment))
                : ((this.profit = we(
                    this.profit,
                    t.profit,
                    this.digits_currency
                  )),
                  (this.storage = we(
                    this.storage,
                    t.storage,
                    this.digits_currency
                  )),
                  (this.commission = we(
                    this.commission,
                    t.commission,
                    this.digits_currency
                  )),
                  (this.commission_fee = we(
                    this.commission_fee,
                    t.commission_fee,
                    this.digits_currency
                  )),
                  t.isService() ||
                    (this.close_time
                      ? ((this.close_time = Math.max(
                          this.close_time,
                          t.time_create
                        )),
                        (this.close_price =
                          (Number(this.close_volume) * this.close_price +
                            Number(t.trade_volume) * t.price_open) /
                          (Number(this.close_volume) + Number(t.trade_volume))),
                        (this.close_volume += t.trade_volume))
                      : ((this.close_time = t.time_create),
                        (this.close_price = t.price_open),
                        (this.close_volume = t.trade_volume)),
                    (this.sl = t.sl),
                    (this.tp = t.tp))),
              (this.digits = t.digits),
              (this.digits_currency = t.digits_currency),
              (this.contract_size = t.contract_size),
              !0)
            : ((this.trade_symbol = t.trade_symbol),
              (this.position_id = t.position_id),
              (this.trade_type = t.isBuy() ? 0 : 1),
              (this.expert = t.expert),
              (this.trade_reason = t.trade_reason),
              (this.open_volume = t.trade_volume),
              (this.open_time = t.time_create),
              (this.open_price = t.price_open),
              (this.sl = t.sl),
              (this.tp = t.tp),
              (this.close_volume = BigInt(0)),
              (this.close_time = 0),
              (this.close_price = 0),
              (this.profit = t.profit),
              (this.storage = t.storage),
              (this.commission = t.commission),
              (this.commission_fee = t.commission_fee),
              (this.digits = t.digits),
              (this.digits_currency = t.digits_currency),
              (this.contract_size = t.contract_size),
              (this.comment = t.comment),
              !0));
  }
  isBuy() {
    return 0 === this.trade_type;
  }
  isSell() {
    return 1 === this.trade_type;
  }
  isBalance() {
    return Ee(this.trade_type);
  }
}
class fs {
  constructor() {
    (this.total = 0),
      (this.filled = 0),
      (this.canceled = 0),
      (this.rejected = 0);
  }
  clear() {
    return (
      (this.total = 0),
      (this.filled = 0),
      (this.canceled = 0),
      (this.rejected = 0),
      this
    );
  }
  orderAdd(t) {
    switch (((this.total += 1), t.order_state)) {
      case 4:
        return (this.filled += 1), this;
      case 2:
        return (this.canceled += 1), this;
      case 5:
        return (this.rejected += 1), this;
    }
    return this;
  }
}
class bs {
  constructor() {
    (this.balance = 0),
      (this.profit = 0),
      (this.swap = 0),
      (this.commission = 0),
      (this.commissionFee = 0),
      (this.buysell = 0),
      (this.credit = 0),
      (this.deposit = 0),
      (this.withdrawal = 0);
  }
  clear() {
    return (
      (this.balance = 0),
      (this.profit = 0),
      (this.swap = 0),
      (this.commission = 0),
      (this.commissionFee = 0),
      (this.buysell = 0),
      (this.credit = 0),
      (this.deposit = 0),
      (this.withdrawal = 0),
      this
    );
  }
  dealAdd(t) {
    const e = t.digits_currency;
    return (
      (this.swap = we(this.swap, t.storage, e)),
      (this.commission = we(this.commission, t.commission, e)),
      (this.commissionFee = we(this.commissionFee, t.commission_fee, e)),
      (this.balance = we(this.balance, t.profit, e)),
      (this.balance = we(this.balance, t.storage, e)),
      (this.balance = we(this.balance, t.commission, e)),
      (this.balance = we(this.balance, t.commission_fee, e)),
      t.isTrade()
        ? ((this.profit = we(this.profit, t.profit, e)),
          (this.buysell = we(this.buysell, t.profit, e)),
          (this.buysell = we(this.buysell, t.storage, e)),
          (this.buysell = we(this.buysell, t.commission, e)),
          (this.buysell = we(this.buysell, t.commission_fee, e)),
          this)
        : t.isCredit()
        ? ((this.credit = we(this.credit, t.profit, e)), this)
        : 2 === t.trade_action && t.profit > 0
        ? ((this.deposit = we(this.deposit, t.profit, e)), this)
        : 2 === t.trade_action && t.profit < 0
        ? ((this.withdrawal = we(this.withdrawal, t.profit, e)), this)
        : t.isBalance()
        ? ((this.profit = we(this.profit, t.profit, e)),
          (this.buysell = we(this.buysell, t.profit, e)),
          this)
        : this
    );
  }
}
class vs {
  constructor() {
    (this.hasIdProp = !1),
      (this.dealsList = null),
      (this.dealsByDeal = null),
      (this.dealsById = null),
      (this.ordersList = null),
      (this.ordersByOrder = null),
      (this.positionsList = null),
      (this.positionsTotal = null),
      (this.ordersTotal = null),
      (this.dealsTotal = null);
  }
  clear() {
    (this.ordersList = null),
      (this.dealsList = null),
      (this.positionsList = null),
      (this.ordersByOrder = null),
      (this.dealsByDeal = null),
      (this.dealsById = null);
  }
  getSymbols() {
    var t;
    return null == (t = this.dealsList)
      ? void 0
      : t.reduce((t, e) => {
          const i = e.trade_symbol;
          return i && -1 === t.indexOf(i) && t.push(i), t;
        }, []);
  }
  addOrder(t) {
    var e, i;
    null == (e = this.ordersList) || e.push(t),
      null == (i = this.ordersTotal) || i.orderAdd(t);
  }
  setOrders(t) {
    (this.ordersList = t), this.calcOrdersTotal();
  }
  getOrders() {
    return (this.ordersList && this.ordersList.slice()) || [];
  }
  getOrdersTotal() {
    return this.ordersTotal;
  }
  calcOrdersTotal() {
    var t;
    this.ordersTotal || (this.ordersTotal = new fs()),
      this.ordersTotal.clear(),
      null == (t = this.ordersList) ||
        t.forEach((t) => {
          var e;
          null == (e = this.ordersTotal) || e.orderAdd(t);
        });
  }
  getOrderById(t) {
    var e;
    if (!(null == (e = this.ordersByOrder) ? void 0 : e.length)) return null;
    let i = 0,
      r = this.ordersByOrder.length;
    for (; i < r; ) {
      let e = Math.floor(i + (r - i) / 2);
      const s = this.ordersByOrder[e] && this.ordersByOrder[e].trade_order;
      if (s === t) return this.ordersByOrder[e];
      s > t ? (r = e - 1) : (i = e + 1);
    }
    return null;
  }
  removeOrderById(t, e) {
    if (!this.ordersList) return;
    const i =
      this.ordersList && this.ordersList.findIndex((e) => e.trade_order === t);
    -1 !== i &&
      (e ? this.ordersList.splice(i, 1, e) : this.ordersList.splice(i, 1),
      this.sortRecords());
  }
  addDeal(t) {
    var e, i;
    null == (e = this.dealsList) || e.push(t),
      null == (i = this.dealsTotal) || i.dealAdd(t);
  }
  setDeals(t) {
    (this.dealsList = t), this.calcDealsTotal();
  }
  getDeals() {
    var t;
    return (null == (t = this.dealsList) ? void 0 : t.slice()) ?? [];
  }
  getDealsTotal() {
    return this.dealsTotal;
  }
  calcDealsTotal() {
    var t;
    this.dealsTotal || (this.dealsTotal = new bs()),
      this.dealsTotal.clear(),
      null == (t = this.dealsList) ||
        t.forEach((t) => {
          var e;
          null == (e = this.dealsTotal) || e.dealAdd(t);
        });
  }
  getDealByDeal(t) {
    var e;
    if (!(null == (e = this.dealsByDeal) ? void 0 : e.length)) return null;
    let i = 0,
      r = this.dealsByDeal.length;
    for (; i < r; ) {
      const e = Math.floor(i + (r - i) / 2),
        s = this.dealsByDeal[e] && this.dealsByDeal[e].deal;
      if (s === t) return this.dealsByDeal[e];
      s > t ? (r = e - 1) : (i = e + 1);
    }
    return null;
  }
  getDealById(t) {
    var e;
    if (!(null == (e = this.dealsById) ? void 0 : e.length)) return null;
    const i = t.toString();
    let r = 0,
      s = this.dealsById.length;
    for (; r < s; ) {
      const t = Math.floor(r + (s - r) / 2),
        e = this.dealsById[t] && this.dealsById[t].position_id.toString();
      if (e === i) return this.dealsById[t];
      e > i ? (s = t - 1) : (r = t + 1);
    }
    return null;
  }
  getDealBySymbolId(t, e) {
    return t.isHedgedMargin() ? this.getDealById(e) : null;
  }
  getDealsByOrder(t) {
    return this.dealsList && this.dealsList.filter((e) => e.trade_order === t);
  }
  removeDealByDeal(t, e) {
    if (!this.dealsList) return;
    const i = this.dealsList.findIndex((e) => e.deal === t);
    "number" == typeof i &&
      -1 !== i &&
      (e ? this.dealsList.splice(i, 1, e) : this.dealsList.splice(i, 1),
      this.sortRecords());
  }
  getPositions() {
    return (this.positionsList && this.positionsList.slice()) || [];
  }
  getPositionsTotal() {
    return this.positionsTotal;
  }
  buildPositions(t) {
    if (
      ((this.positionsList = []),
      this.positionsTotal || (this.positionsTotal = new gs()),
      this.positionsTotal.clear(),
      this.dealsList)
    ) {
      let e = this.dealsList.slice().sort(X);
      t && (e = e.filter((e) => e.trade_symbol === t)),
        e.forEach((t) => this.updateHistoryPosition(t)),
        this.calcPositionsTotal(t),
        this.positionsList.sort(j);
    }
  }
  updateHistoryPosition(t, e = !1) {
    var i;
    const r = t.isBalance() ? t.deal : t.position_id;
    let s =
      this.positionsList &&
      this.positionsList.find(
        (e) => e.position_id === r && Ee(e.trade_type) === Ee(t.trade_action)
      );
    s
      ? s.dealAdd(t)
      : ((s = new ys()),
        s.dealAdd(t),
        null == (i = this.positionsList) || i.push(s),
        e && this.positionsList && this.positionsList.sort(j));
  }
  calcPositionsTotal(t) {
    if (
      (this.positionsTotal || (this.positionsTotal = new gs()),
      this.positionsTotal.clear(),
      this.dealsList)
    ) {
      let e = this.dealsList;
      t &&
        (e = this.dealsList
          .slice()
          .sort(X)
          .filter((e) => e.trade_symbol === t)),
        e.forEach((t) => {
          var e;
          const i = t.isBalance() ? t.deal : t.position_id,
            r =
              this.positionsList &&
              this.positionsList.find(
                (e) =>
                  e.position_id === i && Ee(e.trade_type) === Ee(t.trade_action)
              );
          r &&
            (r.close_volume || r.isBalance()) &&
            (null == (e = this.positionsTotal) || e.positionAdd(t));
        });
    }
  }
  sortRecords() {
    this.dealsList &&
      ((this.dealsByDeal = this.dealsList.slice().sort(J)),
      (this.dealsById = this.dealsList.slice().sort(W)),
      (this.hasIdProp = this.dealsList.some((t) => !!t.deal_id))),
      this.ordersList &&
        ((this.ordersByOrder = this.ordersList.slice().sort(K)),
        (this.hasIdProp =
          this.hasIdProp || this.ordersList.some((t) => !!t.order_id)));
  }
}
class Ts {
  constructor(t, e) {
    (this.historyStorage = new vs()),
      (this.historyApi = t),
      (this.accountController = e),
      (this.onHistory = this.onHistory.bind(this));
  }
  async loadHistory(t) {
    const e = await this.historyApi.getTradeHistory(t);
    this.onHistory(e);
  }
  destroy() {
    this.historyStorage.clear();
  }
  onHistory(t) {
    const { deals: e, orders: i } = t;
    return (
      this.historyStorage.setOrders(i),
      this.historyStorage.setDeals(e),
      this.historyStorage.sortRecords(),
      this.historyStorage.buildPositions(),
      t
    );
  }
  addOrder(t) {
    this.historyStorage.addOrder(t);
  }
  sortRecords() {
    this.historyStorage.sortRecords();
  }
  getOrderById(t) {
    return this.historyStorage.getOrderById(t);
  }
  getDealBySymbolId(t) {
    return this.historyStorage.getDealBySymbolId(
      this.accountController.getAccount(),
      t
    );
  }
  removeOrderById(t, e) {
    this.historyStorage.removeOrderById(t, e);
  }
  getDealByDeal(t) {
    return this.historyStorage.getDealByDeal(t);
  }
  getDealById(t) {
    return this.historyStorage.getDealById(t);
  }
  updateHistoryPosition(t, e = !1) {
    this.historyStorage.updateHistoryPosition(t, e),
      this.historyStorage.calcPositionsTotal();
  }
  removeDealByDeal(t, e) {
    this.historyStorage.removeDealByDeal(t, e);
  }
  addDeal(t) {
    this.historyStorage.addDeal(t);
  }
  getDeals() {
    return this.historyStorage.getDeals();
  }
  getDealsTotal() {
    return this.historyStorage.getDealsTotal();
  }
  getOrders() {
    return this.historyStorage.getOrders();
  }
  getOrdersTotal() {
    return this.historyStorage.getOrdersTotal();
  }
  getPositions() {
    return this.historyStorage.getPositions();
  }
  getPositionsTotal() {
    return this.historyStorage.getPositionsTotal();
  }
}
const Ss = [
    { propType: 17 },
    { propType: 11, propLength: 64 },
    { propType: 11, propLength: 64 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 17 },
    { propType: 17 },
    { propType: 6 },
    { propType: 17 },
    { propType: 17 },
    { propType: 11, propLength: 64 },
    { propType: 8 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 3 },
    { propType: 3 },
  ],
  ks = ee.getSeriesSize(Ss),
  Cs = [
    { propType: 17 },
    { propType: 11, propLength: 64 },
    { propType: 17 },
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 64 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 18 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 17 },
    { propType: 17 },
    { propType: 11, propLength: 64 },
    { propType: 8 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 3 },
    { propType: 3 },
    { propType: 8 },
  ],
  Es = ee.getSeriesSize(Cs);
class Bs extends Ge {
  async getTradeHistory(t) {
    var e;
    return {
      deals: rt(
        (e = (
          await this.socket.sendCommand(
            5,
            (function ({ from: t, to: e } = { from: 0, to: 0 }) {
              return Int32Array.from([t, e]).buffer;
            })(t)
          )
        ).resBody),
        0
      ),
      orders: tt(e, it(e, 0)),
    };
  }
}
class ws {
  constructor(t) {
    this.historyController = t;
  }
  async load(t) {
    await this.historyController.loadHistory(t);
  }
  deals() {
    return {
      items: this.historyController.getDeals().map(Ls.from),
      total: this.historyController.getDealsTotal(),
    };
  }
  orders() {
    return {
      items: this.historyController.getOrders().map(Os.from),
      total: this.historyController.getOrdersTotal(),
    };
  }
  positions() {
    const t = [];
    return (
      this.historyController.getPositions().forEach((e) => {
        e.isBalance() ? t.push(new Rs(e)) : e.close_volume && t.push(new Is(e));
      }),
      {
        items: t.sort((t, e) => t.timeOpen - e.timeOpen),
        total: this.historyController.getPositionsTotal(),
      }
    );
  }
}
class Ls {
  constructor(t) {
    (this.isBuy = !1),
      (this.isSell = !1),
      (this.symbol = t.trade_symbol),
      (this.timeCreate = t.time_create),
      (this.deal = nt(t)),
      (this.id = st(t)),
      (this.order = lt(t)),
      (this.position = at(t)),
      (this.action = t.trade_action),
      (this.isBuy = t.isBuy()),
      (this.isSell = t.isSell()),
      (this.isBalance = t.isBalance()),
      (this.entry = (function (t) {
        switch (t.entry) {
          case Qr.IN:
            return "in";
          case Qr.OUT:
            return "out";
          case Qr.INOUT:
            return "in/out";
          case Qr.OUT_BY:
            return "out by";
          default:
            return "";
        }
      })(t)),
      (this.volume = f(t.trade_volume)),
      (this.volumeValue = Yi.toDouble(t.trade_volume)),
      (this.tradeReason = t.trade_reason),
      (this.volumeSize = y(Yi.toSize(t.trade_volume, t.contract_size))),
      (this.priceOpen = oe(t.price_open, t.digits + 3)),
      (this.priceClose = oe(t.price_close, t.digits + 3)),
      (this.commission = t.commission),
      (this.commissionFee = t.commission_fee),
      (this.storage = t.storage),
      (this.digits = t.digits),
      (this.digitsCurrency = t.digits_currency),
      (this.comment = t.comment || ""),
      (t.hasProfit() || t.profit) &&
        (this.profit = oe(t.profit, t.digits_currency));
  }
  static from(t) {
    return new Ls(t);
  }
}
class Os {
  constructor(t) {
    (this.price = null),
      (this.timeSetup = t.time_setup),
      (this.timeDone = t.time_done),
      (this.order = t.trade_order.toString()),
      (this.id = t.order_id),
      (this.symbol = t.trade_symbol),
      (this.type = t.order_type),
      (this.typeReason = t.type_reason),
      (this.volume = gt(t, !1)),
      (this.volumeValue = Yi.toDouble(t.volume_initial)),
      (this.volumeSize = gt(t, !0)),
      (this.digits = t.digits),
      (this.digitsCurrency = t.digits_currency),
      t.price_order && (this.price = oe(t.price_order, t.digits)),
      (this.sl = oe(t.price_sl, t.digits)),
      (this.tp = oe(t.price_tp, t.digits)),
      (this.comment = t.comment),
      (this.state = t.order_state);
  }
  static from(t) {
    return new Os(t);
  }
}
class Is {
  constructor(t) {
    (this.isBuy = !1),
      (this.isSell = !1),
      (this.isBalance = !1),
      (this.id = at(t)),
      (this.comment = t.comment || ""),
      (this.timeOpen = t.open_time),
      (this.sl = oe(t.sl, t.digits)),
      (this.tp = oe(t.tp, t.digits)),
      (this.digits = t.digits),
      (this.digitsCurrency = t.digits_currency),
      (this.type = t.trade_type),
      (this.isBuy = t.isBuy()),
      (this.isSell = t.isSell()),
      (this.isBalance = t.isBalance()),
      t.open_volume === t.close_volume
        ? ((this.volume = f(t.open_volume)),
          (this.volumeValue = Yi.toDouble(t.open_volume)),
          (this.volumeSize = y(Yi.toSize(t.open_volume, t.contract_size))))
        : ((this.volume = f(t.close_volume)),
          (this.volumeValue = Yi.toDouble(t.close_volume)),
          (this.volumeSize = y(Yi.toSize(t.close_volume, t.contract_size)))),
      t.close_volume && (this.timeClose = t.close_time),
      (this.symbol = ot(t)),
      (this.priceOpen = oe(t.open_price, this.digits + 3)),
      (this.priceClose = oe(t.close_price, this.digits + 3)),
      (this.commission = oe(t.commission || 0, this.digitsCurrency)),
      (this.commissionFee = oe(t.commission_fee || 0, this.digitsCurrency)),
      (t.profit || t.isBalance()) &&
        (this.profit = oe(t.profit || 0, this.digitsCurrency)),
      t.close_volume &&
        (this.storage = oe(t.storage || 0, this.digitsCurrency));
  }
  static from(t) {
    return new Is(t);
  }
}
class Rs extends Is {
  static from(t) {
    return new Rs(t);
  }
  constructor(t) {
    super(t),
      (this.id = at(t)),
      (this.comment = t.comment || ""),
      (this.timeOpen = t.open_time),
      (this.digits = t.digits),
      (this.digitsCurrency = t.digits_currency),
      (this.type = t.trade_type),
      (t.profit || t.isBalance()) &&
        (this.profit = oe(t.profit, this.digitsCurrency)),
      t.close_volume &&
        (this.storage = oe(t.storage || 0, this.digitsCurrency));
  }
}
class As {
  constructor(t, e) {
    (this.controller = new Ts(new Bs(t), e)),
      (this.view = new ws(this.controller));
  }
}
const Ms = 1e11;
class $s {
  constructor() {
    (this.has = {}), (this.positionList = []), (this.orderList = []);
  }
  positions() {
    return this.positionList.slice();
  }
  orders() {
    return this.orderList.slice();
  }
  clear() {
    (this.positionList = []),
      (this.orderList = []),
      (this.has.id = !1),
      (this.has.positionSL = !1),
      (this.has.positionTP = !1),
      (this.has.orderSL = !1),
      (this.has.orderTP = !1);
  }
  sortRecords() {
    (this.has.positionSL = this.positionList.some((t) => !!t.sl)),
      (this.has.positionTP = this.positionList.some((t) => !!t.tp)),
      (this.has.orderSL = this.orderList.some((t) => !!t.price_sl)),
      (this.has.orderTP = this.orderList.some((t) => !!t.price_tp));
  }
  addOrder(t) {
    if (!t) return !1;
    const e = t.trade_order;
    return (
      !this.orderList.find((t) => t.trade_order === e) &&
      ((t.prev = new kr()),
      this.orderList.push(t),
      t.order_id && (this.has.id = !0),
      !0)
    );
  }
  addPosition(t) {
    return (
      (t.prev = new Kr()),
      this.positionList.push(t),
      t.external_id && (this.has.id = !0),
      !0
    );
  }
  removeOrder(t, e = null) {
    if (!t) return !1;
    const i = t.trade_order,
      r = this.orderList.findIndex((t) => t.trade_order === i);
    return (
      -1 !== r &&
      (e ? this.orderList.splice(r, 1, e) : this.orderList.splice(r, 1), !0)
    );
  }
  removePosition(t, e = null) {
    let i;
    return (
      (i = t.position_id
        ? this.getPositionById(t.position_id, !0)
        : this.getPositionBySymbol(t.trade_symbol, !0)),
      i > -1 &&
        (e ? this.positionList.splice(i, 1, e) : this.positionList.splice(i, 1),
        !0)
    );
  }
  getOrderById(t, e) {
    return e
      ? this.orderList.findIndex((e) => e.trade_order === t)
      : this.orderList.find((e) => e.trade_order === t) ?? null;
  }
  getOrdersBySymbol(t) {
    return this.orderList.filter((e) => e.trade_symbol === t);
  }
  getPositionById(t, e) {
    return t
      ? e
        ? this.positionList.findIndex((e) => e.position_id === t)
        : this.positionList.find((e) => e.position_id === t) ?? null
      : null;
  }
  getPositionBySymbol(t, e) {
    return e
      ? this.positionList.findIndex((e) => e.trade_symbol === t)
      : this.positionList.find((e) => e.trade_symbol === t) ?? null;
  }
  getPositionsBySymbol(t) {
    return this.positionList.filter((e) => e.trade_symbol === t);
  }
  useSymbol(t) {
    return (
      !!this.orderList.some((e) => e.trade_symbol === t) ||
      !!this.positionList.some((e) => e.trade_symbol === t)
    );
  }
  hasOrders() {
    return Boolean(this.orderList.length);
  }
  hasPositions() {
    return this.positionList.some((t) => !t.isCollateral());
  }
}
let xs = new Map();
class Ps {
  constructor(t, e, i, r, s, o, a) {
    (this.timeout = null),
      (this.queue = new Set()),
      (this.tradeStorage = new $s()),
      (this.emitter = t),
      (this.tradeApi = e),
      (this.ticksController = i),
      (this.symbolsController = r),
      (this.accountController = s),
      (this.converterController = o),
      (this.marginController = a),
      (this.onTick = this.onTick.bind(this)),
      (this.onPosition = this.onPosition.bind(this));
  }
  async init() {
    await this.loadOpened();
  }
  async loadOpened() {
    const t = await this.tradeApi.getTradingOpened(),
      e = [
        ...((null == t ? void 0 : t.orders) ?? []),
        ...((null == t ? void 0 : t.positions) ?? []),
      ].map(({ trade_symbol: t }) => t);
    await this.getMany(e), this.onPosition(t);
  }
  getActiveSymbols() {
    return [
      ...this.tradeStorage
        .orders()
        .map((t) => t.trade_symbol)
        .filter(Boolean),
      ...this.tradeStorage
        .positions()
        .map((t) => t.trade_symbol)
        .filter(Boolean),
    ];
  }
  destroy() {
    this.ticksController.setTradeList(),
      this.getActiveSymbols().forEach((t) =>
        this.ticksController.off(t, this.onTick)
      ),
      this.tradeStorage.clear(),
      (xs = new Map());
  }
  hedgeAllowed() {
    return this.accountController.getAccount().isHedgedMargin();
  }
  addOrder(t) {
    if (this.tradeStorage.addOrder(t)) {
      const e = t.trade_symbol;
      this.ticksController.setTradeList(this.getActiveSymbols()),
        this.ticksController.on(e, this.onTick);
    }
  }
  removeOrder(t, e = null) {
    const i = this.tradeStorage.removeOrder(t, e);
    if (i) {
      const e = null == t ? void 0 : t.trade_symbol;
      e &&
        !this.tradeStorage.useSymbol(e) &&
        this.ticksController.off(e, this.onTick);
    }
    return this.ticksController.setTradeList(this.getActiveSymbols()), i;
  }
  addPosition(t) {
    if (this.tradeStorage.addPosition(t)) {
      this.ticksController.setTradeList(this.getActiveSymbols());
      const e = t.trade_symbol;
      this.ticksController.on(e, this.onTick);
    }
  }
  removePosition(t, e = null) {
    if (this.tradeStorage.removePosition(t, e)) {
      const e = null == t ? void 0 : t.trade_symbol;
      e &&
        !this.tradeStorage.useSymbol(e) &&
        (this.ticksController.setTradeList(this.getActiveSymbols()),
        this.ticksController.off(e, this.onTick));
    }
  }
  onPosition(t) {
    const { positions: e } = t;
    e &&
      e.forEach((t) => {
        this.addPosition(t);
      });
    const { orders: i } = t;
    i &&
      i.forEach((t) => {
        this.addOrder(t);
      });
  }
  onTick(t) {
    const e = t.trade_symbol;
    let i = xs.get(e);
    i || ((i = this.applyTick.bind(this, e)), xs.set(e, i)),
      this.queue.add(i),
      this.timeout ||
        (this.timeout = window.setTimeout(() => {
          this.queue.forEach((t) => t()),
            this.queue.clear(),
            (this.timeout = null);
        }, 200));
  }
  applyTick(t) {
    const e = this.tradeStorage.getOrdersBySymbol(t),
      i = this.tradeStorage.getPositionsBySymbol(t);
    if (!e.length && !i.length) return;
    const r = this.symbolsController.getFullSymbolByName(t);
    if (!r) return;
    const s = this.ticksController.getTick(t, r.isDelayed());
    if (!s) return;
    const o = ft(r, s),
      a = this.accountController.getAccount(),
      n = this.converterController.rateBuy(
        r,
        r.currency_profit,
        a.account_currency
      ),
      l = this.converterController.rateSell(
        r,
        r.currency_profit,
        a.account_currency
      );
    i.length &&
      n &&
      l &&
      (i.forEach((t) => {
        r &&
          ((function (t, e, i, r, s, o) {
            let a = 0;
            if (t.isCollateral())
              r.isExchangeMargin()
                ? (a = e.last ?? a)
                : e.last
                ? (a = e.last)
                : (i.isBuy() && (a = e.bid), i.isSell() && (a = e.ask));
            else {
              const r = ft(t, e);
              i.isBuy() && (a = r.bid), i.isSell() && (a = r.ask);
            }
            a && ((i.price_close = a), bt(t, i, r, s, o));
          })(r, s, t, a, n, l),
          bt(r, t, a, n, l, r.isCollateral()),
          this.emitter.trigger(4, t.position_id.toString()));
      }),
      this.marginController.calcAccount(this.getOrders(), this.getPositions()),
      this.marginController.checkStopOut(a),
      this.emitter.trigger(3)),
      e.length &&
        e.forEach((t) => {
          switch (t.order_type) {
            case 0:
            case 2:
            case 4:
            case 6:
              o.ask && (t.price_current = o.ask);
              break;
            case 1:
            case 3:
            case 5:
            case 7:
              o.bid && (t.price_current = o.bid);
          }
          this.emitter.trigger(5, t.trade_order.toString());
        });
  }
  useSymbol(t) {
    return this.tradeStorage.useSymbol(t);
  }
  getPositions() {
    return this.tradeStorage.positions();
  }
  getOrders() {
    return this.tradeStorage.orders();
  }
  async getMany(t) {
    const e = [],
      i = [],
      r = [];
    t.forEach((t, s) => {
      const o = this.symbolsController.getSymbolByName(t);
      o &&
        (o instanceof Vi
          ? i.push(o)
          : (i.push(null), r.push({ idx: s, symbol: t }), e.push(o.symbol_id)));
    }),
      e.length &&
        (await this.symbolsController.loadConfig(e),
        r.forEach(({ idx: t, symbol: e }) => {
          const r = this.symbolsController.getSymbolByName(e);
          r && r instanceof Vi && (i[t] = r);
        }));
  }
  getOrderById(t) {
    return this.tradeStorage.getOrderById(t);
  }
  sortRecords() {
    this.tradeStorage.sortRecords();
  }
  getPositionBySymbol(t) {
    return this.tradeStorage.getPositionBySymbol(t);
  }
  getPositionById(t) {
    return this.tradeStorage.getPositionById(t);
  }
  getOrdersBySymbol(t) {
    return this.tradeStorage.getOrdersBySymbol(t);
  }
  getPositionsBySymbol(t) {
    return this.tradeStorage.getPositionsBySymbol(t);
  }
}
const zs = [
    { propType: 17 },
    { propType: 17 },
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 64 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 18 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 17 },
    { propType: 17 },
    { propType: 11, propLength: 64 },
    { propType: 8 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 64 },
    { propType: 3 },
    { propType: 3 },
  ],
  Ds = ee.getSeriesSize(zs);
class Ns extends Ge {
  async getTradingOpened() {
    var t;
    return {
      positions: St((t = (await this.socket.sendCommand(4)).resBody), 0),
      orders: tt(t, Tt(t, 0)),
    };
  }
}
class Us {
  constructor(t) {
    this.tradeController = t;
  }
  getPosition(t) {
    const e = this.tradeController.getPositionById(BigInt(t));
    return e ? Us.formatPosition(e) : null;
  }
  getPositions() {
    const t = { items: [] };
    return (
      this.tradeController.getPositions().forEach((e) => {
        e.isCollateral()
          ? (t.collateral = Us.formatCollateral(e))
          : t.items.push(Us.formatPosition(e));
      }),
      t
    );
  }
  getOrder(t) {
    const e = this.tradeController.getOrderById(BigInt(t));
    return e ? Us.formatOrder(e) : null;
  }
  getOrders() {
    return this.tradeController.getOrders().map((t) => Us.formatOrder(t));
  }
  static formatPosition(t) {
    return new qs({
      symbol: ot(t),
      id: at(t),
      externalId: t.external_id,
      timeCreate: t.time_create,
      timeUpdate: t.time_update,
      typeName: Le(t.trade_action),
      tradeAction: t.trade_action,
      volume: f(t.trade_volume),
      volumeValue: Yi.toDouble(t.trade_volume),
      volumeSize: y(Yi.toSize(t.trade_volume, t.contract_size)),
      priceOpen: oe(t.price_open, t.digits),
      priceClose: oe(t.price_close, t.digits + 3),
      sl: oe(t.sl, t.digits),
      tp: oe(t.tp, t.digits),
      storage: oe(t.storage || 0, t.digits_currency),
      profit: oe(t.profit || 0, t.digits_currency),
      profitState: 0 === Number(t.profit) ? null : t.profit > 0,
      comment: t.comment || "",
      info: dt(t),
      infoTemplate: ((e = t), _t(e, at(e) || st(e))),
      isBuy: t.isBuy(),
      isSell: t.isSell(),
      digits: t.digits,
      digitsCurrency: t.digits_currency,
    });
    var e;
  }
  static formatCollateral(t) {
    return new Vs({
      id: at(t),
      symbol: ot(t),
      timeCreate: t.time_create,
      action: Le(t.trade_action),
      volume: f(t.trade_volume),
      volumeSize: y(Yi.toSize(t.trade_volume, t.contract_size)),
      priceClose: b(t.price_close, t.digits, 3),
      comment: t.comment || "",
      info: dt(t),
    });
  }
  static formatOrder(t) {
    const e = new Fs({
      symbol: pt(t),
      order: ut(t),
      id: mt(t),
      timeSetup: t.time_setup,
      type: t.order_type,
      typeName: Oe(t.order_type),
      isBuy: t.isBuy(),
      isSell: t.isSell(),
      isClose: t.isClose(),
      isCloseBy: t.isCloseBy(),
      isLimit: t.isLimit(),
      isMarket: t.isMarket(),
      isMarketPrice: t.isMarketPrice(),
      isPending: t.isPending(),
      isStop: t.isStop(),
      isStopLimit: t.isStopLimit(),
      volumeValue: Yi.toDouble(t.volume_initial),
      volume: gt(t),
      volumeLots: gt(t, !0),
      price: oe(t.price_order, t.digits),
      sl: oe(t.price_sl, t.digits),
      tp: oe(t.price_tp, t.digits),
      priceCurrent: oe(t.price_current, t.digits + 3),
      state: t.order_state,
      comment: t.comment || "",
      info: yt(t),
      digits: t.digits,
      digitsCurrency: t.digits_currency,
      expiration: t.type_time,
      date: t.time_expiration,
      filling: t.type_filling,
    });
    return (
      t.isStopLimit() &&
        ((e.priceOrder = b(t.price_order, t.digits)),
        (e.priceTrigger = t.price_trigger)),
      e
    );
  }
}
class qs {
  constructor(t) {
    (this.symbol = t.symbol),
      (this.id = t.id),
      (this.externalId = t.externalId),
      (this.timeCreate = t.timeCreate),
      (this.timeUpdate = t.timeUpdate),
      (this.typeName = t.typeName),
      (this.volume = t.volume),
      (this.volumeValue = t.volumeValue),
      (this.volumeSize = t.volumeSize),
      (this.priceOpen = t.priceOpen),
      (this.priceClose = t.priceClose),
      (this.sl = t.sl),
      (this.tp = t.tp),
      (this.storage = t.storage),
      (this.profit = t.profit),
      (this.comment = t.comment),
      (this.info = t.info),
      (this.infoTemplate = t.infoTemplate),
      (this.profitState = t.profitState),
      (this.tradeAction = t.tradeAction),
      (this.isBuy = t.isBuy),
      (this.isSell = t.isSell),
      (this.digits = t.digits),
      (this.digitsCurrency = t.digitsCurrency);
  }
}
class Vs {
  constructor(t) {
    (this.id = t.id),
      (this.symbol = t.symbol),
      (this.timeCreate = t.timeCreate),
      (this.typeName = t.action),
      (this.volume = t.volume),
      (this.volumeSize = t.volumeSize),
      (this.priceClose = t.priceClose),
      (this.comment = t.comment),
      (this.info = t.info);
  }
}
class Fs {
  constructor(t) {
    (this.symbol = t.symbol),
      (this.order = t.order),
      (this.id = t.id),
      (this.timeSetup = t.timeSetup),
      (this.type = t.type),
      (this.typeName = t.typeName),
      (this.volume = t.volume),
      (this.volumeValue = t.volumeValue),
      (this.volumeLots = t.volumeLots),
      (this.price = t.price),
      (this.sl = t.sl),
      (this.tp = t.tp),
      (this.priceCurrent = t.priceCurrent),
      (this.state = t.state),
      (this.comment = t.comment),
      (this.info = t.info),
      (this.priceOrder = t.priceOrder),
      (this.priceTrigger = t.priceTrigger),
      (this.isBuy = t.isBuy),
      (this.isSell = t.isSell),
      (this.isClose = t.isClose),
      (this.isCloseBy = t.isCloseBy),
      (this.isLimit = t.isLimit),
      (this.isMarket = t.isMarket),
      (this.isMarketPrice = t.isMarketPrice),
      (this.isPending = t.isPending),
      (this.isStop = t.isStop),
      (this.isStopLimit = t.isStopLimit),
      (this.digits = t.digits),
      (this.digitsCurrency = t.digitsCurrency),
      (this.expiration = t.expiration),
      (this.date = t.date),
      (this.filling = t.filling);
  }
}
class Hs {
  constructor(t, e, i, r, s, o, a) {
    (this.controller = new Ps(t, new Ns(e), i, r, s, o, a)),
      (this.view = new Us(this.controller));
  }
}
class Gs {
  constructor(t) {
    (this.isSell = t.isSell()),
      (this.isBuy = t.isBuy()),
      (this.isSpread = t.isSpread()),
      (this.price = t.price),
      (this.volume = t.trade_volume),
      (this.volumeLots = t.trade_volume_lots),
      (this.ratio = t.ratio);
    const e = t.orders.map((t) => ({
        isSell: t.isSell(),
        type: kt(t.order_type),
        volume: Yi.toDouble(t.volume_initial),
      })),
      i = t.sls.map((t) => ({
        isSell: !t.isSell(),
        type: 5,
        volume: Yi.toDouble(t.trade_volume),
      })),
      r = t.tps.map((t) => ({
        isSell: !t.isSell(),
        type: 6,
        volume: Yi.toDouble(t.trade_volume),
      }));
    this.actions = [...e, ...i, ...r];
  }
}
class Ys {
  constructor(t, e, i, r, s) {
    (this.orders = []),
      (this.positions = []),
      (this.sls = []),
      (this.tps = []),
      (this.ratio = 0),
      (this.flag_mask = t[0]),
      (this.book_type = t[1]),
      (this.price = pe(t[2], r)),
      (this.trade_volume = Yi.toDouble(t[3])),
      (this.trade_volume_lots = oe(this.trade_volume / s, 8)),
      (this.interest = t[4]),
      this.calcOrders(e),
      this.calcPositions(i);
  }
  format() {
    return new Gs(this);
  }
  calcPositions(t) {
    (this.positions = []),
      (this.sls = []),
      (this.tps = []),
      t.forEach((t) => {
        t.price_open === this.price && this.positions.push(t),
          t.sl === this.price && this.sls.push(t),
          t.tp === this.price && this.tps.push(t);
      });
  }
  calcOrders(t) {
    (this.orders = []),
      t.forEach((t) => {
        t.price_order === this.price && this.orders.push(t);
      });
  }
  isBuy() {
    return 2 === this.book_type || 4 === this.book_type;
  }
  isSell() {
    return 1 === this.book_type || 3 === this.book_type;
  }
  isSpread() {
    return 0 === this.book_type;
  }
  isReset() {
    return 0 === this.book_type;
  }
}
class Qs {
  constructor(t) {
    (this.symbol = t.symbol),
      (this.digits = t.config.digits),
      (this.point = t.config.point),
      (this.books = []),
      t.sell.forEach((t) => this.books.push(t.format())),
      t.buy.forEach((t) => this.books.push(t.format())),
      (this.extendedBooks = []),
      t.sellExtended.forEach((t) => this.extendedBooks.push(t.format())),
      t.spread.forEach((t) => this.extendedBooks.push(t.format())),
      t.buyExtended.forEach((t) => this.extendedBooks.push(t.format()));
  }
}
class Ks {
  constructor(t, e, i, r, s) {
    (this.books = new Map()),
      (this.sell = new Map()),
      (this.sellExtended = new Map()),
      (this.buy = new Map()),
      (this.spread = []),
      (this.buyExtended = new Map()),
      (this.spreadSize = 10),
      (this.config = e),
      (this.symbol = e.trade_symbol),
      (this.trade_symbol = t[0]),
      (this.books_time = t[1]),
      (this.time_msc = t[2]),
      (this.flag_mask = t[3]),
      (this.books_flags = t[4]),
      (this.spreadSize = i),
      this.updateBooks(t[6], r, s);
  }
  static format(t) {
    return new Qs(t);
  }
  format() {
    return new Qs(this);
  }
  updateBooks(t = [], e = [], i = []) {
    const { digits: r, trade_contract_size: s } = this.config;
    t.forEach((t) => {
      const o = new Ys(t, e, i, r, s);
      this.addBook(o);
    }),
      this.clearEmpty(),
      this.sort(),
      this.calcRatios();
    const o = this.extendSell(e, i),
      a = this.extendBuy(e, i);
    this.spread = a && o ? this.getSpread(a, o, e, i) : [];
  }
  clearEmpty() {
    this.sell.forEach((t, e) => {
      t.trade_volume || this.sell.delete(e);
    }),
      this.buy.forEach((t, e) => {
        t.trade_volume || this.buy.delete(e);
      });
  }
  extendSell(t = [], e = []) {
    const i = Array.from(this.sell.values()).reverse();
    if (!i.length) return null;
    const r = [];
    let s = oe(i[0].price, this.config.digits),
      o = 0;
    for (; o < 10; ) {
      let i = this.sell.get(s);
      i ||
        ((i = new Ys(
          [1, 1, 0, BigInt(0), 0],
          [],
          [],
          this.config.digits,
          this.config.point
        )),
        (i.price = s),
        i.calcOrders(t),
        i.calcPositions(e)),
        r.push(i),
        (s = oe(s + this.config.point, this.config.digits)),
        (o += 1);
    }
    return (
      (this.sellExtended = new Map(r.reverse().map((t) => [t.price, t]))),
      r.length ? r[r.length - 1].price : null
    );
  }
  extendBuy(t = [], e = []) {
    const i = Array.from(this.buy.values());
    if (!i.length) return null;
    const r = [];
    let s = oe(i[0].price, this.config.digits),
      o = 0;
    for (; o < 10; ) {
      let i = this.buy.get(s);
      i ||
        ((i = new Ys(
          [1, 2, 0, BigInt(0), 0],
          [],
          [],
          this.config.digits,
          this.config.point
        )),
        (i.price = s),
        i.calcOrders(t),
        i.calcPositions(e)),
        r.push(i),
        (s = oe(s - this.config.point, this.config.digits)),
        (o += 1);
    }
    return (
      (this.buyExtended = new Map(r.map((t) => [t.price, t]))),
      r.length ? r[0].price : null
    );
  }
  getSpread(t, e, i = [], r = []) {
    return (function (t, e, i, r, s = 10) {
      if (!s) return [];
      let o = i;
      const a = (function (t, e, i, r) {
        return oe(e - i - (t + i), r);
      })(t, e, o, r);
      if (a / o > s) {
        o = (function (t, e, i, r) {
          let s = t / e;
          return (s = Math.ceil(s / i) * i), oe(s, r);
        })(a, s, o, r);
        let n = oe(t + i, r),
          l = oe(e - i, r);
        const c = [n],
          _ = [l];
        for (n = oe(n + o, r), l = oe(l - o, r); n < e - i; )
          n < l && c.unshift(n),
            (n = oe(n + o, r)),
            l > n && _.push(l),
            (l = oe(l - o, r));
        return [..._, ...c];
      }
      const n = [];
      let l = oe(e - i, r);
      for (; l > t; ) n.push(l), (l = oe(l - i, r));
      return n;
    })(t, e, this.config.point, this.config.digits, this.spreadSize).map(
      (t) => {
        const e = new Ys(
          [1, 0, 0, BigInt(0), 0],
          [],
          [],
          this.config.digits,
          this.config.point
        );
        return (e.price = t), e.calcOrders(i), e.calcPositions(r), e;
      }
    );
  }
  calcRatios() {
    const t = Math.max(
      ...Array.from(this.buy.values()).map((t) => Math.abs(t.trade_volume))
    );
    this.buy.forEach((e) => {
      e.ratio = e.trade_volume / t;
    });
    const e = Math.max(
      ...Array.from(this.sell.values()).map((t) => Math.abs(t.trade_volume))
    );
    this.sell.forEach((t) => {
      t.ratio = Math.abs(t.trade_volume / e);
    });
  }
  addBook(t) {
    if (t.isBuy())
      if (0 === t.trade_volume) this.buy.delete(t.price);
      else {
        const e = this.buy.get(t.price);
        e
          ? ((t.trade_volume += e.trade_volume),
            (t.trade_volume_lots += e.trade_volume_lots),
            t.trade_volume <= 0
              ? this.buy.delete(e.price)
              : this.buy.set(t.price, t))
          : this.buy.set(t.price, t);
      }
    else if (t.isSell())
      if (0 === t.trade_volume) this.sell.delete(t.price);
      else {
        const e = this.sell.get(t.price);
        e
          ? ((t.trade_volume += e.trade_volume),
            (t.trade_volume_lots += e.trade_volume_lots),
            t.trade_volume <= 0
              ? this.sell.delete(e.price)
              : this.sell.set(t.price, t))
          : this.sell.set(t.price, t);
      }
    else
      t.isReset()
        ? (this.sell.clear(), this.buy.clear())
        : this.books.set(t.price, t);
  }
  sort() {
    (this.sell = new Map(
      [...this.sell.entries()].sort((t, e) =>
        t[0] < e[0] ? 1 : t[0] > e[0] ? -1 : 0
      )
    )),
      (this.buy = new Map(
        [...this.buy.entries()].sort((t, e) =>
          t[0] < e[0] ? 1 : t[0] > e[0] ? -1 : 0
        )
      ));
  }
}
class Ws {
  constructor() {
    (this.spreadSize = 10), (this.books = {});
  }
  getBooks() {
    return { ...this.books };
  }
  setSpreadSize(t) {
    this.spreadSize = t;
  }
  clear() {
    delete this.symbolId, (this.books = {});
  }
  getBookBySymbol(t) {
    return this.books[t];
  }
  setBook(t, e) {
    this.books[t] = e;
  }
  getSpreadSize() {
    return this.spreadSize;
  }
}
class js {
  constructor(t, e, i, r) {
    (this.booksStorage = new Ws()),
      (this.emitter = t),
      (this.booksApi = e),
      (this.symbolsController = i),
      (this.tradeController = r),
      (this.onUpdate = this.onUpdate.bind(this)),
      this.booksApi.on(this.onUpdate);
  }
  destroy() {
    this.booksApi.off(this.onUpdate), this.booksStorage.clear();
  }
  sign(t) {
    this.booksStorage.symbolId !== t &&
      ("number" != typeof t
        ? (this.booksApi.subscribe([]), this.booksStorage.clear())
        : (this.booksApi.subscribe([t]), (this.booksStorage.symbolId = t)));
  }
  onUpdate(t) {
    this.updateDiffs(t).length &&
      this.emitter.trigger(
        8,
        Object.values(
          Object.values(this.booksStorage.getBooks()).map(Ks.format)
        )
      );
  }
  setSpreadSize(t) {
    this.booksStorage.setSpreadSize(t);
  }
  updateDiffs(t) {
    const e = [];
    return (
      t.forEach((t) => {
        const i = this.symbolsController.getFullSymbolById(t[0]);
        if (!i) return;
        const r = this.tradeController.getOrdersBySymbol(i.trade_symbol),
          s = this.tradeController.getPositionsBySymbol(i.trade_symbol);
        let o = this.booksStorage.getBookBySymbol(i.trade_symbol);
        o
          ? ((o.books_time = t[1]),
            (o.time_msc = t[2]),
            (o.flag_mask = t[3]),
            (o.books_flags = t[4]),
            (o.spreadSize = this.booksStorage.getSpreadSize()),
            o.updateBooks(t[6], r, s))
          : ((o = new Ks(t, i, this.booksStorage.getSpreadSize(), r, s)),
            this.booksStorage.setBook(i.trade_symbol, o)),
          e.push(o);
      }),
      e
    );
  }
}
const Xs = [
    { propType: 6 },
    { propType: 4 },
    { propType: 6 },
    { propType: 17 },
    { propType: 6 },
  ],
  Js = ee.getSeriesSize(Xs),
  Zs = [
    { propType: 6 },
    { propType: 3 },
    { propType: 3 },
    { propType: 6 },
    { propType: 6 },
    { propType: 5 },
  ],
  to = ee.getSeriesSize(Zs);
class eo extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  subscribe(t) {
    return this.socket.sendCommand(22, h(t), !1);
  }
  on(t) {
    let e = this.map.get(t);
    e || ((e = this.onBooks.bind(this, t)), this.map.set(t, e)),
      this.socket.on(23, e);
  }
  off(t) {
    const e = this.map.get(t);
    e && this.socket.off(23, e);
  }
  onBooks(t, e) {
    t(
      (function (t) {
        if (t.byteLength <= 4) return [];
        const e = [];
        let i = 0;
        const r = new DataView(t).getUint32(i, !0);
        i += 4;
        for (let s = 0; s < r; s++) {
          const r = wt(t, i);
          (i += to), e.push([...r, Bt(t, i, r[5])]), (i += Et(r[5]));
        }
        return e;
      })(e.resBody)
    );
  }
}
class io {
  constructor(t, e, i, r) {
    this.controller = new js(t, new eo(e), i, r);
  }
}
class ro {
  constructor(t, e, i, r, s) {
    (this.emitter = t),
      (this.marginController = e),
      (this.accountController = i),
      (this.tradeController = r),
      (this.historyController = s);
  }
  init() {
    const t = this.accountController.getAccount(),
      e = this.tradeController.getOrders(),
      i = this.tradeController.getPositions();
    this.marginController.calcAccount(e, i),
      this.marginController.checkStopOut(t),
      this.emitter.trigger(14);
  }
  transactionEvent() {
    const t = this.accountController.getAccount(),
      e = this.tradeController.getOrders(),
      i = this.tradeController.getPositions();
    this.marginController.calcAccount(e, i),
      this.marginController.checkStopOut(t),
      this.emitter.trigger(14),
      this.emitter.trigger(1);
  }
  updateOpenOrder(t) {
    const e = this.tradeController.getOrderById(t.trade_order);
    e
      ? ((t.prev = e), this.tradeController.removeOrder(e, t))
      : this.tradeController.addOrder(t),
      this.tradeController.sortRecords(),
      this.transactionEvent();
  }
  deleteOpenOrder(t) {
    this.tradeController.removeOrder(t) &&
      (this.tradeController.sortRecords(), this.transactionEvent());
  }
  addHistoryOrder(t) {
    this.historyController.getOrderById(t.trade_order) ||
      (this.historyController.addOrder(t),
      this.historyController.sortRecords(),
      this.transactionEvent());
  }
  updateHistoryOrder(t) {
    const e = this.historyController.getOrderById(t.trade_order);
    e &&
      ((t.prev = e),
      this.historyController.removeOrderById(t.trade_order, t),
      this.transactionEvent());
  }
  deleteHistoryOrder(t) {
    this.historyController.removeOrderById(t.trade_order),
      this.transactionEvent();
  }
  addHistoryDeal(t) {
    this.historyController.getDealByDeal(t.deal) ||
      (this.historyController.addDeal(t),
      this.historyController.sortRecords(),
      this.historyController.updateHistoryPosition(t, !0),
      this.transactionEvent());
  }
  updateHistoryDeal(t) {
    const e = this.historyController.getDealByDeal(t.deal);
    e &&
      ((t.prev = e),
      this.historyController.removeDealByDeal(t.deal, t),
      this.transactionEvent());
  }
  deleteHistoryDeal(t) {
    this.historyController.removeDealByDeal(t.deal), this.transactionEvent();
  }
  updatePosition(t) {
    let e;
    if (
      ((e = t.position_id
        ? this.tradeController.getPositionById(t.position_id)
        : this.tradeController.getPositionBySymbol(t.trade_symbol)),
      e)
    )
      (t.prev = e),
        t.trade_volume
          ? this.tradeController.removePosition(e, t)
          : this.tradeController.removePosition(e),
        this.transactionEvent();
    else {
      if (!t.trade_volume) return !1;
      this.tradeController.addPosition(t), this.tradeController.sortRecords();
    }
    return this.transactionEvent(), !0;
  }
}
class so {
  constructor(t, e, i, r, s) {
    this.controller = new ro(t, e, i, r, s);
  }
}
class oo {
  constructor(t) {
    (this.flag_mask = t[0]),
      (this.transaction_id = t[1]),
      (this.transaction_type = t[2]),
      (this.deal = t[3]),
      (this.trade_position = t[4]),
      (this.balance = t[5]),
      (this.credit = t[6]),
      (this.commission_daily = t[7]),
      (this.commission_monthly = t[8]),
      (this.acc_profit = t[9]),
      (this.deals = []),
      (this.positions = []);
  }
}
const ao = [
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 12, parser: et, propLength: Es },
    { propType: 12, parser: vt, propLength: Ds },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
  ],
  no = ee.getSeriesSize(ao);
class lo {
  constructor(t) {
    (this.flag_mask = t[0]),
      (this.transaction_id = t[1]),
      (this.transaction_type = t[2]),
      (this.trade_order = t[3]);
  }
}
const co = [
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 12, parser: Z, propLength: ks },
  ],
  _o = ee.getSeriesSize(co);
class ho {
  constructor(t, e, i, r, s, o) {
    (this.emitter = t),
      (this.transactionsApi = e),
      (this.transactionsPrinter = i),
      (this.accountController = r),
      (this.ticksController = s),
      (this.updaterController = o),
      (this.onTransaction = this.onTransaction.bind(this)),
      this.transactionsApi.on(this.onTransaction);
  }
  destroy() {
    this.transactionsApi.off(this.onTransaction);
  }
  onTransaction(t) {
    t.forEach((t) => {
      const e = t.transaction_type,
        i = t.flag_mask;
      if (0 === i && t instanceof lo) {
        const i = t.trade_order;
        return (
          0 === e || 1 === e
            ? this.updaterController.updateOpenOrder(i)
            : 2 === e && this.updaterController.deleteOpenOrder(i),
          void (0 === e
            ? this.emitter.trigger(6, this.transactionsPrinter.printOrderAdd(i))
            : 1 === e &&
              this.emitter.trigger(
                6,
                this.transactionsPrinter.printOrderUpdate(i)
              ))
        );
      }
      if (1 === i && t instanceof lo) {
        const i = t.trade_order;
        return (
          0 === e
            ? this.updaterController.addHistoryOrder(i)
            : 1 === e
            ? this.updaterController.updateHistoryOrder(i)
            : 2 === e && this.updaterController.deleteHistoryOrder(i),
          void (
            0 === e &&
            this.emitter.trigger(
              6,
              this.transactionsPrinter.printOrderDelete(i)
            )
          )
        );
      }
      if (2 === i && t instanceof oo) {
        const { deals: i, deal: r } = t;
        if (0 === e) {
          const e = this.accountController.getAccount();
          (e.balance = t.balance),
            (e.credit = t.credit),
            (e.acc_profit = t.acc_profit),
            (e.commission_daily = t.commission_daily),
            (e.commission_monthly = t.commission_monthly);
        }
        if (t.trade_position.trade_symbol || t.deal.trade_symbol) {
          if (!this.updaterController.updatePosition(t.trade_position)) return;
          t.positions.forEach((t) => {
            this.updaterController.updatePosition(t);
          }),
            this.ticksController.sign(r.trade_symbol);
        }
        "0" !== r.deal.toString() &&
          (0 === e
            ? this.updaterController.addHistoryDeal(r)
            : 1 === e
            ? this.updaterController.updateHistoryDeal(r)
            : 2 === e && this.updaterController.deleteHistoryDeal(r),
          r.isTrade() &&
            this.emitter.trigger(6, this.transactionsPrinter.printDeal(r))),
          i.forEach((t) => {
            0 === e
              ? this.updaterController.addHistoryDeal(t)
              : 1 === e
              ? this.updaterController.updateHistoryDeal(t)
              : 2 === e && this.updaterController.deleteHistoryDeal(t);
          }),
          0 === e
            ? this.emitter.trigger(
                6,
                this.transactionsPrinter.printDealAdd(t.deal)
              )
            : 1 === e &&
              this.emitter.trigger(
                6,
                this.transactionsPrinter.printPositionUpdate(t.trade_position)
              );
      }
    });
  }
}
class po extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  on(t) {
    let e = this.map.get(t);
    e || ((e = this.onTransaction.bind(this, t)), this.map.set(t, e)),
      this.socket.on(10, e);
  }
  off(t) {
    const e = this.map.get(t);
    return e && this.socket.off(10, e), this;
  }
  onTransaction(t, e) {
    t(
      (function (t) {
        const e = [],
          i = new DataView(t).getUint32(0, !0);
        let r = 0;
        const s = t.byteLength;
        for (; r < s; )
          2 === i
            ? (e.push(Ot(t, r)), (r += Lt(t, r)))
            : (e.push(It(t, r)), (r += _o));
        return e;
      })(e.resBody)
    );
  }
}
class uo {
  constructor(t, e, i) {
    (this.accountController = t),
      (this.tradeController = e),
      (this.historyController = i);
  }
  printOrderAdd(t) {
    return "";
  }
  printOrderUpdate(t) {
    return "";
  }
  printOrderDelete(t) {
    return "";
  }
  printDealAdd(t) {
    return "";
  }
  printPositionUpdate(t) {
    return "";
  }
  printDeal(t) {
    let e = `${this.accountController.getAccount().login}: deal `;
    var i;
    return (
      (e += ct((i = t), nt(i) || st(i))),
      (e += " done (based on order #"),
      (e += lt(t)),
      (e += ")"),
      e
    );
  }
  getLogHeader(t, e) {
    let i = "";
    return (
      (i += `${this.accountController.getAccount().login}: `),
      (i += `${e || "order"} #`),
      (i += ut(t)),
      (i += " "),
      (i += Oe(t.order_type)),
      (i += " "),
      (i += gt(t)),
      (i += " "),
      (i += pt(t)),
      i
    );
  }
}
class mo {
  constructor(t, e, i, r, s, o, a) {
    (this.printer = new uo(i, a, o)),
      (this.controller = new ho(t, new po(e), this.printer, i, r, s));
  }
}
class go {
  constructor(t, e, i, r) {
    (this.accountController = t),
      (this.symbolsController = e),
      (this.ticksController = i),
      (this.tradeController = r);
  }
  checkAction(t, e, i = !1) {
    let r;
    const s = this.accountController.getAccount();
    if (
      ((e.login = s.login),
      (e.digits = 5),
      (r = this.checkExecution(e)),
      0 !== r)
    )
      return r;
    switch (e.trade_action) {
      case 0:
        r = this.checkPrices(e);
        break;
      case 1:
        r = this.checkRequest(e);
        break;
      case 2:
        r = this.checkInstant(t, e, i);
        break;
      case 3:
        r = this.checkMarket(e);
        break;
      case 4:
        r = this.checkExchange(e);
        break;
      case 5:
        r = this.checkPending(e);
        break;
      case 6:
        r = this.checkSLTP(e);
        break;
      case 7:
        r = this.checkModify(e);
        break;
      case 8:
        r = this.checkRemove(e);
        break;
      case 10:
        r = this.checkCloseBy(s, e);
    }
    return r;
  }
  checkInstant(t, e, i = !1) {
    const r = {};
    let s = this.checkPrepare(e, r);
    if (0 !== s || !r.trade_position || !r.config) return s;
    const o = r.config,
      a = r.trade_position;
    return Rt(e.price_order, o)
      ? o.trade.trade_exemode !== Fe.INSTANT
        ? 10013
        : At(o, e, !0)
        ? zt(e, o, a)
          ? ((s = this.checkStopsPosition(e, o, a)),
            0 !== s
              ? s
              : ((s = Dt(e, o, a)),
                0 !== s
                  ? s
                  : e.price_deviation > ae
                  ? 10017
                  : Mt(o, e.trade_type)
                  ? ((s = this.checkInstantPrices(
                      t,
                      this.accountController.getAccount(),
                      e,
                      o,
                      i
                    )),
                    0 !== s ? s : ((e.type_filling = 0), 0))
                  : 10035))
          : 10014
        : 10030
      : 10015;
  }
  checkInstantPrices(t, e, i, r, s = !1) {
    if (2 !== i.trade_action) return 0;
    if (
      s &&
      (function (t, e, i) {
        const r = Date.now();
        let s = null;
        const o = t.getRequotes();
        for (let a = 0; a < o.length; a++) {
          const i = o[a];
          if (r > i.time) return t.deleteRequote(i), null;
          e.trade_action === i.trans_request.trade_action &&
            e.trade_type === i.trans_request.trade_type &&
            e.trade_volume === i.trans_request.trade_volume &&
            e.trade_symbol === i.trans_request.trade_symbol &&
            (s = i);
        }
        if (s) {
          let r;
          (r = 0 === e.trade_type ? s.ask : s.bid),
            t.deleteRequote(s),
            10 ** i.digits * Math.abs(e.price_order - r) > 0 && (s = null);
        }
        return !!s;
      })(t, i, r)
    )
      return 0;
    let o = this.ticksController.getTick(r.trade_symbol, r.isDelayed());
    if (!o) return 10021;
    if (
      (0 === i.trade_type &&
        o.fields &&
        2 & o.fields &&
        i.price_order === o.ask_last) ||
      (1 === i.trade_type &&
        o.fields &&
        1 & o.fields &&
        i.price_order === o.bid_last)
    )
      return 0;
    const a = this.ticksController.getLast(i.trade_symbol);
    if (!(null == a ? void 0 : a.size)) return 0;
    let n = Array.from(a);
    (n = n.slice()), n.length > 20 && (n.length = 20);
    let l,
      c,
      _ = 0,
      d = 0,
      h = 0;
    for (c = n.length - 1; c >= 0; c--)
      if (((o = n[c]), o)) {
        if (0 === i.trade_type) {
          if (!(o.fields && 2 & o.fields)) continue;
          (l = o.ask),
            (d = Math.floor(o.tick_time_ms / 1e3)),
            (h += 1),
            h || (_ = d - 1);
        }
        if (1 === i.trade_type) {
          if (!(o.fields && 1 & o.fields)) continue;
          (l = o.bid),
            (d = Math.floor(o.tick_time_ms / 1e3)),
            (h += 1),
            h || (_ = d - 1);
        }
        if (d < _) {
          s && (e.bad_request += 2);
          break;
        }
        if (h > 2) {
          s && (e.bad_request += 2);
          break;
        }
        if (l === i.price_order) {
          if (h > 1) {
            if (s && ((e.bad_request += 2), e.bad_request >= 15)) break;
          } else s && (e.bad_request -= 1);
          return 0;
        }
      }
    return h ? (c < 0 && s && (e.bad_request += 2), 10021) : 0;
  }
  checkMarket(t) {
    const e = {};
    let i = this.checkPrepare(t, e);
    if (0 !== i || !e.config || !e.trade_position) return i;
    const r = e.config,
      s = e.trade_position;
    return Rt(t.price_order, r)
      ? r.trade.trade_exemode !== Fe.MARKET
        ? 10013
        : At(r, t, !0)
        ? zt(t, r, s)
          ? ((i = this.checkStopsPosition(t, r, s)),
            0 !== i
              ? i
              : ((i = Dt(t, r, s)),
                0 !== i ? i : Mt(r, t.trade_type) ? 0 : 10035))
          : 10014
        : 10030
      : 10015;
  }
  checkRemove(t) {
    const e = this.tradeController.getOrderById(t.trade_order);
    if (!e) return 10013;
    const i = this.symbolsController.getFullSymbolByName(e.trade_symbol);
    if (!i) return 10013;
    const r = Pt(i);
    return 0 !== r
      ? r
      : (0 !== e.order_type && 1 !== e.order_type) ||
        i.trade.trade_exemode === Fe.EXCHANGE
      ? 1 !== e.order_state && 3 !== e.order_state
        ? 10013
        : ((t.trade_symbol = e.trade_symbol),
          (t.trade_type = e.order_type),
          (t.digits = i.digits),
          0)
      : 10013;
  }
  checkExecution(t) {
    if (
      1 !== t.trade_action &&
      2 !== t.trade_action &&
      3 !== t.trade_action &&
      4 !== t.trade_action
    )
      return 0;
    const e = this.symbolsController.getFullSymbolByName(t.trade_symbol);
    if (!e) return 10013;
    switch (e.trade.trade_exemode) {
      case Fe.REQUEST:
        1 !== t.trade_action && (t.trade_action = 1);
        break;
      case Fe.INSTANT:
        e.trade.trade_instant_volume &&
        t.trade_volume > e.trade.trade_instant_volume
          ? (t.trade_action = 1)
          : (t.trade_action = 2);
        break;
      case Fe.MARKET:
        3 !== t.trade_action && (t.trade_action = 3);
        break;
      case Fe.EXCHANGE:
        4 !== t.trade_action && (t.trade_action = 4);
    }
    return 0;
  }
  checkSLTP(t) {
    const e = {};
    let i = this.checkPrepare(t, e);
    if (0 !== i || !e.config || !e.trade_position) return i;
    const r = e.config,
      s = e.trade_position;
    if (!s.trade_volume) return 10036;
    if (!Rt(t.price_sl, r) || !Rt(t.price_tp, r)) return 10016;
    (t.price_order = s.price_close), (t.trade_type = s.isBuy() ? 0 : 1);
    const o = this.ticksController.getTick(r.trade_symbol, r.isDelayed());
    return o
      ? ((i = $t(o, r, t, s.price_close, s.sl, s.tp)),
        0 !== i
          ? i
          : s.sl === t.price_sl && s.tp === t.price_tp
          ? 10025
          : Mt(r, t.trade_type)
          ? 0
          : 10035)
      : 10021;
  }
  checkModify(t) {
    const e = this.tradeController.getOrderById(t.trade_order);
    if (!e) return 10013;
    const i = this.symbolsController.getFullSymbolByName(e.trade_symbol);
    if (!i) return 10013;
    if (
      ((t.trade_type = e.order_type), 0 === e.order_type || 1 === e.order_type)
    )
      return 10013;
    if (1 !== e.order_state && 3 !== e.order_state) return 10013;
    const r = this.checkStopsOrder(t, i, e);
    return 0 !== r
      ? r
      : e.price_order === t.price_order &&
        e.price_trigger === t.price_trigger &&
        e.price_sl === t.price_sl &&
        e.price_tp === t.price_tp &&
        e.type_time === t.type_time &&
        e.time_expiration === t.time_expiration
      ? 10025
      : Mt(i, t.trade_type)
      ? ((t.trade_symbol = e.trade_symbol),
        (t.trade_type = e.order_type),
        (t.digits = i.digits),
        0)
      : 10035;
  }
  checkCloseBy(t, e) {
    if (!t.isHedgedMargin()) return 10013;
    const i = this.tradeController.getPositionById(e.trade_position),
      r = this.tradeController.getPositionById(e.position_by);
    if (!i || !r) return 10013;
    if (i.trade_symbol !== r.trade_symbol || i.trade_action === r.trade_action)
      return 10013;
    const s = this.symbolsController.getFullSymbolByName(i.trade_symbol);
    if (!s) return 10013;
    const o = Pt(s);
    return 0 !== o
      ? o
      : (function (t) {
          return t && t.isOrderEnabled(Ve.CLOSEBY);
        })(s)
      ? ((e.trade_symbol = s.trade_symbol),
        (e.digits = s.digits),
        (e.trade_volume = i.trade_volume),
        0)
      : 10035;
  }
  checkPending(t) {
    const e = {};
    let i = this.checkPrepare(t, e);
    if (0 !== i || !e.config || !e.trade_position) return i;
    const r = e.config,
      s = e.trade_position;
    return (function (t, e) {
      switch (e.type_time) {
        case 0:
          return Boolean(t.trade.trade_time_flags & qe.GTC);
        case 1:
          return Boolean(t.trade.trade_time_flags & qe.DAY);
        case 2:
          return Boolean(t.trade.trade_time_flags & qe.SPECIFIED);
        case 3:
          return Boolean(t.trade.trade_time_flags & qe.SPECIFIED_DAY);
        default:
          return !1;
      }
    })(r, t) &&
      ((2 !== t.type_time && 3 !== t.type_time) ||
        !(
          !t.time_expiration ||
          t.time_expiration < 0 ||
          t.time_expiration > ae
        ))
      ? zt(t, r, s)
        ? ((i = this.checkStopsOrder(t, r, new kr())),
          0 !== i
            ? i
            : t.isLimit() &&
              ((r.trade_price_limit_min &&
                Se(t.price_order, r.trade_price_limit_min, r.digits) < 0) ||
                (r.trade_price_limit_max &&
                  Se(t.price_order, r.trade_price_limit_max, r.digits) > 0))
            ? 10015
            : ((i = Dt(t, r, s)),
              0 !== i
                ? i
                : At(r, t, !0)
                ? Mt(r, t.trade_type)
                  ? (r.trade.trade_exemode !== Fe.MARKET &&
                      r.trade.trade_exemode !== Fe.EXCHANGE &&
                      (t.type_filling = 2),
                    0)
                  : 10035
                : 10030))
        : 10014
      : 10022;
  }
  checkStopsOrder(t, e, i) {
    if (!Rt(t.price_order, e) || !Rt(t.price_trigger, e)) return 10015;
    if (!Rt(t.price_sl, e) || !Rt(t.price_tp, e)) return 10016;
    const r = this.ticksController.getTick(e.trade_symbol, e.isDelayed());
    return r ? $t(r, e, t, i.price_order, i.price_sl, i.price_tp) : 10021;
  }
  checkExchange(t) {
    const e = {};
    let i = this.checkPrepare(t, e);
    if (0 !== i || !e.config || !e.trade_position) return i;
    const r = e.config,
      s = e.trade_position;
    return Rt(t.price_order, r)
      ? r.trade.trade_exemode !== Fe.EXCHANGE
        ? 10013
        : At(r, t, !0)
        ? zt(t, r, s)
          ? ((i = this.checkStopsPosition(t, r, s)),
            0 !== i
              ? i
              : ((i = Dt(t, r, s)),
                0 !== i
                  ? i
                  : Mt(r, t.trade_type)
                  ? ((t.type_flags |= 2), (t.price_order = 0), 0)
                  : 10035))
          : 10014
        : 10030
      : 10015;
  }
  checkStopsPosition(t, e, i) {
    let r = i.sl,
      s = i.tp;
    if (!Rt(t.price_order, e)) return 10015;
    if (!Rt(t.price_sl, e) || !Rt(t.price_tp, e)) return 10016;
    ((0 === t.trade_type && i.isSell()) || (1 === t.trade_type && i.isBuy())) &&
      t.trade_volume >= i.trade_volume &&
      ((r = 0), (s = 0));
    const o = this.ticksController.getTick(e.trade_symbol, e.isDelayed());
    return o ? $t(o, e, t, i.price_close, r, s) : 10021;
  }
  checkPrepare(t, e) {
    let i = null;
    if (this.accountController.getAccount().isHedgedMargin()) {
      if (
        t.trade_position &&
        ((i = this.tradeController.getPositionById(t.trade_position)), !i)
      )
        return 10013;
      if (i && t.isClose()) {
        if (t.trade_volume > i.trade_volume) return 10014;
        if ((t.isBuy() && i.isBuy()) || (t.isSell() && i.isSell()))
          return 10013;
      }
    } else
      t.trade_symbol &&
        (i = this.tradeController.getPositionBySymbol(t.trade_symbol));
    i || (i = new Kr());
    const r = this.symbolsController.getFullSymbolByName(
      i && i.trade_volume ? i.trade_symbol : t.trade_symbol
    );
    if (!r) return 10013;
    const s = Pt(r);
    return 0 !== s
      ? s
      : ((t.trade_symbol = r.trade_symbol),
        (t.digits = r.digits),
        e && ((e.trade_position = i), (e.config = r)),
        0);
  }
  checkPrices(t) {
    const e = {},
      i = this.checkPrepare(t, e);
    if (0 !== i || !e.config || !e.trade_position) return i;
    const r = e.config;
    return r.trade.trade_exemode !== Fe.REQUEST &&
      (r.trade.trade_exemode !== Fe.INSTANT ||
        !r.trade.trade_instant_volume ||
        r.trade.trade_instant_volume >= t.trade_volume)
      ? 10013
      : (function (t, e, i = !1) {
          return (
            void 0 === i && (i = !0),
            !(
              void 0 === e ||
              e <= 0 ||
              (i && e < t.trade.volume_min) ||
              e > t.trade.volume_max ||
              e % t.trade.volume_step
            )
          );
        })(r, t.trade_volume, !1)
      ? 0
      : 10014;
  }
  checkRequest(t) {
    const e = {};
    let i = this.checkPrepare(t, e);
    if (0 !== i || !e.config || !e.trade_position) return i;
    const r = e.trade_position,
      s = e.config;
    return At(s, t, !0)
      ? zt(t, s, r)
        ? ((i = this.checkStopsPosition(t, s, r)),
          0 !== i
            ? i
            : ((i = Dt(t, s, r)),
              0 !== i
                ? i
                : Mt(s, t.trade_type)
                ? ((t.type_filling = 0), 0)
                : 10035))
        : 10014
      : 10030;
  }
}
class yo {
  constructor(t, e, i, r) {
    this.controller = new go(t, e, i, r);
  }
}
class fo extends Ge {
  async getTradeRequest(t) {
    const e = (function (t) {
        const e = [
          { propType: 6, propValue: t.action_id || 0 },
          { propType: 6, propValue: t.trade_action || 0 },
          {
            propType: 11,
            propValue: (t.trade_symbol || "").substring(0, 32),
            propLength: 64,
          },
          { propType: 18, propValue: t.trade_volume || BigInt(0) },
          { propType: 6, propValue: t.digits || 0 },
          { propType: 18, propValue: t.trade_order || BigInt(0) },
          { propType: 6, propValue: t.trade_type || 0 },
          { propType: 6, propValue: t.type_filling || 0 },
          { propType: 6, propValue: t.type_time || 0 },
          { propType: 6, propValue: t.type_flags || 0 },
          { propType: 6, propValue: t.type_reason || 0 },
          { propType: 8, propValue: t.price_order || 0 },
          { propType: 8, propValue: t.price_trigger || 0 },
          { propType: 8, propValue: t.price_sl || 0 },
          { propType: 8, propValue: t.price_tp || 0 },
          { propType: 6, propValue: t.price_deviation || 0 },
          { propType: 8, propValue: t.price_top || 0 },
          { propType: 8, propValue: t.price_bottom || 0 },
          {
            propType: 11,
            propValue: t.comment.substring(0, 32),
            propLength: 64,
          },
          { propType: 18, propValue: t.trade_position || BigInt(0) },
          { propType: 18, propValue: t.position_by || BigInt(0) },
          { propType: 6, propValue: t.time_expiration || 0 },
        ];
        return ee.serialize(e);
      })(t),
      i = await this.socket.sendCommand(12, e);
    return new Uint32Array(i.resBody)[0];
  }
}
class bo {
  constructor() {
    (this.trade_volume = BigInt(0)),
      (this.price_order = 0),
      (this.price_trigger = 0),
      (this.price_sl = 0),
      (this.price_tp = 0),
      (this.price_deviation = 0),
      (this.price_top = 0),
      (this.price_bottom = 0),
      (this.action_id = 0),
      (this.trade_action = 0),
      (this.trade_symbol = ""),
      (this.digits = 0),
      (this.trade_order = BigInt(0)),
      (this.trade_type = 0),
      (this.type_flags = 0),
      (this.comment = ""),
      (this.position_by = BigInt(0)),
      (this.send_time = 0),
      (this.login = 0),
      (this.complete = !1);
  }
  copy() {
    const t = new bo();
    return (
      (t.action_id = this.action_id),
      (t.trade_action = this.trade_action),
      (t.trade_symbol = this.trade_symbol),
      (t.trade_volume = this.trade_volume),
      (t.digits = this.digits),
      (t.trade_order = this.trade_order),
      (t.trade_type = this.trade_type),
      (t.type_filling = this.type_filling),
      (t.type_time = this.type_time),
      (t.type_flags = this.type_flags),
      (t.type_reason = this.type_reason),
      (t.price_order = this.price_order),
      (t.price_trigger = this.price_trigger),
      (t.price_sl = this.price_sl),
      (t.price_tp = this.price_tp),
      (t.price_deviation = this.price_deviation),
      (t.price_top = this.price_top),
      (t.price_bottom = this.price_bottom),
      (t.comment = this.comment),
      (t.trade_position = this.trade_position),
      (t.position_by = this.position_by),
      t
    );
  }
  isBuy() {
    return ue(this.trade_type);
  }
  isSell() {
    return me(this.trade_type);
  }
  isLimit() {
    return fe(this.trade_type);
  }
  isStop() {
    return be(this.trade_type);
  }
  isStopLimit() {
    return ve(this.trade_type);
  }
  isMarket() {
    const t = this.trade_action;
    return 1 === t || 2 === t || 3 === t || 4 === t || 200 === t;
  }
  isPending() {
    return 5 === this.trade_action;
  }
  isModify() {
    return 7 === this.trade_action;
  }
  isRemove() {
    return 8 === this.trade_action;
  }
  isClient() {
    return this.trade_action >= 0 && this.trade_action <= 10;
  }
  isDealer() {
    return this.trade_action >= 200 && this.trade_action <= 208;
  }
  isBalance() {
    return 206 === this.trade_action;
  }
  isServer() {
    return this.trade_action >= 100 && this.trade_action <= 106;
  }
  isExpert() {
    return 0 != (256 & this.type_flags);
  }
  isSignal() {
    return 0 != (512 & this.type_flags);
  }
  isExpiration() {
    return 106 === this.trade_action;
  }
  isSLTP() {
    return 101 === this.trade_action || 102 === this.trade_action;
  }
  isStopoutPosition() {
    return 105 === this.trade_action;
  }
  isSkipMarginCheck() {
    return this.isDealer() && 0 != (1024 & this.type_flags);
  }
  isClose() {
    return Boolean((this.isMarket() || this.isSLTP()) && this.trade_position);
  }
  isCloseBy() {
    return 10 === this.trade_action || 208 === this.trade_action;
  }
}
class vo {
  constructor(t) {
    (this.retcode = 0),
      (this.trade_order = BigInt(0)),
      (this.volume = BigInt(0)),
      (this.price = 0),
      (this.bid = 0),
      (this.ask = 0),
      (this.retcode = t ?? this.retcode);
  }
  isDone() {
    const { retcode: t } = this;
    return 10009 === t || 10010 === t || 11001 === t;
  }
  isFinal() {
    const { retcode: t } = this;
    return 0 !== t && 10001 !== t && 10002 !== t && 10003 !== t && 10028 !== t;
  }
}
class To {
  constructor() {
    (this.requotes = new Map()), (this.count = 1e3), (this.cache = new Map());
  }
  clear() {
    (this.count = 1e3), this.cache.clear(), this.requotes.clear();
  }
  incRequestsCount() {
    this.count += 1;
  }
  getRequestsCount() {
    return this.count;
  }
  setAction(t) {
    this.cache.set(t.action_id, t);
  }
  getAction(t) {
    return this.cache.get(t);
  }
  getRequotesCount() {
    return this.requotes.size;
  }
  getRequote(t) {
    const e = this.requotes.get(t);
    if (e) {
      if (e.time > Date.now()) return e;
      this.requotes.delete(t);
    }
    return null;
  }
  addRequote(t) {
    this.requotes.set(t.trans_request.trade_symbol, t);
  }
  getRequotes() {
    return Array.from(this.requotes.values());
  }
  deleteRequote(t) {
    this.requotes.delete(t.trans_request.trade_symbol);
  }
}
class So {
  constructor(t, e, i, r, s, o, a, n) {
    (this.requestsStorage = new To()),
      (this.emitter = t),
      (this.requestsApi = e),
      (this.loginController = i),
      (this.accountController = r),
      (this.symbolsController = s),
      (this.tradeController = o),
      (this.historyController = a),
      (this.checkController = n);
  }
  destroy() {
    this.clear();
  }
  clear() {
    this.requestsStorage.clear();
  }
  send(t) {
    (t.type_reason = 0), (t.type_flags &= -257), (t.type_flags &= -513);
    const e = this.accountController.getAccount();
    (t.login = e.login),
      (t.action_id = this.requestsStorage.getRequestsCount()),
      this.requestsStorage.incRequestsCount(),
      (t.send_time = Date.now());
    const i = this.checkController.checkAction(this, t, !0);
    if (0 !== i) {
      const e = this.symbolsController.getSymbolByName(t.trade_symbol);
      return (
        this.emitter.trigger(
          6,
          Vt(
            this.tradeController,
            this.historyController,
            this.accountController,
            e,
            t,
            new vo(i)
          )
        ),
        i
      );
    }
    if (
      !this.loginController.hasSignalServerConnection() ||
      !this.loginController.hasTradeServerConnection()
    ) {
      const e = this.symbolsController.getSymbolByName(t.trade_symbol);
      return (
        this.emitter.trigger(
          6,
          Vt(
            this.tradeController,
            this.historyController,
            this.accountController,
            e,
            t,
            new vo(10)
          )
        ),
        i
      );
    }
    this.requestsApi
      .getTradeRequest(t)
      .then((e) => this.onSend(t, e))
      .catch(() => this.onTimeout(t));
    const r = this.symbolsController.getSymbolByName(t.trade_symbol);
    return (
      this.emitter.trigger(
        6,
        Vt(
          this.tradeController,
          this.historyController,
          this.accountController,
          r,
          t,
          new vo(10001)
        )
      ),
      this.requestsStorage.setAction(t),
      0
    );
  }
  onSend(t, e) {
    if (0 !== e) {
      const i = new vo(e),
        r = this.symbolsController.getSymbolByName(t.trade_symbol),
        s = Vt(
          this.tradeController,
          this.historyController,
          this.accountController,
          r,
          t,
          new vo(e)
        );
      this.emitter.trigger(6, s),
        this.emitter.trigger(2, {
          id: t.action_id,
          order: "",
          action: Ft(t),
          result: Gt(i),
          code: e,
          log: s,
        });
    }
  }
  onTimeout(t) {
    if (this) {
      const e = this.symbolsController.getSymbolByName(t.trade_symbol),
        i = Vt(
          this.tradeController,
          this.historyController,
          this.accountController,
          e,
          t,
          new vo(10012)
        );
      this.emitter.trigger(6, i),
        this.emitter.trigger(2, {
          id: t.action_id,
          order: "",
          action: Ft(t),
          code: 10012,
          log: i,
        });
    }
  }
  getAction(t) {
    return this.requestsStorage.getAction(t);
  }
  addRequote(t) {
    this.requestsStorage.addRequote(t);
  }
  loadAndCheckConfig(t, e) {
    return (
      this.symbolsController.getFullSymbolByName(e) ||
      ((t.result.retcode = 2), null)
    );
  }
  orderDelete(t) {
    const e = Yt();
    if ((Qt(e, t), !t)) return e;
    const i = this.loadAndCheckConfig(e, t.trade_symbol);
    return i
      ? ((function (t, e, i) {
          const { request: r } = t;
          (r.trade_symbol = i.trade_symbol),
            (r.trade_action = 8),
            (r.trade_volume = i.volume_initial),
            (r.trade_order = i.trade_order),
            (r.price_order = O(i.price_order, e.trade_tick_size, e.digits)),
            (r.price_trigger = O(i.price_trigger, e.trade_tick_size, e.digits)),
            (r.price_sl = O(i.price_sl, e.trade_tick_size, e.digits)),
            (r.price_tp = O(i.price_tp, e.trade_tick_size, e.digits)),
            (r.type_time = i.type_time),
            (r.time_expiration = Math.round((i.time_expiration ?? 0) / 1e3)),
            (r.trade_type = i.order_type);
        })(e, i, t),
        (e.result.retcode = this.send(e.request)),
        e)
      : e;
  }
  orderModify(t, e, i, r, s, o, a, n) {
    const l = Yt();
    if ((Qt(l, t), !t)) return l;
    const c = this.loadAndCheckConfig(l, t.trade_symbol);
    return c
      ? ((function (t, e, i, r, s, o, a, n, l, c) {
          const { request: _ } = t;
          let d = r ? r - i.price_order : 0;
          i.price_sl && (i.price_sl = oe(i.price_sl + d, i.digits)),
            i.price_tp && (i.price_tp = oe(i.price_tp + d, i.digits)),
            (6 !== i.order_type && 7 !== i.order_type) ||
              ((i.price_trigger = oe(i.price_trigger + d, i.digits)),
              c &&
                0 === d &&
                ((d = c - i.price_trigger),
                i.price_sl && (i.price_sl = oe(i.price_sl + d, i.digits)),
                i.price_tp && (i.price_tp = oe(i.price_tp + d, i.digits))));
          const h = e.trade_tick_size,
            p = e.digits;
          (_.trade_symbol = i.trade_symbol),
            (_.trade_action = 7),
            (_.trade_volume = i.volume_initial),
            (_.trade_order = i.trade_order),
            (_.trade_type = i.order_type),
            (_.price_order = O(r ?? i.price_order, h, p)),
            (_.price_trigger = O(c ?? i.price_trigger, h, p)),
            (_.price_sl = O(s ?? i.price_sl, h, p)),
            (_.price_tp = O(o ?? i.price_tp, h, p)),
            (_.type_time = a ?? i.type_time),
            (_.time_expiration = Math.round((n ?? i.time_expiration) / 1e3)),
            (_.comment = l ?? i.comment);
        })(l, c, t, e, i, r, s, o, a, n),
        (l.result.retcode = this.send(l.request)),
        l)
      : l;
  }
  orderOpen(t, e, i, r, s, o, a, n, l, c, _) {
    const d = Yt(),
      h = this.loadAndCheckConfig(d, e);
    return h
      ? ((function (t, e, i, r, s, o, a, n, l, c, _, d) {
          const { request: h } = t;
          (h.trade_type = i),
            (h.trade_symbol = e.trade_symbol),
            (h.trade_action = ye(i) ? 5 : 2),
            (h.trade_volume = Yi.toInt(r)),
            (h.digits = e.digits),
            (h.type_flags = 2),
            (h.price_order = O(s, e.trade_tick_size, e.digits)),
            (h.price_trigger = O(_ ?? 0, e.trade_tick_size, e.digits)),
            (h.price_sl = O(o ?? 0, e.trade_tick_size, e.digits)),
            (h.price_tp = O(a ?? 0, e.trade_tick_size, e.digits)),
            (h.type_time = n ?? 0),
            (h.time_expiration = Math.round((l ?? 0) / 1e3)),
            (h.comment = c ?? ""),
            e.trade.trade_exemode === Fe.EXCHANGE
              ? (h.type_filling = d ?? 2)
              : (h.type_filling = 2);
        })(d, h, t, i, r, s, o, a, n, l, c, _),
        (d.result.retcode = this.send(d.request)),
        d)
      : d;
  }
  positionClose(t, e, i, r) {
    const s = Yt();
    if ((Kt(s, t), !t)) return s;
    const o = this.loadAndCheckConfig(s, t.trade_symbol);
    return o
      ? ((function (t, e, i, r, s, o, a) {
          var n;
          const { request: l } = t;
          switch (
            ((l.trade_symbol = e.trade_symbol),
            (l.trade_volume = a ? Yi.toInt(a) : i.trade_volume),
            (l.digits = e.digits),
            (l.trade_order = BigInt(0)),
            (l.type_flags = 3),
            (l.trade_position = i.position_id),
            (l.price_order = i.price_close),
            (l.price_trigger = 0),
            (l.price_sl = 0),
            (l.price_tp = 0),
            (l.type_time = 0),
            (l.time_expiration = 0),
            (l.trade_type = i.isBuy() ? 1 : 0),
            null == (n = e.trade) ? void 0 : n.trade_exemode)
          ) {
            case Fe.INSTANT:
              if (
                ((l.type_filling = 0),
                o &&
                  !r &&
                  (i.isBuy()
                    ? (l.price_order = o.bid)
                    : i.isSell() && (l.price_order = o.ask)),
                (e.trade && !e.trade.trade_instant_volume) ||
                  l.trade_volume <= e.trade.trade_instant_volume)
              ) {
                (l.trade_action = 2), (l.price_deviation = 1);
                break;
              }
            case Fe.REQUEST:
              s
                ? ((l.price_order = s), (l.trade_action = 1))
                : (l.trade_action = 0);
              break;
            case Fe.MARKET:
              (l.trade_action = 3),
                e.trade && e.trade.trade_fill_flags & Ue.IOC
                  ? (l.type_filling = 1)
                  : e.trade && e.trade.trade_fill_flags & Ue.FOK
                  ? (l.type_filling = 0)
                  : (l.type_filling = 2);
              break;
            case Fe.EXCHANGE:
              (l.trade_action = 4), (l.type_filling = 2);
          }
        })(s, o, t, e, i, this.requestsStorage.getRequote(t.trade_symbol), r),
        (s.result.retcode = this.send(s.request)),
        s)
      : s;
  }
  positionCloseBySymbol(t) {
    const e = this.tradeController.getPositionBySymbol(t);
    return this.positionClose(e, !1);
  }
  positionCloseBy(t, e) {
    const i = Yt();
    if ((Kt(i, t), !t)) return i;
    if ((Kt(i, e), !e)) return i;
    const r = this.loadAndCheckConfig(i, t.trade_symbol);
    return r
      ? ((function (t, e, i, r) {
          const { request: s } = t;
          let o = i.trade_volume;
          o >= r.trade_volume && (o = r.trade_volume),
            (s.trade_symbol = e.trade_symbol),
            (s.trade_volume = o),
            (s.digits = e.digits),
            (s.trade_order = BigInt(0)),
            (s.type_flags = 3),
            (s.trade_position = i.position_id),
            (s.position_by = r.position_id),
            (s.price_order = i.price_close),
            (s.price_trigger = 0),
            (s.price_sl = 0),
            (s.price_tp = 0),
            (s.type_time = 0),
            (s.time_expiration = 0),
            (s.trade_type = i.isBuy() ? 1 : 0),
            (s.trade_action = 10),
            (s.type_filling = 0);
        })(i, r, t, e),
        (i.result.retcode = this.send(i.request)),
        i)
      : i;
  }
  positionModify(t, e, i, r) {
    const s = Yt();
    if ((Kt(s, t), !t)) return s;
    const o = this.loadAndCheckConfig(s, t.trade_symbol);
    return o
      ? ((function (t, e, i, r, s) {
          const { request: o } = t;
          (o.trade_symbol = e.trade_symbol),
            (o.trade_position = i.position_id),
            (o.trade_volume = i.trade_volume),
            (o.trade_action = 6),
            (o.digits = e.digits),
            r !== Number.MAX_VALUE
              ? (o.price_sl = O(r, e.trade_tick_size, e.digits))
              : (o.price_sl = O(i.sl, e.trade_tick_size, e.digits)),
            s !== Number.MAX_VALUE
              ? (o.price_tp = O(s, e.trade_tick_size, e.digits))
              : (o.price_tp = O(i.tp, e.trade_tick_size, e.digits));
        })(s, o, t, e, i),
        (s.result.retcode = this.send(s.request)),
        s)
      : s;
  }
  positionModifyBySymbol(t, e, i) {
    const r = this.tradeController.getPositionBySymbol(t);
    return this.positionModify(r, e, i);
  }
  positionOpen(t, e, i, r, s, o, a, n) {
    const l = Yt(),
      c = this.loadAndCheckConfig(l, t);
    return c
      ? ((function (t, e, i, r, s, o, a, n, l, c, _) {
          var d;
          void 0 === n &&
            void 0 === l &&
            (r ||
              (i &&
                ((0 === o && i.isBuy()) || (1 === o && i.isSell())) &&
                ((n = i.sl), (l = i.tp)))),
            n || (n = 0),
            l || (l = 0);
          const { request: h } = t;
          switch (
            ((h.trade_symbol = e.trade_symbol),
            (h.trade_volume = Yi.toInt(s)),
            (h.digits = e.digits),
            (h.type_flags = 2),
            (h.price_order = 0),
            (h.price_trigger = 0),
            (h.price_sl = O(n, e.trade_tick_size, e.digits)),
            (h.price_tp = O(l, e.trade_tick_size, e.digits)),
            (h.type_time = 0),
            (h.time_expiration = 0),
            (h.trade_type = o),
            (h.comment = _),
            null == (d = e.trade) ? void 0 : d.trade_exemode)
          ) {
            case Fe.INSTANT:
              if (
                ((h.type_filling = 0),
                !e.trade.trade_instant_volume ||
                  h.trade_volume <= e.trade.trade_instant_volume)
              ) {
                (h.trade_action = 2),
                  (h.price_order = a),
                  (h.price_deviation = 0);
                break;
              }
            case Fe.REQUEST:
              a
                ? ((h.price_order = a), (h.trade_action = 1))
                : (h.trade_action = 0);
              break;
            case Fe.MARKET:
              (h.trade_action = 3),
                e.trade.trade_fill_flags & Ue.IOC
                  ? (h.type_filling = 1)
                  : e.trade.trade_fill_flags & Ue.FOK
                  ? (h.type_filling = 0)
                  : (h.type_filling = 2);
              break;
            case Fe.EXCHANGE:
              (h.trade_action = 4),
                (h.type_filling = c),
                (h.type_flags = 2),
                (h.price_order = 0);
          }
        })(
          l,
          c,
          this.tradeController.getPositionBySymbol(c.trade_symbol),
          this.accountController.getAccount().isHedgedMargin(),
          e,
          i,
          r,
          s,
          o,
          a,
          n
        ),
        (l.result.retcode = this.send(l.request)),
        l)
      : l;
  }
  getRequotes() {
    return this.requestsStorage.getRequotes();
  }
  deleteRequote(t) {
    this.requestsStorage.deleteRequote(t);
  }
}
class ko {
  constructor(t, e) {
    (this.CODES = {
      REQUEST_INWAY: Ht(10001),
      REQUEST_ACCEPTED: Ht(10002),
      REQUEST_PROCESS: Ht(10003),
      REQUEST_REQUOTE: Ht(10004),
      REQUEST_PRICES: Ht(10005),
      REQUEST_REJECT: Ht(10006),
      REQUEST_CANCEL: Ht(10007),
      REQUEST_PLACED: Ht(10008),
      REQUEST_DONE: Ht(10009),
      REQUEST_DONE_PARTIAL: Ht(10010),
      REQUEST_ERROR: Ht(10011),
      REQUEST_TIMEOUT: Ht(10012),
      REQUEST_INVALID: Ht(10013),
      REQUEST_INVALID_VOLUME: Ht(10014),
      REQUEST_INVALID_PRICE: Ht(10015),
      REQUEST_INVALID_STOPS: Ht(10016),
      REQUEST_TRADE_DISABLED: Ht(10017),
      REQUEST_MARKET_CLOSED: Ht(10018),
      REQUEST_NO_MONEY: Ht(10019),
      REQUEST_PRICE_CHANGED: Ht(10020),
      REQUEST_PRICE_OFF: Ht(10021),
      REQUEST_INVALID_EXP: Ht(10022),
      REQUEST_ORDER_CHANGED: Ht(10023),
      REQUEST_TOO_MANY: Ht(10024),
      REQUEST_NO_CHANGES: Ht(10025),
      REQUEST_AT_DISABLED_SERVER: Ht(10026),
      REQUEST_AT_DISABLED_CLIENT: Ht(10027),
      REQUEST_LOCKED: Ht(10028),
      REQUEST_FROZEN: Ht(10029),
      REQUEST_INVALID_FILL: Ht(10030),
      REQUEST_CONNECTION: Ht(10031),
      REQUEST_ONLY_REAL: Ht(10032),
      REQUEST_LIMIT_ORDERS: Ht(10033),
      REQUEST_LIMIT_VOLUME: Ht(10034),
      REQUEST_INVALID_ORDER: Ht(10035),
      REQUEST_POSITION_CLOSED: Ht(10036),
      REQUEST_EXECUTION_SKIPPED: Ht(10037),
      REQUEST_CLOSE_ORDER_EXIST: Ht(10039),
      REQUEST_RETURN: Ht(11e3),
      REQUEST_DONE_CANCEL: Ht(11001),
      REQUEST_REQUOTE_RETURN: Ht(11002),
      REQUEST_INVALID_CLOSE_VOLUME: Ht(10038),
      REQUEST_LIMIT_POSITIONS: Ht(10040),
      REQUEST_REJECT_CANCEL: Ht(10041),
      REQUEST_LONG_ONLY: Ht(10042),
      REQUEST_SHORT_ONLY: Ht(10043),
      REQUEST_CLOSE_ONLY: Ht(10044),
      REQUEST_PROHIBITED_BY_FIFO: Ht(10045),
      OK: Ht(0),
      OK_NONE: Ht(1),
      ERROR: Ht(2),
      ERROR_PARAMS: Ht(3),
      ERROR_DATA: Ht(4),
      ERROR_DISK: Ht(5),
      ERROR_MEM: Ht(6),
      ERROR_NETWORK: Ht(7),
      ERROR_PERMISSIONS: Ht(8),
      ERROR_TIMEOUT: Ht(9),
      ERROR_CONNECTION: Ht(10),
      ERROR_NOSERVICE: Ht(11),
      ERROR_FREQUENT: Ht(12),
      ERROR_NOTFOUND: Ht(13),
      ERROR_PARTIAL: Ht(14),
      ERROR_SHUTDOWN: Ht(15),
      ERROR_CANCEL: Ht(16),
      ERROR_DUPLICATE: Ht(17),
    }),
      (this.requestsController = t),
      (this.tradeController = e);
  }
  positionOpen(t, e, i, r, s, o, a, n) {
    return Wt(this.requestsController.positionOpen(e, i, t, r, s, o, a, n));
  }
  positionModify(t, e, i, r) {
    const s = this.tradeController.getPositionById(BigInt(t));
    return Wt(this.requestsController.positionModify(s, e, i, r));
  }
  modifyBySymbol(t, e, i) {
    return Wt(this.requestsController.positionModifyBySymbol(t, e, i));
  }
  positionClose(t, e, i, r) {
    const s = this.tradeController.getPositionById(BigInt(t)),
      o = this.requestsController.positionClose(s, e, i, r);
    return o && Wt(o);
  }
  positionCloseBy(t, e) {
    const i = this.tradeController.getPositionById(BigInt(t)),
      r = this.tradeController.getPositionById(BigInt(e)),
      s = this.requestsController.positionCloseBy(i, r);
    return s && Wt(s);
  }
  positionCloseBySymbol(t) {
    const e = this.requestsController.positionCloseBySymbol(t);
    return e && Wt(e);
  }
  requestPrice(t, e, i) {
    return this.positionOpen(e, t, i, 0, 0, 0, 0, "");
  }
  orderOpen(t, e, i, r, s, o, a, n, l, c, _) {
    return Wt(
      this.requestsController.orderOpen(t, e, i, r, s, o, a, n, l, c, _)
    );
  }
  orderModify(t, e, i, r, s, o, a, n) {
    const l = this.tradeController.getOrderById(BigInt(t));
    return Wt(this.requestsController.orderModify(l, e, i, r, s, o, a, n));
  }
  orderDelete(t) {
    const e = this.tradeController.getOrderById(BigInt(t));
    return e ? Wt(this.requestsController.orderDelete(e)) : null;
  }
}
class Co {
  constructor(t, e, i, r, s, o, a, n) {
    (this.controller = new So(t, new fo(e), i, r, s, o, a, n)),
      (this.view = new ko(this.controller, o));
  }
}
const Eo = [
    { propType: 6 },
    { propType: 6 },
    { propType: 11, propLength: 64 },
    { propType: 18 },
    { propType: 6 },
    { propType: 17 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 11, propLength: 64 },
    { propType: 18 },
    { propType: 18 },
    { propType: 12, propLength: 4 },
  ],
  Bo = ee.getSeriesSize(Eo),
  wo = [
    { propType: 6 },
    { propType: 17 },
    { propType: 17 },
    { propType: 17 },
    { propType: 8 },
    { propType: 6 },
    { propType: 8 },
    { propType: 8 },
    { propType: 8 },
    { propType: 11, propLength: 64 },
  ],
  Lo = [
    { propType: 6 },
    {
      propType: 12,
      propLength: Bo,
      parser: function (t, e = 0) {
        return (function (t, e = 0) {
          const i = ee.parse(t, Eo, e),
            r = new bo();
          return (
            (r.action_id = i[0]),
            (r.trade_action = i[1]),
            (r.trade_symbol = i[2]),
            (r.trade_volume = i[3]),
            (r.digits = i[4]),
            (r.trade_order = i[5]),
            (r.trade_type = i[6]),
            (r.type_filling = i[7]),
            (r.type_time = i[8]),
            (r.type_flags = i[9]),
            (r.type_reason = i[10]),
            (r.price_order = i[11]),
            (r.price_trigger = i[12]),
            (r.price_sl = i[13]),
            (r.price_tp = i[14]),
            (r.price_deviation = i[15]),
            (r.price_top = i[16]),
            (r.price_bottom = i[17]),
            (r.comment = i[18]),
            (r.trade_position = i[19]),
            (r.position_by = i[20]),
            r
          );
        })(t, e);
      },
    },
    {
      propType: 12,
      propLength: ee.getSeriesSize(wo),
      parser: function (t, e = 0) {
        return (function (t, e = 0) {
          const i = ee.parse(t, wo, e),
            r = new vo(i[0]);
          return (
            (r.retcode = i[0]),
            (r.deal = i[1]),
            (r.trade_order = i[2]),
            (r.volume = i[3]),
            (r.price = i[4]),
            (r.res_time = i[5]),
            (r.bid = i[6]),
            (r.ask = i[7]),
            (r.last = i[8]),
            (r.comment = i[9]),
            r
          );
        })(t, e);
      },
    },
  ];
class Oo extends Ge {
  constructor() {
    super(...arguments), (this.map = new WeakMap());
  }
  on(t) {
    let e = this.map.get(t);
    e || ((e = this.onResult.bind(this, t)), this.map.set(t, e)),
      this.socket.on(19, e);
  }
  off(t) {
    const e = this.map.get(t);
    e && this.socket.off(19, e);
  }
  onResult(t, e) {
    var i;
    t(((i = e.resBody), ee.parse(i, Lo, 0)));
  }
}
class Io {
  constructor(t, e, i, r, s, o, a) {
    (this.emitter = t),
      (this.responseApi = e),
      (this.accountController = i),
      (this.symbolsController = r),
      (this.requestsController = s),
      (this.tradeController = o),
      (this.historyController = a),
      (this.onResponse = this.onResponse.bind(this)),
      this.responseApi.on(this.onResponse);
  }
  destroy() {
    this.responseApi.off(this.onResponse);
  }
  onResponse(t) {
    this.accountController.getAccount();
    let e = t[1];
    const i = t[2];
    if (((e = this.requestsController.getAction(e.action_id)), !e)) return;
    const r = this.symbolsController.getSymbolByName(e.trade_symbol),
      s = new Date().getTime() - e.send_time,
      o = Vt(
        this.tradeController,
        this.historyController,
        this.accountController,
        r,
        e,
        i,
        s
      );
    if (
      (i.isFinal() && this.emitter.trigger(7, o),
      2 === e.trade_action && 10004 === i.retcode)
    ) {
      const t = this.symbolsController.getFullSymbolByName(e.trade_symbol),
        r = (null == t ? void 0 : t.trade.trade_instant_timeout) ?? 7;
      this.requestsController.addRequote({
        trans_request: e,
        time: Date.now() + 1e3 * r,
        bid: i.bid,
        ask: i.ask,
      });
    }
    (e.complete = !0),
      this.emitter.trigger(2, {
        action: Ft(e),
        result: Gt(i),
        id: e.action_id,
        order: i.trade_order ? i.trade_order.toString() : "",
        code: i.retcode,
        log: o,
      }),
      this.emitter.trigger(6, o);
  }
}
class Ro {
  constructor(t, e, i, r, s, o, a) {
    this.controller = new Io(t, new Oo(e), i, r, s, o, a);
  }
}
const Ao = [
    { propType: 6 },
    { propType: 11, propLength: 512 },
    { propType: 11, propLength: 512 },
    { propType: 6 },
    { propType: 12, propLength: 256 },
  ],
  Mo = ee.getSeriesSize(Ao);
class $o extends Ge {
  async loadCorporateLinks() {
    return (function (t) {
      const e = [],
        i = new DataView(t).getUint32(0, !0);
      let r = 4;
      for (let s = 0; s < i; s++) e.push(jt(t, r)), (r += Mo);
      return e;
    })((await this.socket.sendCommand(44)).resBody);
  }
}
class xo {
  constructor(t, e) {
    (this.corporateLinksStorage = t), (this.corporateLinksApi = e);
  }
  async getLinks() {
    if (this.corporateLinksStorage.links)
      return this.corporateLinksStorage.links;
    const t = await this.corporateLinksApi.loadCorporateLinks();
    return (
      (this.corporateLinksStorage.links = t),
      [...this.corporateLinksStorage.links]
    );
  }
}
class Po {
  constructor() {
    this.links = null;
  }
}
class zo {
  constructor(t) {
    this.corporateLinksController = t;
  }
  async getLinks() {
    return this.corporateLinksController.getLinks();
  }
}
class Do {
  constructor(t) {
    (this.storage = new Po()),
      (this.api = new $o(t)),
      (this.constroller = new xo(this.storage, this.api)),
      (this.view = new zo(this.constroller));
  }
}
class No {
  constructor(t, e, i, r) {
    (this.socket = e),
      (this.destroy = this.destroy.bind(this)),
      (this.onError = this.onError.bind(this)),
      (this.onDisconnect = this.onDisconnect.bind(this)),
      (this.emitter = t),
      (this.login = i),
      this.emitter.on(15, this.onError),
      this.emitter.on(11, this.onDisconnect),
      (this.account = r),
      (this.notify = new bi(e)),
      (this.symbolTypes = new wi(e)),
      (this.corporateLinks = new Do(e)),
      (this.symbols = new or(
        this.emitter,
        e,
        this.symbolTypes.controller,
        this.account.controller
      )),
      (this.spreads = new Ui(e, this.symbols.controller)),
      (this.ticks = new vr(
        this.emitter,
        e,
        this.symbols.controller,
        this.spreads.controller
      )),
      (this.converter = new Sr(this.symbols.controller, this.ticks.controller)),
      (this.margin = new ns(
        this.symbols.controller,
        this.ticks.controller,
        this.converter.controller,
        this.spreads.controller,
        this.account.controller
      )),
      (this.rates = new ps(e)),
      (this.otp = new ms(e)),
      (this.history = new As(e, this.account.controller)),
      (this.trade = new Hs(
        this.emitter,
        e,
        this.ticks.controller,
        this.symbols.controller,
        this.account.controller,
        this.converter.controller,
        this.margin.controller
      )),
      (this.books = new io(
        this.emitter,
        e,
        this.symbols.controller,
        this.trade.controller
      )),
      (this.updater = new so(
        this.emitter,
        this.margin.controller,
        this.account.controller,
        this.trade.controller,
        this.history.controller
      )),
      (this.transactions = new mo(
        this.emitter,
        e,
        this.account.controller,
        this.ticks.controller,
        this.updater.controller,
        this.history.controller,
        this.trade.controller
      )),
      (this.check = new yo(
        this.account.controller,
        this.symbols.controller,
        this.ticks.controller,
        this.trade.controller
      )),
      (this.requests = new Co(
        this.emitter,
        e,
        this.login.controller,
        this.account.controller,
        this.symbols.controller,
        this.trade.controller,
        this.history.controller,
        this.check.controller
      )),
      (this.response = new Ro(
        this.emitter,
        e,
        this.account.controller,
        this.symbols.controller,
        this.requests.controller,
        this.trade.controller,
        this.history.controller
      ));
  }
  async init() {
    this.account.controller.getAccount().isResetPass() ||
      (await this.symbolTypes.controller.init(),
      await this.symbols.controller.init(),
      await this.trade.controller.init(),
      this.updater.controller.init());
  }
  static async create(t, e, i, r) {
    const s = await mi.create(t, e, r),
      o = new No(t, e, i, s);
    return (
      await o.init(),
      {
        api: o,
        view: {
          destroy: o.destroy,
          login: o.login.view,
          account: o.account.view,
          notify: o.notify.view,
          symbols: o.symbols.view,
          spreads: o.spreads.view,
          symbolTypes: o.symbolTypes.view,
          corporateLinks: o.corporateLinks.view,
          rates: o.rates.view,
          otp: o.otp.view,
          ticks: o.ticks.view,
          history: o.history.view,
          books: o.books.controller,
          trade: o.trade.view,
          request: o.requests.view,
          margin: o.margin.view,
          on: t.on.bind(t),
          off: t.off.bind(t),
        },
      }
    );
  }
  destroy() {
    this.login.controller.destroy(),
      this.account.controller.destroy(),
      this.symbolTypes.controller.destroy(),
      this.symbols.controller.destroy(),
      this.ticks.controller.destroy(),
      this.rates.controller.destroy(),
      this.history.controller.destroy(),
      this.trade.controller.destroy(),
      this.books.controller.destroy(),
      this.transactions.controller.destroy(),
      this.requests.controller.destroy(),
      this.response.controller.destroy();
  }
  onError() {}
  onClose() {}
  onDisconnect() {}
}
export { No as NextApi };
