function e(e, n, o) {
  const t = e.slice();
  return (t[17] = n[o]), (t[18] = n), (t[19] = o), t;
}
function n(e) {
  function n(n) {
    e[10](n, e[17]);
  }
  function o(n) {
    e[11](n);
  }
  let t,
    r,
    i,
    s,
    l = { name: a(e[17]) };
  return (
    void 0 !== e[3][a(e[17])] && (l.checked = e[3][a(e[17])]),
    void 0 !== e[2] && (l.errors = e[2]),
    (t = new fe({ props: l })),
    pe.push(() => $e(t, "checked", n)),
    pe.push(() => $e(t, "errors", o)),
    {
      c() {
        J(t.$$.fragment);
      },
      m(e, n) {
        Y(t, e, n), (s = !0);
      },
      p(n, o) {
        e = n;
        const s = {};
        1 & o && (s.name = a(e[17])),
          !r &&
            9 & o &&
            ((r = !0), (s.checked = e[3][a(e[17])]), ge(() => (r = !1))),
          !i && 4 & o && ((i = !0), (s.errors = e[2]), ge(() => (i = !1))),
          t.$set(s);
      },
      i(e) {
        s || (Z(t.$$.fragment, e), (s = !0));
      },
      o(e) {
        oe(t.$$.fragment, e), (s = !1);
      },
      d(e) {
        ie(t, e);
      },
    }
  );
}
function o(e) {
  let o,
    t,
    r,
    i,
    s,
    l,
    c = Number(e[17].flags),
    d = a(e[17]) + "",
    u = c && n(e);
  return {
    c() {
      (o = W("div")),
        u && u.c(),
        (t = L()),
        (r = W("a")),
        (i = P(d)),
        K(r, "class", "link svelte-14is8za"),
        K(r, "href", (s = e[17].url)),
        K(r, "target", "_blank"),
        K(r, "rel", "noreferrer"),
        K(o, "class", "agreement svelte-14is8za");
    },
    m(e, n) {
      Q(e, o, n), u && u.m(o, null), X(o, t), X(o, r), X(r, i), (l = !0);
    },
    p(e, m) {
      1 & m && (c = Number(e[17].flags)),
        c
          ? u
            ? (u.p(e, m), 1 & m && Z(u, 1))
            : ((u = n(e)), u.c(), Z(u, 1), u.m(o, t))
          : u &&
            (ee(),
            oe(u, 1, 1, () => {
              u = null;
            }),
            ne()),
        (!l || 1 & m) && d !== (d = a(e[17]) + "") && le(i, d),
        (!l || (1 & m && s !== (s = e[17].url))) && K(r, "href", s);
    },
    i(e) {
      l || (Z(u), (l = !0));
    },
    o(e) {
      oe(u), (l = !1);
    },
    d(e) {
      e && te(o), u && u.d();
    },
  };
}
function t(e) {
  let n,
    o = window.tr(window.lang.login.form.btn.back) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function r(e) {
  let n,
    o = window.tr(window.lang.login.demo.btnOpenDemo) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function i(e) {
  let n, o, i, s;
  return (
    (n = new ce({ props: { $$slots: { default: [t] }, $$scope: { ctx: e } } })),
    n.$on("click", e[12]),
    (i = new ce({
      props: { active: !0, $$slots: { default: [r] }, $$scope: { ctx: e } },
    })),
    i.$on("click", e[8]),
    {
      c() {
        J(n.$$.fragment), (o = L()), J(i.$$.fragment);
      },
      m(e, t) {
        Y(n, e, t), Q(e, o, t), Y(i, e, t), (s = !0);
      },
      p(e, o) {
        const t = {};
        1048576 & o && (t.$$scope = { dirty: o, ctx: e }), n.$set(t);
        const r = {};
        1048576 & o && (r.$$scope = { dirty: o, ctx: e }), i.$set(r);
      },
      i(e) {
        s || (Z(n.$$.fragment, e), Z(i.$$.fragment, e), (s = !0));
      },
      o(e) {
        oe(n.$$.fragment, e), oe(i.$$.fragment, e), (s = !1);
      },
      d(e) {
        e && te(o), ie(n, e), ie(i, e);
      },
    }
  );
}
function s(n) {
  let t,
    r,
    s,
    a,
    l,
    c,
    d,
    u,
    m,
    f = U(n[0]),
    p = [];
  for (let i = 0; i < f.length; i += 1) p[i] = o(e(n, f, i));
  const $ = (e) =>
    oe(p[e], 1, 1, () => {
      p[e] = null;
    });
  return (
    (u = new H({
      props: {
        cols: 2,
        style: n[1] ? "" : "justify-content: flex-end;",
        $$slots: { default: [i] },
        $$scope: { ctx: n },
      },
    })),
    {
      c() {
        (t = W("div")),
          (r = W("h2")),
          (r.textContent = `${n[5]}`),
          (s = L()),
          (a = W("a")),
          (l = P(n[7])),
          (c = L());
        for (let e = 0; e < p.length; e += 1) p[e].c();
        (d = L()),
          J(u.$$.fragment),
          K(r, "class", "title svelte-14is8za"),
          K(a, "class", "broker-site link svelte-14is8za"),
          K(a, "href", n[6]);
      },
      m(e, n) {
        Q(e, t, n), X(t, r), X(t, s), X(t, a), X(a, l), X(t, c);
        for (let o = 0; o < p.length; o += 1) p[o] && p[o].m(t, null);
        X(t, d), Y(u, t, null), (m = !0);
      },
      p(n, [r]) {
        if (13 & r) {
          let i;
          for (f = U(n[0]), i = 0; i < f.length; i += 1) {
            const s = e(n, f, i);
            p[i]
              ? (p[i].p(s, r), Z(p[i], 1))
              : ((p[i] = o(s)), p[i].c(), Z(p[i], 1), p[i].m(t, d));
          }
          for (ee(), i = f.length; i < p.length; i += 1) $(i);
          ne();
        }
        const i = {};
        2 & r && (i.style = n[1] ? "" : "justify-content: flex-end;"),
          1048576 & r && (i.$$scope = { dirty: r, ctx: n }),
          u.$set(i);
      },
      i(e) {
        if (!m) {
          for (let e = 0; e < f.length; e += 1) Z(p[e]);
          Z(u.$$.fragment, e), (m = !0);
        }
      },
      o(e) {
        p = p.filter(Boolean);
        for (let n = 0; n < p.length; n += 1) oe(p[n]);
        oe(u.$$.fragment, e), (m = !1);
      },
      d(e) {
        e && te(t), re(p, e), ie(u);
      },
    }
  );
}
function a(e) {
  return e.caption_type === de.CUSTOM ? e.caption_custom : ue(e.caption_type);
}
function l(e, n, o) {
  let { agreements: t } = n,
    { acceptedAgreements: r } = n,
    { mobile: i } = n;
  const s = se(),
    { name: l, url: c } = ae.broker,
    d = c.indexOf("//"),
    u = -1 !== d ? d + 2 : 0,
    m = c.slice(u),
    f = {};
  let p = {};
  t.forEach((e) => {
    const n = a(e);
    (f[n] = { value: !1 }), Number(e.flags) && (f[n].validators = ["required"]);
  });
  const $ = new me(f),
    g = $.getValues(f);
  return (
    (e.$$set = (e) => {
      "agreements" in e && o(0, (t = e.agreements)),
        "acceptedAgreements" in e && o(9, (r = e.acceptedAgreements)),
        "mobile" in e && o(1, (i = e.mobile));
    }),
    [
      t,
      i,
      p,
      g,
      s,
      l,
      c,
      m,
      function () {
        const e = { ...g };
        o(2, (p = $.validate(e))),
          Object.keys(p).length ||
            (Object.keys(g).forEach((e, n) => {
              g[e] || o(9, (r |= 2 ** (n + 1)));
            }),
            s("submit"));
      },
      r,
      function (n, t) {
        e.$$.not_equal(g[a(t)], n) && ((g[a(t)] = n), o(3, g));
      },
      function (e) {
        (p = e), o(2, p);
      },
      () => s("prevStep"),
    ]
  );
}
function c(e) {
  let n, o;
  return (
    (n = new Ae({
      props: {
        $$slots: { footer: [B], title: [A], default: [E] },
        $$scope: { ctx: e },
      },
    })),
    n.$on("submit", e[18]),
    {
      c() {
        J(n.$$.fragment);
      },
      m(e, t) {
        Y(n, e, t), (o = !0);
      },
      p(e, o) {
        const t = {};
        (6143 & o[0]) | (64 & o[2]) && (t.$$scope = { dirty: o, ctx: e }),
          n.$set(t);
      },
      i(e) {
        o || (Z(n.$$.fragment, e), (o = !0));
      },
      o(e) {
        oe(n.$$.fragment, e), (o = !1);
      },
      d(e) {
        ie(n, e);
      },
    }
  );
}
function d(e) {
  let n, o;
  return (
    (n = new Oe({})),
    n.$on("back", e[17]),
    {
      c() {
        J(n.$$.fragment);
      },
      m(e, t) {
        Y(n, e, t), (o = !0);
      },
      p: we,
      i(e) {
        o || (Z(n.$$.fragment, e), (o = !0));
      },
      o(e) {
        oe(n.$$.fragment, e), (o = !1);
      },
      d(e) {
        ie(n, e);
      },
    }
  );
}
function u(e) {
  let n;
  return {
    c() {
      n = P(e[15]);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function m(e) {
  let n;
  return {
    c() {
      (n = W("div")),
        (n.textContent = `${window.tr(window.lang.login.form.name.yourName)}`),
        K(n, "class", "field svelte-124c4cb");
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function f(e) {
  let n, o, t;
  return {
    c() {
      (n = W("div")),
        (n.textContent = `${window.tr(window.lang.login.form.name.title)}`),
        (o = L()),
        (t = W("div")),
        (t.textContent = `${window.tr(window.lang.login.form.name.surname)}`),
        K(n, "class", "field svelte-124c4cb"),
        K(t, "class", "field svelte-124c4cb");
    },
    m(e, r) {
      Q(e, n, r), Q(e, o, r), Q(e, t, r);
    },
    p: we,
    d(e) {
      e && (te(n), te(o), te(t));
    },
  };
}
function p(e) {
  function n(e, n) {
    return e[2] ? f : m;
  }
  let o,
    t = n(e),
    r = t(e);
  return {
    c() {
      r.c(), (o = ve());
    },
    m(e, n) {
      r.m(e, n), Q(e, o, n);
    },
    p(e, i) {
      t === (t = n(e)) && r
        ? r.p(e, i)
        : (r.d(1), (r = t(e)), r && (r.c(), r.m(o.parentNode, o)));
    },
    d(e) {
      e && te(o), r.d(e);
    },
  };
}
function $(e) {
  function n(n) {
    e[27](n);
  }
  function o(n) {
    e[28](n);
  }
  function t(n) {
    e[29](n);
  }
  function r(n) {
    e[30](n);
  }
  function i(n) {
    e[31](n);
  }
  function s(n) {
    e[32](n);
  }
  let a,
    l,
    c,
    d,
    u,
    m,
    f,
    p,
    $,
    g,
    w = {
      name: "firstName",
      placeholder: window.tr(window.lang.login.form.name.title),
      disabled: e[12],
    };
  void 0 !== e[0].firstName && (w.value = e[0].firstName),
    void 0 !== e[8] && (w.errors = e[8]),
    void 0 !== e[7] && (w.focus = e[7]),
    (a = new Se({ props: w })),
    pe.push(() => $e(a, "value", n)),
    pe.push(() => $e(a, "errors", o)),
    pe.push(() => $e(a, "focus", t));
  let v = {
    name: "secondName",
    placeholder: window.tr(window.lang.login.form.name.surname),
    disabled: e[12],
  };
  return (
    void 0 !== e[0].secondName && (v.value = e[0].secondName),
    void 0 !== e[8] && (v.errors = e[8]),
    void 0 !== e[7] && (v.focus = e[7]),
    (m = new Se({ props: v })),
    pe.push(() => $e(m, "value", r)),
    pe.push(() => $e(m, "errors", i)),
    pe.push(() => $e(m, "focus", s)),
    {
      c() {
        J(a.$$.fragment), (u = L()), J(m.$$.fragment);
      },
      m(e, n) {
        Y(a, e, n), Q(e, u, n), Y(m, e, n), (g = !0);
      },
      p(e, n) {
        const o = {};
        4096 & n[0] && (o.disabled = e[12]),
          !l &&
            1 & n[0] &&
            ((l = !0), (o.value = e[0].firstName), ge(() => (l = !1))),
          !c && 256 & n[0] && ((c = !0), (o.errors = e[8]), ge(() => (c = !1))),
          !d && 128 & n[0] && ((d = !0), (o.focus = e[7]), ge(() => (d = !1))),
          a.$set(o);
        const t = {};
        4096 & n[0] && (t.disabled = e[12]),
          !f &&
            1 & n[0] &&
            ((f = !0), (t.value = e[0].secondName), ge(() => (f = !1))),
          !p && 256 & n[0] && ((p = !0), (t.errors = e[8]), ge(() => (p = !1))),
          !$ && 128 & n[0] && (($ = !0), (t.focus = e[7]), ge(() => ($ = !1))),
          m.$set(t);
      },
      i(e) {
        g || (Z(a.$$.fragment, e), Z(m.$$.fragment, e), (g = !0));
      },
      o(e) {
        oe(a.$$.fragment, e), oe(m.$$.fragment, e), (g = !1);
      },
      d(e) {
        e && te(u), ie(a, e), ie(m, e);
      },
    }
  );
}
function g(e) {
  function n(n) {
    e[36](n);
  }
  function o(n) {
    e[37](n);
  }
  function t(n) {
    e[38](n);
  }
  let r,
    i,
    s,
    a,
    l,
    c = {
      name: "emailConfirmCode",
      width: e[2] ? "100%" : 29,
      placeholder: window.tr(window.lang.login.form.email.code),
    };
  return (
    void 0 !== e[1].emailCode && (c.value = e[1].emailCode),
    void 0 !== e[8] && (c.errors = e[8]),
    void 0 !== e[7] && (c.focus = e[7]),
    (r = new Se({ props: c })),
    pe.push(() => $e(r, "value", n)),
    pe.push(() => $e(r, "errors", o)),
    pe.push(() => $e(r, "focus", t)),
    {
      c() {
        J(r.$$.fragment);
      },
      m(e, n) {
        Y(r, e, n), (l = !0);
      },
      p(e, n) {
        const o = {};
        4 & n[0] && (o.width = e[2] ? "100%" : 29),
          !i &&
            2 & n[0] &&
            ((i = !0), (o.value = e[1].emailCode), ge(() => (i = !1))),
          !s && 256 & n[0] && ((s = !0), (o.errors = e[8]), ge(() => (s = !1))),
          !a && 128 & n[0] && ((a = !0), (o.focus = e[7]), ge(() => (a = !1))),
          r.$set(o);
      },
      i(e) {
        l || (Z(r.$$.fragment, e), (l = !0));
      },
      o(e) {
        oe(r.$$.fragment, e), (l = !1);
      },
      d(e) {
        ie(r, e);
      },
    }
  );
}
function w(e) {
  function n(n) {
    e[33](n);
  }
  function o(n) {
    e[34](n);
  }
  function t(n) {
    e[35](n);
  }
  let r,
    i,
    s,
    a,
    l,
    c,
    d,
    u = {
      name: "email",
      placeholder: window.tr(window.lang.login.form.email.address),
      type: "email",
      width: e[2] ? "100%" : 46,
      disabled: e[12],
    };
  void 0 !== e[0].email && (u.value = e[0].email),
    void 0 !== e[8] && (u.errors = e[8]),
    void 0 !== e[7] && (u.focus = e[7]),
    (r = new Se({ props: u })),
    pe.push(() => $e(r, "value", n)),
    pe.push(() => $e(r, "errors", o)),
    pe.push(() => $e(r, "focus", t));
  let m = e[6].email && g(e);
  return {
    c() {
      J(r.$$.fragment), (l = L()), m && m.c(), (c = ve());
    },
    m(e, n) {
      Y(r, e, n), Q(e, l, n), m && m.m(e, n), Q(e, c, n), (d = !0);
    },
    p(e, n) {
      const o = {};
      4 & n[0] && (o.width = e[2] ? "100%" : 46),
        4096 & n[0] && (o.disabled = e[12]),
        !i &&
          1 & n[0] &&
          ((i = !0), (o.value = e[0].email), ge(() => (i = !1))),
        !s && 256 & n[0] && ((s = !0), (o.errors = e[8]), ge(() => (s = !1))),
        !a && 128 & n[0] && ((a = !0), (o.focus = e[7]), ge(() => (a = !1))),
        r.$set(o),
        e[6].email
          ? m
            ? (m.p(e, n), 64 & n[0] && Z(m, 1))
            : ((m = g(e)), m.c(), Z(m, 1), m.m(c.parentNode, c))
          : m &&
            (ee(),
            oe(m, 1, 1, () => {
              m = null;
            }),
            ne());
    },
    i(e) {
      d || (Z(r.$$.fragment, e), Z(m), (d = !0));
    },
    o(e) {
      oe(r.$$.fragment, e), oe(m), (d = !1);
    },
    d(e) {
      e && (te(l), te(c)), ie(r, e), m && m.d(e);
    },
  };
}
function v(e) {
  function n(n) {
    e[42](n);
  }
  function o(n) {
    e[43](n);
  }
  function t(n) {
    e[44](n);
  }
  let r,
    i,
    s,
    a,
    l,
    c = {
      name: "phoneConfirmCode",
      placeholder: window.tr(window.lang.login.form.phone.sms),
      width: e[2] ? "100%" : 29,
    };
  return (
    void 0 !== e[1].phoneCode && (c.value = e[1].phoneCode),
    void 0 !== e[8] && (c.errors = e[8]),
    void 0 !== e[7] && (c.focus = e[7]),
    (r = new Se({ props: c })),
    pe.push(() => $e(r, "value", n)),
    pe.push(() => $e(r, "errors", o)),
    pe.push(() => $e(r, "focus", t)),
    {
      c() {
        J(r.$$.fragment);
      },
      m(e, n) {
        Y(r, e, n), (l = !0);
      },
      p(e, n) {
        const o = {};
        4 & n[0] && (o.width = e[2] ? "100%" : 29),
          !i &&
            2 & n[0] &&
            ((i = !0), (o.value = e[1].phoneCode), ge(() => (i = !1))),
          !s && 256 & n[0] && ((s = !0), (o.errors = e[8]), ge(() => (s = !1))),
          !a && 128 & n[0] && ((a = !0), (o.focus = e[7]), ge(() => (a = !1))),
          r.$set(o);
      },
      i(e) {
        l || (Z(r.$$.fragment, e), (l = !0));
      },
      o(e) {
        oe(r.$$.fragment, e), (l = !1);
      },
      d(e) {
        ie(r, e);
      },
    }
  );
}
function h(e) {
  function n(n) {
    e[39](n);
  }
  function o(n) {
    e[40](n);
  }
  function t(n) {
    e[41](n);
  }
  let r,
    i,
    s,
    a,
    l,
    c,
    d,
    u = {
      name: "phone",
      type: "tel",
      placeholder: window.tr(window.lang.login.form.phone.number),
      width: e[2] ? "100%" : 46,
      maxlength: 64,
      disabled: e[12],
    };
  void 0 !== e[0].phone && (u.value = e[0].phone),
    void 0 !== e[8] && (u.errors = e[8]),
    void 0 !== e[7] && (u.focus = e[7]),
    (r = new Se({ props: u })),
    pe.push(() => $e(r, "value", n)),
    pe.push(() => $e(r, "errors", o)),
    pe.push(() => $e(r, "focus", t));
  let m = e[6].phone && v(e);
  return {
    c() {
      J(r.$$.fragment), (l = L()), m && m.c(), (c = ve());
    },
    m(e, n) {
      Y(r, e, n), Q(e, l, n), m && m.m(e, n), Q(e, c, n), (d = !0);
    },
    p(e, n) {
      const o = {};
      4 & n[0] && (o.width = e[2] ? "100%" : 46),
        4096 & n[0] && (o.disabled = e[12]),
        !i &&
          1 & n[0] &&
          ((i = !0), (o.value = e[0].phone), ge(() => (i = !1))),
        !s && 256 & n[0] && ((s = !0), (o.errors = e[8]), ge(() => (s = !1))),
        !a && 128 & n[0] && ((a = !0), (o.focus = e[7]), ge(() => (a = !1))),
        r.$set(o),
        e[6].phone
          ? m
            ? (m.p(e, n), 64 & n[0] && Z(m, 1))
            : ((m = v(e)), m.c(), Z(m, 1), m.m(c.parentNode, c))
          : m &&
            (ee(),
            oe(m, 1, 1, () => {
              m = null;
            }),
            ne());
    },
    i(e) {
      d || (Z(r.$$.fragment, e), Z(m), (d = !0));
    },
    o(e) {
      oe(r.$$.fragment, e), oe(m), (d = !1);
    },
    d(e) {
      e && (te(l), te(c)), ie(r, e), m && m.d(e);
    },
  };
}
function b(e) {
  let n,
    o = window.tr(window.lang.login.form.useHedge) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function C(e) {
  function n(n) {
    e[45](n);
  }
  let o,
    t,
    r,
    i = {
      disabled: e[16] !== ye.All || e[12],
      $$slots: { default: [b] },
      $$scope: { ctx: e },
    };
  return (
    void 0 !== e[3] && (i.checked = e[3]),
    (o = new fe({ props: i })),
    pe.push(() => $e(o, "checked", n)),
    {
      c() {
        J(o.$$.fragment);
      },
      m(e, n) {
        Y(o, e, n), (r = !0);
      },
      p(e, n) {
        const r = {};
        4096 & n[0] && (r.disabled = e[16] !== ye.All || e[12]),
          64 & n[2] && (r.$$scope = { dirty: n, ctx: e }),
          !t && 8 & n[0] && ((t = !0), (r.checked = e[3]), ge(() => (t = !1))),
          o.$set(r);
      },
      i(e) {
        r || (Z(o.$$.fragment, e), (r = !0));
      },
      o(e) {
        oe(o.$$.fragment, e), (r = !1);
      },
      d(e) {
        ie(o, e);
      },
    }
  );
}
function y(e) {
  let n,
    o = window.tr(window.lang.login.form.policyCheckbox) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function x(e) {
  function n(e, n) {
    return e[6].phone && e[6].email
      ? q
      : e[6].phone
      ? k
      : e[6].email
      ? N
      : void 0;
  }
  let o,
    t = n(e),
    r = t && t(e);
  return {
    c() {
      (o = W("span")), r && r.c(), K(o, "class", "note alert svelte-124c4cb");
    },
    m(e, n) {
      Q(e, o, n), r && r.m(o, null);
    },
    p(e, i) {
      t === (t = n(e)) && r
        ? r.p(e, i)
        : (r && r.d(1), (r = t && t(e)), r && (r.c(), r.m(o, null)));
    },
    d(e) {
      e && te(o), r && r.d();
    },
  };
}
function N(e) {
  let n,
    o = window.tr(window.lang.login.form.verificationCodes.email) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function k(e) {
  let n,
    o = window.tr(window.lang.login.form.verificationCodes.phone) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function q(e) {
  let n,
    o = window.tr(window.lang.login.form.verificationCodes.phoneEmail) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function _(e) {
  function n(n) {
    e[55](n);
  }
  function o(n) {
    e[56](n);
  }
  let t,
    r,
    i,
    s,
    a,
    l,
    c,
    d,
    u,
    m = je(e[14].url) + "",
    f = {
      name: "disclaimer",
      checkboxPosition: "top",
      disabled: e[12],
      $$slots: { default: [y] },
      $$scope: { ctx: e },
    };
  void 0 !== e[0].disclaimer && (f.checked = e[0].disclaimer),
    void 0 !== e[8] && (f.errors = e[8]),
    (t = new fe({ props: f })),
    pe.push(() => $e(t, "checked", n)),
    pe.push(() => $e(t, "errors", o));
  let p = (e[6].email || e[6].phone) && x(e);
  return {
    c() {
      J(t.$$.fragment),
        (s = L()),
        (a = W("a")),
        (l = P(m)),
        (c = L()),
        p && p.c(),
        (d = ve()),
        K(a, "class", "disclaimer-link link svelte-124c4cb"),
        K(a, "href", e[14].url),
        K(a, "target", "_blank"),
        K(a, "rel", "noreferrer");
    },
    m(e, n) {
      Y(t, e, n),
        Q(e, s, n),
        Q(e, a, n),
        X(a, l),
        Q(e, c, n),
        p && p.m(e, n),
        Q(e, d, n),
        (u = !0);
    },
    p(e, n) {
      const o = {};
      4096 & n[0] && (o.disabled = e[12]),
        64 & n[2] && (o.$$scope = { dirty: n, ctx: e }),
        !r &&
          1 & n[0] &&
          ((r = !0), (o.checked = e[0].disclaimer), ge(() => (r = !1))),
        !i && 256 & n[0] && ((i = !0), (o.errors = e[8]), ge(() => (i = !1))),
        t.$set(o),
        e[6].email || e[6].phone
          ? p
            ? p.p(e, n)
            : ((p = x(e)), p.c(), p.m(d.parentNode, d))
          : p && (p.d(1), (p = null));
    },
    i(e) {
      u || (Z(t.$$.fragment, e), (u = !0));
    },
    o(e) {
      oe(t.$$.fragment, e), (u = !1);
    },
    d(e) {
      e && (te(s), te(a), te(c), te(d)), ie(t, e), p && p.d(e);
    },
  };
}
function E(e) {
  function n(n) {
    e[46](n);
  }
  function o(n) {
    e[47](n);
  }
  function t(n) {
    e[48](n);
  }
  function r(n) {
    e[49](n);
  }
  function i(n) {
    e[50](n);
  }
  function s(n) {
    e[51](n);
  }
  function a(n) {
    e[52](n);
  }
  function l(n) {
    e[53](n);
  }
  function c(n) {
    e[54](n);
  }
  let d,
    m,
    f,
    g,
    v,
    b,
    y,
    x,
    N,
    k,
    q,
    E,
    A,
    O,
    M,
    S,
    B,
    j,
    V,
    R,
    G,
    D,
    I,
    T,
    F,
    z,
    U,
    ee,
    ne,
    re,
    se,
    ae,
    ce,
    de,
    ue,
    me,
    fe,
    we,
    ve,
    he,
    be,
    Ce,
    ye,
    xe,
    Ne,
    ke,
    qe,
    _e,
    Ee,
    Ae,
    Oe,
    je,
    Ve,
    Re = window.tr(window.lang.login.form.broker) + "",
    Ge = window.tr(window.lang.login.form.server) + "",
    De = e[0].currency + "";
  (y = new H({
    props: {
      marginBottom: e[2] ? 1 : 2,
      $$slots: { default: [u] },
      $$scope: { ctx: e },
    },
  })),
    (N = new H({ props: { $$slots: { default: [p] }, $$scope: { ctx: e } } })),
    (q = new H({
      props: { cols: 2, $$slots: { default: [$] }, $$scope: { ctx: e } },
    })),
    (M = new H({
      props: { cols: 2, $$slots: { default: [w] }, $$scope: { ctx: e } },
    })),
    (V = new H({
      props: {
        cols: 2,
        marginBottom: e[2] ? 1 : 2,
        $$slots: { default: [h] },
        $$scope: { ctx: e },
      },
    })),
    (G = new H({
      props: {
        style: "grid-column: 2 / 3;",
        $$slots: { default: [C] },
        $$scope: { ctx: e },
      },
    }));
  let Ie = { name: "groupId", options: e[4], disabled: !e[4].length || e[12] };
  void 0 !== e[5] && (Ie.value = e[5]),
    void 0 !== e[8] && (Ie.errors = e[8]),
    void 0 !== e[7] && (Ie.focus = e[7]),
    (F = new Me({ props: Ie })),
    pe.push(() => $e(F, "value", n)),
    pe.push(() => $e(F, "errors", o)),
    pe.push(() => $e(F, "focus", t));
  let Te = {
    type: "number",
    name: "deposit",
    disabled: !e[9] || e[12],
    min: 0,
    width: "100%",
    maxWidth: 22,
  };
  void 0 !== e[0].deposit && (Te.value = e[0].deposit),
    void 0 !== e[8] && (Te.errors = e[8]),
    void 0 !== e[7] && (Te.focus = e[7]),
    (de = new Se({ props: Te })),
    pe.push(() => $e(de, "value", r)),
    pe.push(() => $e(de, "errors", i)),
    pe.push(() => $e(de, "focus", s));
  let Fe = {
    name: "leverage",
    options: e[10],
    width: "100%",
    maxWidth: 22,
    disabled: e[12],
  };
  return (
    void 0 !== e[0].leverage && (Fe.value = e[0].leverage),
    void 0 !== e[8] && (Fe.errors = e[8]),
    void 0 !== e[7] && (Fe.focus = e[7]),
    (Ne = new Me({ props: Fe })),
    pe.push(() => $e(Ne, "value", a)),
    pe.push(() => $e(Ne, "errors", l)),
    pe.push(() => $e(Ne, "focus", c)),
    (Ae = new H({
      props: {
        marginBottom: "1",
        style: "grid-column: 1 / 3;",
        $$slots: { default: [_] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        (d = P(Re)),
          (m = L()),
          (f = W("button")),
          (f.textContent = `${e[14].name}`),
          (g = L()),
          (v = P(Ge)),
          (b = L()),
          J(y.$$.fragment),
          (x = L()),
          J(N.$$.fragment),
          (k = L()),
          J(q.$$.fragment),
          (E = L()),
          (A = W("span")),
          (A.textContent = `${window.tr(window.lang.login.form.email.title)}`),
          (O = L()),
          J(M.$$.fragment),
          (S = L()),
          (B = W("div")),
          (B.textContent = `${window.tr(window.lang.login.form.phone.mobile)}`),
          (j = L()),
          J(V.$$.fragment),
          (R = L()),
          J(G.$$.fragment),
          (D = L()),
          (I = W("span")),
          (I.textContent = `${window.tr(window.lang.login.form.accountType)}`),
          (T = L()),
          J(F.$$.fragment),
          (ne = L()),
          (re = W("div")),
          (se = W("span")),
          (se.textContent = `${window.tr(window.lang.login.form.deposit)}`),
          (ae = L()),
          (ce = W("div")),
          J(de.$$.fragment),
          (we = L()),
          (ve = W("div")),
          (he = P(De)),
          (be = L()),
          (Ce = W("span")),
          (Ce.textContent = `${window.tr(window.lang.login.form.leverage)}`),
          (ye = L()),
          (xe = W("div")),
          J(Ne.$$.fragment),
          (Ee = L()),
          J(Ae.$$.fragment),
          K(f, "class", "broker-info svelte-124c4cb"),
          K(f, "type", "button"),
          K(A, "class", "field svelte-124c4cb"),
          K(B, "class", "field svelte-124c4cb"),
          K(I, "class", "field svelte-124c4cb"),
          K(se, "class", "field svelte-124c4cb"),
          K(ve, "class", "currency field svelte-124c4cb"),
          K(ce, "class", "deposit-input svelte-124c4cb"),
          K(Ce, "class", "field leverage-label svelte-124c4cb"),
          K(xe, "class", "leverage svelte-124c4cb"),
          K(re, "class", "deposit svelte-124c4cb");
      },
      m(n, o) {
        Q(n, d, o),
          Q(n, m, o),
          Q(n, f, o),
          Q(n, g, o),
          Q(n, v, o),
          Q(n, b, o),
          Y(y, n, o),
          Q(n, x, o),
          Y(N, n, o),
          Q(n, k, o),
          Y(q, n, o),
          Q(n, E, o),
          Q(n, A, o),
          Q(n, O, o),
          Y(M, n, o),
          Q(n, S, o),
          Q(n, B, o),
          Q(n, j, o),
          Y(V, n, o),
          Q(n, R, o),
          Y(G, n, o),
          Q(n, D, o),
          Q(n, I, o),
          Q(n, T, o),
          Y(F, n, o),
          Q(n, ne, o),
          Q(n, re, o),
          X(re, se),
          X(re, ae),
          X(re, ce),
          Y(de, ce, null),
          X(ce, we),
          X(ce, ve),
          X(ve, he),
          X(re, be),
          X(re, Ce),
          X(re, ye),
          X(re, xe),
          Y(Ne, xe, null),
          Q(n, Ee, o),
          Y(Ae, n, o),
          (Oe = !0),
          je || ((Ve = Be(f, "click", e[17])), (je = !0));
      },
      p(e, n) {
        const o = {};
        4 & n[0] && (o.marginBottom = e[2] ? 1 : 2),
          64 & n[2] && (o.$$scope = { dirty: n, ctx: e }),
          y.$set(o);
        const t = {};
        (4 & n[0]) | (64 & n[2]) && (t.$$scope = { dirty: n, ctx: e }),
          N.$set(t);
        const r = {};
        (4481 & n[0]) | (64 & n[2]) && (r.$$scope = { dirty: n, ctx: e }),
          q.$set(r);
        const i = {};
        (4551 & n[0]) | (64 & n[2]) && (i.$$scope = { dirty: n, ctx: e }),
          M.$set(i);
        const s = {};
        4 & n[0] && (s.marginBottom = e[2] ? 1 : 2),
          (4551 & n[0]) | (64 & n[2]) && (s.$$scope = { dirty: n, ctx: e }),
          V.$set(s);
        const a = {};
        (4104 & n[0]) | (64 & n[2]) && (a.$$scope = { dirty: n, ctx: e }),
          G.$set(a);
        const l = {};
        16 & n[0] && (l.options = e[4]),
          4112 & n[0] && (l.disabled = !e[4].length || e[12]),
          !z && 32 & n[0] && ((z = !0), (l.value = e[5]), ge(() => (z = !1))),
          !U && 256 & n[0] && ((U = !0), (l.errors = e[8]), ge(() => (U = !1))),
          !ee &&
            128 & n[0] &&
            ((ee = !0), (l.focus = e[7]), ge(() => (ee = !1))),
          F.$set(l);
        const c = {};
        4608 & n[0] && (c.disabled = !e[9] || e[12]),
          !ue &&
            1 & n[0] &&
            ((ue = !0), (c.value = e[0].deposit), ge(() => (ue = !1))),
          !me &&
            256 & n[0] &&
            ((me = !0), (c.errors = e[8]), ge(() => (me = !1))),
          !fe &&
            128 & n[0] &&
            ((fe = !0), (c.focus = e[7]), ge(() => (fe = !1))),
          de.$set(c),
          (!Oe || 1 & n[0]) && De !== (De = e[0].currency + "") && le(he, De);
        const d = {};
        1024 & n[0] && (d.options = e[10]),
          4096 & n[0] && (d.disabled = e[12]),
          !ke &&
            1 & n[0] &&
            ((ke = !0), (d.value = e[0].leverage), ge(() => (ke = !1))),
          !qe &&
            256 & n[0] &&
            ((qe = !0), (d.errors = e[8]), ge(() => (qe = !1))),
          !_e &&
            128 & n[0] &&
            ((_e = !0), (d.focus = e[7]), ge(() => (_e = !1))),
          Ne.$set(d);
        const u = {};
        (4417 & n[0]) | (64 & n[2]) && (u.$$scope = { dirty: n, ctx: e }),
          Ae.$set(u);
      },
      i(e) {
        Oe ||
          (Z(y.$$.fragment, e),
          Z(N.$$.fragment, e),
          Z(q.$$.fragment, e),
          Z(M.$$.fragment, e),
          Z(V.$$.fragment, e),
          Z(G.$$.fragment, e),
          Z(F.$$.fragment, e),
          Z(de.$$.fragment, e),
          Z(Ne.$$.fragment, e),
          Z(Ae.$$.fragment, e),
          (Oe = !0));
      },
      o(e) {
        oe(y.$$.fragment, e),
          oe(N.$$.fragment, e),
          oe(q.$$.fragment, e),
          oe(M.$$.fragment, e),
          oe(V.$$.fragment, e),
          oe(G.$$.fragment, e),
          oe(F.$$.fragment, e),
          oe(de.$$.fragment, e),
          oe(Ne.$$.fragment, e),
          oe(Ae.$$.fragment, e),
          (Oe = !1);
      },
      d(e) {
        e &&
          (te(d),
          te(m),
          te(f),
          te(g),
          te(v),
          te(b),
          te(x),
          te(k),
          te(E),
          te(A),
          te(O),
          te(S),
          te(B),
          te(j),
          te(R),
          te(D),
          te(I),
          te(T),
          te(ne),
          te(re),
          te(Ee)),
          ie(y, e),
          ie(N, e),
          ie(q, e),
          ie(M, e),
          ie(V, e),
          ie(G, e),
          ie(F, e),
          ie(de),
          ie(Ne),
          ie(Ae, e),
          (je = !1),
          Ve();
      },
    }
  );
}
function A(e) {
  let n,
    o = window.tr(window.lang.login.demo.title) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function O(e) {
  let n, o;
  return (
    (n = new ce({ props: { $$slots: { default: [M] }, $$scope: { ctx: e } } })),
    n.$on("click", e[19]),
    {
      c() {
        J(n.$$.fragment);
      },
      m(e, t) {
        Y(n, e, t), (o = !0);
      },
      p(e, o) {
        const t = {};
        64 & o[2] && (t.$$scope = { dirty: o, ctx: e }), n.$set(t);
      },
      i(e) {
        o || (Z(n.$$.fragment, e), (o = !0));
      },
      o(e) {
        oe(n.$$.fragment, e), (o = !1);
      },
      d(e) {
        ie(n, e);
      },
    }
  );
}
function M(e) {
  let n,
    o = window.tr(window.lang.login.form.btn.back) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function S(e) {
  let n,
    o = window.tr(window.lang.login.demo.btnOpenDemo) + "";
  return {
    c() {
      n = P(o);
    },
    m(e, o) {
      Q(e, n, o);
    },
    p: we,
    d(e) {
      e && te(n);
    },
  };
}
function B(e) {
  let n,
    o,
    t,
    r = e[12] && O(e);
  return (
    (o = new ce({
      props: {
        type: "submit",
        active: !0,
        $$slots: { default: [S] },
        $$scope: { ctx: e },
      },
    })),
    {
      c() {
        r && r.c(), (n = L()), J(o.$$.fragment);
      },
      m(e, i) {
        r && r.m(e, i), Q(e, n, i), Y(o, e, i), (t = !0);
      },
      p(e, t) {
        e[12]
          ? r
            ? (r.p(e, t), 4096 & t[0] && Z(r, 1))
            : ((r = O(e)), r.c(), Z(r, 1), r.m(n.parentNode, n))
          : r &&
            (ee(),
            oe(r, 1, 1, () => {
              r = null;
            }),
            ne());
        const i = {};
        64 & t[2] && (i.$$scope = { dirty: t, ctx: e }), o.$set(i);
      },
      i(e) {
        t || (Z(r), Z(o.$$.fragment, e), (t = !0));
      },
      o(e) {
        oe(r), oe(o.$$.fragment, e), (t = !1);
      },
      d(e) {
        e && te(n), r && r.d(e), ie(o, e);
      },
    }
  );
}
function j(e) {
  function n(e, n) {
    return e[11] ? 0 : 1;
  }
  let o, t, r, i;
  const s = [d, c],
    a = [];
  return (
    (o = n(e)),
    (t = a[o] = s[o](e)),
    {
      c() {
        t.c(), (r = ve());
      },
      m(e, n) {
        a[o].m(e, n), Q(e, r, n), (i = !0);
      },
      p(e, i) {
        let l = o;
        (o = n(e)),
          o === l
            ? a[o].p(e, i)
            : (ee(),
              oe(a[l], 1, 1, () => {
                a[l] = null;
              }),
              ne(),
              (t = a[o]),
              t ? t.p(e, i) : ((t = a[o] = s[o](e)), t.c()),
              Z(t, 1),
              t.m(r.parentNode, r));
      },
      i(e) {
        i || (Z(t), (i = !0));
      },
      o(e) {
        oe(t), (i = !1);
      },
      d(e) {
        e && te(r), a[o].d(e);
      },
    }
  );
}
function V(e, n, o) {
  function t() {
    o(3, (y = "" !== $.hedging ? $.hedging : Boolean(C))),
      o(0, ($.server = $.server || u), $),
      o(0, ($.firstName = $.firstName || Ne.get("first_name") || ""), $),
      o(0, ($.secondName = $.secondName || Ne.get("second_name") || ""), $),
      o(0, ($.email = $.email || Ne.get("email") || ""), $),
      o(0, ($.phone = $.phone || Ne.get("phone") || ""), $),
      o(0, ($.deposit = $.deposit || N.default_deposit || Te), $),
      o(0, ($.currency = $.currency || N.currency), $),
      o(0, ($.leverage = $.leverage || N.leverages[0]), $),
      o(0, ($.disclaimer = "" !== $.disclaimer && $.disclaimer), $);
  }
  function r() {
    o(1, (h.email = !1), h),
      o(1, (h.phone = !1), h),
      (null == v ? void 0 : v.flags) &&
        (o(1, (h.email = Boolean(8 & (null == v ? void 0 : v.flags))), h),
        o(1, (h.phone = Boolean(4 & (null == v ? void 0 : v.flags))), h));
  }
  function i() {
    return {
      firstName: $.firstName,
      secondName: $.secondName,
      email: $.email,
      phone: $.phone,
      deposit: $.deposit,
      leverage: $.leverage,
      group: v,
      agreements: $.agreements,
      emailConfirm: h.email,
      emailConfirmCode: +h.emailCode,
      phoneConfirm: h.phone,
      phoneConfirmCode: +h.phoneCode,
    };
  }
  function s() {
    (k = null),
      o(21, (w |= 1)),
      v.agreements.length ? c("nextStep") : c("submit");
  }
  let a;
  const { layoutStore: l } = he.layout;
  be(e, l, (e) => o(58, (a = e)));
  const c = se(),
    { broker: d, tradeServerDemo: u, build: m, accountUrl: f } = ae;
  let { mobile: p = !1 } = n,
    { values: $ } = n,
    { formValidator: g } = n,
    { acceptedAgreements: w } = n,
    { group: v } = n,
    { confirmation: h } = n,
    { demoController: b } = n;
  const C = Ce(ae.demoGroups);
  let y = "" !== $.hedging ? $.hedging : [ye.OnlyHedge, ye.All].includes(C),
    x = xe(ae.demoGroups, y);
  const N = x[0];
  let k,
    q = x.map((e) => ({ id: e.group, name: e.name })),
    _ = $.groupId || (null == N ? void 0 : N.group),
    E = "",
    A = {},
    O = (null == v ? void 0 : v.group) || "",
    M = !N.default_deposit,
    S =
      null == v ? void 0 : v.leverages.map((e) => ({ id: e, name: String(e) })),
    B = { email: !1, phone: !1 },
    j = !1,
    V = !1;
  return (
    t(),
    ke(() => {
      o(21, (w = 0)),
        o(1, (h.emailCode = ""), h),
        o(1, (h.phoneCode = ""), h),
        r();
    }),
    (e.$$set = (e) => {
      "mobile" in e && o(2, (p = e.mobile)),
        "values" in e && o(0, ($ = e.values)),
        "formValidator" in e && o(22, (g = e.formValidator)),
        "acceptedAgreements" in e && o(21, (w = e.acceptedAgreements)),
        "group" in e && o(20, (v = e.group)),
        "confirmation" in e && o(1, (h = e.confirmation)),
        "demoController" in e && o(23, (b = e.demoController));
    }),
    (e.$$.update = () => {
      64 & e.$$.dirty[0] && o(12, (V = B.email || B.phone)),
        33554457 & e.$$.dirty[0] &&
          $.hedging !== y &&
          (o(0, ($.hedging = y), $),
          o(25, (x = xe(ae.demoGroups, y))),
          o(4, (q = x.map((e) => ({ id: e.group, name: e.name })))),
          o(5, (_ = String(q[0].id)))),
        68157473 & e.$$.dirty[0] &&
          ($.groupId !== _ &&
            (o(0, ($.groupId = _), $),
            o(20, (v = ae.demoGroups.find((e) => e.group === _))),
            r()),
          v.group !== O &&
            (o(26, (O = v.group)),
            o(0, ($.deposit = v.default_deposit || Te), $),
            o(0, ($.leverage = v.leverages[0]), $),
            o(0, ($.currency = v.currency), $),
            o(9, (M = !v.default_deposit)),
            o(10, (S = v.leverages.map((e) => ({ id: e, name: String(e) }))))));
    }),
    [
      $,
      h,
      p,
      y,
      q,
      _,
      B,
      E,
      A,
      M,
      S,
      j,
      V,
      l,
      d,
      u,
      C,
      function () {
        o(11, (j = !j));
      },
      async function () {
        if (f)
          return (
            window.open(f, "_blank"), void a.setLayout({ auth: qe.Connect })
          );
        const e = { ...$ };
        o(8, (A = g.validate(e))),
          Object.keys(A).length > 0
            ? o(7, (E = Object.keys(A)[0]))
            : (h.email && !h.emailCode) || (h.phone && !h.phoneCode)
            ? (async function () {
                let e;
                k = null;
                try {
                  e = await b.getVerifyCodes(u, i(), m);
                } catch (n) {
                  n instanceof _e
                    ? ((k = Ee(n.code)),
                      7 === n.code &&
                        o(
                          8,
                          (A = {
                            ...A,
                            email: window.tr(
                              window.lang.login.errors.invalidEmail
                            ),
                          })
                        ),
                      8 === n.code &&
                        o(
                          8,
                          (A = {
                            ...A,
                            phone: window.tr(
                              window.lang.login.errors.invalidPhone
                            ),
                          })
                        ))
                    : n instanceof Error &&
                      (k = { message: n.message, type: "error" }),
                    k ||
                      (k = {
                        message: window.tr(
                          window.lang.login.errors.unknownError
                        ),
                        type: "error",
                      }),
                    c("error", k);
                }
                if (null == e ? void 0 : e.verify) {
                  const [n, t] = e.verify;
                  if (n || t) {
                    o(6, (B = { email: Boolean(n), phone: Boolean(t) }));
                    const e = {};
                    n && (e.emailConfirmCode = { validators: ["required"] }),
                      t && (e.phoneConfirmCode = { validators: ["required"] });
                    const r = new me(e);
                    o(
                      8,
                      (A = {
                        ...r.validate({
                          emailConfirmCode: "",
                          phoneConfirmCode: "",
                        }),
                      })
                    );
                  } else s();
                }
              })()
            : h.email || h.phone
            ? (async function () {
                let e;
                k = null;
                try {
                  e = await b.sendVerifyCodes(u, i(), m);
                } catch (n) {
                  n instanceof _e
                    ? (k = Ee(n.code))
                    : n instanceof Error &&
                      (k = { message: n.message, type: "error" }),
                    k ||
                      (k = {
                        message: window.tr(
                          window.lang.login.errors.unknownError
                        ),
                        type: "error",
                      }),
                    c("error", k);
                }
                if (null == e ? void 0 : e.verify) {
                  const [n, t] = e.verify;
                  if (n && t) s();
                  else {
                    const e = {};
                    n || (e.emailConfirmCode = { validators: ["required"] }),
                      t || (e.phoneConfirmCode = { validators: ["required"] });
                    const r = new me(e);
                    o(
                      8,
                      (A = {
                        ...r.validate({
                          emailConfirmCode: n ? h.emailCode : "",
                          phoneConfirmCode: t ? h.phoneCode : "",
                        }),
                      })
                    );
                  }
                }
              })()
            : s();
      },
      function () {
        o(6, (B = { email: !1, phone: !1 })),
          o(1, (h.emailCode = ""), h),
          o(1, (h.phoneCode = ""), h);
      },
      v,
      w,
      g,
      b,
      t,
      x,
      O,
      function (n) {
        e.$$.not_equal($.firstName, n) &&
          (($.firstName = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal($.secondName, n) &&
          (($.secondName = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal($.email, n) &&
          (($.email = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal(h.emailCode, n) && ((h.emailCode = n), o(1, h));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal($.phone, n) &&
          (($.phone = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal(h.phoneCode, n) && ((h.phoneCode = n), o(1, h));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (e) {
        (y = e), o(3, y);
      },
      function (e) {
        (_ = e),
          o(5, _),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(20, v),
          o(26, O);
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal($.deposit, n) &&
          (($.deposit = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal($.leverage, n) &&
          (($.leverage = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
      function (e) {
        (E = e), o(7, E);
      },
      function (n) {
        e.$$.not_equal($.disclaimer, n) &&
          (($.disclaimer = n),
          o(0, $),
          o(3, y),
          o(25, x),
          o(4, q),
          o(5, _),
          o(20, v),
          o(26, O));
      },
      function (e) {
        (A = e), o(8, A);
      },
    ]
  );
}
function R(e) {
  function n(n) {
    e[16](n);
  }
  let o,
    t,
    r,
    i = { agreements: e[2].agreements, mobile: e[0] };
  return (
    void 0 !== e[1] && (i.acceptedAgreements = e[1]),
    (o = new Ie({ props: i })),
    pe.push(() => $e(o, "acceptedAgreements", n)),
    o.$on("prevStep", e[10]),
    o.$on("submit", e[8]),
    {
      c() {
        J(o.$$.fragment);
      },
      m(e, n) {
        Y(o, e, n), (r = !0);
      },
      p(e, n) {
        const r = {};
        4 & n && (r.agreements = e[2].agreements),
          1 & n && (r.mobile = e[0]),
          !t &&
            2 & n &&
            ((t = !0), (r.acceptedAgreements = e[1]), ge(() => (t = !1))),
          o.$set(r);
      },
      i(e) {
        r || (Z(o.$$.fragment, e), (r = !0));
      },
      o(e) {
        oe(o.$$.fragment, e), (r = !1);
      },
      d(e) {
        ie(o, e);
      },
    }
  );
}
function G(e) {
  function n(n) {
    e[11](n);
  }
  function o(n) {
    e[12](n);
  }
  function t(n) {
    e[13](n);
  }
  function r(n) {
    e[14](n);
  }
  let i,
    s,
    a,
    l,
    c,
    d,
    u = { demoController: e[6], formValidator: e[7], mobile: e[0] };
  return (
    void 0 !== e[5] && (u.values = e[5]),
    void 0 !== e[1] && (u.acceptedAgreements = e[1]),
    void 0 !== e[2] && (u.group = e[2]),
    void 0 !== e[4] && (u.confirmation = e[4]),
    (i = new Fe({ props: u })),
    pe.push(() => $e(i, "values", n)),
    pe.push(() => $e(i, "acceptedAgreements", o)),
    pe.push(() => $e(i, "group", t)),
    pe.push(() => $e(i, "confirmation", r)),
    i.$on("nextStep", e[9]),
    i.$on("submit", e[8]),
    i.$on("error", e[15]),
    {
      c() {
        J(i.$$.fragment);
      },
      m(e, n) {
        Y(i, e, n), (d = !0);
      },
      p(e, n) {
        const o = {};
        1 & n && (o.mobile = e[0]),
          !s && 32 & n && ((s = !0), (o.values = e[5]), ge(() => (s = !1))),
          !a &&
            2 & n &&
            ((a = !0), (o.acceptedAgreements = e[1]), ge(() => (a = !1))),
          !l && 4 & n && ((l = !0), (o.group = e[2]), ge(() => (l = !1))),
          !c &&
            16 & n &&
            ((c = !0), (o.confirmation = e[4]), ge(() => (c = !1))),
          i.$set(o);
      },
      i(e) {
        d || (Z(i.$$.fragment, e), (d = !0));
      },
      o(e) {
        oe(i.$$.fragment, e), (d = !1);
      },
      d(e) {
        ie(i, e);
      },
    }
  );
}
function D(e) {
  function n(e, n) {
    return e[3] === ze.DEMO_FORM ? 0 : e[3] === ze.AGREEMENTS ? 1 : -1;
  }
  let o, t, r, i;
  const s = [G, R],
    a = [];
  return (
    ~(o = n(e)) && (t = a[o] = s[o](e)),
    {
      c() {
        t && t.c(), (r = ve());
      },
      m(e, n) {
        ~o && a[o].m(e, n), Q(e, r, n), (i = !0);
      },
      p(e, [i]) {
        let l = o;
        (o = n(e)),
          o === l
            ? ~o && a[o].p(e, i)
            : (t &&
                (ee(),
                oe(a[l], 1, 1, () => {
                  a[l] = null;
                }),
                ne()),
              ~o
                ? ((t = a[o]),
                  t ? t.p(e, i) : ((t = a[o] = s[o](e)), t.c()),
                  Z(t, 1),
                  t.m(r.parentNode, r))
                : (t = null));
      },
      i(e) {
        i || (Z(t), (i = !0));
      },
      o(e) {
        oe(t), (i = !1);
      },
      d(e) {
        e && te(r), ~o && a[o].d(e);
      },
    }
  );
}
function I(e, n, o) {
  const { demoController: t } = Ge,
    r = se();
  let i,
    s,
    { mobile: a } = n,
    l = 0,
    c = ze.DEMO_FORM,
    d = { email: !1, phone: !1, emailCode: "", phoneCode: "" };
  const u = {
      server: { validators: ["required"] },
      firstName: { validators: ["required"] },
      secondName: { validators: ["required"] },
      email: { validators: ["required", "email"] },
      phone: { validators: ["required"] },
      hedging: {},
      groupId: { validators: ["required"] },
      deposit: { validators: ["required"] },
      currency: { validators: ["required"] },
      leverage: { validators: ["required"] },
      disclaimer: { validators: ["required"] },
    },
    m = new me(u);
  let f = m.getValues(u);
  return (
    (e.$$set = (e) => {
      "mobile" in e && o(0, (a = e.mobile));
    }),
    [
      a,
      l,
      s,
      c,
      d,
      f,
      t,
      m,
      async function () {
        const e = { ...f };
        try {
          const n = await t.create(e.server, {
            firstName: e.firstName,
            secondName: e.secondName,
            email: e.email,
            phone: e.phone,
            deposit: e.deposit,
            leverage: e.leverage,
            group: s,
            agreements: l,
            emailConfirm: d.email,
            emailConfirmCode: +d.emailCode,
            phoneConfirm: d.phone,
            phoneConfirmCode: +d.phoneCode,
            country: De(ae.traderCountry),
          });
          r("success", { response: n, isHedgedMargin: Ve(s) });
        } catch (n) {
          n instanceof _e
            ? (i = Ee(n.code))
            : n instanceof Error && (i = { message: n.message, type: "error" }),
            i ||
              (i = {
                message: window.tr(window.lang.login.errors.unknownError),
                type: "error",
              }),
            r("error", i);
        }
      },
      function () {
        o(3, (c = ze.AGREEMENTS));
      },
      function () {
        o(3, (c = ze.DEMO_FORM));
      },
      function (e) {
        (f = e), o(5, f);
      },
      function (e) {
        (l = e), o(1, l);
      },
      function (e) {
        (s = e), o(2, s);
      },
      function (e) {
        (d = e), o(4, d);
      },
      function (n) {
        Re.call(this, e, n);
      },
      function (e) {
        (l = e), o(1, l);
      },
    ]
  );
}
import {
  S as T,
  i as F,
  s as z,
  p as U,
  aG as H,
  e as W,
  a as L,
  n as P,
  c as J,
  b as K,
  d as Q,
  f as X,
  m as Y,
  t as Z,
  g as ee,
  j as ne,
  h as oe,
  k as te,
  q as re,
  l as ie,
  a1 as se,
  aI as ae,
  R as le,
  aO as ce,
  bg as de,
  bh as ue,
  bi as me,
  C as fe,
  T as pe,
  U as $e,
  W as ge,
  o as we,
  B as ve,
  aR as he,
  ai as be,
  bj as Ce,
  bk as ye,
  aU as xe,
  aJ as Ne,
  a5 as ke,
  aT as qe,
  aL as _e,
  aM as Ee,
  bl as Ae,
  bm as Oe,
  V as Me,
  I as Se,
  O as Be,
  aN as je,
  aK as Ve,
  Q as Re,
} from "./00a24b22.js";
import { d as Ge, g as De } from "./a1151122.js";
class Ie extends T {
  constructor(e) {
    super(),
      F(this, e, l, s, z, { agreements: 0, acceptedAgreements: 9, mobile: 1 });
  }
}
const Te = 1e5;
class Fe extends T {
  constructor(e) {
    super(),
      F(
        this,
        e,
        V,
        j,
        z,
        {
          mobile: 2,
          values: 0,
          formValidator: 22,
          acceptedAgreements: 21,
          group: 20,
          confirmation: 1,
          demoController: 23,
          initFields: 24,
        },
        null,
        [-1, -1, -1]
      );
  }
  get initFields() {
    return this.$$.ctx[24];
  }
}
const ze = { DEMO_FORM: 0, AGREEMENTS: 1 };
class Ue extends T {
  constructor(e) {
    super(), F(this, e, I, D, z, { mobile: 0 });
  }
}
export { ze as DEMO_STEPS, Ue as default };
