# MetaTrader Reverse Eng.

```bash
python -m venv .venv # (use python3.9)
python -m pip install -r requirements.txt
python -m pytest -v
```

https://mt5-demo-web.deriv.com/terminal?login=<login-id>&server=<server-name>
https://github.com/networkdynamics/pytok
https://gemini.google.com/app/2bebf7e5c671de5a

Deriv Momentum Bot:
https://medium.com/coinmonks/building-a-momentum-trading-algorithm-using-python-1924a5939204
