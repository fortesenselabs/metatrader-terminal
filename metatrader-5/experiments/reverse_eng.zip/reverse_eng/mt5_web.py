import os
import asyncio
from playwright.async_api import async_playwright, BrowserContext
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

MT5_LOGIN = os.environ.get("MT5_LOGIN")
MT5_PASSWORD = os.environ.get("MT5_PASSWORD")
MT5_SERVER = os.environ.get("MT5_SERVER")

TARGET_URL = (
    f"https://mt5-demo-web.deriv.com/terminal?login={MT5_LOGIN}&server={MT5_SERVER}"
)
# TARGET_URL = f"https://trade.metatrader5.com/terminal?login={MT5_LOGIN}&server={MT5_SERVER}"


async def mt5(context: BrowserContext, page_data_timeout: int = 5000):
    page = await context.new_page()

    await page.goto(TARGET_URL)

    await page.wait_for_selector(
        "body >> text=Disclaimer"
    )  # "body >> text=MetaTrader 5"

    # click on the accept button
    await page.click(
        "body > div._portal > div > div.window.svelte-1eljjld.draggable > div > div.body.svelte-1eljjld > div > div.button.svelte-1yp4k0h > button"
    )

    # wait for the Connect to account dialog
    await page.wait_for_selector("body >> text=Connect to account")

    # Fill the password (not recommended for security reasons)
    await page.fill(
        "body > div._portal > div > div.window.svelte-1eljjld.draggable > div > div.body.svelte-1eljjld > div > div.login-content.svelte-jdc7pc > div.content.svelte-jdc7pc > div > div > form > div.layout.svelte-1bpvxjz > div:nth-child(1) > div > span > input",
        MT5_PASSWORD,
    )

    # Check the "save password" checkbox
    await page.check(
        "body > div._portal > div > div.window.svelte-1eljjld.draggable > div > div.body.svelte-1eljjld > div > div.login-content.svelte-jdc7pc > div.content.svelte-jdc7pc > div > div > form > div.layout.svelte-1bpvxjz > div:nth-child(1) > div > label"
    )

    # Click the "Connect to Account" button
    await page.click(
        "body > div._portal > div > div.window.svelte-1eljjld.draggable > div > div.body.svelte-1eljjld > div > div.login-content.svelte-jdc7pc > div.content.svelte-jdc7pc > div > div > form > div.footer.svelte-1h6ohe8 > div > button"
    )

    # Wait for network idle or a specific element (replace with your selector)
    await page.wait_for_selector("body >> text=Symbol", state="visible")
    # Adjust selector if needed
    await page.wait_for_timeout(page_data_timeout)
    # Wait for initial data update

    # Get account details
    account_details = await page.inner_html(
        "body > div.layout.svelte-10px9pj > div.bot-panel.svelte-1v6t8g7 > div > div.wrapper.svelte-1kc7mgs > div > div > div.tr.svelte-1efg8dq.inactive.sticky > div:nth-child(1) > div"
    )
    print(
        account_details
    )  # TODO: add name to the list of elements (the account name is located in the menu)

    # Saves screenshot
    await page.screenshot(path="screenshot.png")

    return page


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False
        )  # with desired browser (firefox, webkit)
        context = await browser.new_context(
            # record_video_dir="videos/"
        )  # record_video_dir="videos/" | record_video_size={"width": 640, "height": 480}

        await mt5(context)

        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())

# javascript from the MT5 web app:
# window.lang

# https://stackoverflow.com/questions/71937343/playwright-how-to-wait-until-there-is-no-animation-on-the-page
# https://github.com/microsoft/playwright/issues/15660

# Get list of all elements currently in the browser DOM:
# Goto chrome or any chrome enabled browser
# open devtools and goto console tab
# type document.all and press enter

# https://metaapi.cloud/docs/client/
# https://metaapi.cloud/sdks
# https://metaapi.cloud/docs/client/restApi/api/readTradingTerminalState/readAccountInformation/
# https://github.com/microsoft/playwright/issues/20954
# https://metatraderweb.app/trade

# Get list of all servers available
# https://metatraderweb.app/trade/servers (default is version 4)
# https://metatraderweb.app/trade/servers?version=4
# https://metatraderweb.app/trade/servers?version=5
#
# https://www.mql5.com/en/forum/449944
# https://www.metatrader5.com/en/news/2254
# https://mt5-demo-web.deriv.com/terminal/json
# https://stackoverflow.com/questions/66694130/pure-gui-testing-using-vnc
# https://github.com/cutedriver/cutedriver-driver
# https://rahulkumar1.medium.com/running-automated-test-cases-on-vnc-viewer-using-docker-16656c3d1d87
# https://github.com/novnc/noVNC
