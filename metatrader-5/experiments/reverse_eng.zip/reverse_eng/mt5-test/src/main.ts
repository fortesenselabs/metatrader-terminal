import { fetchTradeServerInfo } from "./lib/tradeServer";
import { WebSocketClient } from "./lib/websocketClient";

async function main() {
  const serverInfo = await fetchTradeServerInfo("terminal/json", "Deriv-Demo", 30565290)

  console.log(serverInfo);

  const wsClient = new WebSocketClient({
    apiKey: serverInfo.key,
    token: serverInfo.token,
    signal_server: serverInfo.signal_server
  }, 0)

  const client = await wsClient.connectToServer()

  console.log("client.readyState: ", client.readyState)
}

main()
.then()
.catch((e) => {
  console.error(e)
});