// // Dc class in 00a24b22.js file
// //
// // 1. **Property Initialization**:
// //    - `this.isReady`, `this.requests`, `this.listeners`, `this.queues`, and `this.systemListeners` are initialized with default values (`false` for `isReady` and new `Map()` instances for the rest).

// // 2. **Count Assignment**:
// //    - `this.count` is set to `0` initially and then reassigned to the value of `t` provided as an argument.

// // 3. **Server Information**:
// //    - `this.server` is assigned the value of `e.signal_server`.

// // 4. **Token Handling**:
// //    - If `e.token` is a string, it's converted into a 64-byte ArrayBuffer using a function (`Oc.setCharString`) and assigned to `this.token`.
// //    - If `e.token` is already an ArrayBuffer, it's directly assigned to `this.token`.

// // 5. **API Key Assignment**:
// //    - `this.apiKey` is assigned the value of `e.apiKey`.

// // 6. **Initialization Reset**:
// //    - `this.reset()` is called, presumably to reset any internal state or configurations.

// // 7. **Binding Event Handlers**:
// //    - Event handler methods (`onMessage`, `onParse`, `onClose`, `onTimeout`, `onError`, `onOpen`) are bound to the current instance of the class (`this`) using `bind(this)`.
// import WebSocket, {ErrorEvent, MessageEvent} from 'ws';
// import { decryptData, en, encryptData, importKeyFromRaw, ro, so, writeStringIntoBuffer } from './utils';
// import { webcrypto } from 'crypto';

// enum ConnectionState {
//   CONNECTING = 0,
//   OPEN = 1,
//   CLOSED = 2,
// }

// interface ServerInfo {
//   signal_server: string;
//   token: string | ArrayBuffer;
//   apiKey: string;
// }

// const Mc = {
//   Close: "close",
//   Error: "error",
//   Open: "open",
//   Reconnect: "reconnect",
// };

// const validCommands = [
//   0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22,
//   23, 24, 25, 27, 28, 29, 30, 33, 34, 37, 38, 39, 40, 41, 42, 43, 44, 50, 51,
// ];

// const validCommandSet = new Set(validCommands);

// class ApiError extends Error {
//   public readonly command: number;
//   public readonly code: number;
//   public readonly count: number;

//   constructor(error: { command: number; code: number; count: number, message?: string }) {
//     super(error.message ?? "");
//     this.command = error.command;
//     this.code = error.code;
//     this.count = error.count;
//   }
// }

// class WebSocketEvent {
//   constructor(public resCode: number, public resBody: ArrayBuffer) {}
// }

// enum WebSocketEventType {
//   Open,
//   Close,
//   Error,
// }

// interface Response {
//   resCode: number;
//   resBody: ArrayBuffer;
// }


// function Xo(e) {
//     return validCommandSet.has(e);
//   }

// export class PendingRequest {
//   private readonly resolve: (data: Response) => void;
//   private readonly reject: (error: ApiError) => void;
//   private readonly timeoutId: number | null;

//   constructor(resolve: (data: Response) => void, reject: (error: ApiError) => void, timeoutId?: number) {
//     this.resolve = resolve;
//     this.reject = reject;
//     this.timeoutId = timeoutId ?? null;
//   }

//   public resolvePromise(data: Response): void {
//     this.resolve(data);
//     if (this.timeoutId) clearTimeout(this.timeoutId);
//   }

//   public rejectPromise(error: ApiError): void {
//     this.reject(error);
//     if (this.timeoutId) clearTimeout(this.timeoutId);
//   }

//   public stopTimeout(): void {
//     if (this.timeoutId) clearTimeout(this.timeoutId);
//   }
// }

// class Pc {
//     private canceled: boolean = false;
//     private timeout?: number;
//     private start: number = 0;
//     private command: any;
//     private buffer: any;
//     private resolve!: (value: any) => void;
//     private reject!: (reason?: any) => void;
//     public promise: Promise<any>;
  
//     constructor(command: any, buffer: any) {
//       this.command = command;
//       this.buffer = buffer;
  
//       this.promise = new Promise<any>((resolve, reject) => {
//         this.resolve = resolve;
//         this.reject = reject;
//       });
  
//       // Attach the request reference to the promise
//       (this.promise as any).request = this;
//     }
  
//     resolvePromise(value: any): void {
//       if (!this.canceled && this.resolve) {
//         this.canceled = true;
//         this.resolve(value);
//         this.stopTimeout();
//       }
//     }
  
//     rejectPromise(reason: any): void {
//       if (!this.canceled && this.reject) {
//         this.canceled = true;
//         this.reject(reason);
//         this.stopTimeout();
//       }
//     }
  
//     onTimeout(callback: (request: Pc) => void): this {
//       this.timeout = setTimeout(() => {
//         callback(this);
//       }, 30000);
//       return this;
//     }
  
//     stopTimeout(): this {
//       if (this.timeout !== undefined) {
//         clearTimeout(this.timeout);
//         this.canceled = true;
//         delete this.timeout;
//         delete this.resolve;
//         delete this.reject;
//       }
//       return this;
//     }
//   }
  

// export class WebSocketClient {
//   public static readonly CloseEvent = "close";
//   public static readonly ErrorEvent = "error";
//   public static readonly OpenEvent = "open";
//   public static readonly ReconnectEvent = "reconnect";

//   private readonly serverInfo: ServerInfo;
//   private webSocket?: WebSocket;
//   private isReady: boolean;
//   private keyPrivate?: webcrypto.CryptoKey;
//   private keyPublic?: webcrypto.CryptoKey;
//   private listeners: Map<number, Set<Function>>;
//   private queues: Map<number, PendingRequest[]>;
//   private requests: Map<number, PendingRequest>;
//   private server: string;
//   private signalServerVersion?: number;
//   private count: number;
//   private token: ArrayBuffer;
//   private apiKey: string;
//   private systemListeners: Map<string, Set<Function>>;
//     reject: (reason?: any) => void;
//     resolve: (value: void | PromiseLike<void>) => void;

//   constructor(serverInfo: ServerInfo, count: number = 0) {
//     this.serverInfo = serverInfo;
//     this.isReady = false;
//     this.count = count;
//     this.server = serverInfo.signal_server;
//     this.token = typeof serverInfo.token === "string" 
//       ? WebSocketClient.createTokenBuffer(serverInfo.token) 
//       : serverInfo.token;
//     this.apiKey = serverInfo.apiKey;
//     this.listeners = new Map();
//     this.queues = new Map();
//     this.requests = new Map();
//     this.systemListeners = new Map();

//     this.initEventHandlers();
//     this.reset();
//   }

//   private static createTokenBuffer(token: string): ArrayBuffer {
//     const buffer = new ArrayBuffer(64);
//     writeStringIntoBuffer(buffer, token, 0);
//     return buffer;
//   }

//   private initEventHandlers(): void {
//     this.onMessage = this.onMessage.bind(this);
//     this.onParse = this.onParse.bind(this);
//     this.onClose = this.onClose.bind(this);
//     this.onTimeout = this.onTimeout.bind(this);
//     this.onError = this.onError.bind(this);
//     this.onOpen = this.onOpen.bind(this);
//   }

//   private reset(): void {
//     this.requests.clear();
//     this.listeners.clear();
//     this.queues.clear();
//     validCommands.forEach(cmd => {
//       const command = Number(cmd);
//       if (!isNaN(command)) {
//         this.listeners.set(command, new Set());
//         this.queues.set(command, []);
//       }
//     });
//   }

//   private systemTrigger(event: string, data: any): void {
//     const listeners = this.systemListeners.get(event);
//     listeners?.forEach(listener => listener(data));
//   }

//   get readyState(): number | undefined {
//     return this.webSocket?.readyState;
//   }

//   getServer(): string {
//     return this.server;
//   }

//   recreateSocket(count: number): WebSocketClient {
//     return new WebSocketClient({ signal_server: this.server, token: this.token, apiKey: this.apiKey }, count);
//   }

//   private onError(error: ErrorEvent): void {
//     this.rejectAllPendingRequests(new ApiError({ code: 104, command: -1, count: this.count }));
//   }

//   private onOpen(): void {
//     this.systemTrigger(Mc.Open, this);
//   }

//   private onMessage(event: MessageEvent): void {
//     const data = event.data.slice(8);
  
//     if (data.toString().length) {
//         decryptData(data, this.keyPublic)
//         .then(en)
//         .then(this.onParse);
//     }
//   }

//   private onParse(): void {}
  
//   private onClose(): void {}

//   private onTimeout(): void {}

//   async connectToServer(): Promise<this> {
//     this.isReady = false;
  
//     await Promise.all([
//     importKeyFromRaw(ro(this.apiKey)).then((keyPublic) => {
//         this.keyPublic = keyPublic;
//       }),
//       importKeyFromRaw(
//         ro(
//           so(
//             "13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75"
//           )
//         )
//       ).then((keyPrivate) => {
//         this.keyPrivate = keyPrivate;
//       }),
//     ]);
  
//     const connectionPromise = new Promise<void>((resolve, reject) => {
//       this.reject = reject;
//       this.resolve = resolve;
//       this.webSocket = new WebSocket(`wss://${this.server}`);
//       this.webSocket.binaryType = "arraybuffer";
  
//       this.webSocket.addEventListener("message", this.onMessage);
//       this.webSocket.addEventListener("close", this.onClose, { once: true });
//       this.webSocket.addEventListener("error", this.onError, { once: true });
//       this.webSocket.addEventListener("open", this.onOpen, { once: true });
//     });
  
//     await connectionPromise;
  
//     const response = await this.sendCommand(0, this.token);
//     this.signalServerVersion = new Uint16Array(response.resBody)[0];
//     this.isReady = true;
  
//     return this;
//   }
  
//   close(forceClose = false): Promise<void> {
//     return new Promise<void>((resolve) => {
//       this.queues.forEach((queue) => {
//         queue.forEach((pendingRequest) => pendingRequest.stopTimeout());
//       });
  
//       this.queues.clear();
  
//       this.requests.forEach((pendingRequest) => {
//         pendingRequest.stopTimeout();
//       });
  
//       this.requests.clear();
  
//       this.webSocket.removeEventListener("message", this.onMessage);
//       this.webSocket.removeEventListener("error", this.onError);
//       this.webSocket.removeEventListener("open", this.onOpen);
  
//       if (forceClose) {
//         this.webSocket.removeEventListener("close", this.onClose);
//         this.onClose();
//         resolve();
//       } else {
//         this.webSocket.addEventListener("close", () => resolve());
//       }
  
//       this.webSocket.close();
//     });
//   }
  

//   async sendCommand(e, t, o = !0, n = !1) {
//     if (!Xo(e)) throw new ApiError({ command: e, code: 102, count: this.count });
//     const r = 0 === e ? this.keyPrivate : this.keyPublic,
//       i = (function (e, t) {
//         const o = new Uint8Array(4 + ((t && t.byteLength) || 0));
//         t && o.set(new Uint8Array(t), 4);
//         const n = new DataView(o.buffer);
//         return (
//           n.setUint8(0, Math.floor(255 * Math.random())),
//           n.setUint8(1, Math.floor(255 * Math.random())),
//           n.setUint16(2, e, !0),
//           o.buffer
//         );
//       })(e, t),
//       s = await encryptData(i, r);
//     try {
//       const t = await this.send(e, s, o, n);
//       if (0 !== t.resCode)
//         throw new ApiError({ command: e, code: t.resCode, count: this.count });
//       return t;
//     } catch (a) {
//       const { command: e, code: t } = a;
//       throw new ApiError({ command: e, code: t, count: this.count });
//     }
//   }

//   send(e, t, o, n) {
//     var r;
//     if (!this.isReady && 0 !== e) {
//       const t = new ApiError({ command: e, code: 103, count: this.count });
//       return this.systemTrigger(Mc.Error, t), Promise.reject(new ApiError(t));
//     }
//     const i = new Pc(
//       e,
//       (function (e) {
//         const t = (e && e.byteLength) || 0,
//           o = new Uint8Array(8 + t);
//         e && o.set(new Uint8Array(e), 8);
//         const n = new DataView(o.buffer);
//         return n.setUint32(0, t, !0), n.setUint32(4, 1, !0), o.buffer;
//       })(t)
//     );
//     if ((o && i.onTimeout(this.onTimeout), n)) {
//       const t = this.queues.get(e);
//       null == t ||
//         t.forEach((t) => {
//           t.rejectPromise(new ApiError({ command: e, code: 1e4, count: this.count }));
//         }),
//         this.queues.set(e, [i]);
//     } else null == (r = this.queues.get(e)) || r.push(i);
//     return this.checkQueue(e), i.promise;
//   }

//   sendRequest(e) {
//     this.requests.set(e.command, e), this.webSocket.send(e.buffer);
//   }
//   checkQueue(e) {
//     const t = this.queues.get(e);
//     if (t && t.length && !this.requests.get(e)) {
//       const e = t.shift();
//       e && this.sendRequest(e);
//     }
//   }

//   private rejectAllPendingRequests(error: ApiError): void {
//     this.requests.forEach(request => request.rejectPromise(error));
//   }
// }






// // class PendingRequest {
//     //   constructor(
//     //     public command: number,
//     //     public buffer: ArrayBuffer,
//     //     public promise: Promise<Response>,
//     //     public rejectPromise: (error: Error) => void
//     //   ) {}
    
//     //   onTimeout(timeoutCallback: (request: PendingRequest) => void) {
//     //     // Implementation
//     //   }

// // }

// //   async init(serverInfo: ServerInfo) {
// //     this.prepareKeys(serverInfo.token, serverInfo.apiKey);
// //     await this.connectToServer(serverInfo.signal_server);
// //   }

// //   async connectToServer(serverUrl: string) {
// //     // Implementation
// //   }

// //   prepareKeys(token: string | ArrayBuffer, apiKey: string) {
// //     // Implementation
// //   }

// //   async sendCommand(
// //     command: number,
// //     data: ArrayBuffer,
// //     isPrivate: boolean = false,
// //     isRetry: boolean = false
// //   ): Promise<Response> {
// //     // Implementation
// //   }

//   // Other methods...