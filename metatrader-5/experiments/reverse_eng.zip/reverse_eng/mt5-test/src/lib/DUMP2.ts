// Dc class in 00a24b22.js file

// 1. **Property Initialization**:
//    - `this.isReady`, `this.requests`, `this.listeners`, `this.queues`, and `this.systemListeners` are initialized with default values (`false` for `isReady` and new `Map()` instances for the rest).

// 2. **Count Assignment**:
//    - `this.count` is set to `0` initially and then reassigned to the value of `t` provided as an argument.

// 3. **Server Information**:
//    - `this.server` is assigned the value of `e.signal_server`.

// 4. **Token Handling**:
//    - If `e.token` is a string, it's converted into a 64-byte ArrayBuffer using a function (`Oc.setCharString`) and assigned to `this.token`.
//    - If `e.token` is already an ArrayBuffer, it's directly assigned to `this.token`.

// 5. **API Key Assignment**:
//    - `this.apiKey` is assigned the value of `e.apiKey`.

// 6. **Initialization Reset**:
//    - `this.reset()` is called, presumably to reset any internal state or configurations.

// 7. **Binding Event Handlers**:
//    - Event handler methods (`onMessage`, `onParse`, `onClose`, `onTimeout`, `onError`, `onOpen`) are bound to the current instance of the class (`this`) using `bind(this)`.

// import WebSocket, { ErrorEvent, MessageEvent } from 'ws';
// import { decodeCustomString, decryptData, encryptData, hexStringToArrayBuffer, importKeyFromRaw, parseResponseBuffer, writeStringIntoBuffer } from './utils';
// import { webcrypto } from 'crypto';

// export enum ConnectionState {
//   CONNECTING = 0,
//   OPEN = 1,
//   CLOSED = 2,
// }

// interface ServerInfo {
//   signal_server: string;
//   token: string | ArrayBuffer;
//   apiKey: string;
// }

// const Mc = {
//   Close: "close",
//   Error: "error",
//   Open: "open",
//   Reconnect: "reconnect",
// };

// const validCommands = [
//   0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22,
//   23, 24, 25, 27, 28, 29, 30, 33, 34, 37, 38, 39, 40, 41, 42, 43, 44, 50, 51,
// ];

// const validCommandSet = new Set(validCommands);

// class ApiError extends Error {
//   public readonly command: number;
//   public readonly code: number;
//   public readonly count: number;

//   constructor(error: { command: number; code: number; count: number, message?: string }) {
//     super(error.message ?? "");
//     this.command = error.command;
//     this.code = error.code;
//     this.count = error.count;
//   }
// }

// export class WebSocketEvent {
//   constructor(public resCode: number, public resBody: ArrayBuffer) {}
// }

// export enum WebSocketEventType {
//   Open,
//   Close,
//   Error,
// }

// interface Response {
//   resCommand?: number;
//   resCode: number;
//   resBody: ArrayBuffer;
// }

// function isValidCommand(e: number): boolean {
//   return validCommandSet.has(e);
// }

// class PendingRequest {
//     private readonly resolve: (data: Response) => void;
//     private readonly reject: (error: ApiError) => void;
//     private readonly timeoutId: number | null;
//     private canceled: boolean = false;
//     public data: ArrayBuffer | null;
//     public command: number | null;
  
//     constructor(resolve: (data: Response) => void, reject: (error: ApiError) => void, timeoutId?: number, data?: ArrayBuffer, command?: number) {
//       this.resolve = resolve;
//       this.reject = reject;
//       this.timeoutId = timeoutId ?? null;
//       this.data = data ?? null;
//       this.command = command ?? null;
//     }
  
//     public resolvePromise(data: Response): void {
//       if (!this.canceled) {
//         this.resolve(data);
//         this.stopTimeout();
//       }
//     }
  
//     public rejectPromise(error: ApiError): void {
//       if (!this.canceled) {
//         this.reject(error);
//         this.stopTimeout();
//       }
//     }
  
//     public stopTimeout(): void {
//       if (this.timeoutId) clearTimeout(this.timeoutId);
//     }
  
//     public cancel(): void {
//       this.canceled = true;
//       this.stopTimeout();
//     }
  
//     public static withTimeout<T>(callback: (request: PendingRequest) => void, timeout = 30000, data?: ArrayBuffer): [Promise<T>, PendingRequest] {
//       let resolve: (value: any) => void;
//       let reject: (reason?: any) => void;
  
//       const promise = new Promise<T>((res, rej) => {
//         resolve = res;
//         reject = rej;
//       });
  
//       const request = new PendingRequest(resolve, reject, setTimeout(() => callback(request), timeout) as unknown as number, data);
//       return [promise, request];
//     }
//   }
  
  

//   export class WebSocketClient {
//     public static readonly CloseEvent = "close";
//     public static readonly ErrorEvent = "error";
//     public static readonly OpenEvent = "open";
//     public static readonly ReconnectEvent = "reconnect";
  
//     private readonly serverInfo: ServerInfo;
//     private webSocket?: WebSocket;
//     private isReady: boolean;
//     private keyPrivate?: webcrypto.CryptoKey;
//     private keyPublic?: webcrypto.CryptoKey;
//     private listeners: Map<number, Set<Function>>;
//     private queues: Map<number, PendingRequest[]>;
//     private requests: Map<number, PendingRequest>;
//     private server: string;
//     private signalServerVersion?: number;
//     private count: number;
//     private token: ArrayBuffer;
//     private apiKey: string;
//     private systemListeners: Map<string, Set<Function>>;
//     private reject!: (reason?: any) => void;
//     private resolve!: (value: void | PromiseLike<void>) => void;
  
//     constructor(serverInfo: ServerInfo, count: number = 0) {
//       this.serverInfo = serverInfo;
//       this.isReady = false;
//       this.count = count;
//       this.server = serverInfo.signal_server;
//       this.token = typeof serverInfo.token === "string" 
//         ? WebSocketClient.createTokenBuffer(serverInfo.token) 
//         : serverInfo.token;
//       this.apiKey = serverInfo.apiKey;
//       this.listeners = new Map();
//       this.queues = new Map();
//       this.requests = new Map();
//       this.systemListeners = new Map();
  
//       this.initEventHandlers();
//       this.reset();
//     }
  
//     private static createTokenBuffer(token: string): ArrayBuffer {
//       const buffer = new ArrayBuffer(64);
//       writeStringIntoBuffer(buffer, token, 0);
//       return buffer;
//     }
  
//     private initEventHandlers(): void {
//       this.onMessage = this.onMessage.bind(this);
//       this.onParse = this.onParse.bind(this);
//       this.onClose = this.onClose.bind(this);
//       this.onTimeout = this.onTimeout.bind(this);
//       this.onError = this.onError.bind(this);
//       this.onOpen = this.onOpen.bind(this);
//     }
  
//     private reset(): void {
//       this.requests.clear();
//       this.listeners.clear();
//       this.queues.clear();
//       validCommands.forEach(cmd => {
//         const command = Number(cmd);
//         if (!isNaN(command)) {
//           this.listeners.set(command, new Set());
//           this.queues.set(command, []);
//         }
//       });
//     }
  
//     private systemTrigger(event: string, data: WebSocketClient | ApiError): void {
//       const listeners = this.systemListeners.get(event);
//       listeners?.forEach(listener => listener(data));
//     }
  
//     get readyState(): number | undefined {
//       return this.webSocket?.readyState;
//     }
  
//     getServer(): string {
//       return this.server;
//     }
  
//     recreateSocket(count: number): WebSocketClient {
//       return new WebSocketClient({ signal_server: this.server, token: this.token, apiKey: this.apiKey }, count);
//     }
  
//     private onError(error: ErrorEvent): void {
//       console.error(error)
//       this.rejectAllPendingRequests(new ApiError({ code: 104, command: -1, count: this.count }));
//     }
  
//     private onOpen(): void {
//       this.systemTrigger(Mc.Open, this);
//     }
  
//     private async onMessage(event: MessageEvent): Promise<void> {
//       const data = event.data.slice(8);
    
//       if (data.toString().length) {
//           try {
//               const decryptedData = await decryptData(data, this.keyPublic);
//               const parsedData = parseResponseBuffer(decryptedData);
//               this.onParse(parsedData);
//           } catch (error) {
//               console.error("Error decrypting or parsing data:", error);
//           }
//       }
//     }
  
//     private onClose(): void {
//       this.systemTrigger(Mc.Close, this);
//       this.reset(); 
//     }
  
//     private onParse(response: Response): void {
//         const { resCommand, resCode, resBody } = response;
    
//         if (resCode > 0) {
//           this.systemTrigger(
//             Mc.Error,
//             new ApiError({ code: resCode, command: resCommand, count: this.count })
//           );
//         }
    
//         const request = this.requests.get(resCommand);
//         if (request) {
//           request.resolvePromise({ resCode, resBody });
//           if (request && request.command !== 8 && isValidCommand(request.command)) {
//             this.requests.delete(resCommand);
//           }
//         }
    
//         this.checkQueue(resCommand);
//         this.trigger(resCommand, { resCode, resBody });
//       }
    
//       private onTimeout(request: PendingRequest): void {
//         request.rejectPromise(
//           new ApiError({ command: request.command, code: 408, count: this.count })
//         );
//         this.requests.delete(request.command);
//         this.checkQueue(request.command);
//       }

//     async connectToServer(): Promise<this> {
//       this.isReady = false;
    
//       await Promise.all([
//         importKeyFromRaw(hexStringToArrayBuffer(this.apiKey)).then((keyPublic) => {
//           this.keyPublic = keyPublic;
//         }),
//         importKeyFromRaw(hexStringToArrayBuffer(decodeCustomString("13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75"))).then((keyPrivate) => {
//           this.keyPrivate = keyPrivate;
//         }),
//       ]);
    
//       const connectionPromise = new Promise<void>((resolve, reject) => {
//         this.reject = reject;
//         this.resolve = resolve;
//         this.webSocket = new WebSocket(`wss://${this.server}`);
//         this.webSocket.binaryType = "arraybuffer";
    
//         this.webSocket.addEventListener("message", this.onMessage);
//         this.webSocket.addEventListener("close", this.onClose, { once: true });
//         this.webSocket.addEventListener("error", this.onError, { once: true });
//         this.webSocket.addEventListener("open", this.onOpen);
//       });
    
//       await connectionPromise;
    
//       const response = await this.sendCommand(0, this.token);
//       this.signalServerVersion = new Uint16Array(response.resBody)[0];
//       this.isReady = true;
    
//       return this;
//     }
    
//     close(forceClose = false): Promise<void> {
//       return new Promise<void>((resolve) => {
//         this.queues.forEach((queue) => {
//           queue.forEach((pendingRequest) => pendingRequest.cancel());
//         });
    
//         this.queues.clear();
    
//         this.requests.forEach((pendingRequest) => {
//           pendingRequest.cancel();
//         });
    
//         this.requests.clear();
    
//         this.webSocket.removeEventListener("message", this.onMessage);
//         this.webSocket.removeEventListener("error", this.onError);
//         this.webSocket.removeEventListener("open", this.onOpen);
    
//         if (forceClose) {
//           this.webSocket.removeEventListener("close", this.onClose);
//           this.onClose();
//           resolve();
//         } else {
//           this.webSocket.addEventListener("close", () => resolve());
//         }
    
//         this.webSocket.close();
//       });
//     }
    
  
//     async sendCommand(e, t, o = true, n = false): Promise<Response> {
//       if (!isValidCommand(e)) throw new ApiError({ command: e, code: 102, count: this.count });
  
//       const key = (e === 0) ? this.keyPrivate : this.keyPublic;
//       const buffer = this.createBuffer(e, t);
//       const encryptedData = await encryptData(buffer, key);
  
//       try {
//         const response = await this.send(e, encryptedData, o, n);
//         if (response.resCode !== 0) {
//           throw new ApiError({ command: e, code: response.resCode, count: this.count });
//         }
//         return response;
//       } catch (error) {
//         const { command, code } = error;
//         throw new ApiError({ command, code, count: this.count });
//       }
//     }
  
//     private createBuffer(command: number, data?: ArrayBuffer): ArrayBuffer {
//       const length = 4 + (data?.byteLength || 0);
//       const buffer = new Uint8Array(length);
//       const view = new DataView(buffer.buffer);
  
//       view.setUint32(0, command, true);
//       if (data) buffer.set(new Uint8Array(data), 4);
  
//       return buffer.buffer;
//     }
  
//     private send(command: number, data: ArrayBuffer, wait: boolean, clearQueue: boolean): Promise<Response> {
//       if (!this.isReady && command !== 0) {
//         const error = new ApiError({ command, code: 103, count: this.count });
//         this.systemTrigger(Mc.Error, error);
//         return Promise.reject(error);
//       }
  
//       const [promise, request] = PendingRequest.withTimeout<Response>(this.onTimeout, 30000, data);
//       this.requests.set(command, request);
      
//       if (clearQueue) {
//         const queue = this.queues.get(command);
//         queue?.forEach(req => req.rejectPromise(new ApiError({ command, code: 10000, count: this.count })));
//         this.queues.set(command, [request]);
//       } else {
//         this.queues.get(command)?.push(request);
//       }
  
//       this.checkQueue(command);
//       this.sendRequest(command, request, data);
  
//       return promise;
//     }
  
//     private sendRequest(command: number, request: PendingRequest, data: ArrayBuffer): void {
//       const packetBuffer = this.createPacketBuffer(data);
//       this.webSocket.send(packetBuffer);
//     //   TODO: fix the resCode in the promise 
//       request.resolvePromise({ resBody: data, resCode: command });
//     }
  
//     private createPacketBuffer(data: ArrayBuffer): ArrayBuffer {
//       const length = data.byteLength;
//       const buffer = new Uint8Array(8 + length);
//       buffer.set(new Uint8Array(data), 8);
//       const view = new DataView(buffer.buffer);
  
//       view.setUint32(0, length, true);
//       view.setUint32(4, 1, true);
  
//       return buffer.buffer;
//     }
  
//     private checkQueue(command: number): void {
//       const queue = this.queues.get(command);
//       if (queue && queue.length && !this.requests.get(command)) {
//         const request = queue.shift();
//         if (request) {
//           this.sendRequest(command, request, request.data!);
//         }
//       }
//     }

//     private trigger(e, t) {
//         const o = this.listeners.get(e);
//         return (
//           o &&
//             o.forEach((e) => {
//               e.call(this, t);
//             }),
//           this
//         );
//       }
  
//     private rejectAllPendingRequests(error: ApiError): void {
//       this.requests.forEach(request => request.rejectPromise(error));
//     }
//   }
  
// function encryptData2(data: ArrayBuffer, key: crypto.webcrypto.CryptoKey): Promise<ArrayBuffer> {
//   const cipher = crypto.createCipheriv(algorithmName, key, new Uint8Array(blockSize));
//   return new Promise((resolve, reject) => {
//     cipher.on('error', reject);
//     cipher.on('readable', () => {
//       const encrypted = cipher.read();
//       if (encrypted) {
//         resolve(encrypted);
//       }
//     });
//     cipher.push(data);
//     cipher.end();
//   });
// }

// function decryptData(
//   encryptedData: string | ArrayBuffer | Buffer | Buffer[],
//   key: crypto.webcrypto.CryptoKey
// ): Promise<ArrayBuffer> {
//   const decipher = crypto.createDecipheriv(algorithmName, key, new Uint8Array(blockSize));
//   return new Promise((resolve, reject) => {
//     decipher.on('error', reject);
//     decipher.on('readable', () => {
//       const decrypted = decipher.read();
//       if (decrypted) {
//         resolve(decrypted);
//       }
//     });
//     decipher.push(encryptedData);
//     decipher.end();
//   });
// }