import * as crypto from 'crypto';

const blockSize = 16;
const algorithmName: string = "AES-CBC";

interface Account {
  account_type: number;
}

interface EncryptedData {
  real?: boolean;
  countries: string[];
}

// type AesCbcParams = {
//   name: string;
//   iv: Uint8Array;
// };

function countAccountsOfType(accounts: Account[], type: number): number {
  const hasType = accounts.some((account) => account.account_type === type);
  const hasOtherType = accounts.some(
    (account) => account.account_type !== type
  );
  return hasType && !hasOtherType ? 1 : !hasType && hasOtherType ? 0 : -1;
}

function filterAccountsByType(
  accounts: Account[],
  type: number,
  include: boolean
): Account[] {
  return countAccountsOfType(accounts, type) !== -1
    ? accounts
    : accounts.filter((account) =>
        include ? isOfType(account) : !isOfType(account)
      );
}

function isOfType(account: Account): boolean {
  return account.account_type === 2;
}

function filterAccountsByRealStatus(
  accounts: EncryptedData[],
  isReal: boolean,
  country?: string
): EncryptedData[] {
  return accounts.filter((account) => {
    const matchesRealStatus = Boolean(account.real) === isReal;
    return country && account.countries.length
      ? matchesRealStatus && account.countries.includes(country)
      : matchesRealStatus;
  });
}

function hexStringToBuffer(hexString: string): ArrayBuffer {
  const byteArray: number[] = [];
  for (let i = 0; i < hexString.length / 2; i++) {
    byteArray.push(Number(`0x${hexString.substring(2 * i, 2 * i + 2)}`));
  }
  return new Uint8Array(byteArray).buffer;
}

function bufferToHexString(buffer: ArrayBuffer): string {
  const hexArray: string[] = [];
  const dataView = new DataView(buffer);
  for (let i = 0; i < buffer.byteLength; i++) {
    let hex: string = dataView.getUint8(i).toString(16);
    hex.length < 2 && (hex = ["0", hex].join(""));
    hexArray.push(hex);
  }
  return hexArray.join("");
}

async function importKeyFromRaw(rawKey: ArrayBuffer): Promise<crypto.webcrypto.CryptoKey> {
  if (!crypto.subtle) throw new Error("Error initializing crypto API (Node.js doesn't have subtle)");
  const algorithm = { name: algorithmName };
  return crypto.subtle.importKey("raw", rawKey, algorithm, true, [
    "encrypt",
    "decrypt",
  ]);
}

function encryptData(data: ArrayBuffer, key: crypto.webcrypto.CryptoKey): Promise<ArrayBuffer> {
  const o = { name: algorithmName, iv: new Uint8Array(blockSize) };
  return crypto.webcrypto.subtle.encrypt(o, key, data) 
}

function decryptData(
  encryptedData: ArrayBuffer,
  key: crypto.webcrypto.CryptoKey
): Promise<ArrayBuffer> {
  const o = { name: algorithmName, iv: new Uint8Array(blockSize) };
  return crypto.webcrypto.subtle.decrypt(o, key, encryptedData) 
}

function setStringToBuffer(buffer, str = "", startIndex = 0) {
    // Ensure the buffer is provided
    if (!buffer) return;
  
    // Create a DataView for the buffer
    const dataView = new DataView(buffer);
  
    // Loop through each character in the string
    for (let charIndex = 0; charIndex < str.length; charIndex++) {
      // Get the UTF-16 code of the current character
      const charCode = str.charCodeAt(charIndex);
  
      // Write the UTF-16 code into the buffer at the specified index
      dataView.setInt8(startIndex, charCode);
  
      // Move to the next index in the buffer
      startIndex += 1;
    }
  }
  
  function decodeUtf8FromArrayBuffer(buffer, startIndex = 0, length = 0) {
    // Slice the portion of the buffer specified by startIndex and length
    const slicedBuffer = buffer.slice(startIndex, startIndex + length);
  
    // Create a Uint8Array from the sliced buffer
    const uint8Array = new Uint8Array(slicedBuffer);
  
    // Convert the Uint8Array to a string using UTF-8 decoding
    const decodedString = String.fromCharCode(...uint8Array);
  
    // Return the decoded string
    return decodedString;
  }
  
  function writeStringIntoBuffer(buffer: ArrayBuffer, stringToWrite: string, offset: number = 0): void {
    if (!buffer || !stringToWrite) return; // Early return if either argument is missing
  
    const dataView = new DataView(buffer);
    for (let i = 0; i < stringToWrite.length; i++) {
      dataView.setInt8(offset + i, stringToWrite.charCodeAt(i));
    }
  }

  export function hexStringToArrayBuffer(hexString: string): ArrayBuffer {
    const byteArray = new Uint8Array(hexString.length / 2);
  
    for (let i = 0; i < hexString.length; i += 2) {
      byteArray[i / 2] = parseInt(hexString.substr(i, 2), 16);
    }
  
    return byteArray.buffer;
  }
  
  export function decodeCustomString(input: string): string {
    const result: string[] = [];
  
    for (let i = 0; i < input.length; i++) {
      const charCode = input.charCodeAt(i);
  
      if (charCode === 28) {
        result.push("&");
      } else if (charCode === 23) {
        result.push("!");
      } else {
        result.push(String.fromCharCode(charCode - 1));
      }
    }
  
    return result.join("");
  }
  

  interface ParsedResponse {
    resCommand: number;
    resCode: number;
    resBody: ArrayBuffer;
  }
  
export function parseResponseBuffer(buffer: ArrayBuffer): ParsedResponse {
  const dataView = new DataView(buffer);

  return {
    resCommand: dataView.getUint16(2, true), // true for little-endian
    resCode: dataView.getUint8(4),
    resBody: buffer.slice(5),
  };
}



  
// Remove or adapt generateUniqueIdentifier for Node.js backend

export {
  importKeyFromRaw,
  encryptData,
  decryptData,
  bufferToHexString,
  countAccountsOfType,
  filterAccountsByType,
  isOfType,
  filterAccountsByRealStatus,
  hexStringToBuffer,
  setStringToBuffer,
  decodeUtf8FromArrayBuffer,
  writeStringIntoBuffer
}